import { motion, useScroll, useTransform } from "motion/react";
import { Button } from "../ui/button";
import { ArrowRight, Check, Star } from "lucide-react";
import { useRef } from "react";

export function LandingPage() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.8]);
  const y = useTransform(scrollYProgress, [0, 1], [0, -100]);

  const features = [
    {
      icon: "📚",
      title: "Проверенные советы",
      description: "Экспертный контент от педиатров и специалистов по уходу за детьми",
    },
    {
      icon: "✓",
      title: "Умные чеклисты",
      description: "Организуйте покупки и задачи, ничего не забывайте",
    },
    {
      icon: "💬",
      title: "Поддержка сообщества",
      description: "Общайтесь с другими родителями в безопасной среде",
    },
    {
      icon: "📊",
      title: "Трекер развития",
      description: "Отслеживайте сон, кормление и здоровье малыша",
    },
  ];

  const stats = [
    { value: "10K+", label: "Родителей доверяют нам" },
    { value: "500+", label: "Полезных статей" },
    { value: "4.9", label: "Рейтинг в App Store" },
  ];

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Header */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-xl border-b border-border/50"
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary/10 rounded-2xl flex items-center justify-center">
                <span className="text-2xl">👶</span>
              </div>
              <span className="text-2xl font-medium text-foreground">Семья</span>
            </div>

            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Возможности
              </a>
              <a href="#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                О приложении
              </a>
              <a href="#reviews" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Отзывы
              </a>
            </nav>

            <Button className="rounded-full h-11 px-6 bg-primary text-primary-foreground hover:bg-primary/90">
              Скачать
            </Button>
          </div>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center pt-20">
        {/* Background Effects */}
        <div className="absolute inset-0 -z-10 overflow-hidden">
          <motion.div
            style={{ opacity, scale }}
            className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl"
          />
          <motion.div
            style={{ opacity, scale }}
            className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl"
          />
        </div>

        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Left Content */}
            <motion.div
              style={{ y }}
              className="space-y-8"
            >
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium"
              >
                <Star className="w-4 h-4 fill-primary" />
                Рейтинг 4.9 в App Store
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="space-y-6"
              >
                <h1 className="text-5xl lg:text-7xl font-medium text-foreground leading-tight tracking-tight">
                  Спокойная опора для родителей
                </h1>
                <p className="text-xl text-muted-foreground leading-relaxed max-w-xl">
                  Современное приложение для родителей, которое помогает уверенно заботиться о малыше без стресса и перегрузки
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="flex items-center gap-4"
              >
                <Button size="lg" className="rounded-full h-14 px-8 bg-primary text-primary-foreground hover:bg-primary/90 group">
                  Начать бесплатно
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
                <Button size="lg" variant="outline" className="rounded-full h-14 px-8 border-2">
                  Узнать больше
                </Button>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="flex items-center gap-8 pt-4"
              >
                {stats.map((stat, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="text-3xl font-medium text-foreground">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </div>
                ))}
              </motion.div>
            </motion.div>

            {/* Right Visual - Phone Mockup */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="relative"
            >
              <motion.div
                animate={{
                  y: [0, -20, 0],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="relative z-10"
              >
                <div className="w-[300px] h-[600px] mx-auto bg-gradient-to-br from-card to-secondary rounded-[3rem] p-3 shadow-2xl border border-border/50">
                  <div className="w-full h-full bg-background rounded-[2.5rem] overflow-hidden">
                    <div className="p-6 space-y-6">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Добрый день!</div>
                          <div className="text-lg font-medium">Анна</div>
                        </div>
                        <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                          <span className="text-2xl">👶</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        {[
                          { icon: "🩺", label: "Срочный вопрос", color: "bg-destructive" },
                          { icon: "🛒", label: "Что купить", color: "bg-primary" },
                          { icon: "📚", label: "Советы", color: "bg-accent" },
                          { icon: "⏰", label: "Режим дня", color: "bg-[#A4B5A8]" },
                        ].map((item, idx) => (
                          <div key={idx} className="bg-card border border-border rounded-2xl p-4 space-y-2">
                            <div className={`w-10 h-10 ${item.color} rounded-xl flex items-center justify-center text-xl`}>
                              {item.icon}
                            </div>
                            <div className="text-xs font-medium">{item.label}</div>
                          </div>
                        ))}
                      </div>

                      <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-4 border border-primary/20">
                        <div className="flex items-start gap-3">
                          <div className="text-2xl">💡</div>
                          <div className="space-y-1">
                            <div className="text-sm font-medium">Совет дня</div>
                            <div className="text-xs text-muted-foreground">Контакт кожа к коже помогает малышу...</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Floating Elements */}
              <motion.div
                animate={{
                  y: [0, -15, 0],
                  rotate: [0, 5, 0],
                }}
                transition={{
                  duration: 5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute -top-8 -left-8 w-24 h-24 bg-primary/10 rounded-3xl backdrop-blur-sm border border-primary/20 flex items-center justify-center text-4xl shadow-xl"
              >
                🍼
              </motion.div>

              <motion.div
                animate={{
                  y: [0, 15, 0],
                  rotate: [0, -5, 0],
                }}
                transition={{
                  duration: 7,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute -bottom-8 -right-8 w-28 h-28 bg-accent/10 rounded-3xl backdrop-blur-sm border border-accent/20 flex items-center justify-center text-4xl shadow-xl"
              >
                💤
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-32 relative">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h2 className="text-4xl lg:text-5xl font-medium text-foreground mb-6">
              Всё необходимое в одном приложении
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Практичные инструменты и проверенная информация для уверенного родительства
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="group"
              >
                <div className="bg-card border border-border rounded-3xl p-8 h-full hover:border-primary/30 transition-all">
                  <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-4xl mb-6 group-hover:scale-110 transition-transform">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-medium text-foreground mb-3">{feature.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5" />
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <h2 className="text-4xl lg:text-5xl font-medium text-foreground">
              Начните заботиться о малыше с уверенностью
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Присоединяйтесь к тысячам родителей, которые уже используют Семья
            </p>
            <div className="flex items-center justify-center gap-4">
              <Button size="lg" className="rounded-full h-14 px-8 bg-primary text-primary-foreground hover:bg-primary/90">
                Скачать бесплатно
              </Button>
            </div>
            <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-primary" />
                Бесплатно навсегда
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-primary" />
                Без рекламы
              </div>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-primary" />
                Защита данных
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary/10 rounded-2xl flex items-center justify-center">
                <span className="text-2xl">👶</span>
              </div>
              <span className="text-xl font-medium text-foreground">Семья</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © 2026 Семья. Все права защищены.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

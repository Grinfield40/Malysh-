import { ChevronLeft, Clock, Bookmark, Share2 } from "lucide-react";
import { Button } from "../ui/button";

interface ArticleScreenProps {
  onBack: () => void;
}

export function ArticleScreen({ onBack }: ArticleScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 flex items-center gap-4 bg-card border-b border-border">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <div className="flex-1" />
        <button className="p-2">
          <Bookmark className="w-5 h-5 text-foreground" />
        </button>
        <button className="p-2">
          <Share2 className="w-5 h-5 text-foreground" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="px-6 py-6">
          <div className="text-xs text-primary font-medium mb-3">Здоровье</div>
          <h1 className="text-3xl font-medium text-foreground mb-4">
            Когда обращаться к врачу
          </h1>
          <div className="flex items-center gap-3 text-sm text-muted-foreground mb-6">
            <Clock className="w-4 h-4" />
            <span>5 минут чтения</span>
          </div>

          <div className="w-full h-48 rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 flex items-center justify-center mb-6">
            <span className="text-6xl">🩺</span>
          </div>

          <div className="prose prose-sm max-w-none space-y-4 text-foreground/80 leading-relaxed">
            <p>
              Первые месяцы жизни малыша — время, когда родители часто волнуются о здоровье ребенка. Важно знать, в каких ситуациях стоит немедленно обратиться к врачу, а когда можно подождать.
            </p>

            <div className="bg-accent/20 border-l-4 border-accent rounded-r-xl p-4 my-6">
              <h3 className="font-medium text-foreground mb-2">⚠️ Срочно к врачу</h3>
              <p className="text-sm">
                Если у ребенка высокая температура (выше 38°C для детей до 3 месяцев), затрудненное дыхание или необычная вялость — немедленно обратитесь к врачу.
              </p>
            </div>

            <h2 className="text-xl font-medium text-foreground mt-6 mb-3">
              Тревожные симптомы
            </h2>

            <ul className="space-y-2 list-disc list-inside text-foreground/80">
              <li>Температура выше 38°C у детей до 3 месяцев</li>
              <li>Отказ от еды более 8 часов</li>
              <li>Постоянный плач более 3 часов</li>
              <li>Сыпь с температурой</li>
              <li>Рвота или диарея более 6 раз в день</li>
            </ul>

            <h2 className="text-xl font-medium text-foreground mt-6 mb-3">
              Когда можно подождать
            </h2>

            <p>
              Не все симптомы требуют немедленного визита к врачу. Небольшой насморк, редкое чихание или легкое беспокойство могут быть нормой. Наблюдайте за состоянием ребенка и при усилении симптомов консультируйтесь с педиатром.
            </p>

            <div className="bg-primary/10 rounded-xl p-4 my-6">
              <h3 className="font-medium text-foreground mb-2">💡 Совет</h3>
              <p className="text-sm text-foreground/80">
                Ведите дневник самочувствия: температуру, кормления и общее состояние. Так будет проще спокойно рассказать врачу, что происходило.
              </p>
            </div>

            <h2 className="text-xl font-medium text-foreground mt-6 mb-3">
              Доверяйте себе
            </h2>

            <p>
              Родительская интуиция — мощный инструмент. Если вам кажется, что с ребенком что-то не так, даже при отсутствии явных симптомов, лучше проконсультироваться с врачом. Это нормально и правильно.
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-border">
            <h3 className="text-base font-medium mb-4">Похожие статьи</h3>
            <div className="space-y-3">
              {[
                { title: "Первая аптечка для малыша", category: "Покупки", emoji: "💊" },
                { title: "Что нормально, а что нет", category: "Здоровье", emoji: "✅" },
              ].map((article, idx) => (
                <div
                  key={idx}
                  className="rounded-xl bg-card border border-border p-4 flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                    {article.emoji}
                  </div>
                  <div className="flex-1">
                    <div className="text-xs text-primary font-medium mb-1">{article.category}</div>
                    <h4 className="text-sm font-medium text-foreground">{article.title}</h4>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

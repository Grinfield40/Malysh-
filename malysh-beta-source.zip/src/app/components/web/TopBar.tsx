import { motion } from "motion/react";
import { Search, Bell } from "lucide-react";
import { Input } from "../ui/input";
import { Logo } from "../Logo";
import { NotificationsPanel } from "./NotificationsPanel";
import { ThemeToggle } from "../ThemeToggle";
import { useState } from "react";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";

interface TopBarProps {
  onProfileClick: () => void;
  onNavigate: (screen: string) => void;
}

export function TopBar({ onProfileClick, onNavigate }: TopBarProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { baby, age } = useBabyProfile();
  const [profile] = useUserProfile();
  const userInitial = (profile.name?.trim() || "Р").charAt(0).toUpperCase();

  return (
    <>
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 right-0 left-0 md:left-[280px] h-16 md:h-20 bg-card/80 backdrop-blur-xl border-b border-border/50 z-30 px-4 md:px-8"
    >
      <div className="h-full flex items-center justify-between max-w-[1400px]">
        {/* Mobile Logo */}
        <div className="md:hidden flex items-center gap-2">
          <Logo size={32} />
          <span className="text-lg font-medium text-foreground">Малыш+</span>
        </div>

        {/* Baby Context & Search */}
        <div className="hidden md:flex items-center gap-4">
          {/* Baby Info */}
          <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border border-primary/10">
            <div className="text-lg">{baby.emoji}</div>
            <div>
              <div className="text-xs font-semibold text-foreground leading-tight">{baby.name}</div>
              <div className="text-[10px] text-muted-foreground leading-tight">{age.label}</div>
            </div>
          </div>

          {/* Search */}
          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (searchQuery.trim()) {
                try {
                  window.localStorage.setItem("mvp.home.lastSearch", JSON.stringify(searchQuery.trim()));
                } catch {
                  // Search should keep working even if persistence is unavailable.
                }
              }
              onNavigate("tips");
            }}
            className="relative w-80"
          >
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="Поиск..."
              className="h-11 pl-12 rounded-2xl bg-background border-border"
            />
          </form>
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-2 md:gap-4">
          {/* Search Icon Mobile */}
          <motion.button
            type="button"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate("tips")}
            className="hidden sm:flex md:hidden w-10 h-10 rounded-xl bg-secondary hover:bg-primary/10 transition-colors items-center justify-center"
            aria-label="Открыть поиск"
          >
            <Search className="w-5 h-5 text-foreground" />
          </motion.button>

          {/* Theme Toggle */}
          <ThemeToggle />

          {/* Notifications */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setNotificationsOpen(true)}
            className="relative w-10 h-10 md:w-11 md:h-11 rounded-xl md:rounded-2xl bg-secondary hover:bg-primary/10 transition-colors flex items-center justify-center"
          >
            <Bell className="w-5 h-5 text-foreground" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
          </motion.button>

          {/* Profile */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onProfileClick}
            className="flex items-center gap-2 md:gap-3 px-2 md:px-3 py-2 rounded-xl md:rounded-2xl hover:bg-secondary/60 transition-all"
          >
            <div className="w-8 h-8 md:w-9 md:h-9 bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg md:rounded-xl flex items-center justify-center text-xl">
              {userInitial}
            </div>
            <div className="hidden lg:block text-left">
              <div className="text-sm font-semibold text-foreground leading-tight">{profile.name || "Родитель"}</div>
              <div className="text-xs text-muted-foreground leading-tight">{profile.role ?? "Родитель"}</div>
            </div>
          </motion.button>
        </div>
      </div>
    </motion.div>

      {/* Notifications Panel */}
      <NotificationsPanel isOpen={notificationsOpen} onClose={() => setNotificationsOpen(false)} />
    </>
  );
}

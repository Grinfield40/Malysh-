import { Clock, Plus } from "lucide-react";
import { Button } from "../ui/button";

const routineItems = [
  { id: 1, time: "07:00", activity: "Пробуждение", icon: "☀️", duration: "30 мин" },
  { id: 2, time: "07:30", activity: "Кормление", icon: "🍼", duration: "20 мин" },
  { id: 3, time: "08:00", activity: "Бодрствование", icon: "🎵", duration: "1 час" },
  { id: 4, time: "09:00", activity: "Утренний сон", icon: "💤", duration: "1.5 часа" },
  { id: 5, time: "10:30", activity: "Кормление", icon: "🍼", duration: "20 мин" },
  { id: 6, time: "11:00", activity: "Прогулка", icon: "🌳", duration: "2 часа" },
  { id: 7, time: "13:00", activity: "Кормление", icon: "🍼", duration: "20 мин" },
  { id: 8, time: "13:30", activity: "Дневной сон", icon: "🌙", duration: "2 часа" },
  { id: 9, time: "15:30", activity: "Бодрствование", icon: "🧸", duration: "1 час" },
  { id: 10, time: "16:30", activity: "Кормление", icon: "🍼", duration: "20 мин" },
];

export function RoutinesScreen() {
  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-6 bg-gradient-to-b from-secondary/50 to-transparent sticky top-0 z-10 backdrop-blur-sm">
        <h1 className="text-2xl font-medium text-foreground mb-2">Режим дня</h1>
        <p className="text-sm text-muted-foreground">Примерный график на сегодня</p>
      </div>

      <div className="px-6">
        <div className="relative">
          <div className="absolute left-[22px] top-0 bottom-0 w-px bg-border"></div>

          <div className="space-y-4">
            {routineItems.map((item, idx) => (
              <div key={item.id} className="relative flex gap-4">
                <div className="flex flex-col items-center gap-1 w-12 flex-shrink-0">
                  <div className="text-xs text-muted-foreground font-medium">{item.time}</div>
                  <div className="w-10 h-10 rounded-xl bg-card border-2 border-primary/20 flex items-center justify-center text-xl z-10">
                    {item.icon}
                  </div>
                </div>

                <div className="flex-1 pb-2">
                  <div className="rounded-xl bg-card border border-border p-4 hover:border-primary/30 transition-all">
                    <div className="flex items-start justify-between mb-1">
                      <h3 className="font-medium text-foreground">{item.activity}</h3>
                      <span className="text-xs text-muted-foreground">{item.duration}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="fixed bottom-24 right-6">
        <Button
          size="lg"
          className="h-14 w-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}

import { ChevronLeft, MessageSquare, Send } from "lucide-react";
import { Input } from "../ui/input";
import { Avatar, AvatarFallback } from "../ui/avatar";

interface ForumPostScreenProps {
  onBack: () => void;
}

const comments = [
  {
    id: 1,
    author: "Ирина Д.",
    avatar: "ИД",
    time: "10 мин назад",
    text: "У нас была такая же ситуация! Помогло пеленание и белый шум. Попробуйте включать фен или специальное приложение.",
  },
  {
    id: 2,
    author: "Наталья П.",
    avatar: "НП",
    time: "25 мин назад",
    text: "Это абсолютно нормально в таком возрасте. У малышей циклы сна короткие, и они пока не умеют засыпать самостоятельно.",
  },
  {
    id: 3,
    author: "Юлия К.",
    avatar: "ЮК",
    time: "40 мин назад",
    text: "Нам педиатр советовала не перегревать комнату и следить за влажностью. Купили увлажнитель — стало намного лучше!",
  },
];

export function ForumPostScreen({ onBack }: ForumPostScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 flex items-center gap-4 bg-card border-b border-border">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
        <h2 className="text-lg font-medium text-foreground flex-1">Обсуждение</h2>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="px-6 py-6 bg-card border-b border-border">
          <div className="flex items-start gap-3 mb-4">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-primary/10 text-primary">АМ</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium text-foreground">Анна М.</span>
                <span className="text-xs text-muted-foreground">15 мин назад</span>
              </div>
              <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full">
                Сон
              </span>
            </div>
          </div>

          <h1 className="text-xl font-medium text-foreground mb-3">
            Малыш плохо спит ночью
          </h1>

          <p className="text-foreground/80 leading-relaxed mb-4">
            Добрый день! Ребенку 2 месяца, и он просыпается каждые 2 часа ночью. Днем спит нормально, по 1,5-2 часа несколько раз. Ночью же просыпается, плачет, успокаивается только на руках.
          </p>

          <p className="text-foreground/80 leading-relaxed mb-4">
            Это нормально для такого возраста? Или стоит что-то менять в режиме? Очень устала, уже не знаю что делать.
          </p>

          <div className="flex items-center gap-1 text-sm text-muted-foreground">
            <MessageSquare className="w-4 h-4" />
            <span>{comments.length} ответа</span>
          </div>
        </div>

        <div className="px-6 py-4">
          <h3 className="text-sm font-medium text-muted-foreground mb-4">Ответы</h3>
          <div className="space-y-4">
            {comments.map((comment) => (
              <div key={comment.id} className="flex gap-3">
                <Avatar className="w-9 h-9 flex-shrink-0">
                  <AvatarFallback className="bg-secondary text-secondary-foreground text-xs">
                    {comment.avatar}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium text-foreground">{comment.author}</span>
                    <span className="text-xs text-muted-foreground">{comment.time}</span>
                  </div>
                  <p className="text-sm text-foreground/80 leading-relaxed">{comment.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="px-6 py-4 bg-card border-t border-border">
        <div className="flex items-center gap-3">
          <Avatar className="w-9 h-9">
            <AvatarFallback className="bg-primary/10 text-primary text-xs">Вы</AvatarFallback>
          </Avatar>
          <Input
            placeholder="Написать ответ..."
            className="flex-1 h-10 rounded-xl bg-background border-border"
          />
          <button className="p-2 text-primary">
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

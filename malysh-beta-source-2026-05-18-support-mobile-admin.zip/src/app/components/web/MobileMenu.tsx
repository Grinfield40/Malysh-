import { motion, AnimatePresence } from "motion/react";
import { X, Home, ShoppingBag, BookOpen, User, Clock, Activity, Bell, Bookmark, Baby, Heart, Image, ShieldCheck, MessageCircle } from "lucide-react";
import { Logo } from "../Logo";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

const menuSections = [
  {
    title: "Основное",
    items: [
      { id: "home", icon: Home, label: "Главная" },
      { id: "growth-timeline", icon: Baby, label: "Развитие малыша" },
      { id: "recommendations", icon: Heart, label: "Мамы одобряют" },
    ],
  },
  {
    title: "Ежедневно",
    items: [
      { id: "fridge", icon: Image, label: "Холодильник" },
      { id: "routines", icon: Clock, label: "Режим дня" },
      { id: "tracker", icon: Activity, label: "Трекер" },
      { id: "reminders", icon: Bell, label: "Напоминания" },
    ],
  },
  {
    title: "Подготовка",
    items: [
      { id: "shopping", icon: ShoppingBag, label: "Покупки" },
    ],
  },
  {
    title: "Контент",
    items: [
      { id: "tips", icon: BookOpen, label: "Советы" },
      { id: "forum", icon: MessageCircle, label: "Форум" },
    ],
  },
  {
    title: "Прочее",
    items: [
      { id: "saved", icon: Bookmark, label: "Сохраненное" },
      { id: "profile", icon: User, label: "Профиль" },
      { id: "privacy", icon: ShieldCheck, label: "Приватность" },
    ],
  },
];

export function MobileMenu({ isOpen, onClose, activeScreen, onNavigate }: MobileMenuProps) {
  const [profile] = useUserProfile();
  const { baby, age } = useBabyProfile();
  const userInitial = (profile.name?.trim() || "Р").charAt(0).toUpperCase();
  const sections = profile.role === "Администратор"
    ? menuSections.map((section) =>
        section.title === "Прочее"
          ? {
              ...section,
              items: [
                { id: "admin", icon: ShieldCheck, label: "Админка" },
                ...section.items,
              ],
            }
          : section
      )
    : menuSections;

  const handleNavigate = (screen: string) => {
    onNavigate(screen);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="md:hidden fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="absolute right-0 top-0 bottom-0 w-[85%] max-w-sm bg-gradient-to-br from-background to-primary/5 shadow-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="sticky top-0 z-10 bg-gradient-to-br from-primary to-accent p-6 border-b-2 border-white/20">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-all"
              >
                <X className="w-6 h-6 text-white" />
              </button>

              <div className="flex items-center gap-4 mb-6">
                <Logo size={48} />
                <div>
                  <h2 className="text-2xl font-bold text-white">Малыш+</h2>
                  <p className="text-sm text-white/80">Меню</p>
                </div>
              </div>

              {/* User Info */}
              <div className="bg-white/20 backdrop-blur-sm rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white/30 rounded-full flex items-center justify-center text-2xl">
                    {userInitial}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-white/80">{profile.name || "Родитель"}</div>
                    <div className="text-xs text-white/60">{baby.name}, {age.label}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="p-4 space-y-6">
              {sections.map((section, sectionIdx) => (
                <div key={section.title}>
                  {/* Section Title */}
                  <div className="px-3 mb-3">
                    <h3 className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-wider">
                      {section.title}
                    </h3>
                  </div>

                  {/* Section Items */}
                  <div className="space-y-1">
                    {section.items.map((item, itemIdx) => {
                      const Icon = item.icon;
                      const isActive = activeScreen === item.id;

                      return (
                        <motion.button
                          key={item.id}
                          initial={{ opacity: 0, x: 50 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: sectionIdx * 0.1 + itemIdx * 0.03 }}
                          whileTap={{ scale: 0.97 }}
                          onClick={() => handleNavigate(item.id)}
                          className={`w-full flex items-center gap-4 p-3 rounded-xl transition-all relative ${
                            isActive
                              ? "bg-primary/10"
                              : "hover:bg-primary/5"
                          }`}
                        >
                          {/* Active Indicator Line */}
                          {isActive && (
                            <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-r-full" />
                          )}

                          <div
                            className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                              isActive
                                ? "text-primary"
                                : "text-muted-foreground/70"
                            }`}
                          >
                            <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
                          </div>
                          <div className="flex-1 text-left">
                            <div
                              className={`text-sm ${
                                isActive ? "font-semibold text-primary" : "font-medium text-foreground"
                              }`}
                            >
                              {item.label}
                            </div>
                          </div>
                          {isActive && (
                            <div className="w-2 h-2 bg-primary rounded-full" />
                          )}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Premium CTA */}
            <div className="px-4 pb-4">
              <motion.button
                onClick={() => {
                  handleNavigate("subscription");
                }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-gradient-to-r from-primary to-accent text-white rounded-2xl p-4 hover:shadow-lg transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
                    <span className="text-2xl">👑</span>
                  </div>
                  <div className="text-left flex-1">
                    <div className="text-sm font-semibold">Премиум</div>
                    <div className="text-xs text-white/80">Получить 7 дней бесплатно</div>
                  </div>
                </div>
              </motion.button>
            </div>

            {/* Footer */}
            <div className="px-6 pb-6 border-t-2 border-primary/10 pt-6">
              <div className="text-center text-sm text-muted-foreground">
                <div className="mb-2">Версия 1.0.0</div>
                <div className="text-xs">© 2026 Малыш+</div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

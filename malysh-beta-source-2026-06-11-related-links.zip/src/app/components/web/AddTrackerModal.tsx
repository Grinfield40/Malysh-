import { motion, AnimatePresence } from "motion/react";
import { X, Milk, Moon, Baby, Thermometer, Scale, Ruler, Pill, StickyNote } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";

interface AddTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (entry: TrackerEntry) => void;
  defaultDate?: string;
  initialType?: TrackerEntry["type"] | null;
}

export interface TrackerEntry {
  type: "feeding" | "sleep" | "diaper" | "temperature" | "weight" | "height" | "medicine" | "note";
  time: string;
  date: string;
  details: Record<string, any>;
}

const trackerTypes = [
  { id: "feeding", label: "Кормление", icon: Milk, color: "from-blue-200/40 to-cyan-200/40" },
  { id: "sleep", label: "Сон", icon: Moon, color: "from-purple-200/40 to-indigo-200/40" },
  { id: "diaper", label: "Подгузник", icon: Baby, color: "from-yellow-200/40 to-orange-200/40" },
  { id: "temperature", label: "Температура", icon: Thermometer, color: "from-red-200/40 to-pink-200/40" },
  { id: "weight", label: "Вес", icon: Scale, color: "from-green-200/40 to-emerald-200/40" },
  { id: "height", label: "Рост", icon: Ruler, color: "from-teal-200/40 to-cyan-200/40" },
  { id: "medicine", label: "Лекарства", icon: Pill, color: "from-pink-200/40 to-purple-200/40" },
  { id: "note", label: "Заметка", icon: StickyNote, color: "from-slate-200/50 to-zinc-200/50" },
] as const;

export function AddTrackerModal({ isOpen, onClose, onAdd, defaultDate, initialType = null }: AddTrackerModalProps) {
  const [selectedType, setSelectedType] = useState<typeof trackerTypes[number]["id"] | null>(null);
  const [time, setTime] = useState("");
  const [date, setDate] = useState("");

  // Feeding details
  const [feedingType, setFeedingType] = useState<"breast" | "bottle" | "solid">("breast");
  const [amount, setAmount] = useState("");
  const [duration, setDuration] = useState("");
  const [side, setSide] = useState<"left" | "right" | "both">("left");

  // Sleep details
  const [sleepDuration, setSleepDuration] = useState("");
  const [sleepQuality, setSleepQuality] = useState<"good" | "normal" | "poor">("normal");

  // Diaper details
  const [diaperType, setDiaperType] = useState<"wet" | "dirty" | "both">("wet");

  // Temperature
  const [temperature, setTemperature] = useState("");

  // Weight/Height
  const [measurement, setMeasurement] = useState("");

  // Medicine
  const [medicineName, setMedicineName] = useState("");
  const [medicineDose, setMedicineDose] = useState("");

  // Free note
  const [noteText, setNoteText] = useState("");
  const trimmedNoteText = noteText.trim();
  const trimmedTemperature = temperature.trim();
  const trimmedMeasurement = measurement.trim();
  const trimmedMedicineName = medicineName.trim();
  const validationMessage = !selectedType
    ? "Выберите тип записи."
    : !date
    ? "Выберите дату записи."
    : !time
    ? "Выберите время записи."
    : selectedType === "note" && !trimmedNoteText
    ? "Добавьте текст заметки."
    : selectedType === "temperature" && !trimmedTemperature
    ? "Укажите температуру."
    : (selectedType === "weight" || selectedType === "height") && !trimmedMeasurement
    ? "Укажите значение измерения."
    : selectedType === "medicine" && !trimmedMedicineName
    ? "Укажите название лекарства."
    : "";
  const shouldShowValidation = Boolean(validationMessage && selectedType);

  useEffect(() => {
    if (!isOpen) return;

    const now = new Date();
    const currentDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;

    setSelectedType(initialType);
    setDate(defaultDate || currentDate);
    setTime(currentTime);
    setAmount("");
    setDuration("");
    setTemperature("");
    setMeasurement("");
    setMedicineName("");
    setMedicineDose("");
    setNoteText("");
  }, [defaultDate, initialType, isOpen]);

  const handleSubmit = () => {
    if (validationMessage || !selectedType) return;

    let details = {};

    if (selectedType === "feeding") {
      details = { type: feedingType, amount, duration, side };
    } else if (selectedType === "sleep") {
      details = { duration: sleepDuration, quality: sleepQuality };
    } else if (selectedType === "diaper") {
      details = { type: diaperType };
    } else if (selectedType === "temperature") {
      details = { value: trimmedTemperature };
    } else if (selectedType === "weight" || selectedType === "height") {
      details = { value: trimmedMeasurement };
    } else if (selectedType === "medicine") {
      details = { name: trimmedMedicineName, dose: medicineDose.trim() };
    } else if (selectedType === "note") {
      details = { text: trimmedNoteText };
    }

    onAdd({
      type: selectedType,
      time,
      date,
      details,
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setSelectedType(null);
    setTime("");
    setDate("");
    setAmount("");
    setDuration("");
    setTemperature("");
    setMeasurement("");
    setMedicineName("");
    setMedicineDose("");
    setNoteText("");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <h2 className="text-2xl font-medium text-foreground">Добавить запись</h2>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6">
              {/* Step 1: Select Type */}
              {!selectedType ? (
                <div>
                  <p className="text-muted-foreground mb-6">Выберите, что хотите записать:</p>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {trackerTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <motion.button
                          key={type.id}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => setSelectedType(type.id)}
                          className={`bg-gradient-to-br ${type.color} border-2 border-white/50 rounded-2xl p-6 hover:shadow-xl transition-all`}
                        >
                          <Icon className="w-10 h-10 text-primary mx-auto mb-3" />
                          <div className="text-sm font-medium text-foreground">{type.label}</div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Back button */}
                  <button
                    onClick={() => setSelectedType(null)}
                    className="text-sm text-primary hover:underline"
                  >
                    ← Назад к выбору типа
                  </button>

                  {/* Date & Time */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Дата</label>
                      <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-xl" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Время</label>
                      <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="rounded-xl" required />
                    </div>
                  </div>

                  {/* Feeding specific */}
                  {selectedType === "feeding" && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-3">Тип кормления</label>
                        <div className="flex gap-2">
                          {[
                            { value: "breast", label: "Грудь" },
                            { value: "bottle", label: "Бутылочка" },
                            { value: "solid", label: "Прикорм" },
                          ].map((option) => (
                            <button
                              key={option.value}
                              onClick={() => setFeedingType(option.value as any)}
                              className={`flex-1 py-2 px-4 rounded-xl border-2 transition-all ${
                                feedingType === option.value
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-secondary border-border hover:border-primary/30"
                              }`}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>

                      {feedingType === "breast" && (
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-3">Сторона</label>
                          <div className="flex gap-2">
                            {[
                              { value: "left", label: "Левая" },
                              { value: "right", label: "Правая" },
                              { value: "both", label: "Обе" },
                            ].map((option) => (
                              <button
                                key={option.value}
                                onClick={() => setSide(option.value as any)}
                                className={`flex-1 py-2 px-4 rounded-xl border-2 transition-all ${
                                  side === option.value
                                    ? "bg-primary text-primary-foreground border-primary"
                                    : "bg-secondary border-border hover:border-primary/30"
                                }`}
                              >
                                {option.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="grid md:grid-cols-2 gap-4">
                        {feedingType === "bottle" || feedingType === "solid" ? (
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">
                              Количество {feedingType === "bottle" ? "(мл)" : "(г)"}
                            </label>
                            <Input
                              type="number"
                              value={amount}
                              onChange={(e) => setAmount(e.target.value)}
                              placeholder="150"
                              className="rounded-xl"
                            />
                          </div>
                        ) : (
                          <div>
                            <label className="block text-sm font-medium text-foreground mb-2">Длительность (мин)</label>
                            <Input
                              type="number"
                              value={duration}
                              onChange={(e) => setDuration(e.target.value)}
                              placeholder="15"
                              className="rounded-xl"
                            />
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {/* Sleep specific */}
                  {selectedType === "sleep" && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Длительность (минут)</label>
                        <Input
                          type="number"
                          value={sleepDuration}
                          onChange={(e) => setSleepDuration(e.target.value)}
                          placeholder="90"
                          className="rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-3">Качество сна</label>
                        <div className="flex gap-2">
                          {[
                            { value: "good", label: "Хорошо" },
                            { value: "normal", label: "Нормально" },
                            { value: "poor", label: "Плохо" },
                          ].map((option) => (
                            <button
                              key={option.value}
                              onClick={() => setSleepQuality(option.value as any)}
                              className={`flex-1 py-2 px-4 rounded-xl border-2 transition-all ${
                                sleepQuality === option.value
                                  ? "bg-primary text-primary-foreground border-primary"
                                  : "bg-secondary border-border hover:border-primary/30"
                              }`}
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  {/* Diaper specific */}
                  {selectedType === "diaper" && (
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-3">Тип</label>
                      <div className="flex gap-2">
                        {[
                          { value: "wet", label: "Мокрый" },
                          { value: "dirty", label: "Грязный" },
                          { value: "both", label: "Оба" },
                        ].map((option) => (
                          <button
                            key={option.value}
                            onClick={() => setDiaperType(option.value as any)}
                            className={`flex-1 py-2 px-4 rounded-xl border-2 transition-all ${
                              diaperType === option.value
                                ? "bg-primary text-primary-foreground border-primary"
                                : "bg-secondary border-border hover:border-primary/30"
                            }`}
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Temperature */}
                  {selectedType === "temperature" && (
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Температура (°C)</label>
                      <Input
                        type="number"
                        step="0.1"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                        placeholder="36.6"
                        className="rounded-xl"
                      />
                    </div>
                  )}

                  {/* Weight/Height */}
                  {(selectedType === "weight" || selectedType === "height") && (
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        {selectedType === "weight" ? "Вес (кг)" : "Рост (см)"}
                      </label>
                      <Input
                        type="number"
                        step="0.1"
                        value={measurement}
                        onChange={(e) => setMeasurement(e.target.value)}
                        placeholder={selectedType === "weight" ? "3.5" : "52"}
                        className="rounded-xl"
                      />
                    </div>
                  )}

                  {/* Medicine */}
                  {selectedType === "medicine" && (
                    <>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Название лекарства</label>
                        <Input
                          value={medicineName}
                          onChange={(e) => setMedicineName(e.target.value)}
                          placeholder="Например: Парацетамол"
                          className="rounded-xl"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">Дозировка</label>
                        <Input
                          value={medicineDose}
                          onChange={(e) => setMedicineDose(e.target.value)}
                          placeholder="Например: 5 мл"
                          className="rounded-xl"
                        />
                      </div>
                    </>
                  )}

                  {/* Note */}
                  {selectedType === "note" && (
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">Что важно запомнить?</label>
                      <Textarea
                        value={noteText}
                        onChange={(e) => setNoteText(e.target.value)}
                        placeholder="Например: после кормления долго икал, уснул на руках, настроение спокойное"
                        className="min-h-28 rounded-xl resize-none"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer */}
            {selectedType && (
              <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
                {shouldShowValidation ? (
                  <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                    {validationMessage}
                  </div>
                ) : null}
                <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                  Отмена
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={Boolean(validationMessage)}
                  className="flex-1 rounded-xl"
                >
                  Добавить запись
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { Moon, Sun } from "lucide-react";
import { useEffect, useState } from "react";
import { motion } from "motion/react";

interface ThemeToggleProps {
  compact?: boolean;
}

export function ThemeToggle({ compact = false }: ThemeToggleProps) {
  const [isDark, setIsDark] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("theme");
      return saved === "dark";
    }
    return false;
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [isDark]);

  if (compact) {
    return (
      <motion.button
        onClick={() => setIsDark(!isDark)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className={`relative rounded-full transition-all ${
          isDark ? "bg-primary/20" : "bg-secondary"
        } flex items-center p-1 w-14 h-7`}
        title={isDark ? "Светлая тема" : "Темная тема"}
      >
        <motion.div
          animate={{
            x: isDark ? 28 : 0,
          }}
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
          className={`w-5 h-5 rounded-full flex items-center justify-center ${
            isDark ? "bg-primary" : "bg-card border border-border"
          }`}
        >
          {isDark ? (
            <Moon className="w-3 h-3 text-primary-foreground" />
          ) : (
            <Sun className="w-3 h-3 text-primary" />
          )}
        </motion.div>
      </motion.button>
    );
  }

  return (
    <motion.button
      onClick={() => setIsDark(!isDark)}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-card border border-border hover:border-primary/30 transition-all flex items-center justify-center"
      title={isDark ? "Светлая тема" : "Темная тема"}
    >
      <motion.div
        initial={false}
        animate={{
          rotate: isDark ? 360 : 0,
          scale: isDark ? 0 : 1,
          opacity: isDark ? 0 : 1,
        }}
        transition={{ duration: 0.3 }}
        className="absolute"
      >
        <Sun className="w-5 h-5 text-primary" />
      </motion.div>
      <motion.div
        initial={false}
        animate={{
          rotate: isDark ? 0 : -360,
          scale: isDark ? 1 : 0,
          opacity: isDark ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="absolute"
      >
        <Moon className="w-5 h-5 text-primary" />
      </motion.div>
    </motion.button>
  );
}

import { mkdir, readdir, stat, unlink, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
loadEnvFile(join(__dirname, "..", ".env"));

const dataDir = process.env.MALYSH_DATA_DIR || join(__dirname, "data");
const dbFile = process.env.MALYSH_DB_FILE || join(dataDir, "app.db");
const backupDir = process.env.MALYSH_BACKUP_DIR || join(__dirname, "backups");
const keepBackups = Number(process.env.MALYSH_BACKUP_KEEP || 14);

await mkdir(backupDir, { recursive: true });
const sourceInfo = await stat(dbFile);

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const target = join(backupDir, `app-${stamp}.db`);
const manifestTarget = join(backupDir, `app-${stamp}.json`);
const db = new DatabaseSync(dbFile);

db.prepare("VACUUM INTO ?").run(target);
db.close();

const backupInfo = await stat(target);
const manifest = {
  createdAt: new Date().toISOString(),
  source: dbFile,
  target,
  sourceSizeBytes: sourceInfo.size,
  backupSizeBytes: backupInfo.size,
};

await writeFile(manifestTarget, JSON.stringify(manifest, null, 2), "utf8");
await pruneOldBackups();

console.log(`Backup created: ${target}`);

async function pruneOldBackups() {
  if (!Number.isFinite(keepBackups) || keepBackups <= 0) return;

  const backupFiles = (await readdir(backupDir))
    .filter((fileName) => fileName.endsWith(".db"))
    .map(async (fileName) => ({
      fileName,
      info: await stat(join(backupDir, fileName)),
    }));
  const files = await Promise.all(backupFiles);
  const oldFiles = files
    .sort((a, b) => b.info.mtime.getTime() - a.info.mtime.getTime())
    .slice(keepBackups);

  await Promise.all(
    oldFiles.flatMap((file) => [
      unlink(join(backupDir, file.fileName)).catch(() => undefined),
      unlink(join(backupDir, file.fileName.replace(/\.db$/, ".json"))).catch(() => undefined),
    ])
  );
}

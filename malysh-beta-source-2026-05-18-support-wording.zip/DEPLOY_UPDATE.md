# Обновление beta-сайта

Короткий маршрут для обычных правок после первого запуска VPS.

## Что не трогаем при обновлении

- База пользователей и действий: `/var/lib/malysh/app.db`.
- Backup базы: `/var/backups/malysh`.
- Production-настройки: `/opt/malysh/.env`.
- Cloudflare Tunnel и домен не пересоздаются.

## Локально

Из папки проекта:

```powershell
cd C:\Users\aleks\Documents\Codex\2026-05-12\new-chat\design-from-code
npm.cmd run beta:launch
npm.cmd run release:zip
```

После этого появится архив:

```text
C:\Users\aleks\Documents\Codex\2026-05-12\new-chat\malysh-beta-source.zip
```

Его нужно заменить в GitHub-репозитории `Grinfield40/Malysh-`.

## На VPS

После замены архива в GitHub открыть консоль сервера и вставить:

```bash
cd /opt/malysh
bash deploy/scripts/vps-update-release.sh
```

Что делает скрипт:

- скачивает свежий zip из GitHub;
- проверяет сборку во временной папке;
- делает backup базы;
- сохраняет rollback старого кода;
- обновляет код в `/opt/malysh`;
- сохраняет `.env`;
- перезапускает `malysh`;
- проверяет `/api/health`.

## Если на сервере еще нет нового скрипта

Первый раз можно запустить старую команду:

```bash
cd /opt/malysh
bash deploy/scripts/vps-update-release.sh.example
```

После этого в следующих обновлениях уже используем короткую команду с `vps-update-release.sh`.

## Проверка после обновления

Открыть:

```text
https://beta.malyshplus.ru
```

Минимум проверить:

- вход и регистрация;
- главная;
- дневник;
- режим;
- форум;
- холодильник;
- админка;
- метрики.

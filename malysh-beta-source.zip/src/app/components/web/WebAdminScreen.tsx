import { motion } from "motion/react";
import {
  Activity,
  Archive,
  Baby,
  BarChart3,
  CheckCircle2,
  Clock,
  Copy,
  Database,
  Download,
  Eye,
  EyeOff,
  Flag,
  HardDrive,
  LogOut,
  MessageSquare,
  NotebookText,
  Plus,
  Power,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Trash2,
  UserCheck,
  UserX,
  Users,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "../ui/button";
import { ConfirmActionDialog } from "./ConfirmActionDialog";
import {
  AdminBetaInvite,
  AdminOverview,
  AdminUser,
  createAdminBackup,
  createAdminInvite,
  deleteAdminUser,
  ForumContentStatus,
  ForumReportStatus,
  getAdminExport,
  getAdminOverview,
  getStoredSession,
  moderateForumComment,
  moderateForumPost,
  moderateForumReport,
  resetAdminUserSessions,
  updateAdminUserStatus,
  updateAdminInvite,
} from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess } from "../../lib/notify";

const stageLabels: Record<string, string> = {
  pregnancy: "Беременность",
  "0-3": "0-3 месяца",
  "3-6": "3-6 месяцев",
  "6-12": "6-12 месяцев",
};

const goalLabels: Record<string, string> = {
  sleep: "Сон",
  feeding: "Кормление",
  shopping: "Покупки",
  anxiety: "Тревоги",
  development: "Развитие",
};

const forumStatusLabels: Record<string, string> = {
  published: "Опубликовано",
  hidden: "Скрыто",
  deleted: "Удалено",
};

const forumReportStatusLabels: Record<string, string> = {
  open: "Открыта",
  reviewed: "Проверена",
  dismissed: "Отклонена",
};

type AdminUserActionKind = "block" | "unblock" | "resetSessions" | "delete";

interface AdminUserAction {
  kind: AdminUserActionKind;
  userId: string;
  userName: string;
  userEmail: string;
  title: string;
  description: string;
  confirmLabel: string;
  destructive?: boolean;
  requiredText?: string;
  requiredTextLabel?: string;
  requiredTextPlaceholder?: string;
}

function formatDateTime(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "—";

  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatDate(value?: string | null) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return value;

  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(date);
}

function formatBytes(bytes: number) {
  if (!bytes) return "0 Б";

  const units = ["Б", "КБ", "МБ", "ГБ"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  const value = bytes / 1024 ** index;

  return `${value.toFixed(value >= 10 || index === 0 ? 0 : 1)} ${units[index]}`;
}

function formatDuration(milliseconds?: number) {
  if (!milliseconds) return "0 сек";

  const seconds = Math.round(milliseconds / 1000);

  if (seconds < 60) return `${seconds} сек`;

  const minutes = Math.floor(seconds / 60);
  const restSeconds = seconds % 60;

  return restSeconds > 0 ? `${minutes} мин ${restSeconds} сек` : `${minutes} мин`;
}

function getRegistrationModeLabel(mode: string) {
  if (mode === "closed") return "Закрытая beta";
  if (mode === "disabled") return "Регистрация выключена";
  if (mode === "open") return "Открытая регистрация";
  return mode;
}

function getBooleanStatus(value: boolean, enabled = "Включено", disabled = "Выключено") {
  return value ? enabled : disabled;
}

const screenLabels: Record<string, string> = {
  home: "Главная",
  tracker: "Дневник",
  routines: "Режим",
  forum: "Форум",
  reminders: "Напоминания",
  recommendations: "Мамы одобряют",
  fridge: "Холодильник",
  shopping: "Покупки",
  profile: "Профиль",
  admin: "Админка",
};

const activityLabels: Record<string, string> = {
  "auth.register": "Регистрация",
  "auth.login": "Вход в аккаунт",
  "auth.register.failed": "Ошибка регистрации",
  "auth.login.failed": "Ошибка входа",
  "storage.patch": "Изменение данных",
  "storage.replace": "Синхронизация данных",
  "forum.post.create": "Пост на форуме",
  "forum.comment.create": "Ответ на форуме",
  "forum.report.create": "Жалоба на форуме",
  screen_view: "Открыл раздел",
  screen_time: "Время в разделе",
};

const analyticsActionLabels: Record<string, string> = {
  auth_register: "Регистрация",
  auth_login: "Вход",
  auth_logout: "Выход",
  onboarding_completed: "Онбординг завершен",
  tracker_entry_added: "Запись в дневнике",
  tracker_entry_edited: "Редактирование дневника",
  tracker_entry_deleted: "Удаление записи",
  routine_item_added: "Пункт режима",
  forum_post_created: "Пост на форуме",
  forum_post_opened: "Открытие поста",
  forum_comment_created: "Ответ на форуме",
  forum_report_created: "Жалоба на форуме",
  fridge_image_uploaded: "Загрузка в холодильник",
  fridge_image_removed: "Удаление фото",
  fridge_upload_rejected: "Ошибка загрузки фото",
  shopping_item_added: "Покупка добавлена",
  shopping_item_toggled: "Покупка отмечена",
  app_error: "Ошибка приложения",
  admin_backup_created: "Backup создан",
  admin_export_downloaded: "Export скачан",
  admin_user_action: "Действие администратора",
};

function labelScreen(screen?: string) {
  return screen ? screenLabels[screen] || screen : "без раздела";
}

function labelAnalyticsAction(action: string) {
  return analyticsActionLabels[action] || activityLabels[action] || action;
}

function labelActivity(action: string, screen?: string) {
  const base = activityLabels[action] || action;

  if ((action === "screen_view" || action === "screen_time") && screen) {
    return `${base}: ${labelScreen(screen)}`;
  }

  return base;
}

function getActivityTone(kind?: string) {
  const tones: Record<string, string> = {
    registration: "bg-emerald-400",
    login: "bg-sky-400",
    forum: "bg-violet-400",
    data: "bg-amber-400",
    fridge: "bg-pink-400",
    screen: "bg-slate-300",
    admin: "bg-rose-400",
    error: "bg-destructive",
  };

  return tones[kind || ""] || "bg-primary/50";
}

function getActivityTitle(event: AdminUser["recentActivity"][number]) {
  return event.title || labelActivity(event.label, event.screen);
}

function getActivityDescription(event: AdminUser["recentActivity"][number]) {
  if (event.kind === "screen" && event.screen) {
    return `Раздел: ${labelScreen(event.screen)}.`;
  }

  return event.description || "";
}

function labelGoal(goal: string) {
  return goalLabels[goal] ?? goal;
}

function getStageLabel(stage?: string) {
  return stage ? stageLabels[stage] ?? stage : "Не указан";
}

function getUserInitials(user: AdminUser) {
  return user.name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function WebAdminScreen() {
  const [overview, setOverview] = useState<AdminOverview | null>(null);
  const [selectedUserId, setSelectedUserId] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [moderatingId, setModeratingId] = useState("");
  const [inviteLabel, setInviteLabel] = useState("");
  const [inviteMaxUses, setInviteMaxUses] = useState(1);
  const [isCreatingInvite, setIsCreatingInvite] = useState(false);
  const [inviteActionId, setInviteActionId] = useState("");
  const [confirmUserAction, setConfirmUserAction] = useState<AdminUserAction | null>(null);
  const [isUserActionBusy, setIsUserActionBusy] = useState(false);

  const loadOverview = async () => {
    const session = getStoredSession();

    if (!session) {
      setError("Нужно войти в аккаунт администратора.");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError("");

    try {
      const nextOverview = await getAdminOverview(session.token);
      setOverview(nextOverview);
      setSelectedUserId((currentId) =>
        currentId && nextOverview.users.some((user) => user.id === currentId)
          ? currentId
          : nextOverview.users[0]?.id ?? ""
      );
    } catch (adminError) {
      setError(adminError instanceof Error ? adminError.message : "Не удалось загрузить админ-панель.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadOverview();
  }, []);

  const selectedUser = useMemo(
    () => overview?.users.find((user) => user.id === selectedUserId) ?? overview?.users[0] ?? null,
    [overview, selectedUserId]
  );
  const currentUserId = getStoredSession()?.user.id ?? "";

  const stats = overview
    ? [
        { label: "Пользователей", value: overview.stats.users, icon: Users },
        { label: "Активных сессий", value: overview.stats.sessions, icon: Activity },
        { label: "Записей дневника", value: overview.stats.diaryEntries, icon: NotebookText },
        { label: "Покупок в списках", value: overview.stats.shoppingItems, icon: ShoppingBag },
        { label: "Постов форума", value: overview.stats.forumPosts, icon: MessageSquare },
        { label: "Ответов форума", value: overview.stats.forumComments, icon: MessageSquare },
        { label: "Жалоб форума", value: overview.stats.forumReports, icon: Flag },
        { label: "Режимов", value: overview.stats.routines, icon: Clock },
        { label: "Холодильник", value: overview.stats.fridgeItems, icon: CheckCircle2 },
        { label: "Ключей данных", value: overview.stats.storageKeys, icon: Database },
        { label: "Бэкапов", value: overview.stats.backups, icon: Archive },
        { label: "Событий метрик", value: overview.stats.analyticsEvents, icon: BarChart3 },
      ]
    : [];

  const handleBackup = async () => {
    const session = getStoredSession();

    if (!session) return;

    setIsBackingUp(true);
    setError("");
    setNotice("");

    try {
      const result = await createAdminBackup(session.token);
      trackEvent("admin_backup_created", {
        screen: "admin",
        meta: {
          sizeBytes: result.backup.sizeBytes,
        },
      });
      setNotice(`Бэкап создан: ${result.backup.fileName}`);
      notifySuccess("Backup создан", {
        description: result.backup.fileName,
      });
      await loadOverview();
    } catch (backupError) {
      const message = backupError instanceof Error ? backupError.message : "Не удалось создать бэкап.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setIsBackingUp(false);
    }
  };

  const handleInviteCreate = async () => {
    const session = getStoredSession();

    if (!session) return;

    setIsCreatingInvite(true);
    setError("");
    setNotice("");

    try {
      const result = await createAdminInvite(session.token, {
        label: inviteLabel.trim() || undefined,
        maxUses: inviteMaxUses,
      });

      setNotice(`Beta-инвайт создан: ${result.invite.code}`);
      notifySuccess("Beta-инвайт создан", {
        description: result.invite.code,
      });
      setInviteLabel("");
      setInviteMaxUses(1);
      void navigator.clipboard?.writeText(result.invite.code).catch(() => undefined);
      await loadOverview();
    } catch (inviteError) {
      const message = inviteError instanceof Error ? inviteError.message : "Не удалось создать beta-инвайт.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setIsCreatingInvite(false);
    }
  };

  const handleInviteCopy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      notifySuccess("Код скопирован", { description: code });
    } catch {
      setNotice(`Код: ${code}`);
    }
  };

  const handleInviteActive = async (inviteId: string, active: boolean) => {
    const session = getStoredSession();

    if (!session) return;

    setInviteActionId(inviteId);
    setError("");
    setNotice("");

    try {
      await updateAdminInvite(session.token, inviteId, { active });
      notifySuccess(active ? "Beta-инвайт включен" : "Beta-инвайт отключен");
      await loadOverview();
    } catch (inviteError) {
      const message = inviteError instanceof Error ? inviteError.message : "Не удалось обновить beta-инвайт.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setInviteActionId("");
    }
  };

  const askUserAction = (kind: AdminUserActionKind, user: AdminUser) => {
    if (kind === "delete" && (!user.blockedAt || user.activeSessions > 0)) {
      const message = !user.blockedAt
        ? "Безопасный режим: сначала заблокируйте пользователя."
        : "Безопасный режим: перед удалением нужно сбросить активные сессии.";

      notifyError(new Error(message));
      return;
    }

    const actionText = {
      block: {
        title: "Заблокировать пользователя?",
        description: `${user.name} не сможет войти, а активные сессии будут сброшены.`,
        confirmLabel: "Заблокировать",
        destructive: true,
      },
      unblock: {
        title: "Разблокировать пользователя?",
        description: `${user.name} снова сможет войти в аккаунт.`,
        confirmLabel: "Разблокировать",
        destructive: false,
      },
      resetSessions: {
        title: "Сбросить активные сессии?",
        description: `${user.name} выйдет из аккаунта на всех устройствах и войдет заново по паролю.`,
        confirmLabel: "Сбросить сессии",
        destructive: false,
      },
      delete: {
        title: "Удалить тестовый аккаунт?",
        description: `Аккаунт ${user.email} уже заблокирован, активных сессий нет. Это жесткое удаление личных данных; форумные материалы останутся без автора, чтобы не ломать обсуждения.`,
        confirmLabel: "Удалить аккаунт",
        destructive: true,
        requiredText: user.email,
        requiredTextLabel: "Для подтверждения введите email пользователя",
        requiredTextPlaceholder: user.email,
      },
    }[kind];

    setConfirmUserAction({
      kind,
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      ...actionText,
    });
  };

  const handleConfirmUserAction = async () => {
    const session = getStoredSession();
    const action = confirmUserAction;

    if (!session || !action) return;

    setIsUserActionBusy(true);
    setError("");
    setNotice("");

    try {
      if (action.kind === "block") {
        await updateAdminUserStatus(session.token, action.userId, true);
        notifySuccess("Пользователь заблокирован", { description: action.userEmail });
      } else if (action.kind === "unblock") {
        await updateAdminUserStatus(session.token, action.userId, false);
        notifySuccess("Пользователь разблокирован", { description: action.userEmail });
      } else if (action.kind === "resetSessions") {
        const result = await resetAdminUserSessions(session.token, action.userId);
        notifySuccess("Сессии сброшены", { description: `${result.sessionsDeleted} активных сессий` });
      } else {
        await deleteAdminUser(session.token, action.userId, action.userEmail);
        notifySuccess("Тестовый аккаунт удален", { description: action.userEmail });
      }

      trackEvent("admin_user_action", {
        screen: "admin",
        meta: {
          action: action.kind,
          userId: action.userId,
        },
      });
      setConfirmUserAction(null);
      await loadOverview();
    } catch (userActionError) {
      const message = userActionError instanceof Error ? userActionError.message : "Не удалось выполнить действие.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setIsUserActionBusy(false);
    }
  };

  const handleExport = async () => {
    const session = getStoredSession();

    if (!session) return;

    setIsExporting(true);
    setError("");
    setNotice("");

    try {
      const exportData = await getAdminExport(session.token);
      const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: "application/json;charset=utf-8",
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = url;
      link.download = `malysh-export-${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      window.URL.revokeObjectURL(url);
      trackEvent("admin_export_downloaded", {
        screen: "admin",
        meta: {
          users: exportData.users.length,
        },
      });
      setNotice("Экспорт подготовлен и загружен.");
      notifySuccess("Экспорт подготовлен", {
        description: "JSON-файл загружен на компьютер.",
      });
      await loadOverview();
    } catch (exportError) {
      const message = exportError instanceof Error ? exportError.message : "Не удалось подготовить экспорт.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setIsExporting(false);
    }
  };

  const handleForumPostStatus = async (postId: string, status: ForumContentStatus) => {
    const session = getStoredSession();

    if (!session) return;

    setModeratingId(`post:${postId}:${status}`);
    setError("");
    setNotice("");

    try {
      await moderateForumPost(session.token, postId, status);
      trackEvent("admin_forum_post_moderated", {
        screen: "admin",
        meta: { postId, status },
      });
      setNotice("Статус поста обновлён.");
      notifySuccess("Статус поста обновлён");
      await loadOverview();
    } catch (moderationError) {
      const message = moderationError instanceof Error ? moderationError.message : "Не удалось обновить пост.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setModeratingId("");
    }
  };

  const handleForumCommentStatus = async (commentId: string, status: ForumContentStatus) => {
    const session = getStoredSession();

    if (!session) return;

    setModeratingId(`comment:${commentId}:${status}`);
    setError("");
    setNotice("");

    try {
      await moderateForumComment(session.token, commentId, status);
      trackEvent("admin_forum_comment_moderated", {
        screen: "admin",
        meta: { commentId, status },
      });
      setNotice("Статус ответа обновлён.");
      notifySuccess("Статус ответа обновлён");
      await loadOverview();
    } catch (moderationError) {
      const message = moderationError instanceof Error ? moderationError.message : "Не удалось обновить ответ.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setModeratingId("");
    }
  };

  const handleForumReportStatus = async (reportId: string, status: ForumReportStatus) => {
    const session = getStoredSession();

    if (!session) return;

    setModeratingId(`report:${reportId}:${status}`);
    setError("");
    setNotice("");

    try {
      await moderateForumReport(session.token, reportId, status);
      trackEvent("admin_forum_report_moderated", {
        screen: "admin",
        meta: { reportId, status },
      });
      setNotice("Жалоба обновлена.");
      notifySuccess("Жалоба обновлена");
      await loadOverview();
    } catch (moderationError) {
      const message = moderationError instanceof Error ? moderationError.message : "Не удалось обновить жалобу.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setModeratingId("");
    }
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1440px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col xl:flex-row xl:items-start xl:justify-between gap-4 mb-6 md:mb-8"
      >
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary mb-3">
            <ShieldCheck className="w-4 h-4" />
            SQLite-панель владельца
          </div>
          <h1 className="text-3xl md:text-4xl font-medium text-foreground mb-2">Админ-панель</h1>
          <p className="text-base md:text-lg text-muted-foreground max-w-3xl">
            Пользователи, профили детей, последние записи, активность сервера, экспорт данных и резервные копии базы.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={handleExport} disabled={isLoading || isExporting} variant="outline" className="rounded-xl">
            <Download className="w-4 h-4" />
            {isExporting ? "Готовим..." : "Экспорт JSON"}
          </Button>
          <Button onClick={handleBackup} disabled={isLoading || isBackingUp} variant="outline" className="rounded-xl">
            <Archive className="w-4 h-4" />
            {isBackingUp ? "Создаем..." : "Backup"}
          </Button>
          <Button onClick={loadOverview} disabled={isLoading} className="rounded-xl">
            <RefreshCw className="w-4 h-4" />
            Обновить
          </Button>
        </div>
      </motion.div>

      {notice ? (
        <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}

      {error ? (
        <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-5 text-destructive">
          {error}
        </div>
      ) : isLoading ? (
        <div className="bg-card border border-border rounded-xl p-8 text-muted-foreground">
          Загружаем админ-панель...
        </div>
      ) : overview ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
            {stats.map((stat) => {
              const Icon = stat.icon;

              return (
                <div key={stat.label} className="bg-card border border-border rounded-xl p-4 md:p-5">
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <span className="text-sm text-muted-foreground">{stat.label}</span>
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-2xl md:text-3xl font-medium text-foreground">{stat.value}</div>
                </div>
              );
            })}
          </div>

          <section className="bg-card border border-border rounded-xl p-4 md:p-6">
            <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-5">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  <h2 className="text-xl font-medium text-foreground">Готовность beta</h2>
                </div>
                <p className="text-sm text-muted-foreground">
                  Быстрая проверка доступа, домена, логов и лимитов перед закрытым тестом.
                </p>
              </div>
              <div className={`rounded-full px-3 py-1 text-xs font-medium ${
                overview.config.registrationMode === "closed" && overview.config.inviteConfigured
                  ? "bg-emerald-50 text-emerald-700 border border-emerald-200"
                  : "bg-amber-50 text-amber-800 border border-amber-200"
              }`}>
                {overview.config.registrationMode === "closed" && overview.config.inviteConfigured
                  ? "К закрытой beta готово"
                  : "Нужно проверить доступ"}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
              <div className="rounded-xl bg-secondary/60 p-4">
                <div className="text-xs uppercase tracking-[0.08em] text-muted-foreground mb-2">Регистрация</div>
                <div className="text-base font-medium text-foreground">
                  {getRegistrationModeLabel(overview.config.registrationMode)}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {overview.config.registrationRequiresInvite
                    ? overview.config.inviteConfigured ? "Код доступа задан" : "Создайте beta-инвайт ниже"
                    : "Код доступа не требуется"}
                </div>
              </div>

              <div className="rounded-xl bg-secondary/60 p-4">
                <div className="text-xs uppercase tracking-[0.08em] text-muted-foreground mb-2">Публичный адрес</div>
                <div className="text-sm font-medium text-foreground break-all">{overview.config.publicUrl}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {overview.config.serveWeb ? "Сайт отдается сервером" : "Сервер отдает только API"}
                </div>
              </div>

              <div className="rounded-xl bg-secondary/60 p-4">
                <div className="text-xs uppercase tracking-[0.08em] text-muted-foreground mb-2">Доступ с сайта</div>
                <div className="text-sm font-medium text-foreground break-all">
                  {overview.config.allowedOrigins.join(", ") || "Не задано"}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {overview.config.allowedOrigins.includes("*") ? "Лучше убрать * перед VPS" : "Домены ограничены"}
                </div>
              </div>

              <div className="rounded-xl bg-secondary/60 p-4">
                <div className="text-xs uppercase tracking-[0.08em] text-muted-foreground mb-2">Диагностика</div>
                <div className="text-sm font-medium text-foreground">
                  Логи: {getBooleanStatus(overview.config.accessLogs)}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  Health details: {getBooleanStatus(overview.config.healthDetails)}
                  {" · "}
                  Stack traces: {getBooleanStatus(overview.config.errorStacks)}
                </div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
              <ProfileMetric label="Фото в холодильнике" value={`${overview.config.limits.maxFridgeImages} шт.`} />
              <ProfileMetric label="Размер фото" value={formatBytes(overview.config.limits.maxFridgeImageBytes)} />
              <ProfileMetric label="Пост форума" value={`${overview.config.limits.forumPostMaxLength} зн.`} />
              <ProfileMetric label="Хранилище ключей" value={overview.config.limits.maxStorageKeys} />
            </div>
            <BetaInvitesPanel
              invites={overview.config.inviteCodes}
              activeInviteCount={overview.config.activeInviteCount}
              envInviteConfigured={overview.config.envInviteConfigured}
              label={inviteLabel}
              maxUses={inviteMaxUses}
              isCreating={isCreatingInvite}
              actionId={inviteActionId}
              onLabelChange={setInviteLabel}
              onMaxUsesChange={setInviteMaxUses}
              onCreate={handleInviteCreate}
              onCopy={handleInviteCopy}
              onSetActive={handleInviteActive}
            />
          </section>

          <section className="bg-card border border-border rounded-xl p-4 md:p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 mb-5">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-medium text-foreground">Метрики продукта</h2>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-secondary/60 px-3 py-2">
                  <div className="text-lg font-medium text-foreground">{overview.analytics.eventsToday}</div>
                  <div className="text-[11px] text-muted-foreground">сегодня</div>
                </div>
                <div className="rounded-lg bg-secondary/60 px-3 py-2">
                  <div className="text-lg font-medium text-foreground">{overview.analytics.activeUsers7d}</div>
                  <div className="text-[11px] text-muted-foreground">за 7 дней</div>
                </div>
                <div className="rounded-lg bg-secondary/60 px-3 py-2">
                  <div className="text-lg font-medium text-foreground">{overview.analytics.totalEvents}</div>
                  <div className="text-[11px] text-muted-foreground">всего</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
              <div className="xl:col-span-2">
                <div className="text-sm font-medium text-foreground mb-3">Популярные разделы</div>
                {overview.analytics.topScreens.length === 0 ? (
                  <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
                    Метрик пока нет. Они появятся после переходов по разделам.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {overview.analytics.topScreens.map((screen) => {
                      const maxViews = Math.max(...overview.analytics.topScreens.map((item) => item.views), 1);
                      const width = Math.max(8, Math.round((screen.views / maxViews) * 100));

                      return (
                        <div key={screen.screen} className="rounded-xl bg-secondary/60 px-4 py-3">
                          <div className="flex items-center justify-between gap-3 mb-2">
                            <div className="text-sm font-medium text-foreground">{labelScreen(screen.screen)}</div>
                            <div className="text-xs text-muted-foreground">
                              {screen.views} просмотров · {formatDuration(screen.avgDurationMs)} среднее
                            </div>
                          </div>
                          <div className="h-2 rounded-full bg-background overflow-hidden">
                            <div className="h-full rounded-full bg-primary" style={{ width: `${width}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <div className="text-sm font-medium text-foreground mb-3">Частые действия</div>
                {overview.analytics.topActions.length === 0 ? (
                  <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
                    Действий пока нет.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {overview.analytics.topActions.map((action) => (
                      <div key={action.name} className="flex items-center justify-between gap-3 rounded-lg border border-border px-3 py-2">
                        <div className="text-sm text-foreground truncate">{labelAnalyticsAction(action.name)}</div>
                        <div className="text-sm font-medium text-primary">{action.count}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </section>

          <ForumModerationPanel
            moderation={overview.forumModeration}
            moderatingId={moderatingId}
            onPostStatus={handleForumPostStatus}
            onCommentStatus={handleForumCommentStatus}
            onReportStatus={handleForumReportStatus}
          />

          <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.45fr)_minmax(360px,0.75fr)] gap-6">
            <section className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center gap-2 mb-5">
                <Users className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-medium text-foreground">Пользователи</h2>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-muted-foreground border-b border-border">
                      <th className="py-3 pr-4 font-medium">Имя</th>
                      <th className="py-3 pr-4 font-medium">Email</th>
                      <th className="py-3 pr-4 font-medium">Роль</th>
                      <th className="py-3 pr-4 font-medium">Ребенок</th>
                      <th className="py-3 pr-4 font-medium">Дневник</th>
                      <th className="py-3 pr-4 font-medium">Покупки</th>
                      <th className="py-3 pr-4 font-medium">Сессии</th>
                    </tr>
                  </thead>
                  <tbody>
                    {overview.users.map((user) => (
                      <tr
                        key={user.id}
                        onClick={() => setSelectedUserId(user.id)}
                        className={`border-b border-border/60 last:border-0 cursor-pointer transition-colors ${
                          selectedUser?.id === user.id ? "bg-primary/5" : "hover:bg-secondary/60"
                        }`}
                      >
                        <td className="py-3 pr-4 text-foreground">
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-secondary text-xs font-medium text-foreground">
                              {getUserInitials(user)}
                            </div>
                            <span className="font-medium">{user.name}</span>
                          </div>
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">{user.email}</td>
                        <td className="py-3 pr-4">
                          <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                            {user.role === "admin" ? "Админ" : "Родитель"}
                          </span>
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">{user.babyName || "—"}</td>
                        <td className="py-3 pr-4 text-muted-foreground">{user.diaryEntries}</td>
                        <td className="py-3 pr-4 text-muted-foreground">
                          {user.shoppingChecked}/{user.shoppingItems}
                        </td>
                        <td className="py-3 pr-4 text-muted-foreground">{user.activeSessions}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center gap-2 mb-5">
                <Baby className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-medium text-foreground">Профиль</h2>
              </div>

              {selectedUser ? (
                <div className="space-y-5">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Аккаунт</div>
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="text-lg font-medium text-foreground">{selectedUser.name}</div>
                      <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${
                        selectedUser.blockedAt ? "bg-destructive/10 text-destructive" : "bg-emerald-50 text-emerald-700"
                      }`}>
                        {selectedUser.blockedAt ? "Заблокирован" : "Активен"}
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">{selectedUser.email}</div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <ProfileMetric label="Создан" value={formatDateTime(selectedUser.createdAt)} />
                    <ProfileMetric label="Последний вход" value={formatDateTime(selectedUser.lastLoginAt)} />
                    <ProfileMetric label="Дневник" value={selectedUser.diaryEntries} />
                    <ProfileMetric label="Хранилище" value={selectedUser.storageKeys} />
                  </div>

                  <AdminUserActions
                    user={selectedUser}
                    currentUserId={currentUserId}
                    onAskAction={askUserAction}
                  />

                  {selectedUser.babyProfile ? (
                    <div className="rounded-xl bg-secondary/60 p-4">
                      <div className="text-sm font-medium text-foreground mb-3">Ребенок</div>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <ProfileLine label="Имя" value={selectedUser.babyProfile.name} />
                        <ProfileLine label="Этап" value={getStageLabel(selectedUser.babyProfile.stage)} />
                        <ProfileLine label="Дата рождения" value={formatDate(selectedUser.babyProfile.birthDate)} />
                        <ProfileLine label="Рост" value={selectedUser.babyProfile.heightCm || "—"} />
                        <ProfileLine label="Вес" value={selectedUser.babyProfile.weightKg || "—"} />
                        <ProfileLine label="Группа крови" value={selectedUser.babyProfile.bloodType || "—"} />
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
                      Профиль ребенка еще не заполнен.
                    </div>
                  )}

                  <div>
                    <div className="text-sm font-medium text-foreground mb-2">Цели родителя</div>
                    {selectedUser.goals.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {selectedUser.goals.map((goal) => (
                          <span key={goal} className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                            {labelGoal(goal)}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <div className="text-sm text-muted-foreground">Цели пока не выбраны.</div>
                    )}
                  </div>

                  <UserDiaryPreview entries={selectedUser.recentDiaryEntries} />
                  <UserForumPreview posts={selectedUser.recentForumPosts} />
                  <UserActivityPreview events={selectedUser.recentActivity} />
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">Пользователей пока нет.</div>
              )}
            </section>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            <section className="xl:col-span-2 bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center gap-2 mb-5">
                <NotebookText className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-medium text-foreground">Последние записи дневника</h2>
              </div>

              {overview.recentDiaryEntries.length === 0 ? (
                <div className="text-sm text-muted-foreground">Записей пока нет.</div>
              ) : (
                <div className="space-y-3">
                  {overview.recentDiaryEntries.map((entry) => (
                    <div key={`${entry.userId}-${entry.id}`} className="rounded-xl bg-secondary/60 px-4 py-3">
                      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2">
                        <div>
                          <div className="text-sm font-medium text-foreground">
                            {entry.details || entry.type || "Запись дневника"}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {entry.userName} · {entry.babyName || "профиль без имени"}
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {[formatDate(entry.date), entry.time].filter(Boolean).join(", ")}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center gap-2 mb-5">
                <HardDrive className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-medium text-foreground">База и backup</h2>
              </div>

              <div className="space-y-4">
                <div className="rounded-xl bg-secondary/60 p-4">
                  <div className="text-sm text-muted-foreground mb-1">Размер базы</div>
                  <div className="text-2xl font-medium text-foreground">{formatBytes(overview.database.sizeBytes)}</div>
                </div>

                <div>
                  <div className="text-sm font-medium text-foreground mb-2">Последние копии</div>
                  {overview.database.backups.length === 0 ? (
                    <div className="text-sm text-muted-foreground">Бэкапов пока нет.</div>
                  ) : (
                    <div className="space-y-2">
                      {overview.database.backups.map((backup) => (
                        <div key={backup.fileName} className="rounded-lg border border-border px-3 py-2">
                          <div className="text-sm font-medium text-foreground truncate">{backup.fileName}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatBytes(backup.sizeBytes)} · {formatDateTime(backup.updatedAt)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </section>
          </div>

          <section className="bg-card border border-border rounded-xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-5">
              <Activity className="w-5 h-5 text-primary" />
              <h2 className="text-xl font-medium text-foreground">История действий</h2>
            </div>

            {overview.audit.length === 0 ? (
              <div className="text-sm text-muted-foreground">Событий пока нет.</div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                {overview.audit.map((event) => {
                  const actor = event.userName || event.userEmail || event.userId || "Система";

                  return (
                    <div key={event.id} className="rounded-xl bg-secondary/60 px-4 py-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0 flex gap-3">
                          <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${getActivityTone(event.kind)}`} />
                          <div className="min-w-0">
                            <div className="text-sm font-medium text-foreground">{event.title || labelActivity(event.action)}</div>
                            <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                              {actor}
                              {event.description ? ` · ${event.description}` : ""}
                            </div>
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground shrink-0">{formatDateTime(event.createdAt)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </section>
        </div>
      ) : null}
      <ConfirmActionDialog
        open={Boolean(confirmUserAction)}
        title={confirmUserAction?.title || ""}
        description={confirmUserAction?.description || ""}
        confirmLabel={isUserActionBusy ? "Выполняем..." : confirmUserAction?.confirmLabel || "Подтвердить"}
        destructive={confirmUserAction?.destructive}
        requiredText={confirmUserAction?.requiredText}
        requiredTextLabel={confirmUserAction?.requiredTextLabel}
        requiredTextPlaceholder={confirmUserAction?.requiredTextPlaceholder}
        onOpenChange={(open) => {
          if (!open && !isUserActionBusy) setConfirmUserAction(null);
        }}
        onConfirm={() => void handleConfirmUserAction()}
      />
    </div>
  );
}

function ProfileMetric({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-border px-3 py-3">
      <div className="text-xs text-muted-foreground mb-1">{label}</div>
      <div className="text-sm font-medium text-foreground">{value}</div>
    </div>
  );
}

function AdminUserActions({
  user,
  currentUserId,
  onAskAction,
}: {
  user: AdminUser;
  currentUserId: string;
  onAskAction: (kind: AdminUserActionKind, user: AdminUser) => void;
}) {
  const isSelf = user.id === currentUserId;
  const isAdmin = user.role === "admin";
  const canDeleteSafely = !isSelf && !isAdmin && Boolean(user.blockedAt) && user.activeSessions === 0;
  const safeDeleteHint = !user.blockedAt
    ? "Шаг 1: заблокируйте пользователя. Это сразу сбросит его активные сессии."
    : user.activeSessions > 0
      ? "Шаг 2: сбросьте активные сессии перед удалением."
      : "Удаление доступно только после ручного подтверждения email.";

  return (
    <div className="rounded-xl border border-border bg-background p-4">
      <div className="mb-3 flex items-center gap-2 text-sm font-medium text-foreground">
        <ShieldCheck className="h-4 w-4 text-primary" />
        Действия администратора
      </div>
      <div className="grid gap-2">
        <Button
          type="button"
          variant={user.blockedAt ? "secondary" : "outline"}
          className="h-10 justify-start rounded-xl"
          disabled={isSelf}
          onClick={() => onAskAction(user.blockedAt ? "unblock" : "block", user)}
        >
          {user.blockedAt ? <UserCheck className="h-4 w-4" /> : <UserX className="h-4 w-4" />}
          {user.blockedAt ? "Разблокировать" : "Заблокировать"}
        </Button>
        <Button
          type="button"
          variant="outline"
          className="h-10 justify-start rounded-xl"
          disabled={isSelf || user.activeSessions === 0}
          onClick={() => onAskAction("resetSessions", user)}
        >
          <LogOut className="h-4 w-4" />
          Сбросить сессии
        </Button>
        <Button
          type="button"
          variant="destructive"
          className="h-10 justify-start rounded-xl"
          disabled={!canDeleteSafely}
          onClick={() => onAskAction("delete", user)}
        >
          <Trash2 className="h-4 w-4" />
          Удалить тестовый аккаунт
        </Button>
      </div>
      <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
        {isSelf
          ? "Действия над своим аккаунтом отключены, чтобы не потерять доступ к админке."
          : isAdmin
            ? "Удаление администраторов отключено. Для админов доступна блокировка только если есть другой активный админ."
            : safeDeleteHint}
      </p>
    </div>
  );
}

function UserDiaryPreview({ entries }: { entries: AdminUser["recentDiaryEntries"] }) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
        <NotebookText className="h-4 w-4 text-primary" />
        Последние записи
      </div>
      {entries.length === 0 ? (
        <div className="rounded-xl bg-secondary/60 p-3 text-sm text-muted-foreground">
          Записей дневника пока нет.
        </div>
      ) : (
        <div className="space-y-2">
          {entries.map((entry) => (
            <div key={entry.id} className="rounded-xl bg-secondary/60 px-3 py-3">
              <div className="line-clamp-2 text-sm font-medium text-foreground">
                {entry.details || entry.type || "Запись дневника"}
              </div>
              <div className="mt-1 text-xs text-muted-foreground">
                {[formatDate(entry.date), entry.time].filter(Boolean).join(", ") || formatDateTime(entry.updatedAt)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UserForumPreview({ posts }: { posts: AdminUser["recentForumPosts"] }) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
        <MessageSquare className="h-4 w-4 text-primary" />
        Форум
      </div>
      {posts.length === 0 ? (
        <div className="rounded-xl bg-secondary/60 p-3 text-sm text-muted-foreground">
          Постов на форуме пока нет.
        </div>
      ) : (
        <div className="space-y-2">
          {posts.map((post) => (
            <div key={post.id} className="rounded-xl bg-secondary/60 px-3 py-3">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="line-clamp-1 text-sm font-medium text-foreground">{post.title}</div>
                  <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{post.preview}</div>
                </div>
                <ForumStatusBadge status={post.status || "published"} labels={forumStatusLabels} />
              </div>
              <div className="mt-2 text-xs text-muted-foreground">
                {post.category} · {post.comments} ответов · {post.reports ?? 0} жалоб
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function UserActivityPreview({ events }: { events: AdminUser["recentActivity"] }) {
  return (
    <div>
      <div className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
        <Activity className="h-4 w-4 text-primary" />
        История действий
      </div>
      {events.length === 0 ? (
        <div className="rounded-xl bg-secondary/60 p-3 text-sm text-muted-foreground">
          Действий пока нет.
        </div>
      ) : (
        <div className="space-y-2">
          {events.map((event) => {
            const description = getActivityDescription(event);

            return (
              <div key={event.id} className="flex gap-3 rounded-xl bg-secondary/60 px-3 py-3">
                <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${getActivityTone(event.kind)}`} />
                <div className="min-w-0">
                  <div className="text-sm font-medium text-foreground">{getActivityTitle(event)}</div>
                  {description ? <div className="mt-1 line-clamp-2 text-xs text-muted-foreground">{description}</div> : null}
                  <div className="mt-1 text-xs text-muted-foreground">
                    {formatDateTime(event.createdAt)}
                    {event.durationMs ? ` · ${formatDuration(event.durationMs)}` : ""}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function BetaInvitesPanel({
  invites,
  activeInviteCount,
  envInviteConfigured,
  label,
  maxUses,
  isCreating,
  actionId,
  onLabelChange,
  onMaxUsesChange,
  onCreate,
  onCopy,
  onSetActive,
}: {
  invites: AdminBetaInvite[];
  activeInviteCount: number;
  envInviteConfigured: boolean;
  label: string;
  maxUses: number;
  isCreating: boolean;
  actionId: string;
  onLabelChange: (value: string) => void;
  onMaxUsesChange: (value: number) => void;
  onCreate: () => Promise<void>;
  onCopy: (code: string) => Promise<void>;
  onSetActive: (inviteId: string, active: boolean) => Promise<void>;
}) {
  return (
    <div className="mt-5 border-t border-border pt-5">
      <div className="flex flex-col xl:flex-row xl:items-end xl:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Plus className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-medium text-foreground">Beta-инвайты</h3>
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            Активных кодов: {activeInviteCount}. {envInviteConfigured ? "ENV-код тоже работает." : "ENV-код не задан."}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-[minmax(180px,1fr)_110px_auto] gap-2 xl:min-w-[560px]">
          <input
            value={label}
            onChange={(event) => onLabelChange(event.target.value)}
            placeholder="Название: тестер, семья, друг"
            maxLength={80}
            className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none transition focus:border-primary"
          />
          <input
            type="number"
            min={1}
            max={1000}
            value={maxUses}
            onChange={(event) => onMaxUsesChange(Math.max(1, Math.min(1000, Number(event.target.value) || 1)))}
            className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none transition focus:border-primary"
          />
          <Button type="button" onClick={() => void onCreate()} disabled={isCreating} className="h-11 rounded-xl">
            <Plus className="w-4 h-4" />
            {isCreating ? "Создаем..." : "Создать код"}
          </Button>
        </div>
      </div>

      {invites.length === 0 ? (
        <div className="mt-4 rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
          Инвайтов в базе пока нет. Для закрытого теста создайте первый код и отправьте его тестеру.
        </div>
      ) : (
        <div className="mt-4 grid grid-cols-1 xl:grid-cols-2 gap-3">
          {invites.map((invite) => (
            <div key={invite.id} className="rounded-xl border border-border bg-background p-4">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-sm font-semibold text-foreground">{invite.code}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[11px] font-medium ${
                      invite.active ? "bg-emerald-50 text-emerald-700" : "bg-secondary text-muted-foreground"
                    }`}>
                      {invite.active ? "активен" : "выключен"}
                    </span>
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    {invite.label || "Без названия"} · {invite.usedCount}/{invite.maxUses ?? "∞"} использовано
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Создан: {formatDateTime(invite.createdAt)}
                    {invite.lastUsedAt ? ` · последний вход: ${formatDateTime(invite.lastUsedAt)}` : ""}
                  </div>
                </div>

                <div className="flex shrink-0 gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-9 rounded-lg"
                    onClick={() => void onCopy(invite.code)}
                  >
                    <Copy className="w-4 h-4" />
                    Копировать
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant={invite.active ? "outline" : "secondary"}
                    disabled={actionId === invite.id}
                    className="h-9 rounded-lg"
                    onClick={() => void onSetActive(invite.id, !invite.active)}
                  >
                    <Power className="w-4 h-4" />
                    {invite.active ? "Выключить" : "Включить"}
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ForumModerationPanel({
  moderation,
  moderatingId,
  onPostStatus,
  onCommentStatus,
  onReportStatus,
}: {
  moderation: AdminOverview["forumModeration"];
  moderatingId: string;
  onPostStatus: (postId: string, status: ForumContentStatus) => Promise<void>;
  onCommentStatus: (commentId: string, status: ForumContentStatus) => Promise<void>;
  onReportStatus: (reportId: string, status: ForumReportStatus) => Promise<void>;
}) {
  return (
    <section className="bg-card border border-border rounded-xl p-4 md:p-6">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-5">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-primary" />
          <div>
            <h2 className="text-xl font-medium text-foreground">Модерация форума</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Жалобы, скрытие материалов и мягкое удаление без потери истории.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-2 text-center">
          <ForumMiniMetric label="Открыто" value={moderation.stats.openReports} />
          <ForumMiniMetric label="Скрыто" value={moderation.stats.hiddenPosts + moderation.stats.hiddenComments} />
          <ForumMiniMetric label="Всего жалоб" value={moderation.stats.totalReports} />
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] gap-5">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Flag className="w-4 h-4 text-destructive" />
            <h3 className="font-medium text-foreground">Жалобы</h3>
          </div>
          {moderation.reports.length === 0 ? (
            <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
              Жалоб пока нет. Когда пользователь пожалуется на пост или ответ, запись появится здесь.
            </div>
          ) : (
            <div className="space-y-3">
              {moderation.reports.slice(0, 6).map((report) => (
                <div key={report.id} className="rounded-xl border border-border bg-background px-4 py-3">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-2 mb-2">
                    <div>
                      <div className="text-sm font-medium text-foreground">{report.targetLabel}</div>
                      <div className="text-xs text-muted-foreground mt-1">
                        {report.reasonLabel} · {report.reporterName || report.reporterEmail || "Пользователь"} · {formatDateTime(report.createdAt)}
                      </div>
                    </div>
                    <ForumStatusBadge status={report.status} labels={forumReportStatusLabels} />
                  </div>
                  {report.targetPreview ? (
                    <p className="line-clamp-2 text-sm text-muted-foreground mb-2">{report.targetPreview}</p>
                  ) : null}
                  {report.details ? (
                    <div className="mb-3 rounded-lg bg-secondary/60 px-3 py-2 text-sm text-foreground">
                      {report.details}
                    </div>
                  ) : null}
                  <div className="flex flex-wrap gap-2">
                    {report.status === "open" ? (
                      <>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          disabled={moderatingId === `report:${report.id}:reviewed`}
                          onClick={() => void onReportStatus(report.id, "reviewed")}
                          className="h-8 rounded-lg"
                        >
                          <Eye className="w-4 h-4" />
                          Проверена
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          disabled={moderatingId === `report:${report.id}:dismissed`}
                          onClick={() => void onReportStatus(report.id, "dismissed")}
                          className="h-8 rounded-lg"
                        >
                          <RotateCcw className="w-4 h-4" />
                          Отклонить
                        </Button>
                      </>
                    ) : (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        disabled={moderatingId === `report:${report.id}:open`}
                        onClick={() => void onReportStatus(report.id, "open")}
                        className="h-8 rounded-lg"
                      >
                        <Flag className="w-4 h-4" />
                        Открыть
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <ForumContentList
            title="Посты"
            items={moderation.posts}
            moderatingId={moderatingId}
            getDescription={(post) => post.preview}
            getMeta={(post) => `${post.author} · ${post.category} · ${post.comments} ответов · ${post.reports ?? 0} жалоб`}
            onStatus={onPostStatus}
            type="post"
          />
          <ForumContentList
            title="Ответы"
            items={moderation.comments}
            moderatingId={moderatingId}
            getDescription={(comment) => comment.content}
            getMeta={(comment) => `${comment.author} · ${comment.postTitle} · ${comment.reports ?? 0} жалоб`}
            onStatus={onCommentStatus}
            type="comment"
          />
        </div>
      </div>
    </section>
  );
}

function ForumContentList<T extends { id: string; title?: string; status?: ForumContentStatus; reports?: number; createdAt: string }>({
  title,
  items,
  moderatingId,
  getDescription,
  getMeta,
  onStatus,
  type,
}: {
  title: string;
  items: T[];
  moderatingId: string;
  getDescription: (item: T) => string;
  getMeta: (item: T) => string;
  onStatus: (id: string, status: ForumContentStatus) => Promise<void>;
  type: "post" | "comment";
}) {
  return (
    <div>
      <h3 className="font-medium text-foreground mb-3">{title}</h3>
      {items.length === 0 ? (
        <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">Материалов пока нет.</div>
      ) : (
        <div className="space-y-3">
          {items.slice(0, 5).map((item) => {
            const status = item.status || "published";
            const actionPrefix = `${type}:${item.id}`;

            return (
              <div key={item.id} className="rounded-xl border border-border bg-background px-4 py-3">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-foreground line-clamp-1">
                      {item.title || "Ответ"}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{getMeta(item)}</div>
                  </div>
                  <ForumStatusBadge status={status} labels={forumStatusLabels} />
                </div>
                <p className="line-clamp-2 text-sm text-muted-foreground mb-3">{getDescription(item)}</p>
                <div className="flex flex-wrap gap-2">
                  {status !== "published" ? (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={moderatingId === `${actionPrefix}:published`}
                      onClick={() => void onStatus(item.id, "published")}
                      className="h-8 rounded-lg"
                    >
                      <Eye className="w-4 h-4" />
                      Вернуть
                    </Button>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={moderatingId === `${actionPrefix}:hidden`}
                      onClick={() => void onStatus(item.id, "hidden")}
                      className="h-8 rounded-lg"
                    >
                      <EyeOff className="w-4 h-4" />
                      Скрыть
                    </Button>
                  )}
                  {status !== "deleted" ? (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={moderatingId === `${actionPrefix}:deleted`}
                      onClick={() => void onStatus(item.id, "deleted")}
                      className="h-8 rounded-lg text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                      Удалить
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ForumStatusBadge({
  status,
  labels,
}: {
  status: string;
  labels: Record<string, string>;
}) {
  const tone =
    status === "published" || status === "reviewed"
      ? "bg-emerald-50 text-emerald-700 border-emerald-200"
      : status === "open"
        ? "bg-amber-50 text-amber-700 border-amber-200"
        : "bg-secondary text-muted-foreground border-border";

  return (
    <span className={`shrink-0 rounded-full border px-3 py-1 text-xs font-medium ${tone}`}>
      {labels[status] || status}
    </span>
  );
}

function ForumMiniMetric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-secondary/60 px-3 py-2">
      <div className="text-lg font-medium text-foreground">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function ProfileLine({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-medium text-foreground">{value}</div>
    </div>
  );
}

import { MessageSquare, Plus } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";

interface ForumScreenProps {
  onPostClick: () => void;
}

const tabs = ["Обсуждения", "Популярное", "Новое"];

const posts = [
  {
    id: 1,
    title: "Малыш плохо спит ночью",
    preview: "Ребенку 2 месяца, просыпается каждые 2 часа. Это нормально?",
    author: "Анна М.",
    time: "15 мин назад",
    comments: 12,
    category: "Сон",
  },
  {
    id: 2,
    title: "Когда вводить прикорм?",
    preview: "Педиатр говорит с 6 месяцев, но бабушка настаивает раньше...",
    author: "Екатерина С.",
    time: "1 час назад",
    comments: 24,
    category: "Кормление",
  },
  {
    id: 3,
    title: "Температура после прививки",
    preview: "Сделали АКДС вчера, сегодня 37.5. Нормально ли это?",
    author: "Мария К.",
    time: "2 часа назад",
    comments: 8,
    category: "Здоровье",
  },
  {
    id: 4,
    title: "Выбор коляски",
    preview: "Помогите выбрать между трансформером и модульной коляской",
    author: "Ольга В.",
    time: "3 часа назад",
    comments: 15,
    category: "Покупки",
  },
  {
    id: 5,
    title: "Колики — что помогает?",
    preview: "Уже всё перепробовали, ничего не помогает. Поделитесь опытом",
    author: "Светлана Р.",
    time: "4 часа назад",
    comments: 31,
    category: "Здоровье",
  },
];

export function ForumScreen({ onPostClick }: ForumScreenProps) {
  const [activeTab, setActiveTab] = useState("Обсуждения");

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 bg-card border-b border-border">
        <h1 className="text-2xl font-medium text-foreground mb-4">Форум</h1>
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "bg-transparent text-muted-foreground"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 pb-24">
        <div className="space-y-3">
          {posts.map((post) => (
            <button
              key={post.id}
              onClick={onPostClick}
              className="w-full rounded-xl bg-card border border-border p-4 text-left hover:border-primary/30 transition-all"
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <h3 className="font-medium text-foreground flex-1">{post.title}</h3>
                <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full whitespace-nowrap">
                  {post.category}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{post.preview}</p>
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <div className="flex items-center gap-3">
                  <span>{post.author}</span>
                  <span>•</span>
                  <span>{post.time}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MessageSquare className="w-4 h-4" />
                  <span>{post.comments}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="fixed bottom-24 right-6">
        <Button
          size="lg"
          className="h-14 w-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}

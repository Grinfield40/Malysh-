import { Search, Clock } from "lucide-react";
import { Input } from "../ui/input";
import { useState } from "react";

interface TipsScreenProps {
  onArticleClick: () => void;
}

const categories = ["Все", "Здоровье", "Сон", "Кормление", "Развитие", "Покупки"];

const articles = [
  {
    id: 1,
    title: "Можно ли целовать ребенка",
    category: "Здоровье",
    time: "4 мин",
    featured: true,
    emoji: "💋",
  },
  {
    id: 2,
    title: "Когда обращаться к врачу",
    category: "Здоровье",
    time: "5 мин",
    featured: false,
    emoji: "🩺",
  },
  {
    id: 3,
    title: "Как собрать аптечку",
    category: "Покупки",
    time: "3 мин",
    featured: false,
    emoji: "💊",
  },
  {
    id: 4,
    title: "Что нормально, а что нет",
    category: "Здоровье",
    time: "6 мин",
    featured: false,
    emoji: "✅",
  },
  {
    id: 5,
    title: "Режим сна новорожденного",
    category: "Сон",
    time: "7 мин",
    featured: false,
    emoji: "🌙",
  },
  {
    id: 6,
    title: "Грудное вскармливание: первые дни",
    category: "Кормление",
    time: "8 мин",
    featured: false,
    emoji: "🍼",
  },
];

export function TipsScreen({ onArticleClick }: TipsScreenProps) {
  const [activeCategory, setActiveCategory] = useState("Все");

  const featured = articles.find((a) => a.featured);
  const regular = articles.filter((a) => !a.featured);

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 bg-card border-b border-border">
        <h1 className="text-2xl font-medium text-foreground mb-4">Советы</h1>
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Поиск статей"
            className="h-12 pl-12 rounded-2xl bg-background border-border"
          />
        </div>
      </div>

      <div className="flex gap-2 px-6 py-4 overflow-x-auto">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-all ${
              activeCategory === cat
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="space-y-6">
          {featured && (
            <div>
              <h3 className="text-base font-medium mb-3">Рекомендуем</h3>
              <button
                onClick={onArticleClick}
                className="w-full rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 p-6 text-left hover:border-primary/40 transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-14 h-14 rounded-xl bg-white flex items-center justify-center text-3xl flex-shrink-0">
                    {featured.emoji}
                  </div>
                  <div className="flex-1">
                    <div className="text-xs text-primary font-medium mb-2">{featured.category}</div>
                    <h4 className="text-lg font-medium text-foreground mb-2">{featured.title}</h4>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>{featured.time}</span>
                    </div>
                  </div>
                </div>
              </button>
            </div>
          )}

          <div>
            <h3 className="text-base font-medium mb-3">Все статьи</h3>
            <div className="space-y-3">
              {regular.map((article) => (
                <button
                  key={article.id}
                  onClick={onArticleClick}
                  className="w-full rounded-xl bg-card border border-border p-4 flex items-center gap-4 hover:border-primary/30 transition-all"
                >
                  <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                    {article.emoji}
                  </div>
                  <div className="flex-1 text-left">
                    <div className="text-xs text-primary font-medium mb-1">{article.category}</div>
                    <h4 className="text-sm font-medium text-foreground mb-1">{article.title}</h4>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      <span>{article.time}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

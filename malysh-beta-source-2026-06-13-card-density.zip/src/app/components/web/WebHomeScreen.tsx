import { motion } from "motion/react";
import { AlertCircle, ShoppingBag, BookOpen, Clock, Bookmark, TrendingUp, ShieldAlert, ClipboardList, ArrowRight, CheckCircle2, Circle, Milk, Moon, Baby as BabyIcon, Thermometer, ShieldCheck, X } from "lucide-react";
import { Button } from "../ui/button";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";
import { useParentGoals } from "../../lib/parentGoals";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { CareDiaryEntry, getCareDiarySummary, getTodayCareEntries, TRACKER_QUICK_ENTRY_STORAGE_KEY } from "../../lib/careDiary";
import { BetaSurveyCard } from "./BetaSurveyCard";

interface WebHomeScreenProps {
  onNavigate: (screen: string) => void;
  isAuthenticated?: boolean;
  onRequireAuth?: (returnScreen?: string) => void;
}

interface StoredShoppingCategory {
  items: Array<{ checked: boolean }>;
}

function getTodayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function readLocalStorage<T>(key: string): T | null {
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : null;
  } catch {
    return null;
  }
}

export function WebHomeScreen({ onNavigate, isAuthenticated = true, onRequireAuth }: WebHomeScreenProps) {
  const [profile] = useUserProfile();
  const { baby, age } = useBabyProfile();
  const { selectedGoals } = useParentGoals();
  const storedShopping = readLocalStorage<StoredShoppingCategory[]>("mvp.shopping.items");
  const trackerEntries = readLocalStorage<CareDiaryEntry[]>("mvp.tracker.entries") ?? [];
  const todayTrackerEntries = getTodayCareEntries(trackerEntries);
  const trackerSummary = getCareDiarySummary(todayTrackerEntries);
  const todayKey = getTodayKey();
  const [completedFocusIds, setCompletedFocusIds] = useLocalStorageState<string[]>(
    `mvp.home.completed.${todayKey}`,
    []
  );
  const [homeBetaNoticeDismissed, setHomeBetaNoticeDismissed] = useLocalStorageState(
    "mvp.beta.privacy.notice.dismissed",
    false
  );
  const displayName = profile.name?.trim() || "Родитель";
  const primaryGoal = selectedGoals[0];

  const totalShoppingItems = storedShopping?.reduce((sum, category) => sum + category.items.length, 0) ?? 0;
  const checkedShoppingItems =
    storedShopping?.reduce(
      (sum, category) => sum + category.items.filter((item) => item.checked).length,
      0
    ) ?? 0;
  const shoppingProgressLabel = totalShoppingItems > 0 ? `${checkedShoppingItems}/${totalShoppingItems}` : "список";

  const trackerStats = {
    feeding: trackerSummary.feeding,
    sleep: trackerSummary.sleep,
    diaper: trackerSummary.diaper,
    temperature: trackerSummary.temperature === "—" ? "—" : trackerSummary.temperature.replace("°C", "°"),
  };

  const careQuickActions = [
    { type: "sleep", label: "Сон", value: trackerStats.sleep, hint: "добавить сон", icon: Moon },
    { type: "feeding", label: "Кормление", value: trackerStats.feeding, hint: "записать кормление", icon: Milk },
    { type: "diaper", label: "Подгузник", value: trackerStats.diaper, hint: "смена подгузника", icon: BabyIcon },
    { type: "temperature", label: "Температура", value: trackerStats.temperature, hint: "измерить", icon: Thermometer },
  ] as const;

  const quickActions = [
    { id: "urgent", label: "Срочный вопрос", icon: AlertCircle, color: "bg-destructive", count: null },
    { id: "shopping", label: "Что купить", icon: ShoppingBag, color: "bg-primary", count: shoppingProgressLabel },
    { id: "discharge-checklist", label: "На выписку", icon: ClipboardList, color: "bg-[#A4B5A8]", count: null },
    { id: "tips", label: "Советы", icon: BookOpen, color: "bg-accent", count: "5 новых" },
    { id: "routines", label: "Режим дня", icon: Clock, color: "bg-[#8B9DC3]", count: null },
    { id: "taboo", label: "Табу", icon: ShieldAlert, color: "bg-destructive", count: null },
  ];

  const recentArticles = [
    { title: "Когда обращаться к врачу", time: "5 мин", category: "Здоровье", icon: "🩺" },
    { title: "Первая аптечка для малыша", time: "3 мин", category: "Покупки", icon: "💊" },
    { title: `Режим для этапа ${age.stageLabel}`, time: "7 мин", category: "Сон", icon: "🌙" },
  ];

  const latestActivities = todayTrackerEntries.slice(0, 3).map((entry) => ({
    time: entry.time,
    action: entry.type,
    details: entry.details,
    icon: entry.icon,
  }));

  const focusTasks = [
    ...selectedGoals.map((goal) => ({
      id: `goal-${goal.id}`,
      title: goal.actionLabel,
      description: goal.homeHint,
      icon: goal.icon,
      screen: goal.targetScreen,
    })),
    {
      id: "tracker-check",
      title: todayTrackerEntries.length > 0 ? "Проверить уход" : "Первая запись ухода",
      description:
        todayTrackerEntries.length > 0
          ? `Сегодня уже есть ${todayTrackerEntries.length} записей по уходу.`
          : `Сон, кормление или подгузник для ${baby.name}.`,
      icon: "📝",
      screen: "tracker",
    },
  ].slice(0, 4);
  const completedFocusCount = focusTasks.filter((task) => completedFocusIds.includes(task.id)).length;
  const nextTask = focusTasks.find((task) => !completedFocusIds.includes(task.id)) ?? focusTasks[0];

  const toggleFocusTask = (taskId: string) => {
    setCompletedFocusIds((prev) =>
      prev.includes(taskId)
        ? prev.filter((id) => id !== taskId)
        : [...prev, taskId]
    );
  };

  const openTrackerQuickEntry = (type: (typeof careQuickActions)[number]["type"]) => {
    try {
      window.localStorage.setItem(TRACKER_QUICK_ENTRY_STORAGE_KEY, JSON.stringify(type));
    } catch {
      // Navigation still works even if this quick preference cannot be stored.
    }
    onNavigate("tracker");
  };

  const startFirstDay = () => {
    if (isAuthenticated) {
      onNavigate("profile");
      return;
    }

    onRequireAuth?.("profile");
  };

  const quickActionsSection = (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.12 }}
      className="mb-3 md:mb-4"
    >
      <div className="mb-2 flex items-end justify-between gap-3">
        <div>
          <h2 className="text-lg font-medium text-foreground md:text-xl">Быстрые действия</h2>
          <p className="hidden text-sm text-muted-foreground md:block">Главные разделы под рукой</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2 md:grid-cols-6">
        {quickActions.map((action, idx) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.id}
              onClick={() => onNavigate(action.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.16 + idx * 0.05 }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="min-h-[68px] bg-card border border-border rounded-xl p-2.5 hover:border-primary/30 hover:bg-primary/5 transition-all group md:min-h-[82px]"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className={`w-8 h-8 rounded-xl ${action.color} flex items-center justify-center text-white group-hover:scale-105 transition-transform md:w-9 md:h-9`}>
                  <Icon className="w-4 h-4 md:w-5 md:h-5" />
                </div>
                {action.count && (
                  <span className="hidden text-[11px] md:inline-flex md:text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-full">
                    {action.count}
                  </span>
                )}
              </div>
              <h3 className="text-xs font-medium text-foreground text-left leading-snug md:text-sm">{action.label}</h3>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );

  const starterArticlesSection = (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.16 }}
      className="mb-4 md:mb-6"
    >
      <div className="flex items-center justify-between mb-2 md:mb-3">
        <h2 className="text-lg md:text-xl font-medium text-foreground">Полезное на старте</h2>
        <button onClick={() => onNavigate("tips")} className="text-xs md:text-sm text-primary hover:underline">
          Открыть советы
        </button>
      </div>
      <div className="grid grid-cols-1 gap-2 md:grid-cols-3 md:gap-3">
        {recentArticles.map((article, idx) => (
          <motion.button
            key={idx}
            onClick={() => onNavigate("tips")}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + idx * 0.05 }}
            whileHover={{ y: -3 }}
            className="w-full bg-card border border-border rounded-xl p-3 flex items-center gap-3 hover:border-primary/30 transition-all"
          >
            <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-xl flex-shrink-0">
              {article.icon}
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="text-xs text-primary font-medium">{article.category}</div>
              <h4 className="truncate text-sm font-medium text-foreground">{article.title}</h4>
              <div className="text-xs text-muted-foreground">{article.time} чтения</div>
            </div>
            <Bookmark className="w-4 h-4 text-muted-foreground flex-shrink-0" />
          </motion.button>
        ))}
      </div>
    </motion.div>
  );

  return (
    <div className="p-4 md:p-8 max-w-[1400px] mx-auto relative">
      {!isAuthenticated ? (
        <motion.section
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3 overflow-hidden rounded-xl border border-primary/15 bg-card shadow-sm md:mb-5"
        >
          <div className="grid gap-0 lg:grid-cols-[1.15fr_0.85fr]">
            <div className="p-4 md:p-5">
              <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary">
                <ShieldCheck className="h-4 w-4" />
                Можно посмотреть без регистрации
              </div>
              <h1 className="max-w-2xl text-xl font-medium leading-tight text-foreground md:text-2xl">
                Первый день в Малыш+ должен быть понятным за пару минут
              </h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
                Посмотрите разделы, а когда захотите сохранить профиль ребенка, трекер или список покупок, сайт попросит войти.
              </p>
              <div className="mt-4 flex flex-col gap-2 sm:flex-row">
                <Button type="button" onClick={startFirstDay} className="h-10 rounded-xl">
                  Начать
                  <ArrowRight className="h-4 w-4" />
                </Button>
                <Button type="button" variant="outline" onClick={() => onNavigate("tips")} className="h-10 rounded-xl">
                  Посмотреть советы
                </Button>
              </div>
            </div>

            <div className="hidden border-t border-border bg-secondary/35 p-4 md:block lg:border-l lg:border-t-0">
              <div className="grid gap-3">
                {[
                  { title: "1. Осмотреться", text: "Главная, развитие и советы доступны сразу." },
                  { title: "2. Добавить ребенка", text: "Минимум полей: имя и примерный этап." },
                  { title: "3. Отметить действие", text: "После старта сразу откроется трекер ухода." },
                ].map((step) => (
                  <div key={step.title} className="rounded-xl border border-border bg-card px-3 py-2.5">
                    <div className="text-sm font-medium text-foreground">{step.title}</div>
                    <div className="mt-1 text-xs leading-relaxed text-muted-foreground">{step.text}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.section>
      ) : null}

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-3 md:mb-5"
      >
        <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-1">
          {isAuthenticated ? `Добрый день, ${displayName}!` : "Что можно сделать в Малыш+"}
        </h1>
        <p className="text-sm md:text-lg text-muted-foreground">
          {isAuthenticated
            ? "Главное на сегодня без лишней прокрутки"
            : "Ниже видно, как будет устроен день после входа"}
        </p>
      </motion.div>

      {quickActionsSection}

      {/* Baby Context */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-3 rounded-xl border border-border bg-card p-3 md:mb-4 md:p-4"
      >
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <button
            type="button"
            onClick={() => (isAuthenticated ? onNavigate("profile") : startFirstDay())}
            className="flex min-w-0 items-center gap-3 rounded-xl p-1 text-left transition-colors hover:bg-secondary/40 lg:max-w-[42%]"
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-3xl md:h-14 md:w-14">
              {baby.emoji}
            </div>
            <div className="min-w-0">
              <div className="text-xs text-muted-foreground md:text-sm">
                {isAuthenticated ? "Профиль ребенка" : "Пример профиля после входа"}
              </div>
              <div className="truncate text-base font-medium text-foreground md:text-xl">
                {isAuthenticated ? `${baby.name}, ${age.label}` : "Имя ребенка и этап"}
              </div>
              <div className="text-xs font-medium text-primary">
                {isAuthenticated ? age.stageLabel : "Заполняется за минуту"}
              </div>
            </div>
          </button>

          <div className="min-w-0 flex-1 rounded-xl bg-secondary/45 px-3 py-2.5 md:px-4">
            <div className="text-xs font-medium text-primary">
              {isAuthenticated ? "Ближайшее действие" : "Первый полезный шаг"}
            </div>
            <div className="mt-1 text-sm font-medium text-foreground md:text-base">
              {isAuthenticated ? (nextTask?.title ?? `День ${baby.name} под контролем`) : "Добавить ребенка и отметить первое событие"}
            </div>
            <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
              {isAuthenticated
                ? (nextTask?.description ?? `Фокус сейчас: ${age.focus}.`)
                : "Сначала можно осмотреться. Для сохранения дневника сайт попросит войти."}
            </p>
          </div>

          <Button
            type="button"
            onClick={() => {
              if (!isAuthenticated) {
                startFirstDay();
                return;
              }

              nextTask ? onNavigate(nextTask.screen) : onNavigate("tracker");
            }}
            className="h-10 rounded-xl lg:min-w-[150px]"
          >
            {isAuthenticated ? "Открыть" : "Начать"}
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.08 }}
        className="mb-3 md:mb-4"
      >
        <div className="mb-2 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-medium text-foreground md:text-lg">Что сделать сейчас</h2>
            <p className="hidden text-sm text-muted-foreground md:block">Короткая запись в дневник без лишних шагов</p>
          </div>
          <button type="button" onClick={() => onNavigate("tracker")} className="text-xs font-medium text-primary hover:underline md:text-sm">
            Вся лента
          </button>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {careQuickActions.map((action) => {
            const Icon = action.icon;

            return (
              <button
                key={action.type}
                type="button"
                onClick={() => openTrackerQuickEntry(action.type)}
                className="min-h-[60px] rounded-xl border border-border bg-card p-2 text-center transition-all hover:border-primary/30 hover:bg-primary/5 md:min-h-[76px] md:p-2.5"
              >
                <div className="mx-auto mb-1.5 flex h-8 w-8 items-center justify-center rounded-xl bg-primary/10 text-primary md:h-9 md:w-9">
                  <Icon className="h-4 w-4 md:h-5 md:w-5" />
                </div>
                <div className="text-[11px] font-medium leading-tight text-foreground md:text-sm">{action.label}</div>
                <div className="mt-1 hidden text-[11px] leading-tight text-muted-foreground md:block md:text-xs">
                  {action.value === "—" ? action.hint : `Сегодня: ${action.value}`}
                </div>
              </button>
            );
          })}
        </div>
      </motion.div>

      {starterArticlesSection}

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-3 mt-2 flex flex-col gap-1 border-t border-border pt-4 md:mb-4 md:mt-3"
      >
        <h2 className="text-base font-medium text-foreground md:text-lg">Дальше, если нужно</h2>
        <p className="text-xs leading-relaxed text-muted-foreground md:text-sm">
          Фокусы, чек-лист и активность остаются ниже, чтобы первый экран не перегружал.
        </p>
      </motion.div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-5">
        {/* Left Column - Focus and Tip */}
        <div className="lg:col-span-2 flex flex-col gap-4 md:gap-6">
          {/* Parent Goals */}
          {selectedGoals.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18 }}
              className="order-1"
            >
              <div className="flex items-center justify-between gap-3 mb-3 md:mb-4">
                <h2 className="text-lg md:text-xl font-medium text-foreground">Ваши фокусы</h2>
                <button
                  type="button"
                  onClick={() => onNavigate("profile")}
                  className="text-xs md:text-sm text-primary hover:underline"
                >
                  Изменить
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                {selectedGoals.map((goal) => (
                  <motion.button
                    key={goal.id}
                    type="button"
                    onClick={() => onNavigate(goal.targetScreen)}
                    whileHover={{ y: -3 }}
                    whileTap={{ scale: 0.99 }}
                    className="bg-card border border-border rounded-xl p-3 text-left hover:border-primary/30 transition-all md:p-4"
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-xl">
                        {goal.icon}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">{goal.shortLabel}</div>
                        <div className="text-xs text-primary">{goal.actionLabel}</div>
                      </div>
                    </div>
                    <p className="line-clamp-2 text-xs md:text-sm text-muted-foreground leading-relaxed">
                      {goal.homeHint}
                    </p>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Focus Checklist */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="order-2 bg-card border border-border rounded-xl p-4 md:p-5"
          >
            <div className="flex items-center justify-between gap-3 mb-4">
              <div>
                <h2 className="text-lg md:text-xl font-medium text-foreground">Чек-лист дня</h2>
                <p className="text-xs md:text-sm text-muted-foreground">
                  Отмечайте то, что уже закрыто сегодня
                </p>
              </div>
              <div className="text-sm font-medium text-primary">
                {completedFocusCount}/{focusTasks.length}
              </div>
            </div>
            <div className="space-y-2">
              {focusTasks.map((task) => {
                const isCompleted = completedFocusIds.includes(task.id);

                return (
                  <div
                    key={task.id}
                    className={`flex items-start gap-3 rounded-xl border px-3 py-3 transition-colors ${
                      isCompleted
                        ? "border-primary/20 bg-primary/5"
                        : "border-border bg-background"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleFocusTask(task.id)}
                      className="mt-0.5 text-primary"
                      aria-label={isCompleted ? "Вернуть задачу" : "Отметить задачу"}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onNavigate(task.screen)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <div className={`text-sm font-medium ${isCompleted ? "text-muted-foreground line-through" : "text-foreground"}`}>
                        {task.icon} {task.title}
                      </div>
                      <div className="text-xs text-muted-foreground leading-relaxed">
                        {task.description}
                      </div>
                    </button>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Tip of the Day */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="order-3 rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 p-4 md:p-5"
          >
            <div className="flex items-start gap-3 md:gap-4">
              <div className="w-11 h-11 md:w-12 md:h-12 rounded-xl bg-white flex items-center justify-center text-2xl flex-shrink-0">
                💡
              </div>
              <div className="flex-1">
              <h3 className="text-base md:text-lg font-medium text-foreground mb-2">Совет дня</h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-3 md:mb-4">
                  {primaryGoal
                    ? `${primaryGoal.homeHint} Для этапа «${age.stageLabel}» сейчас особенно важны ${age.focus}.`
                    : `Для этапа «${age.stageLabel}» сейчас особенно важны ${age.focus}. Добавляйте наблюдения в трекер, чтобы увидеть свой ритм без догадок.`}
              </p>
                <button
                  type="button"
                  onClick={() => onNavigate(primaryGoal?.targetScreen ?? "tips")}
                  className="text-xs md:text-sm text-primary font-medium hover:underline"
                >
                  Узнать больше →
                </button>
              </div>
            </div>
          </motion.div>

        </div>

        {/* Right Column - Activity Feed */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-4 md:space-y-6"
        >
          {/* Today's Stats */}
          <div className="rounded-xl border border-border bg-card p-4 md:p-5">
            <div className="flex items-center gap-2 mb-4 md:mb-6">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="text-sm md:text-base font-medium text-foreground">Сегодня у {baby.name}</h3>
            </div>
            <div className="grid grid-cols-2 gap-3 md:gap-4">
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.feeding}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Кормлений</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.sleep}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Сна</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.diaper}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Подгузников</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.temperature}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Температура</div>
              </div>
            </div>
          </div>

          <BetaSurveyCard />

          {/* Recent Activity */}
          <div className="rounded-xl border border-border bg-card p-4 md:p-5">
            <h3 className="text-sm md:text-base font-medium text-foreground mb-3 md:mb-4">Последняя активность</h3>
            <div className="space-y-3 md:space-y-4">
              {latestActivities.length === 0 ? (
                <div className="rounded-xl border border-dashed border-border bg-secondary/30 px-4 py-5 text-center">
                  <div className="mb-2 text-3xl">📝</div>
                  <div className="text-sm font-medium text-foreground">Записей пока нет</div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Добавьте кормление, сон или заметку, и здесь появится живая лента дня.
                  </p>
                  <Button
                    type="button"
                    onClick={() => onNavigate("tracker")}
                    className="mt-4 h-9 rounded-xl px-4 text-xs"
                  >
                    Добавить первую запись
                  </Button>
                </div>
              ) : (
                latestActivities.map((activity, idx) => (
                  <div key={idx} className="flex items-start gap-2 md:gap-3">
                    <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-secondary flex items-center justify-center text-lg md:text-xl flex-shrink-0">
                      {activity.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs md:text-sm font-medium text-foreground">{activity.action}</span>
                        <span className="text-xs text-muted-foreground">{activity.time}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">{activity.details}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
            <button
              onClick={() => onNavigate("tracker")}
              className="w-full mt-3 md:mt-4 h-9 md:h-10 rounded-lg md:rounded-xl border-2 border-dashed border-border hover:border-primary/30 transition-all text-xs md:text-sm text-muted-foreground font-medium"
            >
              Добавить запись
            </button>
          </div>
        </motion.div>
      </div>

      {!homeBetaNoticeDismissed ? (
        <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-3 md:mt-6">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white text-amber-700">
              <ShieldCheck className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium text-amber-900">Закрытая beta</div>
              <p className="mt-1 text-xs leading-relaxed text-amber-900/80 md:text-sm">
                Не вводите чувствительные медицинские данные, документы, адреса и платежную информацию. Малыш+ помогает вести день ребенка, но не заменяет врача.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setHomeBetaNoticeDismissed(true)}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-amber-800 transition-colors hover:bg-amber-100"
              aria-label="Скрыть предупреждение beta"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

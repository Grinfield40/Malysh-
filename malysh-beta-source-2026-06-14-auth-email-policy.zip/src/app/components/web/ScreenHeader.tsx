import type { ReactNode } from "react";
import { motion } from "motion/react";

interface ScreenHeaderProps {
  icon?: ReactNode;
  title: string;
  description: ReactNode;
  badges?: string[];
  action?: ReactNode;
  className?: string;
}

export function ScreenHeader({
  icon,
  title,
  description,
  badges = [],
  action,
  className = "",
}: ScreenHeaderProps) {
  return (
    <motion.header
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`mb-6 md:mb-8 ${className}`}
    >
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="min-w-0 max-w-3xl">
          <div className="mb-2 flex items-center gap-3">
            {icon ? (
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary md:h-12 md:w-12">
                {icon}
              </div>
            ) : null}
            <h1 className="text-2xl font-medium text-foreground md:text-4xl">{title}</h1>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground md:text-base">
            {description}
          </p>
          {badges.length > 0 ? (
            <div className="mt-3 flex flex-wrap gap-2 text-xs font-medium text-primary">
              {badges.map((badge) => (
                <span key={badge} className="rounded-full bg-primary/10 px-3 py-1">
                  {badge}
                </span>
              ))}
            </div>
          ) : null}
        </div>

        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
    </motion.header>
  );
}

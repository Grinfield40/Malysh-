# MVP QA checklist

Date: 2026-05-13
Environment: local app, local API, SQLite

## Scope

This checklist is for a short manual pass before adding larger features. The goal is to catch broken flows, unclear validation, missing confirmations, and rough empty states.

## Smoke

- [x] Local API opens and returns health.
- [x] Local web app opens.
- [x] Existing session is handled correctly.
- [x] Logout returns to auth screen.

## Auth And Onboarding

- [x] User can create a new account.
- [x] Empty or invalid auth fields show clear errors.
- [x] First child onboarding opens after registration.
- [x] Onboarding requires child name, birth date, and at least one goal.
- [x] Completed/migrated onboarding leads to the main app.

## Main Flow

- [x] Home shows child name and next useful actions.
- [x] Route cards and sidebar navigate between key sections.
- [ ] Search/top navigation does not break the current screen.
- [ ] Mobile bottom navigation remains usable.

## Tracker

- [x] User can add a note entry.
- [x] New entry appears in the day feed.
- [x] Editing an entry saves changes and shows feedback.
- [x] Deleting an entry requires confirmation.
- [x] Empty day/filter states are clear.

## Routine

- [x] User can add a routine item.
- [x] Sleep/feeding routine item also appears in tracker/day summary.
- [x] Empty routine state is clear.

## Reminders

- [x] User can add a reminder.
- [x] User can edit a reminder.
- [x] User can delete a reminder with confirmation.
- [x] User can add a checklist task.
- [x] User can delete a checklist task with confirmation.
- [x] User can complete a checklist task.

## Forum

- [x] Forum list loads.
- [x] User can create a post.
- [x] New post opens or appears in the list.
- [x] User can add a comment.
- [x] User can report a post and receives feedback.
- [x] Empty/search states are clear.

## Shopping

- [x] User can add a shopping item.
- [x] User can mark item as bought.
- [x] Progress counters update.

## Fridge

- [x] Upload button opens file picker.
- [x] Invalid upload type/size shows a clear error.
- [x] Existing photo can be removed only after confirmation.

## Admin

- [x] Admin screen blocks non-admin user or shows a clear message.
- [ ] Admin screen loads for admin account.
- [x] Backup/export buttons give feedback.
- [x] Forum moderation actions give feedback.

## Result Notes

- Run completed on local app/API with a temporary QA account.
- Temporary QA user was removed after the pass. Temporary forum content created by the pass was removed as well.
- Found and fixed: React warning from `AlertDialog` components not forwarding refs.
- Fix pass completed: registration now starts with clean account storage and no longer silently migrates an existing local child profile into a newly created account.
- Fix pass completed: routine modal pre-fills the current time on open and after template selection, so the add action no longer depends on a fragile time-field interaction.
- Stability pass completed: auth errors now use app-level validation, logout gives visible feedback, onboarding validates date/goals/optional measurements, tracker edit updates the selected day and shows a save toast.
- Empty states improved for tracker filters and forum search/category filters, including reset actions.
- Reliability pass completed: routine now has direct diary navigation, reminders are sorted by date/time and checklist completion gives feedback, fridge upload errors are announced clearly, admin backup/export/moderation actions show unified notifications.
- Server sync now counts only uploaded fridge photos in SQLite/admin stats, not empty fridge placeholders.
- Browser spot-check completed for empty auth validation. Full logged-in manual pass is still recommended before release.
- Build after the fix passes.

import { useLocalStorageState } from "./useLocalStorageState";
import { type AuthUser } from "./accountApi";

export interface UserProfile {
  name: string;
  email: string;
  role: string;
  avatarDataUrl?: string;
  pediatricianPhone?: string;
}

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: "Родитель",
  email: "parent@yandex.ru",
  role: "Родитель",
};

function isUserProfile(value: unknown): value is Partial<UserProfile> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

export function buildUserProfileFromAuth(user: AuthUser, storedProfile?: unknown): UserProfile {
  const previous = isUserProfile(storedProfile) ? storedProfile : {};

  return {
    ...DEFAULT_USER_PROFILE,
    ...previous,
    name: user.name || previous.name || DEFAULT_USER_PROFILE.name,
    email: user.email || previous.email || DEFAULT_USER_PROFILE.email,
    role: user.role === "admin" ? "Администратор" : "Родитель",
  };
}

export function useUserProfile() {
  return useLocalStorageState<UserProfile>("mvp.user.profile", DEFAULT_USER_PROFILE);
}

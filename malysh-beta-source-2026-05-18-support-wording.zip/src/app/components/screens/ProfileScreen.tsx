import { ChevronRight, Baby, Bookmark, ShoppingBag, Bell, Settings, Clock, Activity } from "lucide-react";
import { Avatar, AvatarFallback } from "../ui/avatar";

interface ProfileScreenProps {
  onNavigate?: (screen: string) => void;
}

const menuItems = [
  {
    id: "child",
    icon: Baby,
    label: "Профиль ребенка",
    subtitle: "Ребенок 0–3 месяца",
  },
  {
    id: "saved",
    icon: Bookmark,
    label: "Сохраненное",
    subtitle: "12 статей",
  },
  {
    id: "reminders",
    icon: Bell,
    label: "Напоминания",
    subtitle: "3 предстоящих",
  },
  {
    id: "tracker",
    icon: Activity,
    label: "Трекер",
    subtitle: "Кормление, сон, подгузники",
  },
  {
    id: "routines",
    icon: Clock,
    label: "Режим дня",
  },
  {
    id: "shopping",
    icon: ShoppingBag,
    label: "Мои списки покупок",
    subtitle: "3 списка",
  },
  {
    id: "settings",
    icon: Settings,
    label: "Настройки",
  },
];

export function ProfileScreen({ onNavigate }: ProfileScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-6 bg-gradient-to-b from-secondary/50 to-transparent">
        <div className="flex items-center gap-4">
          <Avatar className="w-16 h-16">
            <AvatarFallback className="bg-primary text-primary-foreground text-xl">АМ</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h2 className="text-xl font-medium text-foreground mb-1">Анна Михайлова</h2>
            <p className="text-sm text-muted-foreground">anna.m@example.com</p>
          </div>
        </div>
      </div>

      <div className="px-6 py-4">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                if (onNavigate) {
                  if (item.id === "saved") onNavigate("saved");
                  else if (item.id === "reminders") onNavigate("reminders");
                  else if (item.id === "tracker") onNavigate("tracker");
                  else if (item.id === "routines") onNavigate("routines");
                  else if (item.id === "shopping") onNavigate("shopping");
                  else if (item.id === "settings") onNavigate("settings");
                }
              }}
              className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
            >
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center flex-shrink-0">
                <item.icon className="w-5 h-5 text-foreground" />
              </div>
              <div className="flex-1 text-left">
                <div className="font-medium text-foreground">{item.label}</div>
                {item.subtitle && (
                  <div className="text-sm text-muted-foreground">{item.subtitle}</div>
                )}
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
            </button>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-border">
          <button className="w-full h-12 rounded-xl text-destructive font-medium hover:bg-destructive/5 transition-all">
            Выйти из аккаунта
          </button>
        </div>
      </div>
    </div>
  );
}

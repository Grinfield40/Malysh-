import { ArrowLeft, Home } from "lucide-react";
import { Button } from "../ui/button";

interface NotFoundScreenProps {
  onNavigate: (screen: string) => void;
}

export function NotFoundScreen({ onNavigate }: NotFoundScreenProps) {
  return (
    <div className="min-h-[calc(100vh-5rem)] bg-[#e6dde7] px-4 py-6 md:px-8 md:py-10">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-6">
        <img
          src="/not-found-404.png"
          alt="404. Ошибочка вышла... Чиним"
          className="w-full rounded-[28px] object-contain shadow-[0_18px_50px_rgba(52,41,58,0.12)]"
        />
        <div className="flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row">
          <Button onClick={() => onNavigate("home")} className="h-12 rounded-2xl px-6">
            <Home className="mr-2 h-4 w-4" />
            На главную
          </Button>
          <Button onClick={() => window.history.back()} variant="outline" className="h-12 rounded-2xl px-6">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Назад
          </Button>
        </div>
      </div>
    </div>
  );
}

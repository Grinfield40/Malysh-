import { useState } from "react";
import { Bug, DatabaseBackup, KeyRound, Lightbulb, MessageSquare, Send, Star } from "lucide-react";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { getStoredSession, submitBetaFeedback, type BetaFeedbackTopic } from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess } from "../../lib/notify";

export function BetaFeedbackCard({ screen = "home" }: { screen?: string }) {
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const [supportTopic, setSupportTopic] = useState<BetaFeedbackTopic>("other");
  const isSupport = screen === "support";
  const title = isSupport ? "Обратная связь по сайту" : "Отзыв о сайте";
  const description = isSupport
    ? "Баги, вход в аккаунт, потеря данных, ошибки на телефоне и идеи по улучшению."
    : "Что удобно, что мешает, чего не хватает?";
  const placeholder = isSupport
    ? "Например: не могу войти с iPhone, пропали данные ребенка после закрытия браузера, кнопка не нажимается на странице..."
    : "Например: не понял, куда нажать после онбординга...";
  const supportTopics = [
    {
      label: "Проблема со входом",
      value: "login" as const,
      template: "Проблема со входом: ",
      icon: KeyRound,
    },
    {
      label: "Данные пропали",
      value: "data_loss" as const,
      template: "Данные пропали или не сохранились: ",
      icon: DatabaseBackup,
    },
    {
      label: "Баг на странице",
      value: "bug" as const,
      template: "Баг на странице: ",
      icon: Bug,
    },
    {
      label: "Идея улучшения",
      value: "idea" as const,
      template: "Идея улучшения: ",
      icon: Lightbulb,
    },
  ];

  const applySupportTemplate = (topic: BetaFeedbackTopic, template: string) => {
    setSupportTopic(topic);
    setMessage((current) => {
      const trimmed = current.trim();

      if (!trimmed) return template;
      if (trimmed.startsWith(template)) return current;

      return `${template}${trimmed}`;
    });
  };

  const handleSubmit = async () => {
    const session = getStoredSession();
    const text = message.trim();

    if (!session) {
      notifyError(new Error(isSupport ? "Нужно войти в аккаунт, чтобы отправить сообщение." : "Нужно войти в аккаунт, чтобы отправить отзыв."));
      return;
    }

    if (text.length < 4) {
      notifyError(new Error("Напишите пару слов, что именно заметили."));
      return;
    }

    setIsSending(true);

    try {
      await submitBetaFeedback(session.token, {
        message: text,
        rating: rating || null,
        screen,
        topic: isSupport ? supportTopic : "feedback",
      });
      trackEvent("beta_feedback_sent", {
        screen,
        meta: {
          rating: rating || null,
        },
      });
      notifySuccess(isSupport ? "Сообщение отправлено" : "Отзыв отправлен", {
        description: isSupport
          ? "Спасибо, администратор увидит обращение."
          : "Спасибо, администратор увидит сообщение.",
      });
      setMessage("");
      setRating(0);
      setSupportTopic("other");
    } catch (error) {
      notifyError(error, isSupport ? "Не получилось отправить сообщение" : "Не получилось отправить отзыв");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm md:text-base font-medium text-foreground">{title}</h3>
          <p className="text-xs md:text-sm text-muted-foreground">
            {description}
          </p>
        </div>
      </div>

      {isSupport ? (
        <div className="mb-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {supportTopics.map((topic) => {
            const Icon = topic.icon;

            return (
              <button
                key={topic.label}
                type="button"
                onClick={() => applySupportTemplate(topic.value, topic.template)}
                className={`flex min-h-11 items-center gap-2 rounded-xl border px-3 py-2 text-left text-xs font-medium transition-colors ${
                  supportTopic === topic.value
                    ? "border-primary/50 bg-primary/10 text-primary"
                    : "border-border bg-background text-foreground hover:border-primary/40 hover:bg-primary/5"
                }`}
              >
                <Icon className="h-4 w-4 flex-shrink-0 text-primary" />
                {topic.label}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="flex gap-1 mb-3">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              className="text-primary transition-transform hover:scale-110"
              aria-label={`Оценка ${star}`}
            >
              <Star className={`w-5 h-5 ${star <= rating ? "fill-primary" : "text-muted-foreground/40"}`} />
            </button>
          ))}
        </div>
      )}

      <Textarea
        value={message}
        onChange={(event) => setMessage(event.target.value)}
        maxLength={1600}
        placeholder={placeholder}
        className="min-h-[96px] resize-none rounded-xl"
      />

      <Button
        type="button"
        onClick={() => void handleSubmit()}
        disabled={isSending || message.trim().length < 4}
        className="mt-3 w-full rounded-xl"
      >
        <Send className="w-4 h-4" />
        {isSending ? "Отправляем..." : isSupport ? "Отправить сообщение" : "Отправить отзыв"}
      </Button>
    </div>
  );
}

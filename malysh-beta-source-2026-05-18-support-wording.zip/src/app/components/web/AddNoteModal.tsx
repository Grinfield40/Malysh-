import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface AddNoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (note: Note) => void;
}

export interface Note {
  text: string;
  icon: string;
  color: string;
}

const noteIcons = ["💉", "🩺", "🧷", "💊", "📝", "⭐", "💡", "🎯", "📌", "✨", "🎨", "📚"];

const colorOptions = [
  { color: "from-yellow-100 to-yellow-200", borderColor: "border-yellow-300", name: "Желтый" },
  { color: "from-blue-100 to-blue-200", borderColor: "border-blue-300", name: "Синий" },
  { color: "from-pink-100 to-pink-200", borderColor: "border-pink-300", name: "Розовый" },
  { color: "from-green-100 to-green-200", borderColor: "border-green-300", name: "Зеленый" },
  { color: "from-purple-100 to-purple-200", borderColor: "border-purple-300", name: "Фиолетовый" },
  { color: "from-orange-100 to-orange-200", borderColor: "border-orange-300", name: "Оранжевый" },
];

const quickTemplates = [
  { icon: "💉", text: "Сделать прививку", color: "from-red-100 to-red-200", borderColor: "border-red-300" },
  { icon: "🧷", text: "Купить подгузники", color: "from-yellow-100 to-yellow-200", borderColor: "border-yellow-300" },
  { icon: "🩺", text: "Записаться к педиатру", color: "from-blue-100 to-blue-200", borderColor: "border-blue-300" },
  { icon: "💊", text: "Купить витамин D", color: "from-green-100 to-green-200", borderColor: "border-green-300" },
];

export function AddNoteModal({ isOpen, onClose, onAdd }: AddNoteModalProps) {
  const [text, setText] = useState("");
  const [icon, setIcon] = useState("📝");
  const [selectedColor, setSelectedColor] = useState(colorOptions[0]);

  const selectTemplate = (template: typeof quickTemplates[number]) => {
    setText(template.text);
    setIcon(template.icon);
    const matchingColor = colorOptions.find((c) => c.color === template.color);
    if (matchingColor) {
      setSelectedColor(matchingColor);
    }
  };

  const handleSubmit = () => {
    if (!text.trim()) return;

    onAdd({
      text: text.trim(),
      icon,
      color: selectedColor.color,
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setText("");
    setIcon("📝");
    setSelectedColor(colorOptions[0]);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <h2 className="text-2xl font-medium text-foreground">Новая заметка</h2>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Quick Templates */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Быстрые шаблоны</label>
                <div className="grid grid-cols-2 gap-3">
                  {quickTemplates.map((template, idx) => (
                    <button
                      key={idx}
                      onClick={() => selectTemplate(template)}
                      className={`text-left border-2 rounded-xl p-3 transition-all hover:shadow-lg bg-gradient-to-br ${template.color} ${template.borderColor}`}
                    >
                      <div className="text-2xl mb-1">{template.icon}</div>
                      <div className="text-sm font-medium text-foreground">{template.text}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Text */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Текст заметки</label>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Напишите вашу заметку..."
                  className="w-full h-32 px-4 py-3 rounded-xl border-2 border-border bg-background focus:border-primary focus:outline-none resize-none"
                  maxLength={200}
                  required
                />
                <div className="text-xs text-muted-foreground mt-2 text-right">
                  {text.length}/200 символов
                </div>
              </div>

              {/* Icon */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Иконка</label>
                <div className="flex flex-wrap gap-2">
                  {noteIcons.map((e) => (
                    <button
                      key={e}
                      onClick={() => setIcon(e)}
                      className={`w-12 h-12 rounded-xl border-2 text-2xl transition-all ${
                        icon === e
                          ? "border-primary bg-primary/10 scale-110"
                          : "border-border hover:border-primary/30"
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              {/* Color */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Цвет заметки</label>
                <div className="grid grid-cols-3 gap-3">
                  {colorOptions.map((colorOption, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedColor(colorOption)}
                      className={`h-16 rounded-xl border-2 transition-all bg-gradient-to-br ${colorOption.color} ${
                        selectedColor === colorOption
                          ? `${colorOption.borderColor} ring-2 ring-primary ring-offset-2`
                          : "border-border hover:border-primary/30"
                      }`}
                    >
                      <div className="text-xs font-medium text-foreground">{colorOption.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Preview */}
              {text && (
                <div className="bg-secondary/30 rounded-2xl p-4 border-2 border-dashed border-border">
                  <div className="text-sm text-muted-foreground mb-3">Предварительный просмотр:</div>
                  <div
                    className={`bg-gradient-to-br ${selectedColor.color} border-2 ${selectedColor.borderColor} rounded-xl md:rounded-2xl p-3 md:p-5 shadow-lg`}
                  >
                    <div className="flex items-start gap-3 md:gap-4">
                      <div className="w-10 h-10 md:w-12 md:h-12 bg-white rounded-lg md:rounded-xl flex items-center justify-center text-xl md:text-2xl flex-shrink-0 shadow">
                        {icon}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm md:text-base text-foreground">{text}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-border flex gap-3 flex-shrink-0">
              <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button onClick={handleSubmit} disabled={!text.trim()} className="flex-1 rounded-xl">
                Добавить заметку
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { motion, AnimatePresence } from "motion/react";
import { X, Sun, Coffee, Milk, Moon, Baby, Bath, Utensils, Activity } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface AddRoutineModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (routine: RoutineItem) => void;
}

export interface RoutineItem {
  time: string;
  activity: string;
  emoji: string;
  duration: string;
  color: string;
}

const activityTemplates = [
  { emoji: "☀️", label: "Пробуждение", duration: "30", color: "from-yellow-200/30 to-orange-200/30" },
  { emoji: "🍼", label: "Кормление", duration: "20", color: "from-blue-200/30 to-cyan-200/30" },
  { emoji: "🎵", label: "Игры и бодрствование", duration: "60", color: "from-pink-200/30 to-purple-200/30" },
  { emoji: "💤", label: "Сон", duration: "90", color: "from-purple-200/30 to-indigo-200/30" },
  { emoji: "🌳", label: "Прогулка", duration: "120", color: "from-green-200/30 to-emerald-200/30" },
  { emoji: "🛁", label: "Купание", duration: "15", color: "from-cyan-200/30 to-blue-200/30" },
  { emoji: "🥄", label: "Прикорм", duration: "30", color: "from-orange-200/30 to-yellow-200/30" },
  { emoji: "🧸", label: "Тихие игры", duration: "30", color: "from-pink-200/30 to-purple-200/30" },
  { emoji: "🌙", label: "Подготовка ко сну", duration: "20", color: "from-indigo-200/30 to-purple-200/30" },
];

function getCurrentTimeValue() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");

  return `${hours}:${minutes}`;
}

export function AddRoutineModal({ isOpen, onClose, onAdd }: AddRoutineModalProps) {
  const [time, setTime] = useState("");
  const [activity, setActivity] = useState("");
  const [emoji, setEmoji] = useState("⏰");
  const [duration, setDuration] = useState("");
  const [color, setColor] = useState("from-purple-200/30 to-pink-200/30");
  const [customActivity, setCustomActivity] = useState("");
  const trimmedCustomActivity = customActivity.trim();
  const selectedActivity = trimmedCustomActivity || activity;
  const durationValue = Number(duration);
  const validationMessage = !time
    ? "Выберите время события."
    : !selectedActivity
    ? "Выберите шаблон или напишите свое занятие."
    : !duration
    ? "Укажите длительность."
    : !Number.isFinite(durationValue) || durationValue <= 0
    ? "Длительность должна быть больше нуля."
    : "";
  const shouldShowValidation = Boolean(validationMessage && (time || selectedActivity || duration));

  useEffect(() => {
    if (!isOpen) return;

    setTime((value) => value || getCurrentTimeValue());
  }, [isOpen]);

  const selectTemplate = (template: typeof activityTemplates[number]) => {
    setActivity(template.label);
    setEmoji(template.emoji);
    setDuration(template.duration);
    setColor(template.color);
    setCustomActivity("");
    setTime((value) => value || getCurrentTimeValue());
  };

  const handleSubmit = () => {
    if (validationMessage) return;

    onAdd({
      time,
      activity: selectedActivity,
      emoji,
      duration: `${duration} мин`,
      color,
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setTime("");
    setActivity("");
    setEmoji("⏰");
    setDuration("");
    setColor("from-purple-200/30 to-pink-200/30");
    setCustomActivity("");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <h2 className="text-2xl font-medium text-foreground">Добавить событие</h2>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Templates */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  Выберите шаблон или создайте своё
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                  {activityTemplates.map((template, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => selectTemplate(template)}
                      className={`bg-gradient-to-br ${template.color} border-2 rounded-xl p-3 transition-all ${
                        activity === template.label
                          ? "border-primary shadow-lg"
                          : "border-white/50 hover:border-primary/30"
                      }`}
                    >
                      <div className="text-3xl mb-2">{template.emoji}</div>
                      <div className="text-xs font-medium text-foreground">{template.label}</div>
                      <div className="text-[10px] text-muted-foreground mt-1">{template.duration} мин</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Время</label>
                <Input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="rounded-xl"
                  required
                />
              </div>

              {/* Custom Activity */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Или напишите своё занятие
                </label>
                <Input
                  value={customActivity}
                  onChange={(e) => {
                    setCustomActivity(e.target.value);
                    setActivity("");
                  }}
                  placeholder="Например: Массаж"
                  className="rounded-xl"
                />
              </div>

              {/* Duration */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Длительность (минут)</label>
                <Input
                  type="number"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                  placeholder="30"
                  className="rounded-xl"
                  required
                />
              </div>

              {/* Emoji picker */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Выберите иконку</label>
                <div className="flex flex-wrap gap-2">
                  {["⏰", "☀️", "🍼", "💤", "🛁", "🎵", "🧸", "🌳", "🌙", "🥄", "📚", "🎨", "🏃", "🚗"].map((e) => (
                    <button
                      type="button"
                      key={e}
                      onClick={() => setEmoji(e)}
                      className={`w-12 h-12 rounded-xl border-2 text-2xl transition-all ${
                        emoji === e
                          ? "border-primary bg-primary/10 scale-110"
                          : "border-border hover:border-primary/30"
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              {/* Preview */}
              {(activity || customActivity) && time && (
                <div className="bg-secondary/30 rounded-2xl p-4 border-2 border-dashed border-border">
                  <div className="text-sm text-muted-foreground mb-2">Предварительный просмотр:</div>
                  <div className={`bg-gradient-to-br ${color} border-2 border-white/50 rounded-xl p-4`}>
                    <div className="flex items-center gap-3">
                      <div className="text-4xl">{emoji}</div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-primary">{time}</div>
                        <div className="font-medium text-foreground">{customActivity || activity}</div>
                        {duration && <div className="text-sm text-muted-foreground">{duration} мин</div>}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
              {shouldShowValidation ? (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                  {validationMessage}
                </div>
              ) : null}
              <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={Boolean(validationMessage)}
                className="flex-1 rounded-xl"
              >
                Добавить в режим
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

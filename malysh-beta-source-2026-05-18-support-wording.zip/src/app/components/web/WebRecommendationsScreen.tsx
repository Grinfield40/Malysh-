import { motion } from "motion/react";
import { Filter, Heart, ExternalLink, Wrench } from "lucide-react";
import { useState } from "react";
import { PacifierRating } from "../PacifierRating";
import { Button } from "../ui/button";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { useBabyProfile, type BabyProfile } from "../../lib/babyProfile";
import { CareFlowStrip } from "./CareFlowStrip";

const categories = ["Все", "Коляски", "Кроватки", "Питание", "Игрушки", "Одежда", "Гигиена", "Бутылочки", "Мониторы", "Купание"];

const catPalettes = [
  { bg1: "#fff7ed", bg2: "#ede9fe", fur: "#f7c8a8", spots: "#8b5e3c", blush: "#fda4af" },
  { bg1: "#eef2ff", bg2: "#dcfce7", fur: "#f8fafc", spots: "#94a3b8", blush: "#f9a8d4" },
  { bg1: "#fdf2f8", bg2: "#fef3c7", fur: "#d9b99b", spots: "#6b4f3b", blush: "#fb7185" },
  { bg1: "#ecfeff", bg2: "#f5f3ff", fur: "#f5d0fe", spots: "#a855f7", blush: "#f0abfc" },
  { bg1: "#f0fdf4", bg2: "#fff7ed", fur: "#fde68a", spots: "#b45309", blush: "#fdba74" },
  { bg1: "#eff6ff", bg2: "#ffe4e6", fur: "#cbd5e1", spots: "#475569", blush: "#fda4af" },
];

function catPlaceholder(index: number) {
  const palette = catPalettes[(index - 1) % catPalettes.length];
  const shift = (index % 5) * 10;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800">
      <defs>
        <linearGradient id="bg${index}" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stop-color="${palette.bg1}"/>
          <stop offset="100%" stop-color="${palette.bg2}"/>
        </linearGradient>
      </defs>
      <rect width="800" height="800" fill="url(#bg${index})"/>
      <circle cx="${400 - shift}" cy="450" r="205" fill="${palette.fur}"/>
      <path d="M230 320 L285 150 L350 315 Z" fill="${palette.fur}"/>
      <path d="M570 320 L515 150 L450 315 Z" fill="${palette.fur}"/>
      <path d="M260 288 L292 205 L325 292 Z" fill="#fff7ed" opacity=".75"/>
      <path d="M540 288 L508 205 L475 292 Z" fill="#fff7ed" opacity=".75"/>
      <circle cx="${322 - shift}" cy="420" r="22" fill="#312e3f"/>
      <circle cx="${478 - shift}" cy="420" r="22" fill="#312e3f"/>
      <circle cx="${330 - shift}" cy="412" r="7" fill="#ffffff"/>
      <circle cx="${486 - shift}" cy="412" r="7" fill="#ffffff"/>
      <path d="M400 455 L374 484 H426 Z" fill="${palette.spots}"/>
      <path d="M400 484 C380 510 350 508 340 488" fill="none" stroke="#312e3f" stroke-width="12" stroke-linecap="round"/>
      <path d="M400 484 C420 510 450 508 460 488" fill="none" stroke="#312e3f" stroke-width="12" stroke-linecap="round"/>
      <circle cx="${282 - shift}" cy="486" r="28" fill="${palette.blush}" opacity=".45"/>
      <circle cx="${518 - shift}" cy="486" r="28" fill="${palette.blush}" opacity=".45"/>
      <path d="M210 462 H330 M205 505 H330 M470 462 H590 M470 505 H595" stroke="#312e3f" stroke-width="10" stroke-linecap="round" opacity=".45"/>
      <path d="M300 330 C330 285 380 280 400 332 C430 278 490 290 515 335" fill="${palette.spots}" opacity=".18"/>
    </svg>
  `;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const products = [
  {
    id: 1,
    name: "Коляска Bugaboo Fox 5",
    category: "Коляски",
    price: "89 990 ₽",
    rating: 5,
    reviews: 342,
    image: catPlaceholder(1),
    description: "Премиальная модульная коляска с отличной проходимостью",
    approved: 95,
  },
  {
    id: 2,
    name: "Коляска Stokke Xplory",
    category: "Коляски",
    price: "124 990 ₽",
    rating: 5,
    reviews: 256,
    image: catPlaceholder(2),
    description: "Высокая коляска для близкого контакта с малышом",
    approved: 92,
  },
  {
    id: 3,
    name: "Детская кроватка IKEA Sundvik",
    category: "Кроватки",
    price: "12 999 ₽",
    rating: 4,
    reviews: 587,
    image: catPlaceholder(3),
    description: "Классическая деревянная кроватка, растет вместе с ребенком",
    approved: 88,
  },
  {
    id: 4,
    name: "Кроватка Stokke Sleepi",
    category: "Кроватки",
    price: "54 990 ₽",
    rating: 5,
    reviews: 234,
    image: catPlaceholder(4),
    description: "Овальная кроватка-трансформер от 0 до 10 лет",
    approved: 94,
  },
  {
    id: 5,
    name: "Развивающий бизиборд",
    category: "Игрушки",
    price: "3 490 ₽",
    rating: 5,
    reviews: 892,
    image: catPlaceholder(5),
    description: "Деревянная доска с замочками, кнопками и механизмами",
    approved: 97,
  },
  {
    id: 6,
    name: "Конструктор Baby Blocks",
    category: "Игрушки",
    price: "2 290 ₽",
    rating: 4,
    reviews: 1243,
    image: catPlaceholder(6),
    description: "Мягкие кубики для развития мелкой моторики",
    approved: 89,
  },
  {
    id: 7,
    name: "Органическое пюре HiPP",
    category: "Питание",
    price: "145 ₽",
    rating: 5,
    reviews: 2341,
    image: catPlaceholder(7),
    description: "Натуральное овощное пюре без добавок",
    approved: 96,
  },
  {
    id: 8,
    name: "Набор прикорма Gerber",
    category: "Питание",
    price: "890 ₽",
    rating: 4,
    reviews: 1567,
    image: catPlaceholder(8),
    description: "Первый прикорм: каши и пюре",
    approved: 87,
  },
  {
    id: 9,
    name: "Коляска Cybex Priam",
    category: "Коляски",
    price: "156 990 ₽",
    rating: 5,
    reviews: 178,
    image: catPlaceholder(9),
    description: "Люксовая коляска с премиум комфортом",
    approved: 93,
  },
  {
    id: 10,
    name: "Развивающая игрушка Монтессори",
    category: "Игрушки",
    price: "4 590 ₽",
    rating: 5,
    reviews: 734,
    image: catPlaceholder(10),
    description: "Деревянные часы для изучения времени",
    approved: 91,
  },
  {
    id: 11,
    name: "Набор бутылочек Miyoumi (10 предметов)",
    category: "Бутылочки",
    price: "2 800 ₽",
    rating: 5,
    reviews: 456,
    image: catPlaceholder(11),
    description: "Полный набор бутылочек для новорожденных с антиколиковой системой",
    approved: 94,
  },
  {
    id: 12,
    name: "Коляска 3 в 1 Jovola Pepper",
    category: "Коляски",
    price: "25 000 ₽",
    rating: 5,
    reviews: 289,
    image: catPlaceholder(12),
    description: "Универсальная коляска: люлька, прогулочный блок и автокресло",
    approved: 92,
  },
  {
    id: 13,
    name: "Кровать детская Junion Chimmi 120×60",
    category: "Кроватки",
    price: "11 000 ₽",
    rating: 5,
    reviews: 523,
    image: catPlaceholder(13),
    description: "Качественная детская кроватка из массива с регулируемым дном",
    approved: 91,
  },
  {
    id: 14,
    name: "IP-камера Яндекс (2K, поворотная)",
    category: "Мониторы",
    price: "5 000 ₽",
    rating: 5,
    reviews: 1234,
    image: catPlaceholder(14),
    description: "Умная камера с двусторонней связью и ночным видением",
    approved: 96,
  },
  {
    id: 15,
    name: "Радионяня Clear Comfort 2",
    category: "Мониторы",
    price: "3 000 ₽",
    rating: 4,
    reviews: 678,
    image: catPlaceholder(15),
    description: "Надежная радионяня с большим радиусом действия",
    approved: 88,
  },
  {
    id: 16,
    name: "Ванночка складная с термометром",
    category: "Купание",
    price: "3 500 ₽",
    rating: 5,
    reviews: 892,
    image: catPlaceholder(16),
    description: "Компактная ванночка со встроенным термометром и сливом",
    approved: 93,
  },
  {
    id: 17,
    name: "Стульчик-шезлонг Jovola Oscar 3 в 1",
    category: "Игрушки",
    price: "6 500 ₽",
    rating: 5,
    reviews: 445,
    image: catPlaceholder(17),
    description: "Многофункциональный шезлонг-качалка с игровой дугой",
    approved: 90,
  },
  {
    id: 18,
    name: "Подгузники Pampers Premium Care",
    category: "Гигиена",
    price: "1 850 ₽",
    rating: 5,
    reviews: 3456,
    image: catPlaceholder(18),
    description: "Мягкие подгузники премиум класса для новорожденных",
    approved: 97,
  },
  {
    id: 19,
    name: "Крем под подгузник Sanosan",
    category: "Гигиена",
    price: "350 ₽",
    rating: 4,
    reviews: 2134,
    image: catPlaceholder(19),
    description: "Защитный крем против раздражений и опрелостей",
    approved: 89,
  },
  {
    id: 20,
    name: "Боди Body Pillow",
    category: "Одежда",
    price: "700 ₽",
    rating: 5,
    reviews: 567,
    image: catPlaceholder(20),
    description: "Мягкое хлопковое боди для малыша",
    approved: 91,
  },
  {
    id: 21,
    name: "Комбинезон BABYGLORY",
    category: "Одежда",
    price: "1 000 ₽",
    rating: 5,
    reviews: 432,
    image: catPlaceholder(21),
    description: "Теплый комбинезон для прогулок в холодную погоду",
    approved: 92,
  },
  {
    id: 22,
    name: "Аспиратор электрический SISBRO",
    category: "Гигиена",
    price: "1 900 ₽",
    rating: 5,
    reviews: 789,
    image: catPlaceholder(22),
    description: "Электрический назальный аспиратор с музыкой",
    approved: 94,
  },
  {
    id: 23,
    name: "Набор погремушек (12 шт)",
    category: "Игрушки",
    price: "1 300 ₽",
    rating: 4,
    reviews: 623,
    image: catPlaceholder(23),
    description: "Яркие развивающие погремушки для младенцев",
    approved: 86,
  },
  {
    id: 24,
    name: "Матрас детский Junion Napnap",
    category: "Кроватки",
    price: "4 500 ₽",
    rating: 5,
    reviews: 345,
    image: catPlaceholder(24),
    description: "Ортопедический матрас с кокосовой койрой",
    approved: 93,
  },
];

const categoryPriorityByStage: Record<BabyProfile["stage"], string[]> = {
  pregnancy: ["Кроватки", "Гигиена", "Одежда", "Коляски"],
  "0-3": ["Гигиена", "Бутылочки", "Купание", "Коляски"],
  "3-6": ["Игрушки", "Мониторы", "Купание", "Коляски"],
  "6-12": ["Питание", "Игрушки", "Одежда", "Гигиена"],
};

interface WebRecommendationsScreenProps {
  onNavigate: (screen: string) => void;
}

export function WebRecommendationsScreen({ onNavigate }: WebRecommendationsScreenProps) {
  const [activeCategory, setActiveCategory] = useState("Все");
  const [ratingFilter, setRatingFilter] = useState<number>(0); // 0 = все, 4 = 4+, 5 = только 5
  const [savedProductIds, setSavedProductIds] = useLocalStorageState<number[]>("mvp.recommendations.saved", []);
  const { baby, age } = useBabyProfile();

  const suggestedCategories = categoryPriorityByStage[baby.stage || "0-3"];
  const suggestedProducts = products
    .filter((product) => suggestedCategories.includes(product.category))
    .slice(0, 3);

  const priorityScore = (category: string) => {
    const index = suggestedCategories.indexOf(category);
    return index === -1 ? 0 : suggestedCategories.length - index;
  };

  const toggleSavedProduct = (productId: number) => {
    setSavedProductIds((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const filteredProducts = products
    .slice()
    .sort((a, b) => priorityScore(b.category) - priorityScore(a.category) || b.approved - a.approved)
    .filter((p) => activeCategory === "Все" || p.category === activeCategory)
    .filter((p) => ratingFilter === 0 || p.rating >= ratingFilter);

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
          <div className="text-3xl md:text-4xl">💜</div>
          <h1 className="text-2xl md:text-4xl font-medium text-foreground">Мамы одобряют</h1>
        </div>
        <p className="text-sm md:text-lg text-muted-foreground">
          Подборка с учетом профиля {baby.name}: {age.stageLabel}
        </p>
      </motion.div>

      <CareFlowStrip active="recommendations" onNavigate={onNavigate} />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.03 }}
        className="mb-6 md:mb-8 rounded-xl border border-amber-200 bg-amber-50 px-4 py-4 text-amber-950"
      >
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-amber-100 text-amber-700">
            <Wrench className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold uppercase tracking-wide text-amber-700">В разработке</div>
            <p className="mt-1 text-sm leading-relaxed text-amber-900">
              Раздел пока работает как витрина идей: сохранения уже доступны, а живые отзывы, проверки товаров и партнерские ссылки подключим позже.
            </p>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-6 md:mb-8 bg-card border border-border rounded-2xl p-4 md:p-5"
      >
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <div className="max-w-2xl">
            <div className="text-sm font-medium text-primary mb-1">Сейчас актуально для {baby.name}</div>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              {age.recommendationHint}. Начните с этих категорий, а понравившиеся товары сохраняйте сердцем.
            </p>
            <div className="flex flex-wrap gap-2 mt-4">
              {suggestedCategories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveCategory(category)}
                  className="px-3 py-2 rounded-xl bg-primary/10 text-primary text-xs md:text-sm font-medium hover:bg-primary/15 transition-colors"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 lg:min-w-[420px]">
            {suggestedProducts.map((product) => (
              <button
                key={product.id}
                type="button"
                onClick={() => setActiveCategory(product.category)}
                className="text-left rounded-xl bg-secondary/50 border border-border px-3 py-3 hover:border-primary/30 transition-colors"
              >
                <div className="text-xs text-primary mb-1">{product.category}</div>
                <div className="text-sm font-medium text-foreground line-clamp-2">{product.name}</div>
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="mb-6 md:mb-8 space-y-3 md:space-y-4">
        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex gap-2 md:gap-3 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 md:px-6 py-2 md:py-3 rounded-xl md:rounded-2xl whitespace-nowrap text-xs md:text-sm font-medium transition-all border-2 ${
                activeCategory === cat
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-foreground border-border hover:border-primary/30"
              }`}
            >
              {cat}
            </button>
          ))}
        </motion.div>

        {/* Rating Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col md:flex-row md:items-center gap-3 md:gap-4"
        >
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground" />
            <span className="text-xs md:text-sm font-medium text-foreground">Рейтинг:</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0">
            <button
              onClick={() => setRatingFilter(0)}
              className={`px-3 md:px-4 py-2 rounded-lg md:rounded-xl text-xs md:text-sm font-medium transition-all whitespace-nowrap ${
                ratingFilter === 0
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border hover:border-primary/30"
              }`}
            >
              Все
            </button>
            <button
              onClick={() => setRatingFilter(4)}
              className={`px-3 md:px-4 py-2 rounded-lg md:rounded-xl text-xs md:text-sm font-medium transition-all flex items-center gap-1 md:gap-2 whitespace-nowrap ${
                ratingFilter === 4
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border hover:border-primary/30"
              }`}
            >
              <PacifierRating rating={4} size={14} />
              <span>и выше</span>
            </button>
            <button
              onClick={() => setRatingFilter(5)}
              className={`px-3 md:px-4 py-2 rounded-lg md:rounded-xl text-xs md:text-sm font-medium transition-all flex items-center gap-1 md:gap-2 whitespace-nowrap ${
                ratingFilter === 5
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border hover:border-primary/30"
              }`}
            >
              <PacifierRating rating={5} size={14} />
              <span>Только 5</span>
            </button>
          </div>
          <div className="text-xs md:text-sm text-muted-foreground md:ml-auto">
            Найдено: {filteredProducts.length} товаров · сохранено: {savedProductIds.length}
          </div>
        </motion.div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
        {filteredProducts.map((product, idx) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + idx * 0.05 }}
            whileHover={{ y: -8 }}
            className="bg-card border border-border rounded-2xl md:rounded-3xl overflow-hidden hover:border-primary/30 transition-all group cursor-pointer"
          >
            {/* Image */}
            <div className="relative aspect-square overflow-hidden bg-secondary">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-3 md:top-4 right-3 md:right-4 flex gap-2">
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={(event) => {
                    event.stopPropagation();
                    toggleSavedProduct(product.id);
                  }}
                  className={`w-9 h-9 md:w-10 md:h-10 bg-white/90 backdrop-blur-sm rounded-lg md:rounded-xl flex items-center justify-center shadow-lg hover:bg-white transition-colors ${
                    savedProductIds.includes(product.id) ? "text-destructive" : "text-muted-foreground"
                  }`}
                >
                  <Heart
                    className="w-4 h-4 md:w-5 md:h-5"
                    fill={savedProductIds.includes(product.id) ? "currentColor" : "none"}
                  />
                </motion.button>
              </div>
              {product.approved >= 90 && (
                <div className="absolute top-3 md:top-4 left-3 md:left-4 px-2 md:px-3 py-1 bg-primary/90 backdrop-blur-sm rounded-full text-xs font-medium text-white shadow-lg">
                  {product.approved}% одобряют
                </div>
              )}
              <div className="absolute bottom-3 md:bottom-4 left-3 md:left-4 px-3 md:px-4 py-2 bg-white/95 backdrop-blur-sm rounded-xl shadow-lg">
                <div className="text-base md:text-lg font-bold text-foreground">{product.price}</div>
              </div>
            </div>

            {/* Content */}
            <div className="p-4 md:p-6 flex flex-col h-full">
              <div className="text-xs text-primary font-medium mb-2">{product.category}</div>
              <h3 className="text-base md:text-lg font-medium text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2 min-h-[3rem] md:min-h-[3.5rem]">
                {product.name}
              </h3>
              <p className="text-xs md:text-sm text-muted-foreground mb-3 md:mb-4 line-clamp-2 leading-relaxed min-h-[2.5rem]">
                {product.description}
              </p>

              <div className="flex items-center gap-2 mb-3 md:mb-4">
                <PacifierRating rating={product.rating} size={18} />
                <span className="text-xs md:text-sm text-muted-foreground">
                  ({product.reviews})
                </span>
              </div>

              <div className="flex flex-col md:flex-row items-start md:items-center gap-3 md:justify-between pt-3 md:pt-4 border-t border-border mt-auto">
                <div className="text-xl md:text-2xl font-medium text-foreground whitespace-nowrap">{product.price}</div>
                <Button className="w-full md:w-auto rounded-xl bg-primary hover:bg-primary/90 text-sm md:text-xs whitespace-nowrap">
                  <ExternalLink className="w-4 h-4 mr-1.5" />
                  Подробнее
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredProducts.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12 md:py-20"
        >
          <div className="text-5xl md:text-6xl mb-4 md:mb-6">🔍</div>
          <h3 className="text-xl md:text-2xl font-medium text-foreground mb-3">Ничего не найдено</h3>
          <p className="text-sm md:text-base text-muted-foreground mb-4 md:mb-6">
            Попробуйте изменить фильтры или выбрать другую категорию для {baby.name}
          </p>
          <Button
            onClick={() => {
              setActiveCategory("Все");
              setRatingFilter(0);
            }}
            className="rounded-xl md:rounded-2xl"
          >
            Сбросить фильтры
          </Button>
        </motion.div>
      )}
    </div>
  );
}

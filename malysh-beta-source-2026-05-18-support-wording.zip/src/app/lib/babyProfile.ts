import { useMemo } from "react";
import { useLocalStorageState } from "./useLocalStorageState";

export interface BabyProfile {
  name: string;
  birthDate: string;
  stage: "pregnancy" | "0-3" | "3-6" | "6-12";
  heightCm: string;
  weightKg: string;
  bloodType: string;
  emoji: string;
}

export interface BabyAgeInfo {
  days: number;
  weeks: number;
  months: number;
  label: string;
  shortLabel: string;
  stageLabel: string;
  focus: string;
  routineHint: string;
  recommendationHint: string;
}

export const BABY_PROFILE_STORAGE_KEY = "mvp.baby.profile";
export const BABY_ONBOARDING_STORAGE_KEY = "mvp.baby.onboarding.completed";

export const DEFAULT_BABY_PROFILE: BabyProfile = {
  name: "Мира",
  birthDate: "2026-02-13",
  stage: "0-3",
  heightCm: "58",
  weightKg: "5.4",
  bloodType: "—",
  emoji: "👶",
};

function plural(value: number, one: string, few: string, many: string) {
  const mod10 = value % 10;
  const mod100 = value % 100;

  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return few;
  return many;
}

function stageFromDays(days: number): BabyProfile["stage"] {
  if (days < 0) return "pregnancy";
  if (days <= 92) return "0-3";
  if (days <= 183) return "3-6";
  return "6-12";
}

export function inferBabyStageFromBirthDate(birthDate: string): BabyProfile["stage"] {
  const birthTime = Date.parse(birthDate);

  if (Number.isNaN(birthTime)) {
    return "0-3";
  }

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const days = Math.floor((today - birthTime) / 86400000);

  return stageFromDays(days);
}

export function normalizeBabyProfile(profile: BabyProfile): BabyProfile {
  return {
    ...profile,
    name: profile.name.trim() || "Малыш",
    birthDate: profile.birthDate || DEFAULT_BABY_PROFILE.birthDate,
    stage: profile.stage || inferBabyStageFromBirthDate(profile.birthDate),
    heightCm: profile.heightCm.trim(),
    weightKg: profile.weightKg.trim(),
    bloodType: profile.bloodType.trim() || "—",
    emoji: profile.emoji.trim() || "👶",
  };
}

function calendarMonthsSince(birthDate: Date, todayDate: Date) {
  let months =
    (todayDate.getFullYear() - birthDate.getFullYear()) * 12 +
    todayDate.getMonth() -
    birthDate.getMonth();

  if (todayDate.getDate() < birthDate.getDate()) {
    months -= 1;
  }

  return Math.max(0, months);
}

function stageCopy(stage: BabyProfile["stage"]) {
  if (stage === "pregnancy") {
    return {
      stageLabel: "Подготовка к рождению",
      focus: "собрать базовые вещи и убрать лишний шум из подготовки",
      routineHint: "соберите спокойный шаблон первых дней: кормление, сон, прогулка, уход",
      recommendationHint: "сначала пригодятся сон, гигиена, аптечка и базовая одежда",
    };
  }

  if (stage === "0-3") {
    return {
      stageLabel: "0-3 месяца",
      focus: "сон, кормление, восстановление и мягкая предсказуемость дня",
      routineHint: "ориентир по бодрствованию: 45-90 минут, дальше лучше смотреть на сигналы усталости",
      recommendationHint: "сейчас полезнее всего базовый уход, сон, кормление и безопасная прогулка",
    };
  }

  if (stage === "3-6") {
    return {
      stageLabel: "3-6 месяцев",
      focus: "ритм дня, интерес к миру и подготовка к первым новым навыкам",
      routineHint: "окна бодрствования обычно становятся длиннее: примерно 1.5-2.5 часа",
      recommendationHint: "стоит смотреть товары для прогулок, развития, сна и первых попыток прикорма",
    };
  }

  return {
    stageLabel: "6-12 месяцев",
    focus: "прикорм, движение, безопасность дома и более устойчивый режим",
    routineHint: "режим уже можно собирать вокруг сна, кормлений, прогулок и прикорма",
    recommendationHint: "актуальны прикорм, безопасность дома, удобная одежда и развивающие игрушки",
  };
}

export function getBabyAgeInfo(profile: BabyProfile): BabyAgeInfo {
  const birthTime = Date.parse(profile.birthDate);
  const safeBirthTime = Number.isNaN(birthTime) ? Date.parse(DEFAULT_BABY_PROFILE.birthDate) : birthTime;
  const now = new Date();
  const todayDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const today = todayDate.getTime();
  const birthDate = new Date(safeBirthTime);
  const days = Math.floor((today - safeBirthTime) / 86400000);
  const weeks = Math.max(0, Math.floor(days / 7));
  const months = calendarMonthsSince(birthDate, todayDate);
  const stage = profile.stage || stageFromDays(days);
  const copy = stageCopy(stage);

  if (days < 0) {
    const daysLeft = Math.abs(days);
    return {
      days,
      weeks: 0,
      months: 0,
      label: `до рождения ${daysLeft} ${plural(daysLeft, "день", "дня", "дней")}`,
      shortLabel: "ожидание",
      ...copy,
    };
  }

  const label =
    days < 31
      ? `${days} ${plural(days, "день", "дня", "дней")}`
      : `${months} ${plural(months, "месяц", "месяца", "месяцев")}`;

  return {
    days,
    weeks,
    months,
    label,
    shortLabel: `${weeks} ${plural(weeks, "неделя", "недели", "недель")}`,
    ...copy,
  };
}

export function useBabyProfile() {
  const [baby, setBaby] = useLocalStorageState<BabyProfile>(BABY_PROFILE_STORAGE_KEY, DEFAULT_BABY_PROFILE);
  const age = useMemo(() => getBabyAgeInfo(baby), [baby]);

  return { baby, setBaby, age };
}

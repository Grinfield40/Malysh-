import { motion } from "motion/react";
import { Check, Plus } from "lucide-react";
import { useState } from "react";
import { Progress } from "../ui/progress";
import { AddShoppingItemModal, ShoppingItem } from "./AddShoppingItemModal";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { trackEvent } from "../../lib/analytics";
import { notifySuccess } from "../../lib/notify";

const categories = [
  {
    id: "main",
    name: "Основные покупки",
    items: [
      { id: "miyoumi-bottles", name: "Набор бутылочек Miyoumi (10 предметов)", checked: false, priority: "high", price: "2 800 ₽" },
      { id: "pacifiers", name: "Соски-пустышки M&B (набор 2 шт)", checked: false, priority: "medium", price: "500 ₽" },
      { id: "junion-crib", name: "Кровать детская Junion Chimmi 120×60", checked: false, priority: "high", price: "11 000 ₽" },
      { id: "junion-mattress", name: "Матрас детский Junion Napnap", checked: false, priority: "high", price: "4 500 ₽" },
      { id: "jovola-stroller", name: "Коляска 3 в 1 Jovola Pepper", checked: false, priority: "high", price: "25 000 ₽" },
      { id: "jovola-chair", name: "Стульчик-шезлонг Jovola Oscar 3 в 1", checked: false, priority: "medium", price: "6 500 ₽" },
      { id: "yandex-camera", name: "IP-камера Яндекс (2K, поворотная)", checked: false, priority: "medium", price: "5 000 ₽" },
      { id: "radio-nanny", name: "Радионяня Clear Comfort 2", checked: false, priority: "medium", price: "3 000 ₽" },
    ],
  },
  {
    id: "consumables",
    name: "Расходники",
    items: [
      { id: "pampers", name: "Подгузники Pampers Premium Care (5 упаковок)", checked: false, priority: "high", price: "9 250 ₽" },
      { id: "diapers-sheet", name: "Пеленки одноразовые Helen Harper (5 упаковок)", checked: false, priority: "high", price: "3 250 ₽" },
      { id: "wipes", name: "Влажные салфетки AURA (2 упаковки)", checked: false, priority: "medium", price: "1 740 ₽" },
      { id: "mattress-cover", name: "Наматрасник непромокаемый (10 шт)", checked: false, priority: "high", price: "7 000 ₽" },
      { id: "cream", name: "Крем под подгузник Sanosan (3 шт)", checked: false, priority: "high", price: "1 050 ₽" },
      { id: "bath-product", name: "Средство для купания Chicco", checked: false, priority: "medium", price: "1 100 ₽" },
    ],
  },
  {
    id: "bathing",
    name: "Купание и уход",
    items: [
      { id: "bath", name: "Ванночка складная с термометром", checked: false, priority: "high", price: "3 500 ₽" },
      { id: "sterilizer", name: "Подогреватель-стерилизатор бутылочек 8 в 1", checked: false, priority: "medium", price: "1 900 ₽" },
      { id: "aspirator", name: "Аспиратор электрический SISBRO", checked: false, priority: "medium", price: "1 900 ₽" },
    ],
  },
  {
    id: "clothes",
    name: "Одежда",
    items: [
      { id: "body", name: "Боди Body Pillow", checked: false, priority: "high", price: "700 ₽" },
      { id: "romper", name: "Комбинезон BABYGLORY", checked: false, priority: "high", price: "1 000 ₽" },
      { id: "socks", name: "Носки тёплые", checked: false, priority: "medium", price: "400 ₽" },
      { id: "cap", name: "Чепчик NEVALYASHKINO", checked: false, priority: "medium", price: "550 ₽" },
      { id: "swaddles", name: "Набор пеленок Махутошка (3 набора)", checked: false, priority: "high", price: "3 600 ₽" },
    ],
  },
  {
    id: "home",
    name: "Дом и организация",
    items: [
      { id: "changing-table", name: "Пеленальный столик складной с ванночкой", checked: false, priority: "medium", price: "3 100 ₽" },
      { id: "detergent", name: "Стиральный порошок Tide", checked: false, priority: "low", price: "800 ₽" },
    ],
  },
  {
    id: "fun",
    name: "Развлечения и комфорт",
    items: [
      { id: "rattles", name: "Набор погремушек (12 шт)", checked: false, priority: "low", price: "1 300 ₽" },
      { id: "nightlight", name: "Ночник с белым шумом", checked: false, priority: "medium", price: "1 600 ₽" },
      { id: "pillow", name: "Подушка детская (гусиный пух)", checked: false, priority: "low", price: "1 200 ₽" },
    ],
  },
  {
    id: "additional",
    name: "Дополнительно",
    items: [
      { id: "electric-chair", name: "Электрошезлонг CINLANKIDS", checked: false, priority: "low", price: "13 500 ₽" },
      { id: "cpr-device", name: "Устройство СЛР (manual)", checked: false, priority: "medium", price: "800 ₽" },
    ],
  },
];

const categoryDetails: Record<string, { icon: string; hint: string; accent: string; badge: string }> = {
  main: {
    icon: "🛏️",
    hint: "Крупные вещи и база для первых недель",
    accent: "from-primary/70 to-accent/70",
    badge: "База",
  },
  consumables: {
    icon: "🧴",
    hint: "То, что быстро заканчивается",
    accent: "from-accent/70 to-pink-300/70",
    badge: "Запас",
  },
  bathing: {
    icon: "🛁",
    hint: "Купание, аптечка и ежедневный уход",
    accent: "from-sky-300/80 to-primary/60",
    badge: "Уход",
  },
  clothes: {
    icon: "👕",
    hint: "Одежда по сезону и размеру",
    accent: "from-emerald-300/80 to-primary/60",
    badge: "Гардероб",
  },
  home: {
    icon: "🏠",
    hint: "Организация пространства дома",
    accent: "from-primary/60 to-violet-300/80",
    badge: "Дом",
  },
  fun: {
    icon: "🧸",
    hint: "Комфорт, развитие и спокойные вечера",
    accent: "from-yellow-300/80 to-accent/70",
    badge: "Комфорт",
  },
  additional: {
    icon: "✨",
    hint: "Опциональные вещи, которые можно решить позже",
    accent: "from-slate-300/80 to-primary/60",
    badge: "Позже",
  },
};

export function WebShoppingScreen() {
  const [items, setItems] = useLocalStorageState("mvp.shopping.items", categories);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleAddItem = (item: ShoppingItem) => {
    const newItem = {
      id: `custom-${Date.now()}`,
      name: item.name,
      checked: false,
      priority: item.priority,
      price: item.price,
    };

    setItems((prev) =>
      prev.map((category) =>
        category.name === item.category
          ? { ...category, items: [newItem, ...category.items] }
          : category
      )
    );
    trackEvent("shopping_item_added", {
      screen: "shopping",
      meta: {
        category: item.category,
        priority: item.priority,
        hasPrice: Boolean(item.price),
      },
    });
    notifySuccess("Покупка добавлена");
  };

  const totalItems = items.reduce((acc, cat) => acc + cat.items.length, 0);
  const checkedItems = items.reduce(
    (acc, cat) => acc + cat.items.filter((item) => item.checked).length,
    0
  );
  const remainingItems = totalItems - checkedItems;
  const progress = totalItems > 0 ? (checkedItems / totalItems) * 100 : 0;
  const highPriorityLeft = items.reduce(
    (acc, cat) =>
      acc + cat.items.filter((item) => !item.checked && item.priority === "high").length,
    0
  );
  const totalPrice = items.reduce(
    (acc, cat) =>
      acc +
      cat.items.reduce((sum, item) => {
        if (!item.checked && item.price) {
          const price = parseInt(item.price.replace(/[^\d]/g, ""));
          return sum + price;
        }
        return sum;
      }, 0),
    0
  );

  const toggleItem = (categoryId: string, itemId: string) => {
    const category = items.find((itemCategory) => itemCategory.id === categoryId);
    const currentItem = category?.items.find((item) => item.id === itemId);

    setItems((prev) =>
      prev.map((cat) =>
        cat.id === categoryId
          ? {
              ...cat,
              items: cat.items.map((item) =>
                item.id === itemId ? { ...item, checked: !item.checked } : item
              ),
            }
          : cat
      )
    );
    trackEvent("shopping_item_toggled", {
      screen: "shopping",
      meta: {
        categoryId,
        checked: !currentItem?.checked,
        priority: currentItem?.priority,
      },
    });
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-8 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between mb-5">
          <div className="max-w-2xl">
            <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-2">Что купить</h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Соберите покупки для малыша по категориям и отмечайте готовое.
            </p>
            <div className="mt-3 flex flex-wrap gap-2 text-xs font-medium text-primary">
              <span className="rounded-full bg-primary/10 px-3 py-1">Сохраняем в аккаунте</span>
              <span className="rounded-full bg-accent/10 px-3 py-1">Важное видно сразу</span>
            </div>
          </div>
          <motion.button
            onClick={() => {
              setIsModalOpen(true);
              trackEvent("shopping_add_modal_opened", {
                screen: "shopping",
              });
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="h-12 w-full justify-center rounded-2xl bg-primary px-5 text-sm font-medium text-primary-foreground shadow-lg shadow-primary/20 transition-colors hover:bg-primary/90 sm:w-auto md:min-w-[190px] md:text-base flex items-center gap-2"
          >
            <Plus className="w-4 h-4 md:w-5 md:h-5" />
            <span className="hidden md:inline">Добавить пункт</span>
            <span className="md:hidden">Добавить</span>
          </motion.button>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 md:gap-4">
          <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 to-white p-4">
            <div className="text-xs md:text-sm text-muted-foreground mb-1">Прогресс списка</div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-2xl md:text-3xl font-medium text-foreground">
                {checkedItems}
              </span>
              <span className="text-lg md:text-xl text-muted-foreground">/ {totalItems}</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
          <div className="rounded-2xl border border-accent/20 bg-gradient-to-br from-accent/10 to-white p-4">
            <div className="text-xs md:text-sm text-muted-foreground mb-1">Осталось купить</div>
            <div className="text-2xl md:text-3xl font-medium text-foreground">
              {totalPrice.toLocaleString("ru-RU")} ₽
            </div>
            <div className="text-xs md:text-sm text-muted-foreground mt-1">
              {remainingItems} товаров
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="text-xs md:text-sm text-muted-foreground mb-1">Важное вперед</div>
            <div className="text-2xl md:text-3xl font-medium text-foreground">
              {highPriorityLeft}
            </div>
            <div className="text-xs md:text-sm text-muted-foreground mt-1">
              пунктов с высоким приоритетом
            </div>
          </div>
        </div>
      </motion.div>

      {totalItems === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-3xl border-2 border-dashed border-border bg-card px-5 py-12 text-center"
        >
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 text-3xl">
            🛒
          </div>
          <h2 className="mb-2 text-xl font-medium text-foreground">Список покупок пуст</h2>
          <p className="mx-auto mb-5 max-w-md text-sm text-muted-foreground">
            Добавьте первый пункт: подгузники, смесь, аптечку или любую вещь, которую нужно не забыть.
          </p>
          <Button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="h-11 rounded-xl px-5"
          >
            <Plus className="h-4 w-4" />
            Добавить покупку
          </Button>
        </motion.div>
      ) : null}

      {totalItems > 0 ? (
        <div className="mb-4 flex gap-2 overflow-x-auto pb-2 md:hidden">
          {items.map((category) => (
            <a
              key={category.id}
              href={`#shopping-${category.id}`}
              className="flex-shrink-0 rounded-full border border-border bg-card px-3 py-2 text-xs font-medium text-foreground"
            >
              {categoryDetails[category.id]?.badge || "Список"} · {category.items.length}
            </a>
          ))}
        </div>
      ) : null}

      {/* Categories Cards */}
      <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 ${totalItems === 0 ? "hidden" : ""}`}>
        {items.map((category, catIdx) => {
          const catChecked = category.items.filter((i) => i.checked).length;
          const catTotal = category.items.length;
          const catProgress = catTotal > 0 ? (catChecked / catTotal) * 100 : 0;
          const details = categoryDetails[category.id] || {
            icon: "🛒",
            hint: "Дополнительная категория",
            accent: "from-primary/60 to-accent/60",
            badge: "Список",
          };
          const catPrice = category.items.reduce((sum, item) => {
            if (!item.checked && item.price) {
              const price = parseInt(item.price.replace(/[^\d]/g, ""));
              return sum + price;
            }
            return sum;
          }, 0);

          return (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + catIdx * 0.05 }}
              id={`shopping-${category.id}`}
              className="relative scroll-mt-24 overflow-hidden bg-card border border-border rounded-2xl md:rounded-3xl p-4 md:p-6 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5 transition-all"
            >
              <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${details.accent}`} />
              {/* Category Header */}
              <div className="mb-4">
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-secondary text-2xl">
                      {details.icon}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-lg md:text-xl font-medium text-foreground">
                        {category.name}
                      </h3>
                      <p className="mt-1 text-xs md:text-sm text-muted-foreground">
                        {details.hint}
                      </p>
                    </div>
                  </div>
                  <div className="shrink-0 text-sm text-muted-foreground bg-secondary px-3 py-1 rounded-full">
                    {details.badge} · {catChecked}/{catTotal}
                  </div>
                </div>
                <div className="space-y-2">
                  <Progress value={catProgress} className="h-1.5" />
                  <div className="flex items-center justify-between text-xs md:text-sm">
                    <span className="text-muted-foreground">
                      {catTotal - catChecked > 0
                        ? `Осталось: ${catTotal - catChecked}`
                        : "Все куплено!"}
                    </span>
                    {catPrice > 0 && (
                      <span className="font-medium text-primary">
                        Остаток: {catPrice.toLocaleString("ru-RU")} ₽
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                {category.items.length === 0 ? (
                  <div className="rounded-2xl border border-dashed border-border bg-secondary/30 px-4 py-6 text-center">
                    <div className="mb-2 text-3xl">{details.icon}</div>
                    <div className="text-sm font-medium text-foreground">В категории пока нет товаров</div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Добавьте пункт, чтобы не держать покупки в голове.
                    </p>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsModalOpen(true)}
                      className="mt-4 h-9 rounded-xl px-4 text-xs"
                    >
                      Добавить пункт
                    </Button>
                  </div>
                ) : category.items.map((item, itemIdx) => (
                  <motion.button
                    key={item.id}
                    onClick={() => toggleItem(category.id, item.id)}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 + catIdx * 0.05 + itemIdx * 0.02 }}
                    whileHover={{ x: 4 }}
                    className="w-full rounded-2xl border border-transparent bg-secondary/45 p-3 text-left transition-all group hover:border-primary/20 hover:bg-secondary"
                  >
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all mt-0.5 ${
                          item.checked
                            ? "bg-primary border-primary"
                            : "border-border bg-card group-hover:border-primary/50"
                        }`}
                      >
                        {item.checked && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2 mb-1">
                          <h4
                            className={`text-sm font-medium ${
                              item.checked
                                ? "text-muted-foreground line-through"
                                : "text-foreground"
                            }`}
                          >
                            {item.name}
                          </h4>
                          <span
                            className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 ${
                              item.priority === "high"
                                ? "bg-destructive/10 text-destructive"
                                : item.priority === "medium"
                                ? "bg-accent/10 text-accent-foreground"
                                : "bg-muted text-muted-foreground"
                            }`}
                          >
                            {item.priority === "high"
                              ? "Важно"
                              : item.priority === "medium"
                              ? "Средне"
                              : "Позже"}
                          </span>
                        </div>
                        {item.price && (
                          <div
                            className={`text-sm font-medium ${
                              item.checked
                                ? "text-muted-foreground line-through"
                                : "text-primary"
                            }`}
                          >
                            {item.price}
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Add Shopping Item Modal */}
      <AddShoppingItemModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddItem}
      />
    </div>
  );
}

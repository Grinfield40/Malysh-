import { motion, AnimatePresence } from "motion/react";
import { X, Bell, Check, Trash2 } from "lucide-react";
import { Button } from "../ui/button";
import { useLocalStorageState } from "../../lib/useLocalStorageState";

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const notifications = [
  {
    id: 1,
    type: "reminder",
    title: "Прививка АКДС через час",
    message: "Не забудьте взять с собой полис и свидетельство о рождении",
    time: "10 минут назад",
    read: false,
    icon: "💉",
  },
  {
    id: 2,
    type: "forum",
    title: "Новый ответ в обсуждении",
    message: "Мария ответила в теме 'Как справиться с коликами'",
    time: "2 часа назад",
    read: false,
    icon: "💬",
  },
  {
    id: 3,
    type: "milestone",
    title: "Новый этап развития!",
    message: "Ваш малыш достиг этапа '3 месяца' - посмотрите что нового",
    time: "Вчера",
    read: true,
    icon: "⭐",
  },
  {
    id: 4,
    type: "shopping",
    title: "Время пополнить запасы",
    message: "Подгузники заканчиваются - не забудьте купить",
    time: "2 дня назад",
    read: true,
    icon: "🛒",
  },
];

export function NotificationsPanel({ isOpen, onClose }: NotificationsPanelProps) {
  const [items, setItems] = useLocalStorageState("mvp.notifications.items", notifications);
  const unreadCount = items.filter((n) => !n.read).length;

  const handleMarkAsRead = (id: number) => {
    setItems((prev) =>
      prev.map((notification) =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const handleDelete = (id: number) => {
    setItems((prev) => prev.filter((notification) => notification.id !== id));
  };

  const handleMarkAllRead = () => {
    setItems((prev) => prev.map((notification) => ({ ...notification, read: true })));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 md:hidden"
          />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 md:top-20 md:bottom-auto md:right-4 w-full md:w-[420px] md:max-h-[600px] bg-background md:rounded-3xl shadow-2xl z-50 flex flex-col overflow-hidden border-l md:border border-border"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0 bg-gradient-to-r from-primary/10 to-accent/10">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Bell className="w-6 h-6 text-primary" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-white text-xs rounded-full flex items-center justify-center font-medium">
                      {unreadCount}
                    </span>
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-medium text-foreground">Уведомления</h2>
                  <p className="text-xs text-muted-foreground">{unreadCount} непрочитанных</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Actions */}
            {unreadCount > 0 && (
              <div className="px-6 py-3 border-b border-border bg-secondary/30">
                <button
                  onClick={handleMarkAllRead}
                  className="text-sm text-primary hover:underline flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Отметить все как прочитанное
                </button>
              </div>
            )}

            {/* Notifications List */}
            <div className="flex-1 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full py-12 px-6">
                  <div className="text-6xl mb-4">🔔</div>
                  <h3 className="text-lg font-medium text-foreground mb-2">Нет уведомлений</h3>
                  <p className="text-sm text-muted-foreground text-center">
                    Здесь будут появляться напоминания и важные события
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {items.map((notification, idx) => (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`p-4 hover:bg-secondary/30 transition-all cursor-pointer ${
                        !notification.read ? "bg-primary/5" : ""
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        {/* Icon */}
                        <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                          {notification.icon}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h4 className={`text-sm font-medium ${!notification.read ? "text-foreground" : "text-muted-foreground"}`}>
                              {notification.title}
                            </h4>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-1" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">{notification.time}</span>
                            <div className="flex items-center gap-2">
                              {!notification.read && (
                                <button
                                  onClick={() => handleMarkAsRead(notification.id)}
                                  className="text-xs text-primary hover:underline"
                                >
                                  Прочитано
                                </button>
                              )}
                              <button
                                onClick={() => handleDelete(notification.id)}
                                className="p-1 hover:bg-destructive/10 rounded transition-colors"
                              >
                                <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-border bg-secondary/30 flex-shrink-0">
              <Button variant="ghost" className="w-full text-sm" onClick={onClose}>
                Закрыть
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { motion } from "motion/react";
import { Bookmark, Clock, MessageSquare } from "lucide-react";
import { useState } from "react";

const tabs = ["Статьи", "Обсуждения", "Списки"];

const savedArticles = [
  { id: 1, emoji: "🩺", category: "Здоровье", title: "Когда нужен врач, а когда можно наблюдать", time: "5 мин", savedDate: "сегодня" },
  { id: 2, emoji: "🍼", category: "Кормление", title: "Как понять, что малышу хватает молока", time: "7 мин", savedDate: "вчера" },
  { id: 3, emoji: "💤", category: "Сон", title: "Спокойный ритуал перед сном", time: "4 мин", savedDate: "2 дня назад" },
];

const savedPosts = [
  { id: 1, title: "Как мягко выстроить режим дня?", author: "Мария К.", comments: 18, savedDate: "сегодня" },
];

export function WebSavedScreen() {
  const [activeTab, setActiveTab] = useState("Статьи");

  return (
    <div className="p-8 pt-28 max-w-[1400px] mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-medium text-foreground mb-2">Сохраненное</h1>
        <p className="text-lg text-muted-foreground">Ваши избранные материалы</p>
      </motion.div>

      {/* Tabs */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="flex gap-3 mb-8"
      >
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-6 py-3 rounded-2xl text-sm font-medium transition-all border-2 ${
              activeTab === tab
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-foreground border-border hover:border-primary/30"
            }`}
          >
            {tab}
          </button>
        ))}
      </motion.div>

      {/* Content */}
      {activeTab === "Статьи" && (
        savedArticles.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-6">📚</div>
            <h3 className="text-2xl font-medium text-foreground mb-3">Пока нет сохраненных статей</h3>
            <p className="text-muted-foreground">Сохраняйте полезные статьи для быстрого доступа</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {savedArticles.map((article, idx) => (
              <motion.div
                key={article.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + idx * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-card border border-border rounded-3xl p-6 cursor-pointer hover:border-primary/30 transition-all"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center text-3xl">
                    {article.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full">
                      {article.category}
                    </span>
                    <h3 className="text-lg font-medium text-foreground mt-2 mb-1">{article.title}</h3>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{article.time}</span>
                    </div>
                    <span>•</span>
                    <span>{article.savedDate}</span>
                  </div>
                  <Bookmark className="w-5 h-5 text-primary fill-primary" />
                </div>
              </motion.div>
            ))}
          </div>
        )
      )}

      {activeTab === "Обсуждения" && (
        savedPosts.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-6">💬</div>
            <h3 className="text-2xl font-medium text-foreground mb-3">Пока нет сохраненных обсуждений</h3>
            <p className="text-muted-foreground">Сохраняйте интересные обсуждения с форума</p>
          </div>
        ) : (
          <div className="space-y-4">
            {savedPosts.map((post, idx) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + idx * 0.1 }}
                whileHover={{ x: 4 }}
                className="bg-card border border-border rounded-2xl p-6 cursor-pointer hover:border-primary/30 transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-medium text-foreground flex-1">{post.title}</h3>
                  <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full whitespace-nowrap ml-4">
                    {post.category}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>{post.comments} ответов</span>
                    </div>
                    <span>•</span>
                    <span>Сохранено {post.savedDate}</span>
                  </div>
                  <Bookmark className="w-5 h-5 text-primary fill-primary" />
                </div>
              </motion.div>
            ))}
          </div>
        )
      )}

      {activeTab === "Списки" && (
        <div className="text-center py-20">
          <div className="text-6xl mb-6">📋</div>
          <h3 className="text-2xl font-medium text-foreground mb-3">Пока нет сохраненных списков</h3>
          <p className="text-muted-foreground">Сохраняйте чеклисты покупок для быстрого доступа</p>
        </div>
      )}
    </div>
  );
}

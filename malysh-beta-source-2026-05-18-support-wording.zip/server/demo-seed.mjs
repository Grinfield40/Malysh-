import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
loadEnvFile(join(__dirname, "..", ".env"));

const apiBase = normalizeApiBase(
  process.env.MALYSH_SEED_API_URL ||
    process.env.MALYSH_PUBLIC_URL ||
    "http://127.0.0.1:8787"
);
const inviteCode = String(process.env.MALYSH_BETA_INVITE_CODE || "").trim();

const adminAccount = {
  name: "Бета Админ",
  email: "admin@malysh.local",
  password: "Admin12345!",
};

const demoAccount = {
  name: "Демо Родитель",
  email: "demo@malysh.local",
  password: "Demo12345!",
};

const todayKey = getDateKey(new Date());
const tomorrowKey = addDays(todayKey, 1);
const nextWeekKey = addDays(todayKey, 7);
const now = new Date();

try {
  await assertApiOnline();

  const adminSession = await ensureAccount(adminAccount);
  const demoSession = await ensureAccount(demoAccount);

  await replaceAccountStorage(demoSession.token, buildDemoStorage());
  await ensureDemoForumPost(demoSession.token);

  console.log("");
  console.log("Beta demo data is ready.");
  console.log(`App: ${apiBase}`);
  console.log(`Demo login: ${demoAccount.email}`);
  console.log(`Demo password: ${demoAccount.password}`);
  console.log(`Admin login for fresh DB: ${adminAccount.email}`);
  console.log(`Admin password for fresh DB: ${adminAccount.password}`);
  console.log("");
  console.log("Note: admin@malysh.local is admin only when this seed creates the first user in a fresh DB.");
  console.log(`Current admin seed user role: ${adminSession.user.role}`);
} catch (error) {
  console.error("");
  console.error(error instanceof Error ? error.message : error);
  console.error("");
  console.error("Start the local API first, then run: npm.cmd run demo:seed");
  process.exitCode = 1;
}

function normalizeApiBase(value) {
  return String(value || "").replace(/\/+$/, "");
}

async function assertApiOnline() {
  const response = await fetch(`${apiBase}/api/health`).catch(() => null);

  if (!response?.ok) {
    throw new Error(`Local API is not available at ${apiBase}.`);
  }
}

async function ensureAccount(account) {
  const registerResponse = await postJson("/api/auth/register", {
    name: account.name,
    email: account.email,
    password: account.password,
    inviteCode,
  });

  if (registerResponse.ok) {
    return registerResponse.data;
  }

  if (registerResponse.status !== 409) {
    throw new Error(registerResponse.data?.error || `Could not create ${account.email}.`);
  }

  const loginResponse = await postJson("/api/auth/login", {
    email: account.email,
    password: account.password,
  });

  if (!loginResponse.ok) {
    throw new Error(
      `Account ${account.email} already exists, but the seed password did not work. Use the existing password or delete that demo account.`
    );
  }

  return loginResponse.data;
}

async function replaceAccountStorage(token, storage) {
  const response = await postJson(
    "/api/account/storage",
    { storage },
    {
      method: "PUT",
      token,
    }
  );

  if (!response.ok) {
    throw new Error(response.data?.error || "Could not write demo storage.");
  }
}

async function ensureDemoForumPost(token) {
  const title = "Демо: как мягко настроить дневной сон?";
  const listResponse = await requestJson(
    `/api/forum/posts?search=${encodeURIComponent(title)}`,
    { token }
  );

  if (!listResponse.ok) return;

  const alreadyExists = listResponse.data.posts?.some((post) => post.title === title);
  if (alreadyExists) return;

  const createResponse = await postJson(
    "/api/forum/posts",
    {
      title,
      category: "sleep",
      tags: ["сон", "режим", "демо"],
      content:
        "Это демо-тема для бета-пакета. Здесь можно проверить список форума, открытие темы, ответы и жалобу в админке.",
    },
    { token }
  );

  if (!createResponse.ok) {
    throw new Error(createResponse.data?.error || "Could not create demo forum post.");
  }
}

async function postJson(path, body, options = {}) {
  return requestJson(path, {
    ...options,
    method: options.method || "POST",
    body,
  });
}

async function requestJson(path, options = {}) {
  const response = await fetch(`${apiBase}${path}`, {
    method: options.method || "GET",
    headers: {
      "Content-Type": "application/json",
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  }).catch((error) => {
    throw new Error(`Request failed: ${error.message}`);
  });
  const data = await response.json().catch(() => ({}));

  return {
    ok: response.ok,
    status: response.status,
    data,
  };
}

function buildDemoStorage() {
  return {
    "mvp.user.profile": {
      name: "Демо Родитель",
      email: demoAccount.email,
      role: "Родитель",
    },
    "mvp.baby.profile": {
      name: "Кирилл",
      birthDate: "2025-12-01",
      stage: "3-6",
      heightCm: "68",
      weightKg: "7.4",
      bloodType: "—",
      emoji: "👶",
    },
    "mvp.baby.onboarding.completed": true,
    "mvp.parent.goals": ["sleep", "feeding", "development"],
    "mvp.tracker.entries": [
      {
        id: 1001,
        type: "Кормление",
        time: "08:20",
        details: "правая грудь, 18 мин",
        icon: "🍼",
        category: "feeding",
        date: todayKey,
        source: "tracker",
        durationMinutes: 18,
      },
      {
        id: 1002,
        type: "Сон",
        time: "10:05 - 11:25",
        details: "80 мин, качество: хорошее",
        icon: "💤",
        category: "sleep",
        date: todayKey,
        source: "tracker",
        durationMinutes: 80,
      },
      {
        id: 1003,
        type: "Заметка",
        time: "12:10",
        details: "После сна спокойно играл на коврике, хорошо реагировал на голос.",
        icon: "📝",
        category: "note",
        date: todayKey,
        source: "tracker",
      },
    ],
    "mvp.routines.items": [
      {
        id: 2001,
        time: "08:00",
        activity: "Кормление",
        emoji: "🍼",
        duration: "20 мин",
        color: "from-blue-200/30 to-cyan-200/30",
      },
      {
        id: 2002,
        time: "10:00",
        activity: "Сон",
        emoji: "💤",
        duration: "90 мин",
        color: "from-purple-200/30 to-indigo-200/30",
      },
      {
        id: 2003,
        time: "13:00",
        activity: "Прогулка",
        emoji: "🌳",
        duration: "120 мин",
        color: "from-green-200/30 to-emerald-200/30",
      },
    ],
    "mvp.reminders.items": [
      {
        id: 3001,
        title: "Визит к педиатру",
        date: nextWeekKey,
        time: "10:30",
        emoji: "🩺",
        type: "important",
        repeat: "none",
        notes: "Взять дневник сна и список вопросов.",
      },
      {
        id: 3002,
        title: "Купить подгузники",
        date: tomorrowKey,
        time: "18:00",
        emoji: "🧷",
        type: "regular",
        repeat: "none",
        notes: "",
      },
    ],
    "mvp.reminders.checklist": [
      { id: 3101, title: "Стерилизовать бутылочки", checked: true },
      { id: 3102, title: "Проверить аптечку", checked: false },
      { id: 3103, title: "Подготовить сумку на прогулку", checked: false },
    ],
    "mvp.shopping.items": [
      {
        id: "main",
        name: "Основные покупки",
        items: [
          { id: "demo-crib", name: "Кроватка", checked: true, priority: "high", price: "" },
          { id: "demo-stroller", name: "Коляска", checked: false, priority: "high", price: "" },
          { id: "demo-bottles", name: "Бутылочки", checked: false, priority: "medium", price: "" },
        ],
      },
      {
        id: "consumables",
        name: "Расходники",
        items: [
          { id: "demo-diapers", name: "Подгузники", checked: false, priority: "high", price: "" },
          { id: "demo-wipes", name: "Влажные салфетки", checked: true, priority: "medium", price: "" },
        ],
      },
    ],
    "mvp.fridge.drawings": [
      { id: 1, type: "upload", x: 150, y: 150, rotation: -2, magnetColor: "#FFD700" },
      { id: 2, type: "upload", x: 400, y: 150, rotation: 1, magnetColor: "#87CEEB" },
      { id: 3, type: "upload", x: 650, y: 150, rotation: -1, magnetColor: "#FF69B4" },
    ],
    [`mvp.home.completed.${todayKey}`]: ["tracker-check"],
    "mvp.beta.seededAt": now.toISOString(),
  };
}

function getDateKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function addDays(dateKey, offset) {
  const [year, month, day] = dateKey.split("-").map(Number);
  const date = new Date(year, month - 1, day);

  date.setDate(date.getDate() + offset);

  return getDateKey(date);
}

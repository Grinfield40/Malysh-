import { AlertTriangle, ArrowRight, FileText, LogOut, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import {
  acceptAccountConsents,
  type AuthSession,
  type LegalConsentStatus,
} from "../../lib/accountApi";
import {
  buildRegistrationConsentsPayload,
  LEGAL_DOCUMENTS,
  REQUIRED_REGISTRATION_CONSENTS,
  type RegistrationConsentKey,
} from "../../lib/legal";
import { notifyError, notifySuccess, notifyWarning } from "../../lib/notify";
import { Button } from "../ui/button";
import { BetaFeedbackCard } from "./BetaFeedbackCard";

interface LegalConsentGateScreenProps {
  session: AuthSession;
  consentStatus?: LegalConsentStatus;
  onAccepted: (consentStatus: LegalConsentStatus) => void;
  onLogout: () => void;
  onNavigate: (screen: string) => void;
}

export function LegalConsentGateScreen({
  session,
  consentStatus,
  onAccepted,
  onLogout,
  onNavigate,
}: LegalConsentGateScreenProps) {
  const [accepted, setAccepted] = useState<Record<RegistrationConsentKey, boolean>>({
    personalData: false,
    childRepresentative: false,
    sensitiveDataWarning: false,
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const allAccepted = REQUIRED_REGISTRATION_CONSENTS.every((consent) => accepted[consent.key]);
  const missingLabels = useMemo(() => {
    const missing = new Set(consentStatus?.missing || []);

    return REQUIRED_REGISTRATION_CONSENTS
      .filter((consent) => missing.has(consent.key))
      .map((consent) => consent.label);
  }, [consentStatus?.missing]);

  const updateConsent = (key: RegistrationConsentKey, value: boolean) => {
    setAccepted((current) => ({ ...current, [key]: value }));
  };

  const handleAccept = async () => {
    if (!allAccepted) {
      notifyWarning("Подтвердите все пункты, чтобы продолжить.");
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await acceptAccountConsents(session.token, {
        consents: buildRegistrationConsentsPayload(accepted),
      });
      notifySuccess("Согласия сохранены", {
        description: "Можно продолжать пользоваться Малыш+.",
      });
      onAccepted(response.consentStatus);
    } catch (error) {
      notifyError(error, "Не получилось сохранить согласия");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fbf8ff] via-white to-[#f7f3ff] px-4 py-6 md:px-8 md:py-10">
      <div className="mx-auto grid max-w-6xl gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <section className="rounded-[2rem] border border-[#ebe4f7] bg-white p-5 shadow-sm md:p-8">
          <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-3xl bg-[#f1ecff] text-[#9b83db]">
            <ShieldCheck size={28} />
          </div>
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.14em] text-[#9b83db]">
            Обновленные правила beta
          </p>
          <h1 className="text-3xl font-semibold leading-tight text-[#332c4f] md:text-5xl">
            Подтвердите согласия, чтобы продолжить
          </h1>
          <p className="mt-4 max-w-3xl text-base leading-relaxed text-[#7c6fb0] md:text-lg">
            Мы добавили отдельные документы по персональным данным и теперь фиксируем факт согласия на сервере:
            версию документа, дату, email, IP и устройство входа.
          </p>

          {missingLabels.length > 0 && (
            <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-amber-900">
              <div className="mb-2 flex items-center gap-2 font-semibold">
                <AlertTriangle size={18} />
                Нужно подтвердить
              </div>
              <ul className="space-y-1 text-sm">
                {missingLabels.map((label) => (
                  <li key={label}>{label}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-5 space-y-3">
            {REQUIRED_REGISTRATION_CONSENTS.map((consent) => {
              const document = LEGAL_DOCUMENTS[consent.documentKey];

              return (
                <label
                  key={consent.key}
                  className="flex items-start gap-3 rounded-2xl border border-[#ebe4f7] bg-[#fbf8ff] p-4 text-sm leading-relaxed text-[#332c4f]"
                >
                  <input
                    type="checkbox"
                    checked={accepted[consent.key]}
                    onChange={(event) => updateConsent(consent.key, event.target.checked)}
                    className="mt-1 h-4 w-4 rounded border-[#d8cdee] text-[#9b83db] focus:ring-[#9b83db]"
                  />
                  <span>
                    {consent.label}.{" "}
                    <button
                      type="button"
                      className="font-medium text-[#8c75cf] underline-offset-4 hover:underline"
                      onClick={() => onNavigate(document.screen)}
                    >
                      Открыть {document.shortTitle}
                    </button>
                  </span>
                </label>
              );
            })}
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button
              type="button"
              onClick={() => void handleAccept()}
              disabled={isSubmitting || !allAccepted}
              className="h-12 rounded-2xl bg-[#9b83db] px-5 text-white hover:bg-[#8c75cf] sm:flex-1"
            >
              {isSubmitting ? "Сохраняем..." : "Подтвердить и продолжить"}
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onLogout}
              className="h-12 rounded-2xl sm:flex-1"
            >
              <LogOut className="h-4 w-4" />
              Выйти
            </Button>
          </div>

          <div className="mt-5 grid gap-2 sm:grid-cols-2">
            {[LEGAL_DOCUMENTS.privacy, LEGAL_DOCUMENTS.personalDataConsent, LEGAL_DOCUMENTS.childDataConsent, LEGAL_DOCUMENTS.betaTerms].map((document) => (
              <button
                key={document.screen}
                type="button"
                onClick={() => onNavigate(document.screen)}
                className="flex min-h-11 items-center gap-2 rounded-2xl border border-[#ebe4f7] bg-white px-4 py-2 text-left text-sm font-medium text-[#6f639c] hover:border-[#cdbff0] hover:bg-[#fbf8ff]"
              >
                <FileText className="h-4 w-4 text-[#9b83db]" />
                {document.shortTitle}
              </button>
            ))}
          </div>
        </section>

        <aside className="space-y-5">
          <div className="rounded-[2rem] border border-[#ebe4f7] bg-white p-5 shadow-sm md:p-6">
            <h2 className="text-xl font-semibold text-[#332c4f]">Если не хотите продолжать</h2>
            <p className="mt-2 text-sm leading-relaxed text-[#7c6fb0]">
              Можно написать администратору и попросить удалить данные. Пока пользовательский экран удаления
              не готов, такие запросы обрабатываются через поддержку.
            </p>
          </div>
          <BetaFeedbackCard screen="legal-consent" />
        </aside>
      </div>
    </div>
  );
}

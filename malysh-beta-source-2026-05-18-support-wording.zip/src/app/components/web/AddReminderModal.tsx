import { motion, AnimatePresence } from "motion/react";
import { X, Calendar, Clock, Bell, Repeat } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface AddReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (reminder: Reminder) => void;
  initialReminder?: Reminder | null;
}

export interface Reminder {
  title: string;
  date: string;
  time: string;
  emoji: string;
  type: "important" | "regular";
  repeat?: "daily" | "weekly" | "monthly" | "none";
  notes?: string;
}

const emojiOptions = ["💉", "🩺", "💊", "🧷", "🍼", "📅", "⏰", "📝", "🎂", "🏥", "🛒", "🧸"];

const quickTemplates = [
  { emoji: "💉", title: "Прививка", type: "important" as const },
  { emoji: "🩺", title: "Визит к врачу", type: "important" as const },
  { emoji: "💊", title: "Дать лекарство", type: "important" as const },
  { emoji: "🧷", title: "Купить подгузники", type: "regular" as const },
  { emoji: "🍼", title: "Купить смесь", type: "regular" as const },
  { emoji: "🧸", title: "Развивающее занятие", type: "regular" as const },
];

export function AddReminderModal({ isOpen, onClose, onAdd, initialReminder }: AddReminderModalProps) {
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [emoji, setEmoji] = useState("⏰");
  const [type, setType] = useState<"important" | "regular">("regular");
  const [repeat, setRepeat] = useState<"daily" | "weekly" | "monthly" | "none">("none");
  const [notes, setNotes] = useState("");
  const isEditing = Boolean(initialReminder);
  const trimmedTitle = title.trim();
  const validationMessage = !trimmedTitle
    ? "Введите название напоминания."
    : !date
    ? "Выберите дату напоминания."
    : "";
  const shouldShowValidation = Boolean(validationMessage && (title || date || time));

  const resetForm = () => {
    setTitle("");
    setDate("");
    setTime("");
    setEmoji("⏰");
    setType("regular");
    setRepeat("none");
    setNotes("");
  };

  useEffect(() => {
    if (!isOpen) return;

    if (!initialReminder) {
      resetForm();
      return;
    }

    setTitle(initialReminder.title);
    setDate(initialReminder.date);
    setTime(initialReminder.time || "");
    setEmoji(initialReminder.emoji || "⏰");
    setType(initialReminder.type);
    setRepeat(initialReminder.repeat || "none");
    setNotes(initialReminder.notes || "");
  }, [initialReminder, isOpen]);

  const selectTemplate = (template: typeof quickTemplates[number]) => {
    setTitle(template.title);
    setEmoji(template.emoji);
    setType(template.type);
  };

  const handleSubmit = () => {
    if (validationMessage) return;

    onAdd({
      title: trimmedTitle,
      date,
      time,
      emoji,
      type,
      repeat,
      notes,
    });

    onClose();
    resetForm();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-2xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <h2 className="text-2xl font-medium text-foreground">
                {isEditing ? "Редактировать напоминание" : "Новое напоминание"}
              </h2>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Quick Templates */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Быстрый выбор</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {quickTemplates.map((template, idx) => (
                    <button
                      type="button"
                      key={idx}
                      onClick={() => selectTemplate(template)}
                      className={`border-2 rounded-xl p-3 transition-all ${
                        title === template.title
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/30 bg-secondary/30"
                      }`}
                    >
                      <div className="text-3xl mb-2">{template.emoji}</div>
                      <div className="text-sm font-medium text-foreground">{template.title}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Название</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Например: Прививка АКДС"
                  className="rounded-xl"
                  required
                />
              </div>

              {/* Date & Time */}
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    <Calendar className="w-4 h-4 inline mr-2" />
                    Дата
                  </label>
                  <Input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="rounded-xl"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    <Clock className="w-4 h-4 inline mr-2" />
                    Время (необязательно)
                  </label>
                  <Input
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="rounded-xl"
                  />
                </div>
              </div>

              {/* Type */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  <Bell className="w-4 h-4 inline mr-2" />
                  Тип напоминания
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setType("important")}
                    className={`py-3 px-4 rounded-xl border-2 transition-all ${
                      type === "important"
                        ? "bg-red-100/50 border-red-300 text-red-700"
                        : "bg-secondary border-border hover:border-primary/30"
                    }`}
                  >
                    <div className="font-medium">Важное</div>
                    <div className="text-xs text-muted-foreground">Выделяется красным</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setType("regular")}
                    className={`py-3 px-4 rounded-xl border-2 transition-all ${
                      type === "regular"
                        ? "bg-primary/10 border-primary"
                        : "bg-secondary border-border hover:border-primary/30"
                    }`}
                  >
                    <div className="font-medium">Обычное</div>
                    <div className="text-xs text-muted-foreground">Стандартное</div>
                  </button>
                </div>
              </div>

              {/* Repeat */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">
                  <Repeat className="w-4 h-4 inline mr-2" />
                  Повторять
                </label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {[
                    { value: "none", label: "Не повторять" },
                    { value: "daily", label: "Каждый день" },
                    { value: "weekly", label: "Каждую неделю" },
                    { value: "monthly", label: "Каждый месяц" },
                  ].map((option) => (
                    <button
                      type="button"
                      key={option.value}
                      onClick={() => setRepeat(option.value as any)}
                      className={`py-2 px-3 rounded-xl border-2 text-sm transition-all ${
                        repeat === option.value
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-secondary border-border hover:border-primary/30"
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Emoji */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Иконка</label>
                <div className="flex flex-wrap gap-2">
                  {emojiOptions.map((e) => (
                    <button
                      type="button"
                      key={e}
                      onClick={() => setEmoji(e)}
                      className={`w-12 h-12 rounded-xl border-2 text-2xl transition-all ${
                        emoji === e
                          ? "border-primary bg-primary/10 scale-110"
                          : "border-border hover:border-primary/30"
                      }`}
                    >
                      {e}
                    </button>
                  ))}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Заметки (необязательно)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Дополнительная информация..."
                  className="w-full h-24 px-4 py-3 rounded-xl border-2 border-border bg-background focus:border-primary focus:outline-none resize-none"
                />
              </div>

              {/* Preview */}
              {title && date && (
                <div className="bg-secondary/30 rounded-2xl p-4 border-2 border-dashed border-border">
                  <div className="text-sm text-muted-foreground mb-2">Предварительный просмотр:</div>
                  <div
                    className={`rounded-2xl p-5 border-2 ${
                      type === "important"
                        ? "bg-gradient-to-br from-red-100/50 to-pink-100/50 border-red-300"
                        : "bg-card border-border"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-3xl shadow-lg">
                        {emoji}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-foreground mb-2">{title}</h3>
                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <span>📅 {new Date(date).toLocaleDateString("ru-RU")}</span>
                          {time && <span>🕐 {time}</span>}
                        </div>
                        {repeat !== "none" && (
                          <div className="mt-2 text-xs text-primary">
                            🔁 Повторяется{" "}
                            {repeat === "daily"
                              ? "каждый день"
                              : repeat === "weekly"
                              ? "каждую неделю"
                              : "каждый месяц"}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
              {shouldShowValidation ? (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                  {validationMessage}
                </div>
              ) : null}
              <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button onClick={handleSubmit} disabled={Boolean(validationMessage)} className="flex-1 rounded-xl">
                {isEditing ? "Сохранить изменения" : "Создать напоминание"}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

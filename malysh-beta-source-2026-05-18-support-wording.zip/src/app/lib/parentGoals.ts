import { useMemo } from "react";
import { useLocalStorageState } from "./useLocalStorageState";

export type ParentGoalId = "sleep" | "feeding" | "shopping" | "anxiety" | "development";

export interface ParentGoal {
  id: ParentGoalId;
  label: string;
  shortLabel: string;
  icon: string;
  description: string;
  homeHint: string;
  actionLabel: string;
  targetScreen: string;
}

export const PARENT_GOALS_STORAGE_KEY = "mvp.parent.goals";

export const PARENT_GOALS: ParentGoal[] = [
  {
    id: "sleep",
    label: "Сон и режим",
    shortLabel: "Сон",
    icon: "🌙",
    description: "Мягкий ритм дня, окна бодрствования и спокойные укладывания.",
    homeHint: "Проверьте режим дня и добавьте сон в трекер.",
    actionLabel: "Настроить режим",
    targetScreen: "routines",
  },
  {
    id: "feeding",
    label: "Кормление",
    shortLabel: "Кормление",
    icon: "🍼",
    description: "Записи кормлений, интервалы и понятная сводка за день.",
    homeHint: "Запишите кормление, чтобы увидеть интервалы за день.",
    actionLabel: "Открыть трекер",
    targetScreen: "tracker",
  },
  {
    id: "shopping",
    label: "Покупки",
    shortLabel: "Покупки",
    icon: "🛒",
    description: "Списки вещей, рекомендации и контроль готовности.",
    homeHint: "Проверьте список покупок и закройте самое срочное.",
    actionLabel: "Открыть покупки",
    targetScreen: "shopping",
  },
  {
    id: "anxiety",
    label: "Тревоги и безопасность",
    shortLabel: "Тревоги",
    icon: "🩺",
    description: "Быстрые ответы, красные флаги и спокойная навигация в срочных вопросах.",
    homeHint: "Сохраните быстрый путь к срочным вопросам и симптомам.",
    actionLabel: "Срочный вопрос",
    targetScreen: "urgent",
  },
  {
    id: "development",
    label: "Развитие",
    shortLabel: "Развитие",
    icon: "✨",
    description: "Этапы, навыки и идеи занятий по возрасту ребенка.",
    homeHint: "Посмотрите ближайший этап развития и подходящие активности.",
    actionLabel: "Смотреть развитие",
    targetScreen: "growth-timeline",
  },
];

export const DEFAULT_PARENT_GOALS: ParentGoalId[] = ["sleep", "feeding", "development"];

export function getParentGoal(goalId: ParentGoalId) {
  return PARENT_GOALS.find((goal) => goal.id === goalId) ?? PARENT_GOALS[0];
}

export function normalizeParentGoals(goalIds: ParentGoalId[]) {
  const uniqueGoals = Array.from(new Set(goalIds)).filter((goalId) =>
    PARENT_GOALS.some((goal) => goal.id === goalId)
  );

  return uniqueGoals.length > 0 ? uniqueGoals : DEFAULT_PARENT_GOALS;
}

export function useParentGoals() {
  const [goals, setGoals] = useLocalStorageState<ParentGoalId[]>(
    PARENT_GOALS_STORAGE_KEY,
    DEFAULT_PARENT_GOALS
  );
  const selectedGoals = useMemo(
    () => normalizeParentGoals(goals).map(getParentGoal),
    [goals]
  );

  return { goals, setGoals, selectedGoals };
}

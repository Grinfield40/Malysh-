import { AnimatePresence, motion } from "motion/react";
import { Save, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";
import {
  buildTimeRange,
  CareDiaryEntry,
  getEntryStartTime,
  getTodayKey,
  parseDurationMinutes,
} from "../../lib/careDiary";

interface EditDiaryEntryModalProps {
  isOpen: boolean;
  entry: CareDiaryEntry | null;
  onClose: () => void;
  onSave: (entry: CareDiaryEntry) => void;
}

export function EditDiaryEntryModal({ isOpen, entry, onClose, onSave }: EditDiaryEntryModalProps) {
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [details, setDetails] = useState("");
  const [duration, setDuration] = useState("");

  const canTrackDuration = entry?.category === "sleep" || entry?.category === "feeding";
  const trimmedDetails = details.trim();
  const parsedDuration = Number(duration);
  const hasDuration = Number.isFinite(parsedDuration) && parsedDuration > 0;
  const validationMessage = !date
    ? "Выберите дату записи."
    : !time
    ? "Выберите время записи."
    : !trimmedDetails
    ? "Добавьте описание записи."
    : duration && !hasDuration
    ? "Длительность должна быть больше нуля."
    : "";
  const shouldShowValidation = Boolean(validationMessage && entry);

  useEffect(() => {
    if (!entry || !isOpen) return;

    setDate(entry.date || getTodayKey());
    setTime(getEntryStartTime(entry.time));
    setDetails(entry.details);
    setDuration(String((entry.durationMinutes ?? parseDurationMinutes(entry.details)) || ""));
  }, [entry, isOpen]);

  const handleSubmit = () => {
    if (!entry || validationMessage) return;

    const isSleep = entry.category === "sleep";

    onSave({
      ...entry,
      date,
      time: isSleep && hasDuration ? buildTimeRange(time, parsedDuration) : time,
      details: trimmedDetails,
      durationMinutes: hasDuration ? parsedDuration : undefined,
      source: entry.source === "seed" ? "tracker" : entry.source,
    });
  };

  return (
    <AnimatePresence>
      {isOpen && entry && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-secondary flex items-center justify-center text-2xl">
                  {entry.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-medium text-foreground">Редактировать запись</h2>
                  <div className="text-sm text-muted-foreground">{entry.type}</div>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Дата</label>
                  <Input type="date" value={date} onChange={(event) => setDate(event.target.value)} className="rounded-xl" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Время</label>
                  <Input type="time" value={time} onChange={(event) => setTime(event.target.value)} className="rounded-xl" />
                </div>
              </div>

              {canTrackDuration && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">Длительность (минут)</label>
                  <Input
                    type="number"
                    min="1"
                    value={duration}
                    onChange={(event) => setDuration(event.target.value)}
                    placeholder="Например: 90"
                    className="rounded-xl"
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    Для сна это обновит общий счетчик сна за выбранный день.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Описание</label>
                <Textarea
                  value={details}
                  onChange={(event) => setDetails(event.target.value)}
                  className="min-h-28 rounded-xl resize-none"
                />
              </div>
            </div>

            <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
              {shouldShowValidation ? (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                  {validationMessage}
                </div>
              ) : null}
              <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={Boolean(validationMessage)}
                className="flex-1 rounded-xl"
              >
                <Save className="w-4 h-4 mr-2" />
                Сохранить
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

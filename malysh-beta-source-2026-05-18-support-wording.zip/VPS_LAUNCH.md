# Малыш+ VPS launch plan

Сценарий для первого open beta запуска на Ubuntu VPS: сайт доступен по домену, регистрация открыта без кодов, на странице остается beta-предупреждение, данные лежат в SQLite, backup работает по расписанию.

## 0. Что нужно от тебя

- VPS с Ubuntu 22.04/24.04.
- IP сервера.
- Домен или поддомен, например `baby.example.com`.
- DNS `A`-запись домена на IP VPS.

Минимум на старт: 1-2 CPU, 1-2 GB RAM, 20+ GB disk.

## 1. Локально перед переносом

```powershell
cd C:\Users\aleks\Documents\Codex\2026-05-12\new-chat\design-from-code
npm.cmd run beta:launch
npm.cmd run backup
```

Если `beta:launch` зеленый, код можно переносить.

## 2. Первый вход на VPS

```bash
ssh root@YOUR_SERVER_IP
```

Установить базовые пакеты и подготовить папки можно по примеру:

```bash
nano /root/vps-first-install.sh
```

Вставить содержимое `deploy/scripts/vps-first-install.sh.example`, заменить `DOMAIN`, затем:

```bash
chmod +x /root/vps-first-install.sh
/root/vps-first-install.sh
```

## 3. Загрузка проекта

Проект должен оказаться здесь:

```bash
/opt/malysh
```

Варианты:

- через Git, если проект будет в репозитории;
- через архив/`scp`;
- через SFTP из панели VPS.

После загрузки:

```bash
sudo chown -R malysh:malysh /opt/malysh /var/lib/malysh /var/backups/malysh
cd /opt/malysh
```

## 4. Production `.env`

```bash
cp .env.production.example .env
nano .env
```

Минимально заменить:

```env
NODE_ENV=production
MALYSH_HOST=127.0.0.1
MALYSH_API_PORT=8787
MALYSH_PUBLIC_URL=https://your-domain.ru
MALYSH_ALLOWED_ORIGINS=https://your-domain.ru

MALYSH_DATA_DIR=/var/lib/malysh
MALYSH_DB_FILE=/var/lib/malysh/app.db
MALYSH_BACKUP_DIR=/var/backups/malysh
MALYSH_BACKUP_KEEP=30

MALYSH_REGISTRATION_MODE=open
MALYSH_BETA_INVITE_CODE=

MALYSH_ADMIN_EMAIL=admin@your-domain.ru
MALYSH_ADMIN_NAME=Admin
MALYSH_ADMIN_PASSWORD=strong-admin-password
```

Важно: `.env` не коммитить и никому не отправлять.

## 5. Build и preflight

```bash
npm ci
npm run build
npm run vps:check
```

`vps:check` должен пройти без ошибок. В open beta он покажет warning, что регистрация открыта, это нормально.

## 6. Первый админ

```bash
npm run admin:create
```

Или явно:

```bash
npm run admin:create -- admin@your-domain.ru Алекс StrongAdminPassword123
```

## 7. Systemd автозапуск

```bash
sudo cp deploy/systemd/malysh.service.example /etc/systemd/system/malysh.service
sudo systemctl daemon-reload
sudo systemctl enable malysh
sudo systemctl start malysh
sudo systemctl status malysh --no-pager
```

Проверить локально на сервере:

```bash
curl http://127.0.0.1:8787/api/health
```

## 8. Nginx и домен

```bash
sudo cp deploy/nginx/malysh.conf.example /etc/nginx/sites-available/malysh
sudo nano /etc/nginx/sites-available/malysh
```

Заменить:

```nginx
server_name example.com www.example.com;
```

на свой домен/поддомен.

Включить сайт:

```bash
sudo ln -s /etc/nginx/sites-available/malysh /etc/nginx/sites-enabled/malysh
sudo nginx -t
sudo systemctl reload nginx
```

## 9. HTTPS

```bash
sudo certbot --nginx -d your-domain.ru
```

Потом проверить:

```bash
curl https://your-domain.ru/api/health
```

Node-порт `8787` наружу не открывать. Снаружи работают только `80/443`.

## 10. Backup по расписанию

```bash
sudo cp deploy/cron/malysh-backup.cron.example /etc/cron.d/malysh-backup
sudo chmod 644 /etc/cron.d/malysh-backup
npm run backup
ls -lah /var/backups/malysh
```

## 11. Smoke после запуска

На сервере:

```bash
cd /opt/malysh
npm run vps:check
curl https://your-domain.ru/api/health
npm run backup
```

В браузере:

- открыть домен;
- зарегистрировать обычного пользователя без кода;
- пройти onboarding;
- добавить запись в дневник;
- загрузить картинку в холодильник;
- создать пост на форуме;
- войти админом;
- проверить пользователя, метрики, историю действий и backup.

## 12. Обновление версии

Перед обновлением:

```bash
cd /opt/malysh
npm run backup
```

После загрузки новой версии можно использовать пример:

```bash
bash deploy/scripts/vps-update-release.sh.example
```

## 13. Если нужно закрыть регистрацию

В `.env`:

```env
MALYSH_REGISTRATION_MODE=closed
MALYSH_BETA_INVITE_CODE=private-code-for-testers
```

И перезапуск:

```bash
sudo systemctl restart malysh
```

Если нужно полностью остановить новые регистрации:

```env
MALYSH_REGISTRATION_MODE=disabled
```

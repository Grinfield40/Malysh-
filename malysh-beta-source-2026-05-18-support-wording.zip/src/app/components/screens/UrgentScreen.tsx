import { ChevronLeft, Thermometer, Moon, Baby, Milk, AlertCircle, Info } from "lucide-react";

interface UrgentScreenProps {
  onBack: () => void;
}

const urgentTopics = [
  {
    id: "temperature",
    icon: Thermometer,
    label: "Температура",
    description: "Когда нужен врач",
    color: "bg-[#D4846A]",
  },
  {
    id: "sleep",
    icon: Moon,
    label: "Сон",
    description: "Проблемы со сном",
    color: "bg-primary",
  },
  {
    id: "crying",
    icon: Baby,
    label: "Плач",
    description: "Причины и решения",
    color: "bg-accent",
  },
  {
    id: "feeding",
    icon: Milk,
    label: "Кормление",
    description: "Срочные вопросы",
    color: "bg-[#A4B5A8]",
  },
  {
    id: "doctor",
    icon: AlertCircle,
    label: "Когда к врачу",
    description: "Тревожные симптомы",
    color: "bg-destructive",
  },
  {
    id: "normal",
    icon: Info,
    label: "Что нормально",
    description: "Развеиваем тревоги",
    color: "bg-[#8B9B8E]",
  },
];

export function UrgentScreen({ onBack }: UrgentScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 border-b border-border bg-card">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={onBack} className="p-2 -ml-2">
            <ChevronLeft className="w-6 h-6 text-foreground" />
          </button>
          <h1 className="text-2xl font-medium text-foreground flex-1">Срочные ответы</h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Быстрый доступ к важной информации
        </p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6">
        <div className="grid grid-cols-2 gap-4">
          {urgentTopics.map((topic) => {
            const Icon = topic.icon;
            return (
              <button
                key={topic.id}
                className="rounded-2xl bg-card border border-border p-5 flex flex-col items-start gap-4 hover:border-primary/30 transition-all h-36"
              >
                <div className={`w-12 h-12 rounded-xl ${topic.color} flex items-center justify-center text-white`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <h3 className="font-medium text-foreground mb-1">{topic.label}</h3>
                  <p className="text-xs text-muted-foreground leading-tight">{topic.description}</p>
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-6 p-5 rounded-2xl bg-secondary border border-border">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Info className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium text-foreground mb-2">Важно помнить</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Если вы чувствуете, что с ребенком что-то не так — доверяйте своей интуиции и обратитесь к врачу.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useLocalStorageState } from "./useLocalStorageState";

export type CareEventCategory =
  | "feeding"
  | "sleep"
  | "diaper"
  | "temperature"
  | "weight"
  | "height"
  | "medicine"
  | "note";

export interface CareDiaryEntry {
  id: number;
  type: string;
  time: string;
  details: string;
  icon: string;
  category: CareEventCategory | string;
  date?: string;
  source?: "tracker" | "routine" | "seed";
  routineId?: number;
  durationMinutes?: number;
}

export interface TrackerEntryDraft {
  type: CareEventCategory;
  time: string;
  date: string;
  details: Record<string, any>;
}

export interface RoutineEntryDraft {
  id?: number;
  time: string;
  activity: string;
  emoji: string;
  duration: string;
  color?: string;
}

export const CARE_DIARY_STORAGE_KEY = "mvp.tracker.entries";

export const trackerFilterTypes = ["Все", "Кормление", "Сон", "Подгузники", "Температура", "Заметки"];

const trackerMeta: Record<CareEventCategory, { type: string; icon: string; category: CareEventCategory }> = {
  feeding: { type: "Кормление", icon: "🍼", category: "feeding" },
  sleep: { type: "Сон", icon: "💤", category: "sleep" },
  diaper: { type: "Подгузники", icon: "🧷", category: "diaper" },
  temperature: { type: "Температура", icon: "🌡️", category: "temperature" },
  weight: { type: "Вес", icon: "⚖️", category: "weight" },
  height: { type: "Рост", icon: "📏", category: "height" },
  medicine: { type: "Лекарства", icon: "💊", category: "medicine" },
  note: { type: "Заметка", icon: "📝", category: "note" },
};

export const defaultCareDiaryEntries: CareDiaryEntry[] = [];

export function useCareDiary() {
  return useLocalStorageState<CareDiaryEntry[]>(CARE_DIARY_STORAGE_KEY, defaultCareDiaryEntries);
}

export function getTodayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

export function isTodayEntry(entry: CareDiaryEntry, todayKey = getTodayKey()) {
  return !entry.date || entry.date === todayKey;
}

export function isEntryOnDate(entry: CareDiaryEntry, dateKey: string, todayKey = getTodayKey()) {
  return entry.date ? entry.date === dateKey : dateKey === todayKey;
}

export function getCategoryByFilter(filter: string) {
  const map: Record<string, CareEventCategory | "all"> = {
    Все: "all",
    Кормление: "feeding",
    Сон: "sleep",
    Подгузники: "diaper",
    Температура: "temperature",
    Заметки: "note",
  };

  return map[filter] ?? "all";
}

export function sortDiaryEntries(entries: CareDiaryEntry[]) {
  return [...entries].sort((a, b) => {
    const dateCompare = (b.date ?? "").localeCompare(a.date ?? "");

    if (dateCompare !== 0) return dateCompare;

    return parseTimeToMinutes(b.time) - parseTimeToMinutes(a.time);
  });
}

export function getTodayCareEntries(entries: CareDiaryEntry[], todayKey = getTodayKey()) {
  return sortDiaryEntries(entries.filter((entry) => isTodayEntry(entry, todayKey)));
}

export function getCareEntriesForDate(entries: CareDiaryEntry[], dateKey: string, todayKey = getTodayKey()) {
  return sortDiaryEntries(entries.filter((entry) => isEntryOnDate(entry, dateKey, todayKey)));
}

export function addDaysToDateKey(dateKey: string, offset: number) {
  const date = parseDateKey(dateKey);
  date.setDate(date.getDate() + offset);

  return getTodayKey(date);
}

export function formatDateLabel(dateKey: string, todayKey = getTodayKey()) {
  if (dateKey === todayKey) return "Сегодня";
  if (dateKey === addDaysToDateKey(todayKey, -1)) return "Вчера";
  if (dateKey === addDaysToDateKey(todayKey, 1)) return "Завтра";

  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long" }).format(parseDateKey(dateKey));
}

export function formatWeekdayLabel(dateKey: string) {
  return new Intl.DateTimeFormat("ru-RU", { weekday: "short" })
    .format(parseDateKey(dateKey))
    .replace(".", "");
}

export function getDiaryWeekDays(entries: CareDiaryEntry[], anchorDateKey = getTodayKey()) {
  return Array.from({ length: 7 }, (_, index) => {
    const dateKey = addDaysToDateKey(anchorDateKey, index - 6);
    const dayEntries = getCareEntriesForDate(entries, dateKey);

    return {
      dateKey,
      day: String(parseDateKey(dateKey).getDate()),
      weekday: formatWeekdayLabel(dateKey),
      label: formatDateLabel(dateKey),
      summary: getCareDiarySummary(dayEntries),
    };
  });
}

export function trackerToCareDiaryEntry(entry: TrackerEntryDraft): CareDiaryEntry {
  const meta = trackerMeta[entry.type];
  const details = entry.details;
  let readableDetails = "Запись добавлена";
  let durationMinutes: number | undefined;

  if (entry.type === "feeding") {
    const side = details.side === "left" ? "левая грудь" : details.side === "right" ? "правая грудь" : "обе стороны";
    durationMinutes = parseNumber(details.duration);
    readableDetails =
      details.type === "breast"
        ? `${side}, ${details.duration || "—"} мин`
        : `${details.type === "bottle" ? "бутылочка" : "прикорм"}${details.amount ? `, ${details.amount} ${details.type === "solid" ? "г" : "мл"}` : ""}`;
  }

  if (entry.type === "sleep") {
    durationMinutes = parseNumber(details.duration);
    const quality = details.quality === "good" ? "хорошее" : details.quality === "poor" ? "беспокойное" : "обычное";
    readableDetails = `${details.duration || "—"} мин, качество: ${quality}`;
  }

  if (entry.type === "diaper") {
    readableDetails = details.type === "dirty" ? "грязный" : details.type === "both" ? "мокрый и грязный" : "мокрый";
  }

  if (entry.type === "temperature") {
    readableDetails = `${details.value || "—"}°C`;
  }

  if (entry.type === "weight") {
    readableDetails = `${details.value || "—"} кг`;
  }

  if (entry.type === "height") {
    readableDetails = `${details.value || "—"} см`;
  }

  if (entry.type === "medicine") {
    readableDetails = `${details.name || "Лекарство"}${details.dose ? `, ${details.dose}` : ""}`;
  }

  if (entry.type === "note") {
    readableDetails = String(details.text || "").trim() || "Короткая заметка";
  }

  return {
    id: Date.now(),
    type: meta.type,
    time: entry.time,
    details: readableDetails,
    icon: meta.icon,
    category: meta.category,
    date: entry.date,
    source: "tracker",
    durationMinutes,
  };
}

export function inferRoutineCategory(activity: string, emoji: string): "feeding" | "sleep" | null {
  const normalized = activity.toLowerCase();

  if (
    normalized.includes("корм") ||
    normalized.includes("груд") ||
    normalized.includes("бутыл") ||
    normalized.includes("прикорм") ||
    emoji === "🍼" ||
    emoji === "🥄"
  ) {
    return "feeding";
  }

  if (
    normalized.includes("сон") ||
    normalized.includes("сну") ||
    normalized.includes("уклад") ||
    emoji === "💤" ||
    emoji === "🌙"
  ) {
    return "sleep";
  }

  return null;
}

export function routineToCareDiaryEntry(routine: RoutineEntryDraft, date = getTodayKey()): CareDiaryEntry | null {
  const category = inferRoutineCategory(routine.activity, routine.emoji);

  if (!category) return null;

  const durationMinutes = parseDurationMinutes(routine.duration);
  const isSleep = category === "sleep";
  const time = isSleep && durationMinutes ? buildTimeRange(routine.time, durationMinutes) : routine.time;

  return {
    id: Date.now() + 1,
    type: isSleep ? "Сон" : "Кормление",
    time,
    details: `Из режима: ${routine.duration}`,
    icon: isSleep ? "💤" : "🍼",
    category,
    date,
    source: "routine",
    routineId: routine.id,
    durationMinutes,
  };
}

export function getCareDiarySummary(entries: CareDiaryEntry[]) {
  const sortedEntries = sortDiaryEntries(entries);
  const latestTemperature = sortedEntries.find((entry) => entry.category === "temperature")?.details ?? "—";
  const totalSleepMinutes = entries
    .filter((entry) => entry.category === "sleep")
    .reduce((sum, entry) => sum + (entry.durationMinutes ?? parseDurationMinutes(entry.details)), 0);

  return {
    total: entries.length,
    feeding: entries.filter((entry) => entry.category === "feeding").length,
    sleep: entries.filter((entry) => entry.category === "sleep").length,
    diaper: entries.filter((entry) => entry.category === "diaper").length,
    notes: entries.filter((entry) => entry.category === "note").length,
    temperature: latestTemperature,
    totalSleepMinutes,
    totalSleepLabel: formatDuration(totalSleepMinutes),
    lastEntry: sortedEntries[0],
  };
}

export function formatDuration(minutes: number) {
  if (!minutes) return "0 мин";

  if (minutes < 60) return `${minutes} мин`;

  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;

  return rest ? `${hours} ч ${rest} мин` : `${hours} ч`;
}

export function getEntryStartTime(time: string) {
  const match = time.match(/(\d{1,2}):(\d{2})/);

  if (!match) return "";

  return `${String(Number(match[1])).padStart(2, "0")}:${match[2]}`;
}

export function buildTimeRange(startTime: string, durationMinutes: number) {
  return `${startTime} - ${addMinutesToTime(startTime, durationMinutes)}`;
}

function parseNumber(value: unknown) {
  const parsed = Number(value);

  return Number.isFinite(parsed) && parsed > 0 ? parsed : undefined;
}

function parseTimeToMinutes(time: string) {
  const match = time.match(/(\d{1,2}):(\d{2})/);

  if (!match) return 0;

  return Number(match[1]) * 60 + Number(match[2]);
}

export function parseDurationMinutes(value: unknown) {
  if (typeof value !== "string") return 0;

  const normalized = value.replace(",", ".").toLowerCase();
  const hourMatch = normalized.match(/(\d+(?:\.\d+)?)\s*(?:ч|час)/);
  const minuteMatch = normalized.match(/(\d+)\s*мин/);

  if (hourMatch) {
    return Math.round(Number(hourMatch[1]) * 60) + (minuteMatch ? Number(minuteMatch[1]) : 0);
  }

  if (minuteMatch) return Number(minuteMatch[1]);

  const plainNumber = Number(normalized.match(/\d+/)?.[0]);

  return Number.isFinite(plainNumber) ? plainNumber : 0;
}

function addMinutesToTime(time: string, duration: number) {
  const total = parseTimeToMinutes(time) + duration;
  const hours = Math.floor(total / 60) % 24;
  const minutes = total % 60;

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function parseDateKey(dateKey: string) {
  const [year, month, day] = dateKey.split("-").map(Number);

  return new Date(year, month - 1, day);
}

import {
  Activity,
  Baby,
  Bell,
  BookOpen,
  Bookmark,
  ClipboardList,
  Clock,
  Heart,
  Home,
  Image,
  MessageCircle,
  ShieldAlert,
  ShieldCheck,
  ShoppingBag,
  User,
  type LucideIcon,
} from "lucide-react";

export interface NavigationItem {
  id: string;
  icon: LucideIcon;
  label: string;
}

export interface NavigationSection {
  id: string;
  title: string;
  items: NavigationItem[];
}

export const appNavigationSections: NavigationSection[] = [
  {
    id: "today",
    title: "Сегодня",
    items: [
      { id: "home", icon: Home, label: "Главная" },
    ],
  },
  {
    id: "care",
    title: "Уход",
    items: [
      { id: "tracker", icon: Activity, label: "Трекер" },
      { id: "routines", icon: Clock, label: "Режим дня" },
      { id: "reminders", icon: Bell, label: "Напоминания" },
      { id: "fridge", icon: Image, label: "Холодильник" },
    ],
  },
  {
    id: "development",
    title: "Развитие",
    items: [
      { id: "growth-timeline", icon: Baby, label: "Развитие малыша" },
      { id: "tips", icon: BookOpen, label: "Советы" },
      { id: "recommendations", icon: Heart, label: "Мамы одобряют" },
    ],
  },
  {
    id: "preparation",
    title: "Подготовка",
    items: [
      { id: "shopping", icon: ShoppingBag, label: "Покупки" },
      { id: "discharge-checklist", icon: ClipboardList, label: "На выписку" },
      { id: "stroller-guide", icon: Baby, label: "Коляска" },
      { id: "taboo", icon: ShieldAlert, label: "Табу" },
    ],
  },
  {
    id: "community",
    title: "Сообщество",
    items: [
      { id: "forum", icon: MessageCircle, label: "Форум" },
    ],
  },
  {
    id: "personal",
    title: "Мое",
    items: [
      { id: "saved", icon: Bookmark, label: "Сохраненное" },
      { id: "profile", icon: User, label: "Профиль" },
      { id: "privacy", icon: ShieldCheck, label: "Приватность" },
    ],
  },
];

export const adminNavigationSection: NavigationSection = {
  id: "admin",
  title: "Администратор",
  items: [
    { id: "admin", icon: ShieldCheck, label: "Админ-панель" },
  ],
};

export const mobilePrimaryNavigation: NavigationItem[] = [
  { id: "home", icon: Home, label: "Главная" },
  { id: "tracker", icon: Activity, label: "Трекер" },
  { id: "growth-timeline", icon: Baby, label: "Развитие" },
  { id: "forum", icon: MessageCircle, label: "Форум" },
  { id: "profile", icon: User, label: "Профиль" },
];

export const mobileAdminNavigationItem: NavigationItem = {
  id: "admin",
  icon: ShieldCheck,
  label: "Админ",
};

export function isNavigationItemActive(activeScreen: string, itemId: string) {
  return (
    activeScreen === itemId ||
    (itemId === "growth-timeline" && activeScreen === "growth-stage") ||
    (itemId === "tips" && activeScreen === "article")
  );
}

import { motion, AnimatePresence } from "motion/react";
import { X, AlertTriangle, CheckCircle, Phone } from "lucide-react";

interface UrgentTopicModalProps {
  topic: {
    id: string;
    icon: string;
    label: string;
    description: string;
    color: string;
  } | null;
  onClose: () => void;
}

const topicContent: Record<string, {
  whenToWorry: string[];
  whatToDo: string[];
  normal: string[];
  emergency: string[];
}> = {
  temperature: {
    whenToWorry: [
      "Температура выше 38°C у младенца младше 3 месяцев",
      "Температура выше 39°C у ребенка старше 3 месяцев",
      "Температура держится более 3 дней",
      "Ребенок вялый, отказывается от еды и питья",
      "Появились судороги на фоне температуры",
    ],
    whatToDo: [
      "Разденьте ребенка, оставив легкую одежду",
      "Обеспечьте прохладу в комнате (18-20°C)",
      "Давайте больше жидкости (грудное молоко, вода)",
      "При температуре выше 38.5°C дайте жаропонижающее (парацетамол или ибупрофен)",
      "Не кутайте ребенка в одеяла",
    ],
    normal: [
      "Небольшое повышение температуры после прививки",
      "Температура до 37.5°C при прорезывании зубов",
      "Кратковременное повышение на фоне активности",
    ],
    emergency: [
      "Температура выше 40°C",
      "Судороги",
      "Затрудненное дыхание",
      "Сыпь, которая не исчезает при надавливании",
      "Ребенок не реагирует, сонливый",
    ],
  },
  sleep: {
    whenToWorry: [
      "Ребенок не спит более 6 часов подряд",
      "Просыпается каждые 15-20 минут в течение нескольких дней",
      "Плачет во сне и трудно успокаивается",
      "Храп или остановки дыхания во сне",
      "Резкое изменение режима сна",
    ],
    whatToDo: [
      "Создайте спокойную обстановку: приглушите свет, уберите шум",
      "Установите режим: купание, кормление, колыбельная",
      "Проверьте комфорт: подгузник, температуру в комнате (18-22°C)",
      "Успокойте контактом: возьмите на руки, покачайте",
      "Проверьте, не болит ли животик (колики)",
    ],
    normal: [
      "Частые пробуждения у новорожденных (каждые 2-3 часа)",
      "Беспокойный сон при прорезывании зубов",
      "Изменение режима при скачках роста",
    ],
    emergency: [
      "Ребенок не просыпается для кормления",
      "Посинение кожи во время сна",
      "Остановки дыхания более 10 секунд",
      "Высокая температура с нарушением сна",
    ],
  },
  crying: {
    whenToWorry: [
      "Плач более 3 часов без перерыва",
      "Необычный, пронзительный крик",
      "Плач сопровождается температурой выше 38°C",
      "Ребенок безутешен, ничто не помогает",
      "Плач с рвотой, поносом или сыпью",
    ],
    whatToDo: [
      "Проверьте базовые потребности: голод, мокрый подгузник, температура",
      "Возьмите на руки, прижмите к себе",
      "Покачайте или походите с ребенком",
      "Попробуйте белый шум или тихую музыку",
      "Предложите пустышку или дайте пососать",
      "Сделайте легкий массаж животика при коликах",
    ],
    normal: [
      "Плач 1-3 часа в день у младенцев",
      "Вечерний плач (период «фиолетового плача» в 2-5 месяцев)",
      "Плач при переодевании или купании",
    ],
    emergency: [
      "Плач с высокой температурой и судорогами",
      "Плач с затрудненным дыханием",
      "Плач с рвотой «фонтаном»",
      "Плач с твердым, вздутым животом",
      "Ребенок бледный, синюшный",
    ],
  },
  feeding: {
    whenToWorry: [
      "Младенец не ест более 4-6 часов",
      "Отказ от еды более суток",
      "Потеря веса более 10% от веса при рождении",
      "Менее 6 мокрых подгузников в день",
      "Темная моча, сухие губы (признаки обезвоживания)",
    ],
    whatToDo: [
      "Предлагайте грудь или бутылочку чаще, небольшими порциями",
      "Убедитесь, что ребенок правильно захватывает грудь",
      "Проверьте, не заложен ли нос (насморк мешает сосать)",
      "Попробуйте сменить позу для кормления",
      "Создайте спокойную обстановку без отвлекающих факторов",
      "Следите за признаками голода: сосание пальцев, причмокивание",
    ],
    normal: [
      "Отказ от еды во время прорезывания зубов",
      "Снижение аппетита при жаркой погоде",
      "Периоды «забастовок» при грудном вскармливании",
    ],
    emergency: [
      "Признаки сильного обезвоживания: запавший родничок, сухие губы",
      "Рвота после каждого кормления",
      "Отказ от еды с высокой температурой",
      "Кровь в стуле или рвотных массах",
    ],
  },
  breathing: {
    whenToWorry: [
      "Частота дыхания более 60 вдохов в минуту",
      "Втяжение межреберных промежутков при дыхании",
      "Посинение губ или кожи вокруг рта",
      "Хрипы, свист при дыхании",
      "Остановки дыхания более 10 секунд",
    ],
    whatToDo: [
      "Освободите дыхательные пути: прочистите нос аспиратором",
      "Приподнимите головной конец кроватки (подложите подушку под матрас)",
      "Увлажните воздух в комнате",
      "Обеспечьте свежий воздух, проветрите помещение",
      "Успокойте ребенка — паника усиливает одышку",
    ],
    normal: [
      "Периодическое дыхание у новорожденных (паузы до 10 секунд)",
      "Частое дыхание у младенцев (40-60 вдохов в минуту)",
      "Небольшой храп при насморке",
    ],
    emergency: [
      "Посинение кожи или губ",
      "Остановка дыхания более 20 секунд",
      "Ребенок задыхается, не может плакать",
      "Сильное втяжение грудной клетки",
      "Потеря сознания",
    ],
  },
  vomiting: {
    whenToWorry: [
      "Рвота «фонтаном» после каждого кормления",
      "Рвота с кровью или желчью (зеленого цвета)",
      "Рвота более 8-12 часов",
      "Признаки обезвоживания: сухие губы, редкое мочеиспускание",
      "Рвота с высокой температурой и вялостью",
    ],
    whatToDo: [
      "После срыгивания подержите ребенка вертикально 20-30 минут",
      "Кормите меньшими порциями, но чаще",
      "Не трясите и не играйте активно сразу после кормления",
      "При рвоте давайте жидкость малыми порциями (чайная ложка каждые 5 минут)",
      "Следите за количеством мокрых подгузников",
    ],
    normal: [
      "Срыгивания после кормления у младенцев (до 5-7 месяцев)",
      "Небольшое количество молока изо рта",
      "Срыгивания уменьшаются, когда ребенок начинает сидеть",
    ],
    emergency: [
      "Рвота с кровью",
      "Рвота желчью (зеленая или желтая)",
      "Рвота с вздутым твердым животом",
      "Признаки сильного обезвоживания",
      "Рвота после травмы головы",
    ],
  },
};

export function UrgentTopicModal({ topic, onClose }: UrgentTopicModalProps) {
  if (!topic) return null;

  const content = topicContent[topic.id];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[10000] flex items-center justify-center p-0 md:p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="bg-white rounded-t-3xl md:rounded-3xl shadow-2xl max-w-4xl w-full max-h-[95vh] md:max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className={`bg-gradient-to-br ${topic.color} p-4 md:p-8 sticky top-0 z-10 backdrop-blur-sm border-b-2 border-white/50`}>
            <button
              onClick={onClose}
              className="absolute top-3 md:top-6 right-3 md:right-6 w-9 h-9 md:w-10 md:h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center transition-all"
            >
              <X className="w-5 h-5 md:w-6 md:h-6 text-foreground" />
            </button>
            <div className="flex items-center gap-3 md:gap-6">
              <div className="w-14 h-14 md:w-20 md:h-20 bg-white/90 rounded-xl md:rounded-2xl flex items-center justify-center text-3xl md:text-5xl shadow-lg flex-shrink-0">
                {topic.icon}
              </div>
              <div className="flex-1 pr-8">
                <h2 className="text-xl md:text-3xl font-medium text-foreground mb-1 md:mb-2">{topic.label}</h2>
                <p className="text-sm md:text-base text-muted-foreground">{topic.description}</p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 md:p-8 space-y-6 md:space-y-8">
            {/* Emergency Section */}
            <div className="bg-destructive/10 border-2 border-destructive/30 rounded-xl md:rounded-2xl p-4 md:p-6">
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-destructive/20 rounded-lg md:rounded-xl flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 md:w-6 md:h-6 text-destructive" />
                </div>
                <h3 className="text-base md:text-xl font-medium text-destructive">Звоните 103 немедленно, если:</h3>
              </div>
              <ul className="space-y-2">
                {content.emergency.map((item, idx) => (
                  <li key={idx} className="flex gap-2 md:gap-3 items-start">
                    <AlertTriangle className="w-4 h-4 md:w-5 md:h-5 text-destructive flex-shrink-0 mt-0.5" />
                    <span className="text-sm md:text-base text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* When to Worry */}
            <div>
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-orange-200/40 rounded-lg md:rounded-xl flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-5 h-5 md:w-6 md:h-6 text-orange-600" />
                </div>
                <h3 className="text-base md:text-xl font-medium text-foreground">Когда стоит обратиться к врачу</h3>
              </div>
              <ul className="space-y-2 bg-orange-50/50 rounded-xl md:rounded-2xl p-4 md:p-6">
                {content.whenToWorry.map((item, idx) => (
                  <li key={idx} className="flex gap-2 md:gap-3 items-start">
                    <span className="text-orange-600 text-lg md:text-xl flex-shrink-0">•</span>
                    <span className="text-sm md:text-base text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* What to Do */}
            <div>
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/20 rounded-lg md:rounded-xl flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-primary" />
                </div>
                <h3 className="text-base md:text-xl font-medium text-foreground">Что можно сделать дома</h3>
              </div>
              <ul className="space-y-2 bg-primary/5 rounded-xl md:rounded-2xl p-4 md:p-6">
                {content.whatToDo.map((item, idx) => (
                  <li key={idx} className="flex gap-2 md:gap-3 items-start">
                    <CheckCircle className="w-4 h-4 md:w-5 md:h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-sm md:text-base text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Normal Cases */}
            <div>
              <div className="flex items-center gap-2 md:gap-3 mb-3 md:mb-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-green-200/40 rounded-lg md:rounded-xl flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
                </div>
                <h3 className="text-base md:text-xl font-medium text-foreground">Когда это норма</h3>
              </div>
              <ul className="space-y-2 bg-green-50/50 rounded-xl md:rounded-2xl p-4 md:p-6">
                {content.normal.map((item, idx) => (
                  <li key={idx} className="flex gap-2 md:gap-3 items-start">
                    <span className="text-green-600 text-lg md:text-xl flex-shrink-0">•</span>
                    <span className="text-sm md:text-base text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Disclaimer */}
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-xl md:rounded-2xl p-4 md:p-6">
              <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Важно:</strong> Эта информация носит справочный характер и не заменяет консультацию врача. При любых сомнениях обращайтесь к педиатру. Доверяйте своей интуиции — вы лучше всех знаете своего ребенка.
              </p>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

import { motion } from "motion/react";
import { Plus, Crown, Calendar, Lock, CheckCircle2, Clock3 } from "lucide-react";
import { Button } from "../ui/button";
import { AddRoutineModal, RoutineItem } from "./AddRoutineModal";
import { PremiumBadge } from "../PremiumBadge";
import { ActionEmptyState } from "./ActionEmptyState";
import { ScreenHeader } from "./ScreenHeader";
import { useState } from "react";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { useBabyProfile } from "../../lib/babyProfile";
import {
  getCareDiarySummary,
  getTodayCareEntries,
  inferRoutineCategory,
  routineToCareDiaryEntry,
  useCareDiary,
} from "../../lib/careDiary";
import { trackEvent } from "../../lib/analytics";
import { notifySuccess } from "../../lib/notify";

type RoutineStateItem = RoutineItem & { id: number };

const routineItems: RoutineStateItem[] = [];

interface WebRoutinesScreenProps {
  onNavigate: (screen: string) => void;
}

export function WebRoutinesScreen({ onNavigate }: WebRoutinesScreenProps) {
  const [items, setItems] = useLocalStorageState<RoutineStateItem[]>("mvp.routines.items", routineItems);
  const [diaryEntries, setDiaryEntries] = useCareDiary();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { baby, age } = useBabyProfile();

  const todayDiaryEntries = getTodayCareEntries(diaryEntries);
  const summary = getCareDiarySummary(todayDiaryEntries);
  const routineFacts = todayDiaryEntries.filter(
    (entry) => entry.category === "feeding" || entry.category === "sleep"
  );

  const handleAddRoutine = (routine: RoutineItem) => {
    const routineItem = { id: Date.now(), ...routine };
    const diaryEntry = routineToCareDiaryEntry(routineItem);

    setItems((prev) => [routineItem, ...prev].sort((a, b) => a.time.localeCompare(b.time)));

    if (diaryEntry) {
      setDiaryEntries((prev) => [diaryEntry, ...prev]);
    }

    trackEvent("routine_item_added", {
      screen: "routines",
      meta: {
        category: diaryEntry?.category || inferRoutineCategory(routine.activity, routine.emoji) || "other",
        linkedDiary: Boolean(diaryEntry),
      },
    });
    notifySuccess("Пункт режима добавлен", {
      description: diaryEntry ? "Он также появился в дневнике ухода." : "Режим дня обновлен.",
    });
  };

  const getRoutineFact = (item: RoutineStateItem) => {
    const category = inferRoutineCategory(item.activity, item.emoji);

    if (!category) return null;

    return todayDiaryEntries.find(
      (entry) =>
        entry.category === category &&
        (entry.routineId === item.id || entry.time.startsWith(item.time))
    );
  };

  return (
    <div className="p-4 md:p-8 max-w-[1200px] mx-auto">
      <ScreenHeader
        icon={<Calendar className="h-6 w-6" />}
        title="Режим дня"
        description={<>Опорные точки сна, кормления и прогулок для {baby.name}: {age.stageLabel}</>}
        action={
          <Button
            onClick={() => setIsModalOpen(true)}
            className="h-12 w-full justify-center rounded-2xl bg-primary hover:bg-primary/90 sm:w-auto md:min-w-[180px]"
          >
            <Plus className="w-5 h-5 mr-2" />
            Добавить пункт
          </Button>
        }
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-4 md:mb-6 rounded-xl border border-border bg-card p-4 md:p-5"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <div className="text-sm text-muted-foreground mb-1">Ориентир на сейчас</div>
            <div className="text-base md:text-lg font-medium text-foreground leading-relaxed">{age.routineHint}</div>
          </div>
          <div className="rounded-xl bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            {baby.name}, {age.label}
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-[1fr_1.1fr]"
      >
        <div className="rounded-xl border border-border bg-card p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle2 className="w-5 h-5 text-primary" />
            <h2 className="font-medium text-foreground">Факты сегодня</h2>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl bg-secondary/60 p-3">
              <div className="text-2xl font-medium text-foreground">{summary.feeding}</div>
              <div className="text-xs text-muted-foreground">кормлений</div>
            </div>
            <div className="rounded-xl bg-secondary/60 p-3">
              <div className="text-2xl font-medium text-foreground">{summary.sleep}</div>
              <div className="text-xs text-muted-foreground">сна</div>
            </div>
            <div className="rounded-xl bg-secondary/60 p-3">
              <div className="text-2xl font-medium text-foreground">{summary.totalSleepLabel}</div>
              <div className="text-xs text-muted-foreground">сон всего</div>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-4 md:p-5">
          <div className="flex items-center gap-2 mb-4">
            <Clock3 className="w-5 h-5 text-primary" />
            <h2 className="font-medium text-foreground">Из дневника в режим</h2>
          </div>
          {routineFacts.length === 0 ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Когда вы добавите сон или кормление в дневник, они появятся здесь как факты дня.
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={() => onNavigate("tracker")}
                className="w-full rounded-xl sm:w-auto"
              >
                Открыть дневник
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {routineFacts.slice(0, 3).map((entry) => (
                <div key={entry.id} className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-xl">
                    {entry.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium text-foreground">{entry.type}</span>
                      <span className="text-xs text-muted-foreground">{entry.time}</span>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{entry.details}</div>
                  </div>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() => onNavigate("tracker")}
                className="w-full rounded-xl"
              >
                Сверить в дневнике
              </Button>
            </div>
          )}
        </div>
      </motion.div>

      {items.length === 0 ? (
        <ActionEmptyState
          icon={<Calendar className="h-7 w-7" />}
          title="Добавьте первый якорь дня"
          description={`Начните с кормления, сна или прогулки для ${baby.name}. Потом эти точки помогут спокойнее видеть день целиком.`}
          primaryAction={{ label: "Добавить пункт", onClick: () => setIsModalOpen(true) }}
          className="rounded-xl bg-secondary/30 shadow-none"
        />
      ) : (
        <div className="relative">
          <div className="absolute left-[50px] top-0 bottom-0 w-1 bg-gradient-to-b from-primary/30 via-accent/30 to-primary/30 rounded-full sm:left-[80px]" />

          <div className="space-y-4">
            {items.map((item, idx) => {
              const category = inferRoutineCategory(item.activity, item.emoji);
              const linkedFact = getRoutineFact(item);

              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -30 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05, duration: 0.4 }}
                  className="relative flex gap-3 sm:gap-6"
                >
                  <div className="w-10 shrink-0 text-right sm:w-[60px]">
                    <div className="text-sm font-medium text-foreground">{item.time}</div>
                  </div>

                  <div className="relative z-10">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: idx * 0.05 + 0.2 }}
                      className="w-10 h-10 bg-gradient-to-br from-primary to-accent rounded-full border-4 border-white shadow-sm flex items-center justify-center text-xl"
                    >
                      {item.emoji}
                    </motion.div>
                  </div>

                  <motion.div
                    whileHover={{ x: 4, scale: 1.01 }}
                    className={`min-w-0 flex-1 bg-gradient-to-br ${item.color} backdrop-blur-sm border border-border/70 rounded-xl p-3 cursor-pointer shadow-sm hover:shadow-md transition-all md:p-4`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                      <div>
                        <h3 className="font-medium text-foreground mb-1">{item.activity}</h3>
                        <div className="text-sm text-muted-foreground">{item.duration}</div>
                      </div>
                      {category && (
                        <div
                          className={`w-fit rounded-full px-3 py-1 text-xs font-medium ${
                            linkedFact
                              ? "bg-primary/10 text-primary"
                              : "bg-white/70 text-muted-foreground"
                          }`}
                        >
                          {linkedFact ? "записано в дневник" : "ожидает факта"}
                        </div>
                      )}
                    </div>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="mt-8 rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 p-4 md:p-5"
      >
        <div className="flex flex-col md:flex-row md:items-start gap-5 md:gap-6">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-white/80 rounded-xl flex items-center justify-center text-2xl md:text-3xl shadow-sm">
            💡
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium text-foreground mb-2">Совет по режиму</h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4 md:text-base">
              Для {baby.name} на этапе «{age.stageLabel}»: {age.routineHint}. Записывайте фактический сон и кормления, а режим будет показывать, где план совпал с реальностью.
            </p>
            <div className="flex flex-wrap gap-3">
              <div className="bg-white/60 rounded-xl px-4 py-2">
                <div className="text-lg font-medium text-foreground">{summary.feeding}</div>
                <div className="text-xs text-muted-foreground">кормлений</div>
              </div>
              <div className="bg-white/60 rounded-xl px-4 py-2">
                <div className="text-lg font-medium text-foreground">{summary.sleep}</div>
                <div className="text-xs text-muted-foreground">сна</div>
              </div>
              <div className="bg-white/60 rounded-xl px-4 py-2">
                <div className="text-lg font-medium text-foreground">{summary.totalSleepLabel}</div>
                <div className="text-xs text-muted-foreground">сон всего</div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9 }}
        className="mt-6 relative overflow-hidden rounded-xl border border-primary/20 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5 p-4 pt-12 md:p-5"
      >
        <div className="absolute top-4 right-4">
          <PremiumBadge showText size="sm" />
        </div>
        <div className="flex flex-col md:flex-row md:items-start gap-5 md:gap-6">
          <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-primary to-accent rounded-xl flex items-center justify-center text-2xl shadow-sm">
            <Calendar className="w-8 h-8 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-medium text-foreground mb-2">Умный режим дня</h3>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4 md:text-base">
              Адаптивные рекомендации по окнам бодрствования, подсказки о переутомлении и мягкая корректировка режима под профиль {baby.name}
            </p>
            <div className="mb-4 rounded-xl border border-border/50 bg-card/50 p-3 backdrop-blur-sm md:p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-foreground">Персональные рекомендации для {baby.name}</span>
                <Lock className="w-4 h-4 text-muted-foreground/50" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-3 opacity-60">
                  <div className="w-2 h-2 bg-primary rounded-full" />
                  <span className="text-sm text-muted-foreground">Окно бодрствования: 1.5-2 часа</span>
                </div>
                <div className="flex items-center gap-3 opacity-60">
                  <div className="w-2 h-2 bg-accent rounded-full" />
                  <span className="text-sm text-muted-foreground">Рекомендуемое время сна: 14-17 часов</span>
                </div>
                <div className="flex items-center gap-3 opacity-60">
                  <div className="w-2 h-2 bg-accent-soft rounded-full" />
                  <span className="text-sm text-muted-foreground">Совет: {age.routineHint}</span>
                </div>
              </div>
            </div>
            <Button
              type="button"
              onClick={() => onNavigate("subscription")}
              className="w-full md:w-auto rounded-xl bg-gradient-to-r from-primary to-accent text-white hover:opacity-90"
            >
              <Crown className="w-4 h-4 mr-2" />
              Посмотреть план Премиум
            </Button>
          </div>
        </div>
      </motion.div>

      <AddRoutineModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddRoutine}
      />
    </div>
  );
}

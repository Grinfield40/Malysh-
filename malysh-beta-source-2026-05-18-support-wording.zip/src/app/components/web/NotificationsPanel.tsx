import { motion, AnimatePresence } from "motion/react";
import { X, Bell, Check, Trash2 } from "lucide-react";
import { Button } from "../ui/button";
import { useMemo } from "react";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import {
  buildNotificationItems,
  DEFAULT_NOTIFICATIONS,
  type ChecklistNotificationSource,
  type NotificationItem,
  type ReminderNotificationSource,
} from "../../lib/notifications";

interface NotificationsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate?: (screen: string) => void;
}

export function NotificationsPanel({ isOpen, onClose, onNavigate }: NotificationsPanelProps) {
  const [items, setItems] = useLocalStorageState<NotificationItem[]>("mvp.notifications.items", DEFAULT_NOTIFICATIONS);
  const [readIds, setReadIds] = useLocalStorageState<string[]>("mvp.notifications.readIds", []);
  const [hiddenIds, setHiddenIds] = useLocalStorageState<string[]>("mvp.notifications.hiddenIds", []);
  const [reminders] = useLocalStorageState<ReminderNotificationSource[]>("mvp.reminders.items", []);
  const [checklist] = useLocalStorageState<ChecklistNotificationSource[]>("mvp.reminders.checklist", []);

  const notifications = useMemo(
    () =>
      buildNotificationItems({
        storedItems: items,
        reminders,
        checklist,
        readIds,
        hiddenIds,
      }),
    [items, reminders, checklist, readIds, hiddenIds]
  );

  const unreadCount = notifications.filter((notification) => !notification.read).length;

  const handleMarkAsRead = (id: string) => {
    setItems((prev) =>
      prev.map((notification) =>
        String(notification.id) === id ? { ...notification, read: true } : notification
      )
    );
    setReadIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };

  const handleDelete = (id: string) => {
    setItems((prev) => prev.filter((notification) => String(notification.id) !== id));
    setHiddenIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };

  const handleMarkAllRead = () => {
    setItems((prev) => prev.map((notification) => ({ ...notification, read: true })));
    setReadIds((prev) => Array.from(new Set([...prev, ...notifications.map((notification) => notification.id)])));
  };

  const openNotification = (notification: NotificationItem) => {
    if (!notification.read) {
      handleMarkAsRead(notification.id);
    }

    if (notification.targetScreen) {
      onNavigate?.(notification.targetScreen);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 md:hidden"
          />

          <motion.div
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 md:top-20 md:bottom-auto md:right-4 w-full md:w-[420px] md:max-h-[600px] bg-background md:rounded-3xl shadow-2xl z-50 flex flex-col overflow-hidden border-l md:border border-border"
          >
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0 bg-gradient-to-r from-primary/10 to-accent/10">
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Bell className="w-6 h-6 text-primary" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-2 -right-2 min-w-5 h-5 px-1 bg-destructive text-white text-xs rounded-full flex items-center justify-center font-medium">
                      {unreadCount > 9 ? "9+" : unreadCount}
                    </span>
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-medium text-foreground">Уведомления</h2>
                  <p className="text-xs text-muted-foreground">
                    {unreadCount > 0 ? `${unreadCount} непрочитанных` : "Все прочитано"}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
                aria-label="Закрыть уведомления"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {unreadCount > 0 && (
              <div className="px-6 py-3 border-b border-border bg-secondary/30">
                <button
                  type="button"
                  onClick={handleMarkAllRead}
                  className="text-sm text-primary hover:underline flex items-center gap-2"
                >
                  <Check className="w-4 h-4" />
                  Отметить все как прочитанное
                </button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full py-12 px-6">
                  <div className="text-6xl mb-4">🔔</div>
                  <h3 className="text-lg font-medium text-foreground mb-2">Нет уведомлений</h3>
                  <p className="text-sm text-muted-foreground text-center">
                    Здесь будут появляться напоминания, задачи и важные события.
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {notifications.map((notification, idx) => (
                    <motion.div
                      key={notification.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => openNotification(notification)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          openNotification(notification);
                        }
                      }}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className={`w-full p-4 hover:bg-secondary/30 transition-all cursor-pointer text-left ${
                        !notification.read ? "bg-primary/5" : ""
                      }`}
                    >
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
                          {notification.icon}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h4 className={`text-sm font-medium ${!notification.read ? "text-foreground" : "text-muted-foreground"}`}>
                              {notification.title}
                            </h4>
                            {!notification.read && (
                              <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0 mt-1" />
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">{notification.time}</span>
                            <div className="flex items-center gap-2">
                              {!notification.read && (
                                <button
                                  type="button"
                                  onClick={(event) => {
                                    event.stopPropagation();
                                    handleMarkAsRead(notification.id);
                                  }}
                                  className="text-xs text-primary hover:underline"
                                >
                                  Прочитано
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={(event) => {
                                  event.stopPropagation();
                                  handleDelete(notification.id);
                                }}
                                className="p-1 hover:bg-destructive/10 rounded transition-colors"
                                aria-label="Удалить уведомление"
                              >
                                <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 border-t border-border bg-secondary/30 flex-shrink-0">
              <Button variant="ghost" className="w-full text-sm" onClick={onClose}>
                Закрыть
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

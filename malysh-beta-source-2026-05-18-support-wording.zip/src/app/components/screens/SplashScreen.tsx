import { motion } from "motion/react";
import { useEffect } from "react";

interface SplashScreenProps {
  onStart: () => void;
}

export function SplashScreen({ onStart }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onStart();
    }, 2000);

    return () => clearTimeout(timer);
  }, [onStart]);

  return (
    <div className="h-screen bg-gradient-to-b from-secondary via-background to-background flex flex-col items-center justify-center p-8">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="text-center"
      >
        <div className="mb-6">
          <div className="w-20 h-20 mx-auto bg-primary/10 rounded-3xl flex items-center justify-center backdrop-blur-sm">
            <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center">
              <span className="text-4xl">👶</span>
            </div>
          </div>
        </div>

        <motion.h1
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="text-4xl font-medium text-foreground tracking-tight"
        >
          Семья
        </motion.h1>
      </motion.div>
    </div>
  );
}

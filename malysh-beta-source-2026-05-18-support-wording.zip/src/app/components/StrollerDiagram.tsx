import { motion } from "motion/react";

type StrollerType = "bassinet" | "transformer" | "3in1";

interface StrollerDiagramProps {
  type: StrollerType;
  className?: string;
}

export function StrollerDiagram({ type, className = "" }: StrollerDiagramProps) {
  if (type === "bassinet") {
    return (
      <svg
        viewBox="0 0 400 300"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Люлька - простая схема */}
        <defs>
          <linearGradient id="bassinetGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#E8B4D9", stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: "#9B87D4", stopOpacity: 0.3 }} />
          </linearGradient>
        </defs>

        {/* Рама */}
        <motion.line
          x1="150"
          y1="180"
          x2="150"
          y2="240"
          stroke="#6B7280"
          strokeWidth="8"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        />
        <motion.line
          x1="250"
          y1="180"
          x2="250"
          y2="240"
          stroke="#6B7280"
          strokeWidth="8"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        />

        {/* Колеса */}
        <motion.circle
          cx="130"
          cy="260"
          r="30"
          fill="none"
          stroke="#374151"
          strokeWidth="12"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.5 }}
        />
        <motion.circle
          cx="130"
          cy="260"
          r="18"
          fill="#6B7280"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.6 }}
        />
        <motion.circle
          cx="270"
          cy="260"
          r="30"
          fill="none"
          stroke="#374151"
          strokeWidth="12"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.5 }}
        />
        <motion.circle
          cx="270"
          cy="260"
          r="18"
          fill="#6B7280"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.6 }}
        />

        {/* Люлька блок */}
        <motion.rect
          x="80"
          y="80"
          width="240"
          height="100"
          rx="20"
          fill="url(#bassinetGrad)"
          stroke="#9B87D4"
          strokeWidth="4"
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 80, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        />

        {/* Козырёк */}
        <motion.path
          d="M 80 80 Q 200 20 320 80"
          fill="none"
          stroke="#9B87D4"
          strokeWidth="4"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.7, delay: 0.4 }}
        />

        {/* Метки */}
        <text x="200" y="140" textAnchor="middle" fontSize="14" fill="#6B7280" fontWeight="600">
          Только для сна
        </text>
        <text x="200" y="160" textAnchor="middle" fontSize="12" fill="#9CA3AF">
          0-6 месяцев
        </text>
      </svg>
    );
  }

  if (type === "transformer") {
    return (
      <svg
        viewBox="0 0 400 350"
        className={className}
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Трансформер - сложная схема */}
        <defs>
          <linearGradient id="transformerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: "#FCA5A5", stopOpacity: 0.3 }} />
            <stop offset="100%" style={{ stopColor: "#9B87D4", stopOpacity: 0.3 }} />
          </linearGradient>
        </defs>

        {/* Рама усиленная */}
        <motion.rect
          x="100"
          y="180"
          width="200"
          height="60"
          rx="10"
          fill="#E5E7EB"
          stroke="#6B7280"
          strokeWidth="4"
          initial={{ scaleY: 0 }}
          animate={{ scaleY: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        />

        {/* Колеса большие */}
        <motion.circle
          cx="120"
          cy="280"
          r="40"
          fill="none"
          stroke="#374151"
          strokeWidth="14"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        />
        <motion.circle
          cx="120"
          cy="280"
          r="22"
          fill="#6B7280"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.7 }}
        />
        <motion.circle
          cx="280"
          cy="280"
          r="40"
          fill="none"
          stroke="#374151"
          strokeWidth="14"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        />
        <motion.circle
          cx="280"
          cy="280"
          r="22"
          fill="#6B7280"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.4, delay: 0.7 }}
        />

        {/* Сиденье - трансформируемое */}
        <motion.rect
          x="100"
          y="70"
          width="200"
          height="110"
          rx="15"
          fill="url(#transformerGrad)"
          stroke="#9B87D4"
          strokeWidth="4"
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: 70, opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        />

        {/* Спинка - разделительная линия */}
        <motion.line
          x1="100"
          y1="120"
          x2="300"
          y2="120"
          stroke="#9B87D4"
          strokeWidth="2"
          strokeDasharray="5,5"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
        />

        {/* Козырёк */}
        <motion.path
          d="M 90 70 Q 200 10 310 70"
          fill="none"
          stroke="#9B87D4"
          strokeWidth="5"
          strokeLinecap="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        />

        {/* Стрелки трансформации */}
        <motion.path
          d="M 130 130 L 150 130 M 145 125 L 150 130 L 145 135"
          stroke="#E8B4D9"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0, 1] }}
          transition={{ duration: 1.5, repeat: Infinity, delay: 1 }}
        />
        <motion.path
          d="M 270 130 L 250 130 M 255 125 L 250 130 L 255 135"
          stroke="#E8B4D9"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0, 1] }}
          transition={{ duration: 1.5, repeat: Infinity, delay: 1.2 }}
        />

        {/* Метки */}
        <text x="200" y="145" textAnchor="middle" fontSize="14" fill="#6B7280" fontWeight="600">
          Трансформация
        </text>
        <text x="200" y="165" textAnchor="middle" fontSize="12" fill="#9CA3AF">
          0-3 года
        </text>
      </svg>
    );
  }

  // 3 в 1
  return (
    <svg
      viewBox="0 0 450 400"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* 3 в 1 - три модуля */}
      <defs>
        <linearGradient id="module1Grad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#93C5FD", stopOpacity: 0.4 }} />
          <stop offset="100%" style={{ stopColor: "#9B87D4", stopOpacity: 0.4 }} />
        </linearGradient>
        <linearGradient id="module2Grad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#E8B4D9", stopOpacity: 0.4 }} />
          <stop offset="100%" style={{ stopColor: "#9B87D4", stopOpacity: 0.4 }} />
        </linearGradient>
        <linearGradient id="module3Grad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" style={{ stopColor: "#FCD34D", stopOpacity: 0.4 }} />
          <stop offset="100%" style={{ stopColor: "#9B87D4", stopOpacity: 0.4 }} />
        </linearGradient>
      </defs>

      {/* Центральная рама */}
      <motion.rect
        x="150"
        y="200"
        width="150"
        height="60"
        rx="10"
        fill="#E5E7EB"
        stroke="#6B7280"
        strokeWidth="4"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      />

      {/* Колеса */}
      <motion.circle
        cx="170"
        cy="290"
        r="35"
        fill="none"
        stroke="#374151"
        strokeWidth="12"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.7 }}
      />
      <motion.circle
        cx="170"
        cy="290"
        r="20"
        fill="#6B7280"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.4, delay: 0.8 }}
      />
      <motion.circle
        cx="280"
        cy="290"
        r="35"
        fill="none"
        stroke="#374151"
        strokeWidth="12"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5, delay: 0.7 }}
      />
      <motion.circle
        cx="280"
        cy="290"
        r="20"
        fill="#6B7280"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.4, delay: 0.8 }}
      />

      {/* Модуль 1 - Люлька */}
      <motion.g
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.1 }}
      >
        <rect
          x="20"
          y="50"
          width="120"
          height="70"
          rx="12"
          fill="url(#module1Grad)"
          stroke="#93C5FD"
          strokeWidth="3"
        />
        <text x="80" y="85" textAnchor="middle" fontSize="12" fill="#6B7280" fontWeight="600">
          Люлька
        </text>
        <text x="80" y="105" textAnchor="middle" fontSize="10" fill="#9CA3AF">
          0-6 мес
        </text>
      </motion.g>

      {/* Модуль 2 - Прогулка */}
      <motion.g
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
      >
        <rect
          x="165"
          y="50"
          width="120"
          height="70"
          rx="12"
          fill="url(#module2Grad)"
          stroke="#E8B4D9"
          strokeWidth="3"
        />
        <text x="225" y="85" textAnchor="middle" fontSize="12" fill="#6B7280" fontWeight="600">
          Прогулка
        </text>
        <text x="225" y="105" textAnchor="middle" fontSize="10" fill="#9CA3AF">
          6 мес-3 года
        </text>
      </motion.g>

      {/* Модуль 3 - Автокресло */}
      <motion.g
        initial={{ x: 100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.3 }}
      >
        <rect
          x="310"
          y="50"
          width="120"
          height="70"
          rx="12"
          fill="url(#module3Grad)"
          stroke="#FCD34D"
          strokeWidth="3"
        />
        <text x="370" y="85" textAnchor="middle" fontSize="12" fill="#6B7280" fontWeight="600">
          Автокресло
        </text>
        <text x="370" y="105" textAnchor="middle" fontSize="10" fill="#9CA3AF">
          0-1.5 года
        </text>
      </motion.g>

      {/* Стрелки к раме */}
      <motion.path
        d="M 80 120 L 200 200"
        stroke="#93C5FD"
        strokeWidth="2"
        strokeDasharray="5,5"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.8, delay: 0.9 }}
      />
      <motion.path
        d="M 225 120 L 225 200"
        stroke="#E8B4D9"
        strokeWidth="2"
        strokeDasharray="5,5"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.8, delay: 1 }}
      />
      <motion.path
        d="M 370 120 L 250 200"
        stroke="#FCD34D"
        strokeWidth="2"
        strokeDasharray="5,5"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.8, delay: 1.1 }}
      />

      {/* Метка */}
      <motion.text
        x="225"
        y="350"
        textAnchor="middle"
        fontSize="14"
        fill="#6B7280"
        fontWeight="600"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.3 }}
      >
        Одно шасси - три модуля
      </motion.text>
    </svg>
  );
}

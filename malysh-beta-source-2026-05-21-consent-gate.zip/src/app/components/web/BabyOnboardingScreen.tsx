import { FormEvent, useMemo, useState } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Heart,
  Ruler,
  Scale,
} from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Logo } from "../Logo";
import {
  DEFAULT_BABY_PROFILE,
  getBabyAgeInfo,
  inferBabyStageFromBirthDate,
  normalizeBabyProfile,
  type BabyProfile,
} from "../../lib/babyProfile";
import {
  PARENT_GOALS,
  DEFAULT_PARENT_GOALS,
  normalizeParentGoals,
  type ParentGoalId,
} from "../../lib/parentGoals";

interface BabyOnboardingScreenProps {
  onComplete: (profile: BabyProfile, goals: ParentGoalId[]) => void;
  onLogout?: () => void;
  isSaving?: boolean;
  saveError?: string;
}

const steps = [
  { title: "Ребенок", description: "Имя и примерный возраст" },
  { title: "Цели", description: "Что держать в фокусе каждый день" },
  { title: "Старт", description: "Проверка перед входом" },
];

const stageOptions: Array<{
  id: BabyProfile["stage"];
  label: string;
  hint: string;
}> = [
  { id: "pregnancy", label: "Ждем малыша", hint: "ПДР или подготовка" },
  { id: "0-3", label: "0-3 месяца", hint: "сон, кормление, уход" },
  { id: "3-6", label: "3-6 месяцев", hint: "ритм дня и развитие" },
  { id: "6-12", label: "6-12 месяцев", hint: "прикорм и движение" },
];

const emojiOptions = ["👶", "🧸", "🌙", "⭐", "💛"];

function toIsoDate(year: number, month: number, day: number) {
  const date = new Date(year, month - 1, day);

  if (
    date.getFullYear() !== year ||
    date.getMonth() !== month - 1 ||
    date.getDate() !== day
  ) {
    return "";
  }

  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function parseBirthDateInput(value: string) {
  const trimmedValue = value.trim();
  const isoMatch = trimmedValue.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  const ruMatch = trimmedValue.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);

  if (isoMatch) {
    return toIsoDate(Number(isoMatch[1]), Number(isoMatch[2]), Number(isoMatch[3]));
  }

  if (ruMatch) {
    return toIsoDate(Number(ruMatch[3]), Number(ruMatch[2]), Number(ruMatch[1]));
  }

  return "";
}

function getBirthDateIssue(birthDate: string) {
  const birthTime = Date.parse(birthDate);

  if (Number.isNaN(birthTime)) {
    return "Укажите дату в формате 10.04.2026 или 2026-04-10.";
  }

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const earliest = new Date(today);
  const latest = new Date(today);

  earliest.setFullYear(today.getFullYear() - 4);
  latest.setDate(today.getDate() + 300);

  if (birthTime < earliest.getTime()) {
    return "Сейчас Малыш+ рассчитан на беременность и детей до 4 лет. Проверьте дату.";
  }

  if (birthTime > latest.getTime()) {
    return "ПДР выглядит слишком далеко. Проверьте дату, чтобы подсказки были точными.";
  }

  return "";
}

function getNumberFieldIssue(value: string, label: string, min: number, max: number, unit: string) {
  const normalizedValue = value.trim().replace(",", ".");

  if (!normalizedValue) return "";

  const parsedValue = Number(normalizedValue);

  if (!Number.isFinite(parsedValue) || parsedValue < min || parsedValue > max) {
    return `${label} должен быть числом от ${min} до ${max} ${unit}.`;
  }

  return "";
}

export function BabyOnboardingScreen({ onComplete, onLogout, isSaving = false, saveError = "" }: BabyOnboardingScreenProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [draft, setDraft] = useState<BabyProfile>({
    name: "",
    birthDate: "",
    stage: "0-3",
    heightCm: "",
    weightKg: "",
    bloodType: "—",
    emoji: "👶",
  });
  const [birthDateInput, setBirthDateInput] = useState("");
  const [selectedGoals, setSelectedGoals] = useState<ParentGoalId[]>(DEFAULT_PARENT_GOALS);
  const [error, setError] = useState("");

  const normalizedBaby = useMemo(
    () => normalizeBabyProfile({ ...draft, birthDate: draft.birthDate || DEFAULT_BABY_PROFILE.birthDate }),
    [draft]
  );
  const agePreview = useMemo(() => {
    if (!draft.birthDate) return null;
    return getBabyAgeInfo(normalizedBaby);
  }, [draft.birthDate, normalizedBaby]);
  const normalizedGoals = normalizeParentGoals(selectedGoals);

  const updateDraft = (updates: Partial<BabyProfile>) => {
    setDraft((prev) => ({ ...prev, ...updates }));
    setError("");
  };

  const handleBirthDateChange = (value: string) => {
    const birthDate = parseBirthDateInput(value);
    setBirthDateInput(value);

    updateDraft({
      birthDate,
      stage: birthDate ? inferBabyStageFromBirthDate(birthDate) : draft.stage,
    });
  };

  const toggleGoal = (goalId: ParentGoalId) => {
    setSelectedGoals((prev) =>
      prev.includes(goalId)
        ? prev.filter((id) => id !== goalId)
        : [...prev, goalId]
    );
    setError("");
  };

  const validateBabyStep = () => {
    if (!draft.name.trim()) {
      setError("Введите имя ребенка, чтобы персонализировать приложение.");
      return false;
    }

    if (birthDateInput.trim() && !draft.birthDate) {
      setError("Если указываете дату, используйте формат 10.04.2026 или 2026-04-10.");
      return false;
    }

    const birthDateIssue = draft.birthDate ? getBirthDateIssue(draft.birthDate) : "";

    if (birthDateIssue) {
      setError(birthDateIssue);
      return false;
    }

    const heightIssue = getNumberFieldIssue(draft.heightCm, "Рост", 20, 120, "см");

    if (heightIssue) {
      setError(heightIssue);
      return false;
    }

    const weightIssue = getNumberFieldIssue(draft.weightKg, "Вес", 0.3, 30, "кг");

    if (weightIssue) {
      setError(weightIssue);
      return false;
    }

    return true;
  };

  const validateGoalsStep = () => {
    if (normalizedGoals.length === 0) {
      setError("Выберите хотя бы одну цель, чтобы главная была полезной с первого дня.");
      return false;
    }

    return true;
  };

  const goNext = () => {
    if (currentStep === 0 && !validateBabyStep()) return;
    if (currentStep === 1 && !validateGoalsStep()) return;

    setError("");
    setCurrentStep((prev) => Math.min(prev + 1, steps.length - 1));
  };

  const goBack = () => {
    setError("");
    setCurrentStep((prev) => Math.max(prev - 1, 0));
  };

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();

    if (currentStep < steps.length - 1) {
      goNext();
      return;
    }

    if (!validateBabyStep() || !validateGoalsStep()) return;
    onComplete(normalizedBaby, normalizedGoals);
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6 md:px-8 md:py-10">
      <div className="mx-auto flex min-h-[calc(100vh-3rem)] w-full max-w-6xl flex-col">
        <header className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Logo size={44} animate />
            <div>
              <div className="text-xl font-medium text-foreground">Малыш+</div>
              <div className="text-xs text-muted-foreground">Первый запуск</div>
            </div>
          </div>
          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Выйти
            </button>
          )}
        </header>

        <main className="grid flex-1 grid-cols-1 items-center gap-8 py-8 lg:grid-cols-[0.9fr_1.1fr]">
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              <Heart className="h-4 w-4" />
              Мастер настройки
            </div>
            <div>
              <h1 className="mb-4 text-3xl font-medium leading-tight text-foreground md:text-5xl">
                {currentStep === 0 && "Начнем с профиля ребенка"}
                {currentStep === 1 && "Что сейчас важнее всего?"}
                {currentStep === 2 && "Все готово к первому дню"}
              </h1>
              <p className="max-w-xl text-base leading-relaxed text-muted-foreground md:text-lg">
                {currentStep === 0 &&
                  "Эти данные будут использоваться на главной, в режиме дня, трекере и рекомендациях."}
                {currentStep === 1 &&
                  "Выберите несколько целей. По ним Малыш+ соберет быстрые действия и подсказки на главной."}
                {currentStep === 2 &&
                  "Проверьте профиль и приоритеты. Потом их можно будет изменить в профиле."}
              </p>
            </div>

            <div className="space-y-3">
              {steps.map((step, index) => {
                const isActive = currentStep === index;
                const isDone = currentStep > index;

                return (
                  <div
                    key={step.title}
                    className={`flex items-center gap-3 rounded-2xl border px-4 py-3 transition-all ${
                      isActive
                        ? "border-primary bg-primary/10"
                        : "border-border bg-card"
                    }`}
                  >
                    <div
                      className={`flex h-9 w-9 items-center justify-center rounded-xl text-sm font-medium ${
                        isDone || isActive
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {isDone ? <Check className="h-4 w-4" /> : index + 1}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-foreground">{step.title}</div>
                      <div className="text-xs text-muted-foreground">{step.description}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </motion.section>

          <motion.section
            key={currentStep}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="rounded-3xl border border-border bg-card p-5 shadow-xl shadow-primary/5 md:p-8"
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              {currentStep === 0 && (
                <BabyProfileStep
                  draft={draft}
                  birthDateInput={birthDateInput}
                  agePreview={agePreview?.label ? `${agePreview.label} · ${agePreview.stageLabel}` : null}
                  onDraftChange={updateDraft}
                  onBirthDateChange={handleBirthDateChange}
                />
              )}

              {currentStep === 1 && (
                <GoalsStep
                  selectedGoals={selectedGoals}
                  onToggleGoal={toggleGoal}
                />
              )}

              {currentStep === 2 && (
                <SummaryStep
                  baby={normalizedBaby}
                  ageLabel={agePreview?.label ?? "возраст будет уточнен"}
                  stageLabel={agePreview?.stageLabel ?? "этап будет уточнен"}
                  selectedGoals={normalizedGoals}
                />
              )}

              {(error || saveError) && (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                  {error || saveError}
                </div>
              )}

              <div className="flex flex-col-reverse gap-3 md:flex-row md:items-center md:justify-between">
                <Button
                  type="button"
                  variant="outline"
                  onClick={goBack}
                  disabled={currentStep === 0 || isSaving}
                  className="h-12 rounded-xl"
                >
                  <ArrowLeft className="mr-2 h-5 w-5" />
                  Назад
                </Button>
                <Button type="submit" disabled={isSaving} className="h-12 rounded-xl text-base md:min-w-48">
                  {isSaving
                    ? "Сохраняем..."
                    : currentStep === steps.length - 1
                      ? "Открыть Малыш+"
                      : "Продолжить"}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </form>
          </motion.section>
        </main>
      </div>
    </div>
  );
}

interface BabyProfileStepProps {
  draft: BabyProfile;
  birthDateInput: string;
  agePreview: string | null;
  onDraftChange: (updates: Partial<BabyProfile>) => void;
  onBirthDateChange: (value: string) => void;
}

function BabyProfileStep({
  draft,
  birthDateInput,
  agePreview,
  onDraftChange,
  onBirthDateChange,
}: BabyProfileStepProps) {
  return (
    <>
      <div>
        <h2 className="text-2xl font-medium text-foreground">Профиль ребенка</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Минимум: имя и примерный этап. Дату, рост, вес и другие детали можно заполнить позже в профиле.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-[1fr_auto]">
        <div>
          <label className="mb-2 block text-sm font-medium text-foreground">
            Имя ребенка
          </label>
          <Input
            value={draft.name}
            onChange={(event) => onDraftChange({ name: event.target.value })}
            placeholder="Например, София"
            className="h-12 rounded-xl"
            autoFocus
          />
        </div>
        <div>
          <label className="mb-2 block text-sm font-medium text-foreground">
            Значок
          </label>
          <div className="flex h-12 gap-2">
            {emojiOptions.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => onDraftChange({ emoji })}
                aria-pressed={draft.emoji === emoji}
                className={`h-12 w-12 rounded-xl border text-2xl transition-all ${
                  draft.emoji === emoji
                    ? "border-primary bg-primary/10"
                    : "border-border bg-background hover:border-primary/30"
                }`}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div>
          <label className="mb-2 block text-sm font-medium text-foreground">
            Дата рождения или ПДР
          </label>
          <Input
            value={birthDateInput}
            onChange={(event) => onBirthDateChange(event.target.value)}
            placeholder="Можно позже"
            className="h-12 rounded-xl"
          />
        </div>
        <div>
          <label className="mb-2 block text-sm font-medium text-foreground">
            Короткая сводка
          </label>
          <div className="flex h-12 items-center rounded-xl border border-border bg-secondary/50 px-4 text-sm text-muted-foreground">
            {agePreview ?? "Будет точнее после даты"}
          </div>
        </div>
      </div>

      <div>
        <label className="mb-3 block text-sm font-medium text-foreground">
          Текущий этап
        </label>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {stageOptions.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => onDraftChange({ stage: option.id })}
              aria-pressed={draft.stage === option.id}
              className={`rounded-2xl border p-4 text-left transition-all ${
                draft.stage === option.id
                  ? "border-primary bg-primary/10"
                  : "border-border bg-background hover:border-primary/30"
              }`}
            >
              <div className="text-sm font-medium text-foreground">{option.label}</div>
              <div className="mt-1 text-xs text-muted-foreground">{option.hint}</div>
            </button>
          ))}
        </div>
      </div>

      <details className="rounded-2xl border border-border bg-background p-4">
        <summary className="cursor-pointer text-sm font-medium text-foreground">
          Дополнительные данные
        </summary>
        <p className="mt-2 text-sm text-muted-foreground">
          Эти поля не обязательны для первого входа. Оставляем только бытовые параметры ухода без медицинских сведений.
        </p>
        <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
              <Ruler className="h-4 w-4 text-muted-foreground" />
              Рост
            </label>
            <Input
              value={draft.heightCm}
              onChange={(event) => onDraftChange({ heightCm: event.target.value })}
              placeholder="см"
              className="h-12 rounded-xl"
            />
          </div>
          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
              <Scale className="h-4 w-4 text-muted-foreground" />
              Вес
            </label>
            <Input
              value={draft.weightKg}
              onChange={(event) => onDraftChange({ weightKg: event.target.value })}
              placeholder="кг"
              className="h-12 rounded-xl"
            />
          </div>
        </div>
      </details>
    </>
  );
}

interface GoalsStepProps {
  selectedGoals: ParentGoalId[];
  onToggleGoal: (goalId: ParentGoalId) => void;
}

function GoalsStep({ selectedGoals, onToggleGoal }: GoalsStepProps) {
  return (
    <>
      <div>
        <h2 className="text-2xl font-medium text-foreground">Цели родителя</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Можно выбрать несколько. Главная будет поднимать их выше остальных действий.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {PARENT_GOALS.map((goal) => {
          const isSelected = selectedGoals.includes(goal.id);

          return (
            <button
              key={goal.id}
              type="button"
              onClick={() => onToggleGoal(goal.id)}
              aria-pressed={isSelected}
              className={`flex items-start gap-4 rounded-2xl border p-4 text-left transition-all ${
                isSelected
                  ? "border-primary bg-primary/10"
                  : "border-border bg-background hover:border-primary/30"
              }`}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-2xl">
                {goal.icon}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-3">
                  <div className="font-medium text-foreground">{goal.label}</div>
                  <div
                    className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${
                      isSelected
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border bg-card"
                    }`}
                  >
                    {isSelected && <Check className="h-4 w-4" />}
                  </div>
                </div>
                <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                  {goal.description}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </>
  );
}

interface SummaryStepProps {
  baby: BabyProfile;
  ageLabel: string;
  stageLabel: string;
  selectedGoals: ParentGoalId[];
}

function SummaryStep({ baby, ageLabel, stageLabel, selectedGoals }: SummaryStepProps) {
  const goalSummaries = selectedGoals.map((goalId) =>
    PARENT_GOALS.find((goal) => goal.id === goalId)
  ).filter(Boolean);

  return (
    <>
      <div>
        <h2 className="text-2xl font-medium text-foreground">Финальная настройка</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Эти данные сохранятся в вашем аккаунте и сразу настроят Малыш+ под ребенка.
        </p>
      </div>

      <div className="rounded-2xl border border-primary/20 bg-primary/10 p-5">
        <div className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-card text-4xl">
            {baby.emoji}
          </div>
          <div>
            <div className="text-sm text-primary">Профиль ребенка</div>
            <div className="text-2xl font-medium text-foreground">
              {baby.name}, {ageLabel}
            </div>
            <div className="text-sm text-muted-foreground">{stageLabel}</div>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <div className="text-sm font-medium text-foreground">Приоритеты на главной</div>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {goalSummaries.map((goal) => (
            goal && (
              <div
                key={goal.id}
                className="rounded-2xl border border-border bg-background p-4"
              >
                <div className="mb-2 flex items-center gap-2">
                  <span className="text-xl">{goal.icon}</span>
                  <span className="text-sm font-medium text-foreground">{goal.label}</span>
                </div>
                <p className="text-xs leading-relaxed text-muted-foreground">
                  {goal.homeHint}
                </p>
              </div>
            )
          ))}
        </div>
      </div>
    </>
  );
}

import { motion, AnimatePresence } from "motion/react";
import { X, Star, ShoppingCart, Info, Baby, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "../ui/button";
import { StrollerDiagram } from "../StrollerDiagram";

type ModalContentType = "quickGuide" | "education" | "collection" | "product";

interface StrollerModel {
  id: number;
  name: string;
  type: string;
  price: string;
  image: string;
  rating: number;
  reviews: number;
  badges: string[];
  weight: string;
  age: string;
  width: string;
  verdict: string;
}

interface QuickGuideData {
  id: string;
  title: string;
  emoji: string;
  recommendations: string[];
  bestModels: Array<{ name: string; why: string }>;
}

interface EducationData {
  title: string;
  content: string;
  details: string[];
  diagram?: "bassinet" | "transformer" | "3in1";
}

interface CollectionData {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  models: Array<{ name: string; price: string; highlight: string }>;
}

interface ProductDetailData extends StrollerModel {
  description: string;
  pros: string[];
  cons: string[];
  specs: Array<{ label: string; value: string }>;
  diagram?: "bassinet" | "transformer" | "3in1";
}

interface StrollerDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: ModalContentType;
  data: QuickGuideData | EducationData | CollectionData | ProductDetailData;
}

export function StrollerDetailModal({ isOpen, onClose, type, data }: StrollerDetailModalProps) {
  const renderContent = () => {
    if (type === "quickGuide") {
      const guide = data as QuickGuideData;
      return (
        <div>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-6xl">{guide.emoji}</span>
            <div>
              <h2 className="text-2xl md:text-3xl font-medium text-foreground">
                {guide.title}
              </h2>
              <p className="text-sm text-muted-foreground">Рекомендации по выбору</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-foreground mb-3 flex items-center gap-2">
                <Info className="w-5 h-5 text-primary" />
                На что обратить внимание
              </h3>
              <div className="space-y-2">
                {guide.recommendations.map((rec, idx) => (
                  <div key={idx} className="flex items-start gap-3 bg-primary/5 rounded-xl p-3">
                    <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-foreground">{rec}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium text-foreground mb-3 flex items-center gap-2">
                <Star className="w-5 h-5 text-primary" />
                Лучшие модели
              </h3>
              <div className="space-y-3">
                {guide.bestModels.map((model, idx) => (
                  <div key={idx} className="bg-accent/10 rounded-xl p-4">
                    <h4 className="font-medium text-foreground mb-1">{model.name}</h4>
                    <p className="text-sm text-muted-foreground">{model.why}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      );
    }

    if (type === "education") {
      const edu = data as EducationData;
      return (
        <div>
          <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-6">
            {edu.title}
          </h2>

          <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-6 mb-6">
            <p className="text-base text-foreground leading-relaxed">{edu.content}</p>
          </div>

          {edu.diagram && (
            <div className="bg-card border-2 border-border rounded-2xl p-6 mb-6">
              <StrollerDiagram type={edu.diagram} className="w-full max-w-md mx-auto" />
            </div>
          )}

          <div className="space-y-3">
            {edu.details.map((detail, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-sm font-medium mt-0.5">
                  {idx + 1}
                </div>
                <p className="text-sm text-foreground">{detail}</p>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (type === "collection") {
      const collection = data as CollectionData;
      return (
        <div>
          <div className="flex items-center gap-4 mb-6">
            <span className="text-6xl">{collection.icon}</span>
            <div>
              <h2 className="text-2xl md:text-3xl font-medium text-foreground">
                {collection.title}
              </h2>
              <p className="text-sm text-muted-foreground">{collection.subtitle}</p>
            </div>
          </div>

          <div className="grid gap-4">
            {collection.models.map((model, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="bg-card border-2 border-border rounded-xl p-4 hover:border-primary/30 transition-all"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium text-foreground mb-1">{model.name}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{model.highlight}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-medium text-foreground mb-2">{model.price}</div>
                    <Button size="sm" className="rounded-xl">
                      Подробнее
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      );
    }

    // product detail
    const product = data as ProductDetailData;
    return (
      <div>
        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div>
            <img
              src={product.image}
              alt={product.name}
              className="w-full aspect-square object-cover rounded-2xl"
            />
          </div>
          <div>
            <div className="flex flex-wrap gap-2 mb-3">
              {product.badges.map((badge, i) => (
                <span
                  key={i}
                  className="bg-primary/10 text-primary text-xs px-3 py-1 rounded-full"
                >
                  {badge}
                </span>
              ))}
            </div>
            <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-2">
              {product.name}
            </h2>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center gap-1">
                <Star className="w-5 h-5 fill-primary text-primary" />
                <span className="text-lg font-medium">{product.rating}</span>
              </div>
              <span className="text-sm text-muted-foreground">({product.reviews} отзывов)</span>
            </div>
            <p className="text-base text-muted-foreground mb-6">{product.description}</p>

            <div className="bg-primary/5 rounded-xl p-4 mb-6">
              <p className="text-sm text-foreground">💡 {product.verdict}</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-3xl font-medium text-foreground">{product.price}</div>
              <Button className="rounded-xl h-12 px-6">
                <ShoppingCart className="w-5 h-5 mr-2" />
                Купить
              </Button>
            </div>
          </div>
        </div>

        {product.diagram && (
          <div className="bg-card border-2 border-border rounded-2xl p-6 mb-6">
            <h3 className="text-lg font-medium text-foreground mb-4">Конструкция</h3>
            <StrollerDiagram type={product.diagram} className="w-full max-w-lg mx-auto" />
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="text-lg font-medium text-foreground mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              Преимущества
            </h3>
            <div className="space-y-2">
              {product.pros.map((pro, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500 mt-2 flex-shrink-0" />
                  <p className="text-sm text-foreground">{pro}</p>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-lg font-medium text-foreground mb-3 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-500" />
              Недостатки
            </h3>
            <div className="space-y-2">
              {product.cons.map((con, idx) => (
                <div key={idx} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                  <p className="text-sm text-foreground">{con}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-foreground mb-3">Характеристики</h3>
          <div className="grid grid-cols-2 gap-3">
            {product.specs.map((spec, idx) => (
              <div key={idx} className="bg-accent/10 rounded-xl p-3">
                <div className="text-xs text-muted-foreground mb-1">{spec.label}</div>
                <div className="text-sm font-medium text-foreground">{spec.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-4 md:inset-auto md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-4xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <div className="flex items-center gap-2">
                <Baby className="w-6 h-6 text-primary" />
                <span className="text-lg font-medium text-foreground">Малыш+</span>
              </div>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-muted hover:bg-muted/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-6">
              {renderContent()}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

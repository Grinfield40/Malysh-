import { AlertTriangle, ShieldCheck, X } from "lucide-react";
import { Button } from "../ui/button";
import { useLocalStorageState } from "../../lib/useLocalStorageState";

interface BetaPrivacyBannerProps {
  hidden?: boolean;
  onNavigate: (screen: string) => void;
}

export function BetaPrivacyBanner({ hidden = false, onNavigate }: BetaPrivacyBannerProps) {
  const [dismissed, setDismissed] = useLocalStorageState("mvp.beta.privacy.notice.dismissed", false);

  if (hidden || dismissed) {
    return null;
  }

  return (
    <section className="mx-4 mt-4 rounded-[1.5rem] border border-amber-200 bg-amber-50/90 px-4 py-3 shadow-sm md:mx-8 md:mt-6 md:px-5">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div className="flex gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-white text-amber-600 shadow-sm">
            <AlertTriangle size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.08em] text-amber-700">
              <ShieldCheck size={16} />
              Закрытая beta
            </div>
            <p className="mt-1 max-w-4xl text-sm leading-relaxed text-amber-900">
              Не вводите чувствительные медицинские данные, документы, адреса и платежную информацию.
              Приложение помогает вести день ребенка, но не заменяет врача.
            </p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <Button
            type="button"
            variant="outline"
            className="h-10 rounded-2xl border-amber-200 bg-white px-4 text-amber-800 hover:bg-amber-100"
            onClick={() => onNavigate("privacy")}
          >
            Подробнее
          </Button>
          <Button
            type="button"
            variant="ghost"
            className="h-10 w-10 rounded-2xl text-amber-800 hover:bg-amber-100"
            onClick={() => setDismissed(true)}
            aria-label="Скрыть предупреждение"
          >
            <X size={18} />
          </Button>
        </div>
      </div>
    </section>
  );
}

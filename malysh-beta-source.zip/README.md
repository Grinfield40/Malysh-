
  # Design from Code

  This is a code bundle for Design from Code. The original project is available at https://www.figma.com/design/SMAZxURbTSfBNPEJjT4G5t/Design-from-Code.

  ## Running the code

  Run `npm.cmd install` to install the dependencies on Windows PowerShell.

  Run `npm.cmd run dev` to start the development server.

  Run `npm.cmd run build` to verify a production build.

  ## Beta package
  
  For the current product backlog and priorities, use [`PRODUCT_BACKLOG.md`](./PRODUCT_BACKLOG.md).
  
  For the first local beta package, use [`BETA_PACKAGE.md`](./BETA_PACKAGE.md).

  It includes launch commands, demo credentials, backup/restore, and known MVP stubs.

  For VPS preparation and the first open beta test, use [`VPS_LAUNCH.md`](./VPS_LAUNCH.md)
  and [`CLOSED_BETA.md`](./CLOSED_BETA.md).

  For direct public access without Cloudflare Tunnel/VPN, use
  [`DIRECT_PUBLIC_ACCESS.md`](./DIRECT_PUBLIC_ACCESS.md).

  For tester-facing rules, use [`BETA_PRIVACY.md`](./BETA_PRIVACY.md)
  and [`BETA_TERMS.md`](./BETA_TERMS.md). The same pages are available in the app at
  `/privacy` and `/terms`.

  If we decide to close registration later, use [`BETA_INVITES.md`](./BETA_INVITES.md).

  Before giving the build to testers, use [`BETA_LAUNCH_PACK.md`](./BETA_LAUNCH_PACK.md)
  or run `npm.cmd run beta:launch`.

  To run only the isolated closed-beta API smoke test, use [`BETA_SMOKE.md`](./BETA_SMOKE.md)
  or run `npm.cmd run beta:smoke`.

  ## Native iOS sync

  `POST /api/auth/yandex/native` verifies a token returned by Yandex Login SDK,
  checks that it was issued for `MALYSH_YANDEX_CLIENT_ID`, and returns the
  normal revocable Malysh+ server session. The Yandex token must never be
  persisted or logged.

  The iOS client stores its versioned snapshot under
  `mvp.ios.snapshot.v1`. A filtered read is available at
  `GET /api/account/storage?key=mvp.ios.snapshot.v1`; writes use the existing
  authenticated `PATCH /api/account/storage`. Current legal consents remain
  mandatory before reading or writing synced data.

  iOS photo bytes are kept outside SQLite under `MALYSH_MEDIA_DIR`. The private
  endpoints `GET /api/account/fridge-images`,
  `PUT|GET|DELETE /api/account/fridge-images/:id` require the normal server
  session and current consents. SQLite stores only ownership, size, SHA-256 and
  timestamps. The default quota is 6 JPEG files, 2.5 MB each and 15 MB total
  per account.

  ## MVP local state

  This local MVP keeps auth, profile notes, shopping checklist, tracker entries,
  reminders, routines, forum posts, and notification state in the browser's
  `localStorage`. Clear site data in the browser to reset the demo state.
  

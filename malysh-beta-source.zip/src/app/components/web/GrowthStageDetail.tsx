import { motion } from "motion/react";
import { ArrowLeft, Heart, AlertCircle, CheckCircle, Lightbulb } from "lucide-react";
import { Button } from "../ui/button";

interface GrowthStageDetailProps {
  onBack: () => void;
}

export function GrowthStageDetail({ onBack }: GrowthStageDetailProps) {
  const keyChanges = [
    "Держит головку самостоятельно",
    "Улыбается в ответ на улыбку",
    "Гулит, издает звуки",
    "Следит глазами за предметами",
    "Хватает погремушку ручкой",
  ];

  const tips = [
    {
      icon: Heart,
      title: "Общайтесь с малышом",
      text: "Разговаривайте, пойте песенки, улыбайтесь. Это важно для развития речи и эмоциональной связи.",
    },
    {
      icon: Lightbulb,
      title: "Выкладывайте на животик",
      text: "По 2-3 минуты несколько раз в день. Это укрепляет мышцы шеи и спины.",
    },
    {
      icon: CheckCircle,
      title: "Что нормально",
      text: "Малыш может срыгивать после кормления, спать по 16-18 часов в сутки, часто просыпаться ночью.",
    },
  ];

  const warnings = [
    "Не держит головку совсем к концу месяца",
    "Не реагирует на громкие звуки",
    "Не фокусирует взгляд на лицах",
    "Судороги или подергивания",
    "Постоянный плач без причины",
  ];

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>К timeline</span>
      </motion.button>

      {/* Header with Illustration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-purple-100/50 via-pink-100/50 to-blue-100/50 rounded-3xl p-12 mb-8 border-2 border-white/50"
      >
        <div className="flex items-center gap-12">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="relative"
          >
            <div className="w-48 h-48 bg-white/80 rounded-full flex items-center justify-center text-8xl shadow-2xl">
              🍼
            </div>
            <motion.div
              animate={{
                y: [0, -10, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute -top-4 -right-4 w-16 h-16 bg-accent/30 rounded-full backdrop-blur-sm flex items-center justify-center text-3xl"
            >
              ✨
            </motion.div>
          </motion.div>

          <div className="flex-1">
            <div className="inline-block px-4 py-2 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4">
              1 месяц
            </div>
            <h1 className="text-5xl font-medium text-foreground mb-4">
              Первые улыбки
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Ваш малыш уже многое умеет! В этом возрасте начинается активное общение с миром.
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Key Changes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-2xl font-medium text-foreground mb-6">Что происходит</h2>
            <div className="space-y-3">
              {keyChanges.map((change, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + idx * 0.1 }}
                  className="flex items-start gap-4 bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-all"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-foreground flex-1">{change}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Tips */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <h2 className="text-2xl font-medium text-foreground mb-6">Советы</h2>
            <div className="space-y-4">
              {tips.map((tip, idx) => {
                const Icon = tip.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 + idx * 0.1 }}
                    whileHover={{ y: -4 }}
                    className="bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/20 rounded-2xl p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-white/80 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-foreground mb-2">{tip.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">{tip.text}</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        </div>

        {/* Sidebar */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-6"
        >
          {/* When to Worry */}
          <div className="bg-gradient-to-br from-destructive/10 to-destructive/5 border-2 border-destructive/20 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-white/80 rounded-xl flex items-center justify-center shadow-lg">
                <AlertCircle className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="font-medium text-foreground">Когда к врачу</h3>
            </div>
            <ul className="space-y-2">
              {warnings.map((warning, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-destructive mt-1">•</span>
                  <span>{warning}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 pt-6 border-t border-destructive/20">
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Если что-то беспокоит — лучше проконсультироваться с врачом. Доверяйте своей интуиции!
              </p>
              <Button className="w-full rounded-2xl bg-primary hover:bg-primary/90">
                Задать вопрос врачу
              </Button>
            </div>
          </div>

          {/* Support Message */}
          <div className="bg-gradient-to-br from-accent/20 to-primary/20 border-2 border-accent/30 rounded-2xl p-6">
            <div className="text-center">
              <div className="text-4xl mb-4">💜</div>
              <h3 className="font-medium text-foreground mb-2">Вы справляетесь!</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Каждый ребенок развивается в своем темпе. Это нормально, если малыш чуть отличается от описания.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

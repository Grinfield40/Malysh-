import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../ui/alert-dialog";
import { Input } from "../ui/input";
import { useEffect, useState } from "react";

interface ConfirmActionDialogProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  requiredText?: string;
  requiredTextLabel?: string;
  requiredTextPlaceholder?: string;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
}

export function ConfirmActionDialog({
  open,
  title,
  description,
  confirmLabel = "Подтвердить",
  cancelLabel = "Отмена",
  destructive = false,
  requiredText,
  requiredTextLabel,
  requiredTextPlaceholder,
  onOpenChange,
  onConfirm,
}: ConfirmActionDialogProps) {
  const [confirmationValue, setConfirmationValue] = useState("");
  const isConfirmationValid =
    !requiredText || confirmationValue.trim().toLowerCase() === requiredText.trim().toLowerCase();

  useEffect(() => {
    if (open) setConfirmationValue("");
  }, [open, requiredText]);

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="rounded-2xl">
        <AlertDialogHeader>
          <AlertDialogTitle>{title}</AlertDialogTitle>
          <AlertDialogDescription>{description}</AlertDialogDescription>
        </AlertDialogHeader>
        {requiredText ? (
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground" htmlFor="confirm-action-text">
              {requiredTextLabel || "Введите подтверждение"}
            </label>
            <Input
              id="confirm-action-text"
              value={confirmationValue}
              placeholder={requiredTextPlaceholder || requiredText}
              className="rounded-xl"
              onChange={(event) => setConfirmationValue(event.target.value)}
            />
          </div>
        ) : null}
        <AlertDialogFooter>
          <AlertDialogCancel className="rounded-xl">{cancelLabel}</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            disabled={!isConfirmationValid}
            className={
              destructive
                ? "rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
                : "rounded-xl"
            }
          >
            {confirmLabel}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

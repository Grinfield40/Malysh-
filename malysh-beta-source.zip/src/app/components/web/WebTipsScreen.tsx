import { motion } from "motion/react";
import { Search, Clock, Bookmark, TrendingUp, Star, MessageSquare, Plus } from "lucide-react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { AddForumPostModal, ForumPost } from "./AddForumPostModal";
import { useState } from "react";
import { useLocalStorageState } from "../../lib/useLocalStorageState";

interface WebTipsScreenProps {
  onArticleClick?: () => void;
}

const categories = ["Все", "Здоровье", "Сон", "Кормление", "Развитие", "Покупки"];

const featuredArticle = {
  id: 1,
  title: "Можно ли целовать ребенка",
  category: "Здоровье",
  time: "4 мин",
  emoji: "💋",
  description: "Разбираемся в вопросе, который волнует многих родителей",
  rating: 4.9,
  reads: 1234,
};

const articles = [
  {
    id: 2,
    title: "Когда обращаться к врачу",
    category: "Здоровье",
    time: "5 мин",
    emoji: "🩺",
    description: "Важные симптомы, которые нельзя игнорировать",
    rating: 4.8,
    reads: 892,
  },
  {
    id: 3,
    title: "Как собрать аптечку",
    category: "Покупки",
    time: "3 мин",
    emoji: "💊",
    description: "Полный список необходимых медикаментов",
    rating: 4.7,
    reads: 654,
  },
  {
    id: 4,
    title: "Что нормально, а что нет",
    category: "Здоровье",
    time: "6 мин",
    emoji: "✅",
    description: "Развеиваем мифы о развитии младенцев",
    rating: 4.9,
    reads: 1567,
  },
  {
    id: 5,
    title: "Режим сна новорожденного",
    category: "Сон",
    time: "7 мин",
    emoji: "🌙",
    description: "Как наладить здоровый сон малыша",
    rating: 4.6,
    reads: 2341,
  },
  {
    id: 6,
    title: "Грудное вскармливание: первые дни",
    category: "Кормление",
    time: "8 мин",
    emoji: "🍼",
    description: "Советы и рекомендации для начинающих мам",
    rating: 4.8,
    reads: 1876,
  },
];

const forumTabs = ["Обсуждения", "Популярное", "Новое"];

const posts = [
  {
    id: 1,
    title: "Малыш плохо спит ночью",
    preview: "Ребенку 2 месяца, просыпается каждые 2 часа. Это нормально? Днем спит хорошо, а вот ночью...",
    author: "Анна М.",
    avatar: "АМ",
    time: "15 мин назад",
    comments: 12,
    category: "Сон",
    views: 156,
  },
  {
    id: 2,
    title: "Когда вводить прикорм?",
    preview: "Педиатр говорит с 6 месяцев, но бабушка настаивает раньше. Что думаете?",
    author: "Екатерина С.",
    avatar: "ЕС",
    time: "1 час назад",
    comments: 24,
    category: "Кормление",
    views: 342,
  },
  {
    id: 3,
    title: "Температура после прививки",
    preview: "Сделали АКДС вчера, сегодня 37.5. Нормально ли это? Ребенок активный, хорошо ест.",
    author: "Мария К.",
    avatar: "МК",
    time: "2 часа назад",
    comments: 8,
    category: "Здоровье",
    views: 89,
  },
  {
    id: 4,
    title: "Выбор коляски",
    preview: "Помогите выбрать между трансформером и модульной коляской. Живем в городе, частные дома рядом нет.",
    author: "Ольга В.",
    avatar: "ОВ",
    time: "3 часа назад",
    comments: 15,
    category: "Покупки",
    views: 201,
  },
  {
    id: 5,
    title: "Колики — что помогает?",
    preview: "Уже всё перепробовали, ничего не помогает. Поделитесь опытом, что реально работало?",
    author: "Светлана Р.",
    avatar: "СР",
    time: "4 часа назад",
    comments: 31,
    category: "Здоровье",
    views: 512,
  },
  {
    id: 6,
    title: "Как организовать режим дня?",
    preview: "Ребенку месяц, хочу установить какой-то режим, но пока получается хаос. С чего начать?",
    author: "Дарья Л.",
    avatar: "ДЛ",
    time: "5 часов назад",
    comments: 19,
    category: "Режим",
    views: 278,
  },
];

const popularTags = ["Сон", "Кормление", "Здоровье", "Покупки", "Развитие", "Режим"];

const forumCategoryLabels: Record<string, string> = {
  health: "Здоровье",
  feeding: "Кормление",
  sleep: "Сон",
  development: "Развитие",
  shopping: "Покупки",
  other: "Общее",
};

export function WebTipsScreen({ onArticleClick }: WebTipsScreenProps) {
  const [forumPosts, setForumPosts] = useLocalStorageState("mvp.forum.posts", posts);
  const [activeTab, setActiveTab] = useState<"tips" | "forum">("tips");
  const [activeCategory, setActiveCategory] = useState("Все");
  const [activeForumTab, setActiveForumTab] = useState("Обсуждения");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [articleSearchQuery, setArticleSearchQuery] = useState(() => {
    try {
      return JSON.parse(window.localStorage.getItem("mvp.home.lastSearch") ?? "\"\"");
    } catch {
      return "";
    }
  });

  const handleAddPost = (post: ForumPost) => {
    setForumPosts((prev) => [
      {
        id: Date.now(),
        title: post.title,
        preview: post.content,
        author: "Вы",
        avatar: "ВЫ",
        time: "только что",
        comments: 0,
        category: forumCategoryLabels[post.category] ?? "Общее",
        views: 0,
      },
      ...prev,
    ]);
  };
  const normalizedArticleSearch = articleSearchQuery.trim().toLowerCase();
  const filteredArticles = articles.filter((article) => {
    const matchesCategory = activeCategory === "Все" || article.category === activeCategory;
    const haystack = `${article.title} ${article.category} ${article.description}`.toLowerCase();
    const matchesSearch = !normalizedArticleSearch || haystack.includes(normalizedArticleSearch);

    return matchesCategory && matchesSearch;
  });

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      {/* Header with Toggle */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <div className="flex items-start justify-between mb-4 md:mb-6">
          <div>
            <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-2">Советы</h1>
            <p className="text-sm md:text-lg text-muted-foreground">
              Проверенная информация от экспертов
            </p>
          </div>
          {activeTab === "forum" && (
            <Button
              onClick={() => setIsModalOpen(true)}
              className="rounded-full h-10 md:h-12 px-4 md:px-6 bg-primary text-primary-foreground hover:bg-primary/90 text-sm md:text-base"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5 mr-2" />
              <span className="hidden md:inline">Создать пост</span>
              <span className="md:hidden">Пост</span>
            </Button>
          )}
        </div>

      </motion.div>

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6 md:mb-8"
      >
        <div className="relative max-w-2xl">
          <Search className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 w-4 h-4 md:w-5 md:h-5 text-muted-foreground" />
          <Input
            value={articleSearchQuery}
            onChange={(event) => setArticleSearchQuery(event.target.value)}
            placeholder="Поиск статей..."
            className="h-12 md:h-14 pl-12 md:pl-14 rounded-2xl bg-card border-border text-sm md:text-base"
          />
        </div>
      </motion.div>

      {/* Tips Content */}
      {activeTab === "tips" && (
        <>
          {/* Categories */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex gap-2 md:gap-3 mb-6 md:mb-8 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0"
          >
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 md:px-6 py-2 md:py-3 rounded-xl whitespace-nowrap text-xs md:text-sm font-medium transition-all border-2 ${
                  activeCategory === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/30"
                }`}
              >
                {cat}
              </button>
            ))}
          </motion.div>
        </>
      )}

      {/* Forum Tabs */}
      {activeTab === "forum" && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="flex gap-2 mb-6 md:mb-8 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0"
        >
          {forumTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveForumTab(tab)}
              className={`px-4 md:px-6 py-2 md:py-3 rounded-full text-xs md:text-sm font-medium transition-all ${
                activeForumTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border hover:border-primary/30"
              }`}
            >
              {tab}
            </button>
          ))}
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Tips Main Content */}
        {activeTab === "tips" && (
          <div className="lg:col-span-2 space-y-6 md:space-y-8">
          {/* Featured Article */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-xl font-medium text-foreground mb-4">Рекомендуем</h2>
            <motion.button
              onClick={onArticleClick}
              whileHover={{ y: -8 }}
              className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-3xl p-8 cursor-pointer group w-full text-left"
            >
              <div className="flex items-start gap-6">
                <div className="w-24 h-24 rounded-2xl bg-white flex items-center justify-center text-5xl flex-shrink-0 group-hover:scale-110 transition-transform">
                  {featuredArticle.emoji}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-full font-medium">
                      {featuredArticle.category}
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-primary text-primary" />
                      <span className="text-sm font-medium text-foreground">{featuredArticle.rating}</span>
                    </div>
                  </div>
                  <h3 className="text-2xl font-medium text-foreground mb-3 group-hover:text-primary transition-colors">
                    {featuredArticle.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {featuredArticle.description}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{featuredArticle.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      <span>{featuredArticle.reads} прочитали</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.button>
          </motion.div>

          {/* Articles Grid */}
          <div>
            <h2 className="text-xl font-medium text-foreground mb-4">Все статьи</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {filteredArticles.map((article, idx) => (
                <motion.button
                  key={article.id}
                  onClick={onArticleClick}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + idx * 0.05 }}
                  whileHover={{ y: -8 }}
                  className="bg-card border border-border rounded-2xl p-6 cursor-pointer hover:border-primary/30 transition-all group w-full text-left"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center text-3xl flex-shrink-0 group-hover:scale-110 transition-transform">
                      {article.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full font-medium">
                          {article.category}
                        </span>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-primary text-primary" />
                          <span className="text-xs font-medium text-foreground">{article.rating}</span>
                        </div>
                      </div>
                      <h3 className="font-medium text-foreground mb-2 group-hover:text-primary transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                    {article.description}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      <span>{article.time}</span>
                    </div>
                    <span>{article.reads} прочитали</span>
                  </div>
                </motion.button>
              ))}
            </div>
            {filteredArticles.length === 0 && (
              <div className="bg-secondary/30 border-2 border-dashed border-border rounded-2xl p-8 text-center">
                <div className="text-4xl mb-3">🔎</div>
                <h3 className="text-base font-medium text-foreground mb-2">Ничего не найдено</h3>
                <p className="text-sm text-muted-foreground">Попробуйте другую фразу или категорию.</p>
              </div>
            )}
          </div>
        </div>
        )}

        {/* Forum Main Content */}
        {activeTab === "forum" && (
          <div className="lg:col-span-2 space-y-4">
            {forumPosts.map((post, idx) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + idx * 0.05 }}
                whileHover={{ y: -4 }}
                className="bg-card border border-border rounded-2xl p-4 md:p-6 hover:border-primary/30 transition-all cursor-pointer group"
              >
                {/* Header */}
                <div className="flex items-start gap-3 md:gap-4 mb-4">
                  <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-xl md:rounded-2xl flex items-center justify-center text-primary font-medium flex-shrink-0 text-sm md:text-base">
                    {post.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 md:gap-3 mb-1 flex-wrap">
                      <h3 className="text-base md:text-lg font-medium text-foreground group-hover:text-primary transition-colors">
                        {post.title}
                      </h3>
                      <span className="text-[10px] md:text-xs bg-secondary text-secondary-foreground px-2 md:px-3 py-1 rounded-full whitespace-nowrap">
                        {post.category}
                      </span>
                    </div>
                    <p className="text-xs md:text-sm text-muted-foreground line-clamp-2 mb-2">
                      {post.preview}
                    </p>
                    <div className="flex items-center gap-3 md:gap-4 text-[10px] md:text-xs text-muted-foreground">
                      <span className="font-medium">{post.author}</span>
                      <span>•</span>
                      <span>{post.time}</span>
                    </div>
                  </div>
                </div>

                {/* Footer */}
                <div className="flex items-center gap-4 md:gap-6 pt-4 border-t border-border">
                  <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                    <MessageSquare className="w-3 h-3 md:w-4 md:h-4" />
                    <span>{post.comments} ответов</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                    <TrendingUp className="w-3 h-3 md:w-4 md:h-4" />
                    <span>{post.views} просмотров</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Tips Sidebar */}
        {activeTab === "tips" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-6"
          >
          {/* Popular */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Популярное</h3>
            </div>
            <div className="space-y-4">
              {articles.slice(0, 3).map((article, idx) => (
                <button
                  key={article.id}
                  className="w-full text-left group"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-medium text-muted-foreground group-hover:text-primary transition-colors">
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate">
                        {article.title}
                      </h4>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <span>{article.reads} прочитали</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Saved */}
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bookmark className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Сохраненное</h3>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-medium text-foreground">12</div>
              <p className="text-sm text-muted-foreground">статей в избранном</p>
              <button className="text-sm text-primary font-medium hover:underline">
                Посмотреть все →
              </button>
            </div>
          </div>

          {/* Subscribe */}
          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="font-medium text-foreground mb-3">📧 Еженедельная рассылка</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Получайте полезные советы каждую неделю
            </p>
            <Input
              placeholder="Ваш email"
              className="h-10 rounded-xl bg-background border-border mb-3"
            />
            <button className="w-full h-10 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-all text-sm font-medium">
              Подписаться
            </button>
          </div>
        </motion.div>
        )}

        {/* Forum Sidebar */}
        {activeTab === "forum" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Popular Tags */}
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-medium text-foreground mb-4">Популярные темы</h3>
              <div className="flex flex-wrap gap-2">
                {popularTags.map((tag) => (
                  <button
                    key={tag}
                    className="px-3 md:px-4 py-1.5 md:py-2 bg-secondary text-secondary-foreground rounded-full text-xs md:text-sm hover:bg-primary hover:text-primary-foreground transition-all"
                  >
                    #{tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="font-medium text-foreground mb-4">Активность</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Сегодня</span>
                  <span className="text-lg font-medium text-foreground">24</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">На этой неделе</span>
                  <span className="text-lg font-medium text-foreground">156</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Всего участников</span>
                  <span className="text-lg font-medium text-foreground">2,341</span>
                </div>
              </div>
            </div>

            {/* Guidelines */}
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-6">
              <h3 className="font-medium text-foreground mb-3">Правила сообщества</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Будьте вежливы и уважительны</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Не давайте медицинских советов</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>Поддерживайте других родителей</span>
                </li>
              </ul>
            </div>
          </motion.div>
        )}
      </div>

      {/* Add Forum Post Modal */}
      <AddForumPostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddPost}
      />
    </div>
  );
}

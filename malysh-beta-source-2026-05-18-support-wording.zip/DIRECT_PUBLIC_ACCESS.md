# Прямой публичный доступ без VPN

Цель: открыть beta-сайт напрямую через `https://beta.malyshplus.ru`, без зависимости от Cloudflare Tunnel. База пользователей при этом не трогается: аккаунты и записи остаются в `/var/lib/malysh/app.db`.

## Что должно получиться

```text
Пользователь -> https://beta.malyshplus.ru -> VPS nginx -> 127.0.0.1:8787 -> Malysh+
```

Node-приложение остается закрытым внутри сервера, наружу смотрит только nginx на `80/443`.

## 1. DNS

Самый простой вариант для тестеров без VPN:

- `beta.malyshplus.ru` должен указывать на VPS `147.45.175.179`;
- если домен остается в Cloudflare, запись `beta` лучше поставить в режим `DNS only`, то есть серое облако;
- если домен возвращается на DNS Timeweb, нужна запись `A`:

```text
beta -> 147.45.175.179
```

Для первого beta-теста можно не трогать корневой `malyshplus.ru`, достаточно `beta.malyshplus.ru`.

## 2. Firewall у провайдера

В Timeweb/панели VPS входящий трафик должен пропускать:

```text
TCP 80
TCP 443
```

SSH-порт (`22` или `2222`) нужен только тебе для администрирования. Если с домашней сети SSH не открывается, можно продолжать работать через браузерную консоль Timeweb.

## 3. Запуск на VPS

Открыть консоль сервера и вставить:

```bash
cd /opt/malysh
CERTBOT_EMAIL="aleksander.dar@gmail.com" bash deploy/scripts/vps-direct-access.sh
```

Что делает скрипт:

- сохраняет backup текущего `.env` и nginx-конфига;
- выставляет production-адрес `https://beta.malyshplus.ru`;
- настраивает nginx на `127.0.0.1:8787`;
- выключает `cloudflared` на этом VPS;
- перезапускает приложение;
- выпускает HTTPS-сертификат через Let’s Encrypt;
- проверяет `/api/health`.

## 4. Если HTTPS не выдался

Это почти всегда одно из двух:

- DNS еще не обновился;
- `80/443` закрыты в firewall провайдера.

После исправления просто повторить:

```bash
cd /opt/malysh
CERTBOT_EMAIL="aleksander.dar@gmail.com" bash deploy/scripts/vps-direct-access.sh
```

## 5. Проверка

Открыть:

```text
https://beta.malyshplus.ru
https://beta.malyshplus.ru/api/health
```

Если сайт открывается без VPN с телефона на мобильной сети и с обычного браузера на ПК, прямой доступ готов для тестеров.

## 6. Обновления после этого

Обычные обновления сайта делаются старым быстрым путем:

```bash
cd /opt/malysh
bash deploy/scripts/vps-update-release.sh
```

Этот update-скрипт сохраняет базу пользователей, делает backup и меняет только код приложения.

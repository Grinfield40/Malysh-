export function LoadingPanel({ label = "Открываем раздел..." }: { label?: string }) {
  return (
    <div className="p-4 md:p-8">
      <div className="rounded-3xl border border-border bg-card p-6 text-muted-foreground">
        <div className="mb-4 h-3 w-32 rounded-full bg-secondary" />
        <div className="mb-3 h-8 max-w-md rounded-2xl bg-secondary" />
        <div className="grid gap-3 md:grid-cols-3">
          <div className="h-24 rounded-2xl bg-secondary/70" />
          <div className="h-24 rounded-2xl bg-secondary/70" />
          <div className="h-24 rounded-2xl bg-secondary/70" />
        </div>
        <div className="mt-4 text-sm">{label}</div>
      </div>
    </div>
  );
}

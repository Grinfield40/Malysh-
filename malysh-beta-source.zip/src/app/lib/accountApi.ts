export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: "admin" | "user" | string;
  blockedAt?: string | null;
  createdAt?: string;
  lastLoginAt?: string;
}

export interface AuthSession {
  token: string;
  user: AuthUser;
}

export interface AuthResponse extends AuthSession {
  storage: Record<string, unknown>;
}

export interface PublicConfig {
  appName: string;
  publicUrl: string;
  registrationMode: "open" | "closed" | "disabled" | string;
  registrationRequiresInvite: boolean;
}

export interface AdminBackupInfo {
  fileName: string;
  path: string;
  sizeBytes: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminBabyProfile {
  name: string;
  birthDate?: string;
  stage?: string;
  heightCm?: string;
  weightKg?: string;
  bloodType?: string;
  emoji?: string;
}

export interface AdminUserForumPost {
  id: string;
  title: string;
  content: string;
  preview: string;
  categoryId: string;
  category: string;
  tags: string[];
  views: number;
  comments: number;
  reports?: number;
  status?: ForumContentStatus;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
  lastActivityAt?: string;
}

export interface AdminUserActivity {
  id: string;
  type: "audit" | "analytics" | string;
  kind?: "registration" | "login" | "forum" | "data" | "fridge" | "screen" | "admin" | "error" | "activity" | string;
  label: string;
  title?: string;
  description?: string;
  screen?: string;
  durationMs?: number | null;
  createdAt: string;
  meta?: Record<string, unknown>;
}

export interface AdminUser extends AuthUser {
  activeSessions: number;
  storageKeys: number;
  diaryEntries: number;
  routines: number;
  shoppingItems: number;
  shoppingChecked: number;
  forumPosts: number;
  forumComments: number;
  fridgeItems: number;
  babyName?: string;
  goals: string[];
  babyProfile: AdminBabyProfile | null;
  recentDiaryEntries: AdminDiaryEntry[];
  recentForumPosts: AdminUserForumPost[];
  recentActivity: AdminUserActivity[];
}

export interface AdminDiaryEntry {
  id: string;
  type?: string;
  time?: string;
  details?: string;
  icon?: string;
  category?: string;
  date?: string;
  updatedAt: string;
  userId: string;
  userName: string;
  userEmail: string;
  babyName?: string;
}

export interface AdminAuditEvent {
  id: string;
  userId: string | null;
  userName?: string;
  userEmail?: string;
  action: string;
  kind?: "registration" | "login" | "forum" | "data" | "fridge" | "screen" | "admin" | "error" | "activity" | string;
  title?: string;
  description?: string;
  createdAt: string;
  meta?: Record<string, unknown>;
}

export interface AdminAnalyticsEvent {
  id: string;
  name: string;
  screen?: string;
  durationMs?: number;
  meta?: Record<string, unknown>;
  createdAt: string;
  userName?: string;
  userEmail?: string;
}

export interface AdminAnalyticsSummary {
  totalEvents: number;
  eventsToday: number;
  activeUsers7d: number;
  topScreens: Array<{
    screen: string;
    views: number;
    totalDurationMs: number;
    avgDurationMs: number;
  }>;
  topActions: Array<{ name: string; count: number }>;
  recentEvents: AdminAnalyticsEvent[];
}

export interface AdminBetaInvite {
  id: string;
  code: string;
  label: string;
  maxUses: number | null;
  usedCount: number;
  createdBy: string;
  createdByEmail: string;
  createdAt: string;
  lastUsedAt?: string | null;
  disabledAt?: string | null;
  active: boolean;
}

export interface AdminConfigInfo {
  publicUrl: string;
  allowedOrigins: string[];
  registrationMode: "open" | "closed" | "disabled" | string;
  registrationRequiresInvite: boolean;
  inviteConfigured: boolean;
  envInviteConfigured: boolean;
  activeInviteCount: number;
  inviteCodes: AdminBetaInvite[];
  serveWeb: boolean;
  healthDetails: boolean;
  accessLogs: boolean;
  errorStacks: boolean;
  limits: {
    maxJsonBodyBytes: number;
    maxStorageKeys: number;
    maxStorageValueBytes: number;
    maxFridgeCards: number;
    maxFridgeImages: number;
    maxFridgeImageBytes: number;
    maxFridgeTotalImageBytes: number;
    forumTitleMaxLength: number;
    forumPostMaxLength: number;
    forumCommentMaxLength: number;
    forumReportDetailsMaxLength: number;
  };
}

export interface AdminOverview {
  stats: {
    users: number;
    sessions: number;
    diaryEntries: number;
    storageKeys: number;
    routines: number;
    shoppingItems: number;
    fridgeItems: number;
    forumPosts: number;
    forumComments: number;
    forumReports: number;
    backups: number;
    analyticsEvents: number;
  };
  database: {
    path: string;
    sizeBytes: number;
    backupDir: string;
    backups: AdminBackupInfo[];
  };
  config: AdminConfigInfo;
  analytics: AdminAnalyticsSummary;
  users: AdminUser[];
  forumModeration: AdminForumModeration;
  recentDiaryEntries: AdminDiaryEntry[];
  audit: AdminAuditEvent[];
}

export interface AdminBackupResponse {
  ok: true;
  backup: AdminBackupInfo;
  backups: AdminBackupInfo[];
}

export interface AdminExport {
  exportedAt: string;
  service: string;
  database: AdminOverview["database"];
  config: AdminConfigInfo;
  users: AuthUser[];
  accountStorage: Array<{ userId: string; key: string; value: unknown; updatedAt: string }>;
  babyProfiles: unknown[];
  parentGoals: unknown[];
  diaryEntries: unknown[];
  routines: unknown[];
  shoppingItems: unknown[];
  fridgeItems: unknown[];
  forumPosts: unknown[];
  forumComments: unknown[];
  forumReports: unknown[];
  betaInvites: unknown[];
  betaInviteRedemptions: unknown[];
  analytics: {
    summary: AdminAnalyticsSummary;
    events: AdminAnalyticsEvent[];
  };
  audit: AdminAuditEvent[];
}

export type ForumContentStatus = "published" | "hidden" | "deleted";
export type ForumReportStatus = "open" | "reviewed" | "dismissed";

export interface AdminForumReport {
  id: string;
  targetType: "post" | "comment";
  targetId: string;
  postId?: string;
  reason: string;
  reasonLabel: string;
  details?: string;
  status: ForumReportStatus;
  createdAt: string;
  resolvedAt?: string | null;
  reporterName?: string;
  reporterEmail?: string;
  resolverName?: string;
  targetLabel: string;
  targetPreview?: string;
}

export interface AdminForumCommentRecord extends ForumCommentRecord {
  postTitle: string;
}

export interface AdminForumModeration {
  stats: {
    publishedPosts: number;
    hiddenPosts: number;
    deletedPosts: number;
    publishedComments: number;
    hiddenComments: number;
    deletedComments: number;
    openReports: number;
    totalReports: number;
  };
  reports: AdminForumReport[];
  posts: ForumPostRecord[];
  comments: AdminForumCommentRecord[];
}

export interface AnalyticsEventPayload {
  name: string;
  sessionId: string;
  screen?: string;
  durationMs?: number;
  meta?: Record<string, unknown>;
  createdAt: string;
}

export interface ForumPostRecord {
  id: string;
  title: string;
  content: string;
  preview: string;
  categoryId: string;
  category: string;
  tags: string[];
  views: number;
  comments: number;
  reports?: number;
  status?: ForumContentStatus;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
  lastActivityAt?: string;
}

export interface ForumCommentRecord {
  id: string;
  postId: string;
  content: string;
  status?: ForumContentStatus;
  reports?: number;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ForumPostDetail {
  post: ForumPostRecord;
  comments: ForumCommentRecord[];
}

export interface ForumPostsResponse {
  posts: ForumPostRecord[];
  stats: {
    posts: number;
    comments: number;
    today: number;
  };
}

const API_URL = import.meta.env.VITE_MALYSH_API_URL || "/api";
const SESSION_STORAGE_KEY = "mvp.server.session";
const SYNC_DEBOUNCE_MS = 450;
let syncTimer: number | undefined;
const pendingStorage = new Map<string, unknown>();

export function getStoredSession(): AuthSession | null {
  try {
    const rawSession = window.localStorage.getItem(SESSION_STORAGE_KEY);

    return rawSession ? (JSON.parse(rawSession) as AuthSession) : null;
  } catch {
    return null;
  }
}

export function saveStoredSession(session: AuthSession) {
  window.localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
}

export function clearStoredSession() {
  window.localStorage.removeItem(SESSION_STORAGE_KEY);
}

export function isServerAuthConfigured() {
  return Boolean(getStoredSession()?.token);
}

export function shouldSyncStorageKey(key: string) {
  if (!key.startsWith("mvp.")) return false;
  if (key === SESSION_STORAGE_KEY) return false;
  if (key === "mvp.authenticated") return false;
  if (key.startsWith("mvp.server.")) return false;

  return true;
}

export function collectLocalAppStorage() {
  const storage: Record<string, unknown> = {};

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);

    if (!key || !shouldSyncStorageKey(key)) continue;

    const rawValue = window.localStorage.getItem(key);

    try {
      storage[key] = rawValue ? JSON.parse(rawValue) : null;
    } catch {
      storage[key] = rawValue;
    }
  }

  return storage;
}

export function hydrateLocalAppStorage(storage: Record<string, unknown>) {
  const incomingKeys = new Set(Object.keys(storage));
  const keysToRemove: string[] = [];

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);

    if (key && shouldSyncStorageKey(key) && !incomingKeys.has(key)) {
      keysToRemove.push(key);
    }
  }

  keysToRemove.forEach((key) => window.localStorage.removeItem(key));

  Object.entries(storage).forEach(([key, value]) => {
    if (!shouldSyncStorageKey(key)) return;
    window.localStorage.setItem(key, JSON.stringify(value));
  });
}

export function setAppStorageItem(key: string, value: unknown) {
  window.localStorage.setItem(key, JSON.stringify(value));
  queueAccountStorageSync(key, value);
}

export function queueAccountStorageSync(key: string, value: unknown) {
  const session = getStoredSession();

  if (!session || !shouldSyncStorageKey(key)) return;

  pendingStorage.set(key, value);

  if (syncTimer) {
    window.clearTimeout(syncTimer);
  }

  syncTimer = window.setTimeout(() => {
    void flushAccountStorageSync();
  }, SYNC_DEBOUNCE_MS);
}

export async function flushAccountStorageSync() {
  const session = getStoredSession();

  if (!session || pendingStorage.size === 0) return;

  const items = Array.from(pendingStorage.entries());
  pendingStorage.clear();

  await Promise.all(
    items.map(([key, value]) =>
      apiRequest("/account/storage", {
        method: "PATCH",
        token: session.token,
        body: { key, value },
      }).catch(() => {
        pendingStorage.set(key, value);
      })
    )
  );
}

export async function replaceAccountStorage(storage: Record<string, unknown>) {
  const session = getStoredSession();

  if (!session) return;

  await apiRequest("/account/storage", {
    method: "PUT",
    token: session.token,
    body: { storage },
  });
}

export async function getPublicConfig() {
  return apiRequest<PublicConfig>("/config", {
    method: "GET",
  });
}

export async function registerAccount(payload: { name: string; email: string; password: string; inviteCode?: string }) {
  return apiRequest<AuthResponse>("/auth/register", {
    method: "POST",
    body: payload,
  });
}

export async function loginAccount(payload: { email: string; password: string }) {
  return apiRequest<AuthResponse>("/auth/login", {
    method: "POST",
    body: payload,
  });
}

export async function logoutAccount(token: string) {
  return apiRequest<{ ok: true }>("/auth/logout", {
    method: "POST",
    token,
  });
}

export async function getCurrentAccount(token: string) {
  return apiRequest<AuthResponse>("/auth/me", {
    method: "GET",
    token,
  });
}

export async function getAdminOverview(token: string) {
  return apiRequest<AdminOverview>("/admin/overview", {
    method: "GET",
    token,
  });
}

export async function createAdminBackup(token: string) {
  return apiRequest<AdminBackupResponse>("/admin/backup", {
    method: "POST",
    token,
  });
}

export async function updateAdminUserStatus(token: string, userId: string, blocked: boolean) {
  return apiRequest<{ ok: true; user: AuthUser }>(`/admin/users/${userId}/status`, {
    method: "PATCH",
    token,
    body: { blocked },
  });
}

export async function resetAdminUserSessions(token: string, userId: string) {
  return apiRequest<{ ok: true; sessionsDeleted: number }>(`/admin/users/${userId}/sessions/reset`, {
    method: "POST",
    token,
  });
}

export async function deleteAdminUser(token: string, userId: string, confirmEmail: string) {
  return apiRequest<{ ok: true }>(`/admin/users/${userId}`, {
    method: "DELETE",
    token,
    body: { confirmEmail },
  });
}

export async function createAdminInvite(
  token: string,
  payload: { label?: string; maxUses?: number; code?: string }
) {
  return apiRequest<{ ok: true; invite: AdminBetaInvite; config: AdminConfigInfo }>("/admin/invites", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function updateAdminInvite(token: string, inviteId: string, payload: { active: boolean }) {
  return apiRequest<{ ok: true; invite: AdminBetaInvite; config: AdminConfigInfo }>(
    `/admin/invites/${inviteId}`,
    {
      method: "PATCH",
      token,
      body: payload,
    }
  );
}

export async function getAdminExport(token: string) {
  return apiRequest<AdminExport>("/admin/export", {
    method: "GET",
    token,
  });
}

export async function moderateForumPost(token: string, postId: string, status: ForumContentStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/posts/${postId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function moderateForumComment(token: string, commentId: string, status: ForumContentStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/comments/${commentId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function moderateForumReport(token: string, reportId: string, status: ForumReportStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/reports/${reportId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function sendAnalyticsEvents(token: string, events: AnalyticsEventPayload[]) {
  return apiRequest<{ ok: true; accepted: number }>("/analytics/events", {
    method: "POST",
    token,
    body: { events },
  });
}

export async function getForumPosts(
  token: string,
  params: {
    tab?: string;
    search?: string;
    category?: string;
  } = {}
) {
  const searchParams = new URLSearchParams();

  if (params.tab) searchParams.set("tab", params.tab);
  if (params.search) searchParams.set("search", params.search);
  if (params.category) searchParams.set("category", params.category);

  const query = searchParams.toString();

  return apiRequest<ForumPostsResponse>(`/forum/posts${query ? `?${query}` : ""}`, {
    method: "GET",
    token,
  });
}

export async function createForumPost(
  token: string,
  payload: {
    title: string;
    content: string;
    category: string;
    tags: string[];
  }
) {
  return apiRequest<{ post: ForumPostRecord }>("/forum/posts", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function getForumPost(token: string, postId: string) {
  return apiRequest<ForumPostDetail>(`/forum/posts/${postId}`, {
    method: "GET",
    token,
  });
}

export async function createForumComment(token: string, postId: string, content: string) {
  return apiRequest<{ comment: ForumCommentRecord; post: ForumPostRecord }>(
    `/forum/posts/${postId}/comments`,
    {
      method: "POST",
      token,
      body: { content },
    }
  );
}

export async function reportForumContent(
  token: string,
  payload: {
    targetType: "post" | "comment";
    targetId: string;
    reason: string;
    details?: string;
  }
) {
  return apiRequest<{ ok: true; reportId: string; duplicate?: boolean }>("/forum/reports", {
    method: "POST",
    token,
    body: payload,
  });
}

async function apiRequest<T>(
  path: string,
  options: {
    method: string;
    body?: unknown;
    token?: string;
  }
): Promise<T> {
  let response: Response;

  try {
    response = await fetch(`${API_URL}${path}`, {
      method: options.method,
      headers: {
        "Content-Type": "application/json",
        ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new Error("Не удалось подключиться к локальному серверу. Проверьте, что он запущен.");
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data?.error || "Сервер временно недоступен.");
  }

  return data as T;
}

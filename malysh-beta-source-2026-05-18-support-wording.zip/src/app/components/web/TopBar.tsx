import { AnimatePresence, motion } from "motion/react";
import { Search, Bell, ArrowRight } from "lucide-react";
import { Input } from "../ui/input";
import { Logo } from "../Logo";
import { NotificationsPanel } from "./NotificationsPanel";
import { ThemeToggle } from "../ThemeToggle";
import { useMemo, useState, type FormEvent } from "react";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import {
  buildNotificationItems,
  DEFAULT_NOTIFICATIONS,
  type ChecklistNotificationSource,
  type NotificationItem,
  type ReminderNotificationSource,
} from "../../lib/notifications";

interface TopBarProps {
  onProfileClick: () => void;
  onNavigate: (screen: string) => void;
}

interface StoredNote {
  id: number;
  text: string;
  date?: string;
}

interface StoredForumPost {
  id: number;
  title: string;
  preview?: string;
  category?: string;
}

interface SearchTarget {
  id: string;
  label: string;
  description: string;
  screen: string;
  keywords: string;
  icon: string;
}

function readLocalStorageArray<T>(key: string): T[] {
  try {
    const rawValue = window.localStorage.getItem(key);
    if (!rawValue) return [];

    const parsed = JSON.parse(rawValue);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

const navigationSearchTargets: SearchTarget[] = [
  { id: "home", label: "Главная", description: "Сводка дня и быстрые действия", screen: "home", keywords: "главная день обзор", icon: "🏠" },
  { id: "tracker", label: "Трекер", description: "Дневник кормления, сна и заметок", screen: "tracker", keywords: "трекер дневник кормление сон подгузники температура", icon: "📒" },
  { id: "routines", label: "Режим дня", description: "План сна, кормления и прогулок", screen: "routines", keywords: "режим расписание сон кормление прогулка", icon: "🕘" },
  { id: "reminders", label: "Напоминания", description: "Визиты, лекарства и задачи", screen: "reminders", keywords: "напоминания задачи врач лекарства", icon: "🔔" },
  { id: "growth", label: "Развитие малыша", description: "Этапы, навыки и подсказки", screen: "growth-timeline", keywords: "развитие навыки улыбки этапы", icon: "👶" },
  { id: "tips", label: "Советы", description: "Статьи и рекомендации", screen: "tips", keywords: "советы статьи здоровье сон кормление", icon: "📚" },
  { id: "forum", label: "Форум", description: "Обсуждения родителей", screen: "forum", keywords: "форум вопросы обсуждения родители", icon: "💬" },
  { id: "recommendations", label: "Мамы одобряют", description: "Подборки и сохраненные идеи", screen: "recommendations", keywords: "мамы одобряют рекомендации товары", icon: "💜" },
  { id: "fridge", label: "Холодильник", description: "Фото, продукты и сроки", screen: "fridge", keywords: "холодильник продукты фото", icon: "🧊" },
  { id: "urgent", label: "Срочные ответы", description: "Когда звонить врачу и что проверить", screen: "urgent", keywords: "срочно врач температура педиатр помощь", icon: "🆘" },
  { id: "shopping", label: "Покупки", description: "Список покупок для малыша", screen: "shopping", keywords: "покупки список товары", icon: "🛒" },
  { id: "profile", label: "Профиль", description: "Профиль ребенка, цели и заметки", screen: "profile", keywords: "профиль ребенок цели заметки аватар", icon: "👤" },
  { id: "saved", label: "Сохраненное", description: "Избранные материалы", screen: "saved", keywords: "сохраненное избранное", icon: "🔖" },
];

export function TopBar({ onProfileClick, onNavigate }: TopBarProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { baby, age } = useBabyProfile();
  const [profile] = useUserProfile();
  const [storedNotifications] = useLocalStorageState<NotificationItem[]>("mvp.notifications.items", DEFAULT_NOTIFICATIONS);
  const [notificationReadIds] = useLocalStorageState<string[]>("mvp.notifications.readIds", []);
  const [notificationHiddenIds] = useLocalStorageState<string[]>("mvp.notifications.hiddenIds", []);
  const [reminders] = useLocalStorageState<ReminderNotificationSource[]>("mvp.reminders.items", []);
  const [checklist] = useLocalStorageState<ChecklistNotificationSource[]>("mvp.reminders.checklist", []);

  const notificationItems = buildNotificationItems({
    storedItems: storedNotifications,
    reminders,
    checklist,
    readIds: notificationReadIds,
    hiddenIds: notificationHiddenIds,
  });
  const unreadCount = notificationItems.filter((item) => !item.read).length;
  const userInitial = (profile.name?.trim() || "Р").charAt(0).toUpperCase();
  const normalizedSearch = searchQuery.trim().toLowerCase();

  const searchTargets = useMemo(() => {
    const notes = readLocalStorageArray<StoredNote>("mvp.profile.notes").map<SearchTarget>((note) => ({
      id: `note-${note.id}`,
      label: note.text,
      description: note.date ? `Заметка, ${note.date}` : "Заметка в профиле",
      screen: "profile",
      keywords: `заметка ${note.text}`,
      icon: "📝",
    }));

    const reminderTargets = readLocalStorageArray<ReminderNotificationSource>("mvp.reminders.items").map<SearchTarget>((reminder) => ({
      id: `reminder-${reminder.id}`,
      label: reminder.title,
      description: [reminder.date, reminder.time].filter(Boolean).join(" в ") || "Напоминание",
      screen: "reminders",
      keywords: `напоминание ${reminder.title} ${reminder.notes ?? ""}`,
      icon: reminder.emoji || "⏰",
    }));

    const forumTargets = readLocalStorageArray<StoredForumPost>("mvp.forum.posts").map<SearchTarget>((post) => ({
      id: `forum-${post.id}`,
      label: post.title,
      description: post.category ? `Форум: ${post.category}` : "Пост на форуме",
      screen: "forum",
      keywords: `форум ${post.title} ${post.preview ?? ""} ${post.category ?? ""}`,
      icon: "💬",
    }));

    return [...navigationSearchTargets, ...notes, ...reminderTargets, ...forumTargets];
  }, [searchQuery]);

  const searchResults = normalizedSearch.length < 2
    ? []
    : searchTargets
        .filter((target) => `${target.label} ${target.description} ${target.keywords}`.toLowerCase().includes(normalizedSearch))
        .slice(0, 7);

  const openSearchResult = (target: SearchTarget) => {
    setSearchQuery("");
    setIsSearchOpen(false);
    onNavigate(target.screen);
  };

  const handleSearchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (!normalizedSearch) return;

    try {
      window.localStorage.setItem("mvp.home.lastSearch", JSON.stringify(searchQuery.trim()));
    } catch {
      // Search navigation is still useful even if persistence is unavailable.
    }

    if (searchResults[0]) {
      openSearchResult(searchResults[0]);
      return;
    }

    setIsSearchOpen(false);
    onNavigate("tips");
  };

  return (
    <>
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="fixed top-0 right-0 left-0 md:left-[280px] h-16 md:h-20 bg-card/80 backdrop-blur-xl border-b border-border/50 z-30 px-4 md:px-8"
      >
        <div className="h-full flex items-center justify-between max-w-[1400px]">
          <div className="md:hidden flex items-center gap-2">
            <Logo size={32} />
            <span className="text-lg font-medium text-foreground">Малыш+</span>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-2 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border border-primary/10">
              <div className="text-lg">{baby.emoji}</div>
              <div>
                <div className="text-xs font-semibold text-foreground leading-tight">{baby.name}</div>
                <div className="text-[10px] text-muted-foreground leading-tight">{age.label}</div>
              </div>
            </div>

            <form
              onSubmit={handleSearchSubmit}
              className="relative w-80"
            >
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(event) => {
                  setSearchQuery(event.target.value);
                  setIsSearchOpen(true);
                }}
                onFocus={() => setIsSearchOpen(true)}
                onBlur={() => window.setTimeout(() => setIsSearchOpen(false), 120)}
                placeholder="Поиск..."
                className="h-11 pl-12 pr-10 rounded-2xl bg-background border-border"
              />
              <AnimatePresence>
                {isSearchOpen && normalizedSearch.length >= 2 && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    className="absolute left-0 right-0 top-[52px] rounded-2xl border border-border bg-card shadow-2xl overflow-hidden z-50"
                  >
                    {searchResults.length > 0 ? (
                      <div className="max-h-[360px] overflow-y-auto py-2">
                        {searchResults.map((target) => (
                          <button
                            key={target.id}
                            type="button"
                            onMouseDown={(event) => {
                              event.preventDefault();
                              openSearchResult(target);
                            }}
                            className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-secondary/70 transition-colors"
                          >
                            <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-xl flex-shrink-0">
                              {target.icon}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-medium text-foreground truncate">{target.label}</div>
                              <div className="text-xs text-muted-foreground truncate">{target.description}</div>
                            </div>
                            <ArrowRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="px-4 py-5 text-sm text-muted-foreground">
                        Ничего не найдено. Нажмите Enter, чтобы искать в советах.
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </form>
          </div>

          <div className="flex items-center gap-2 md:gap-4">
            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onNavigate("tips")}
              className="hidden sm:flex md:hidden w-10 h-10 rounded-xl bg-secondary hover:bg-primary/10 transition-colors items-center justify-center"
              aria-label="Открыть поиск"
            >
              <Search className="w-5 h-5 text-foreground" />
            </motion.button>

            <ThemeToggle />

            <motion.button
              type="button"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setNotificationsOpen(true)}
              className="relative w-10 h-10 md:w-11 md:h-11 rounded-xl md:rounded-2xl bg-secondary hover:bg-primary/10 transition-colors flex items-center justify-center"
              aria-label="Открыть уведомления"
            >
              <Bell className="w-5 h-5 text-foreground" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 bg-destructive text-white text-[10px] leading-5 rounded-full font-semibold">
                  {unreadCount > 9 ? "9+" : unreadCount}
                </span>
              )}
            </motion.button>

            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onProfileClick}
              className="flex items-center gap-2 md:gap-3 px-2 md:px-3 py-2 rounded-xl md:rounded-2xl hover:bg-secondary/60 transition-all"
            >
              <div className="w-8 h-8 md:w-9 md:h-9 bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg md:rounded-xl flex items-center justify-center text-xl overflow-hidden">
                {profile.avatarDataUrl ? (
                  <img src={profile.avatarDataUrl} alt="Аватар профиля" className="w-full h-full object-cover" />
                ) : (
                  userInitial
                )}
              </div>
              <div className="hidden lg:block text-left">
                <div className="text-sm font-semibold text-foreground leading-tight">{profile.name || "Родитель"}</div>
                <div className="text-xs text-muted-foreground leading-tight">{profile.role ?? "Родитель"}</div>
              </div>
            </motion.button>
          </div>
        </div>
      </motion.div>

      <NotificationsPanel
        isOpen={notificationsOpen}
        onClose={() => setNotificationsOpen(false)}
        onNavigate={onNavigate}
      />
    </>
  );
}

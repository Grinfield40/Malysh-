import { motion } from "motion/react";
import { AlertCircle, Eye, EyeOff, KeyRound, Lock, Mail, ShieldCheck, User } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Logo } from "../Logo";
import {
  AuthSession,
  getPublicConfig,
  hydrateLocalAppStorage,
  loginAccount,
  registerAccount,
  replaceAccountStorage,
  saveStoredSession,
  setAppStorageItem,
} from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess, notifyWarning } from "../../lib/notify";

interface AuthScreenProps {
  onAuth: (session: AuthSession) => void;
  onNavigate?: (screen: string) => void;
}

export function AuthScreen({ onAuth, onNavigate }: AuthScreenProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [registrationMode, setRegistrationMode] = useState("open");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const trimmedName = name.trim();
  const trimmedEmail = email.trim().toLowerCase();
  const trimmedInviteCode = inviteCode.trim();
  const registrationRequiresInvite = registrationMode === "closed";
  const validationMessage = isSignUp && registrationMode === "disabled"
    ? "Регистрация сейчас закрыта. Войдите в существующий аккаунт."
    : isSignUp && !trimmedName
    ? "Введите имя."
    : !trimmedEmail
    ? "Введите email."
    : !/^\S+@\S+\.\S+$/.test(trimmedEmail)
    ? "Введите корректный email."
    : password.length < 6
    ? "Пароль должен быть не короче 6 символов."
    : isSignUp && registrationRequiresInvite && !trimmedInviteCode
    ? "Введите код доступа к закрытой бете."
    : "";

  useEffect(() => {
    let isMounted = true;

    getPublicConfig()
      .then((config) => {
        if (isMounted) setRegistrationMode(config.registrationMode || "open");
      })
      .catch(() => undefined);

    return () => {
      isMounted = false;
    };
  }, []);

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setHasSubmitted(true);
    setError("");

    if (validationMessage) {
      setError(validationMessage);
      notifyWarning(validationMessage);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = isSignUp
        ? await registerAccount({ name: trimmedName, email: trimmedEmail, password, inviteCode: trimmedInviteCode })
        : await loginAccount({ email: trimmedEmail, password });
      const session = { token: response.token, user: response.user };
      const profile = {
        name: response.user.name,
        email: response.user.email,
        role: response.user.role === "admin" ? "Администратор" : "Родитель",
      };

      saveStoredSession(session);

      if (isSignUp) {
        const initialStorage = {
          "mvp.user.profile": profile,
        };

        hydrateLocalAppStorage(initialStorage, { userId: session.user.id, replace: true });
        await replaceAccountStorage(initialStorage);
      } else {
        hydrateLocalAppStorage(response.storage || {}, { userId: session.user.id });
        setAppStorageItem("mvp.user.profile", profile);
      }

      trackEvent(isSignUp ? "auth_register" : "auth_login", {
        meta: {
          role: response.user.role,
          storageKeys: isSignUp ? 1 : Object.keys(response.storage || {}).length,
        },
        immediate: true,
      });

      notifySuccess(isSignUp ? "Аккаунт создан" : "Вы вошли в аккаунт");
      onAuth(session);
    } catch (authError) {
      const message =
        authError instanceof Error
          ? authError.message
          : "Не получилось войти. Проверьте локальный сервер и попробуйте еще раз.";

      setError(message);
      notifyError(new Error(message));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-purple-100/50 via-pink-100/50 to-blue-100/50">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: "spring" }}
            className="inline-block mb-6"
          >
            <Logo size={80} animate />
          </motion.div>
          <h1 className="text-4xl font-medium text-foreground mb-2">Малыш+</h1>
          <p className="text-muted-foreground">
            {isSignUp ? "Создайте аккаунт и сохраните данные" : "Войдите в свой аккаунт"}
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-card/80 backdrop-blur-xl border-2 border-border rounded-3xl p-8 shadow-2xl"
        >
          {error && (
            <div
              aria-live="polite"
              className="mb-5 rounded-2xl border border-destructive/20 bg-destructive/10 px-4 py-3 text-sm text-destructive flex gap-2"
            >
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            {isSignUp && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Имя
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Как к вам обращаться"
                    value={name}
                    onChange={(event) => {
                      setName(event.target.value);
                      setError("");
                    }}
                    aria-invalid={hasSubmitted && isSignUp && !trimmedName}
                    className="h-12 pl-12 rounded-xl"
                  />
                </div>
              </div>
            )}

            {isSignUp && registrationRequiresInvite && (
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Код доступа
                </label>
                <div className="relative">
                  <KeyRound className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Код закрытой беты"
                    value={inviteCode}
                    onChange={(event) => {
                      setInviteCode(event.target.value);
                      setError("");
                    }}
                    aria-invalid={hasSubmitted && registrationRequiresInvite && !trimmedInviteCode}
                    className="h-12 pl-12 rounded-xl"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(event) => {
                    setEmail(event.target.value);
                    setError("");
                  }}
                  aria-invalid={hasSubmitted && (!trimmedEmail || !/^\S+@\S+\.\S+$/.test(trimmedEmail))}
                  className="h-12 pl-12 rounded-xl"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Пароль
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Минимум 6 символов"
                  value={password}
                  onChange={(event) => {
                    setPassword(event.target.value);
                    setError("");
                  }}
                  aria-invalid={hasSubmitted && password.length < 6}
                  className="h-12 pl-12 pr-12 rounded-xl"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={isSubmitting || (isSignUp && registrationMode === "disabled")}
              className="w-full h-12 rounded-xl text-base font-medium"
            >
              {isSubmitting
                ? "Подключаем..."
                : isSignUp
                  ? "Создать аккаунт"
                  : "Войти"}
            </Button>
          </form>

          <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3">
            <div className="mb-1 flex items-center gap-2 text-sm font-medium text-amber-800">
              <ShieldCheck className="h-4 w-4" />
              Закрытая beta
            </div>
            <p className="text-xs leading-relaxed text-amber-900">
              Не вводите чувствительные медицинские данные, документы, адреса и платежную информацию.
              Приложение помогает вести день ребенка, но не заменяет врача.
            </p>
            {onNavigate && (
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  className="rounded-xl bg-white px-3 py-2 text-xs font-medium text-amber-800 shadow-sm hover:bg-amber-100"
                  onClick={() => onNavigate("privacy")}
                >
                  Приватность
                </button>
                <button
                  type="button"
                  className="rounded-xl bg-white px-3 py-2 text-xs font-medium text-amber-800 shadow-sm hover:bg-amber-100"
                  onClick={() => onNavigate("terms")}
                >
                  Условия beta
                </button>
              </div>
            )}
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground">
              {isSignUp ? "Уже есть аккаунт? " : "Еще нет аккаунта? "}
              <button
                type="button"
                onClick={() => {
                  setError("");
                  setHasSubmitted(false);
                  setIsSignUp(!isSignUp);
                }}
                className="text-primary font-medium hover:underline"
              >
                {isSignUp ? "Войти" : "Создать аккаунт"}
              </button>
            </p>
          </div>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 text-center text-xs text-muted-foreground px-4"
        >
          Данные сохраняются локально на вашем сервере и привязываются к учетной записи.
          {onNavigate && (
            <>
              {" "}
              <button
                type="button"
                className="font-medium text-primary hover:underline"
                onClick={() => onNavigate("privacy")}
              >
                Политика приватности
              </button>
              {" · "}
              <button
                type="button"
                className="font-medium text-primary hover:underline"
                onClick={() => onNavigate("terms")}
              >
                Условия beta
              </button>
            </>
          )}
        </motion.p>
      </motion.div>
    </div>
  );
}

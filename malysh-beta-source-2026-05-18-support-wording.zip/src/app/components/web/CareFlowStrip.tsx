import { motion } from "motion/react";
import { ArrowRight, CheckCircle2, Clock, Heart, MessageCircle, NotebookText } from "lucide-react";
import { Button } from "../ui/button";
import {
  CARE_DIARY_STORAGE_KEY,
  CareDiaryEntry,
  getCareDiarySummary,
  getTodayCareEntries,
} from "../../lib/careDiary";
import { useBabyProfile } from "../../lib/babyProfile";

type FlowScreen = "home" | "tracker" | "routines" | "recommendations" | "forum";

interface CareFlowStripProps {
  active: FlowScreen;
  onNavigate: (screen: string) => void;
}

interface RoutineSnapshot {
  id: number;
  time: string;
  activity: string;
}

const flowOrder: FlowScreen[] = ["tracker", "routines", "recommendations", "forum"];

function readLocalStorage<T>(key: string, fallback: T): T {
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function CareFlowStrip({ active, onNavigate }: CareFlowStripProps) {
  const entries = readLocalStorage<CareDiaryEntry[]>(CARE_DIARY_STORAGE_KEY, []);
  const routines = readLocalStorage<RoutineSnapshot[]>("mvp.routines.items", []);
  const savedRecommendations = readLocalStorage<number[]>("mvp.recommendations.saved", []);
  const { baby } = useBabyProfile();

  const todayEntries = getTodayCareEntries(entries);
  const summary = getCareDiarySummary(todayEntries);
  const linkedRoutineFacts = todayEntries.filter((entry) => entry.source === "routine").length;
  const nextScreen =
    summary.total === 0
      ? "tracker"
      : routines.length === 0
        ? "routines"
        : savedRecommendations.length === 0
          ? "recommendations"
          : "forum";

  const steps = [
    {
      id: "tracker" as const,
      icon: NotebookText,
      title: "Дневник",
      detail: summary.total > 0 ? `${summary.total} записей сегодня` : "Добавить первый факт",
      action: summary.total > 0 ? "Открыть ленту" : "Записать событие",
      isDone: summary.total > 0,
    },
    {
      id: "routines" as const,
      icon: Clock,
      title: "Режим",
      detail: routines.length > 0 ? `${routines.length} пунктов, ${linkedRoutineFacts} фактов` : "Собрать опорные точки",
      action: routines.length > 0 ? "Сверить режим" : "Настроить режим",
      isDone: routines.length > 0,
    },
    {
      id: "recommendations" as const,
      icon: Heart,
      title: "Подборки",
      detail: savedRecommendations.length > 0 ? `${savedRecommendations.length} сохранено` : `Под ${baby.name}`,
      action: "Посмотреть",
      isDone: savedRecommendations.length > 0,
    },
    {
      id: "forum" as const,
      icon: MessageCircle,
      title: "Форум",
      detail: "Вопросы и опыт родителей",
      action: "Обсудить",
      isDone: false,
    },
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.08 }}
      className="mb-6 md:mb-8"
    >
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between mb-3">
        <div>
          <div className="text-sm font-medium text-primary mb-1">Маршрут дня</div>
          <h2 className="text-xl md:text-2xl font-medium text-foreground">
            {summary.total > 0 ? `День ${baby.name} уже собирается` : `Начните день ${baby.name} с первой записи`}
          </h2>
        </div>
        <Button
          type="button"
          onClick={() => onNavigate(nextScreen)}
          className="h-12 w-full justify-center rounded-2xl md:w-auto md:min-w-[180px]"
        >
          Следующий шаг
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>

      <div className="-mx-4 flex gap-3 overflow-x-auto px-4 pb-1 md:mx-0 md:grid md:grid-cols-2 md:overflow-visible md:px-0 md:pb-0 xl:grid-cols-4">
        {steps.map((step, index) => {
          const Icon = step.icon;
          const isActive = active === step.id;
          const isPast = flowOrder.indexOf(step.id) < flowOrder.indexOf(nextScreen);

          return (
            <button
              key={step.id}
              type="button"
              onClick={() => onNavigate(step.id)}
              className={`min-w-[235px] text-left rounded-xl border px-4 py-4 transition-all md:min-w-0 ${
                isActive
                  ? "border-primary bg-primary/10"
                  : step.id === nextScreen
                    ? "border-primary/40 bg-card"
                    : "border-border bg-card hover:border-primary/30"
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                    isActive ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">Шаг {index + 1}</div>
                    <div className="font-medium text-foreground">{step.title}</div>
                  </div>
                </div>
                {step.isDone || isPast ? <CheckCircle2 className="w-5 h-5 text-primary" /> : null}
              </div>
              <div className="text-sm text-muted-foreground mb-3">{step.detail}</div>
              <div className="inline-flex items-center gap-1 text-sm font-medium text-primary">
                {isActive ? "Вы здесь" : step.action}
                {!isActive ? <ArrowRight className="w-3.5 h-3.5" /> : null}
              </div>
            </button>
          );
        })}
      </div>
    </motion.section>
  );
}

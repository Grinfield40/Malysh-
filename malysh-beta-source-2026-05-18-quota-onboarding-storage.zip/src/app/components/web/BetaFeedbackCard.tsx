import { useState } from "react";
import { MessageSquare, Send, Star } from "lucide-react";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { getStoredSession, submitBetaFeedback } from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess } from "../../lib/notify";

export function BetaFeedbackCard({ screen = "home" }: { screen?: string }) {
  const [message, setMessage] = useState("");
  const [rating, setRating] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const title = screen === "privacy" ? "Отзыв о сайте" : "Beta-отзыв";

  const handleSubmit = async () => {
    const session = getStoredSession();
    const text = message.trim();

    if (!session) {
      notifyError(new Error("Нужно войти в аккаунт, чтобы отправить отзыв."));
      return;
    }

    if (text.length < 4) {
      notifyError(new Error("Напишите пару слов, что именно заметили."));
      return;
    }

    setIsSending(true);

    try {
      await submitBetaFeedback(session.token, {
        message: text,
        rating: rating || null,
        screen,
      });
      trackEvent("beta_feedback_sent", {
        screen,
        meta: {
          rating: rating || null,
        },
      });
      notifySuccess("Отзыв отправлен", {
        description: "Спасибо, он появится в админке beta.",
      });
      setMessage("");
      setRating(0);
    } catch (error) {
      notifyError(error, "Не получилось отправить отзыв");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6">
      <div className="flex items-start gap-3 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm md:text-base font-medium text-foreground">{title}</h3>
          <p className="text-xs md:text-sm text-muted-foreground">
            Что удобно, что мешает, чего не хватает?
          </p>
        </div>
      </div>

      <div className="flex gap-1 mb-3">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className="text-primary transition-transform hover:scale-110"
            aria-label={`Оценка ${star}`}
          >
            <Star className={`w-5 h-5 ${star <= rating ? "fill-primary" : "text-muted-foreground/40"}`} />
          </button>
        ))}
      </div>

      <Textarea
        value={message}
        onChange={(event) => setMessage(event.target.value)}
        maxLength={1600}
        placeholder="Например: не понял, куда нажать после онбординга..."
        className="min-h-[96px] resize-none rounded-xl"
      />

      <Button
        type="button"
        onClick={() => void handleSubmit()}
        disabled={isSending || message.trim().length < 4}
        className="mt-3 w-full rounded-xl"
      >
        <Send className="w-4 h-4" />
        {isSending ? "Отправляем..." : "Отправить отзыв"}
      </Button>
    </div>
  );
}

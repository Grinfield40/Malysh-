@echo off
cd /d "%~dp0"
set MALYSH_HOST=0.0.0.0
set MALYSH_API_PORT=8787
echo Building Malysh+ production files...
call npm.cmd run build
if errorlevel 1 (
  echo Build failed.
  pause
  exit /b 1
)
echo.
echo Malysh+ server will listen on all network interfaces.
echo Local:   http://localhost:8787
echo Network: http://YOUR_COMPUTER_IP:8787
echo.
call npm.cmd run start

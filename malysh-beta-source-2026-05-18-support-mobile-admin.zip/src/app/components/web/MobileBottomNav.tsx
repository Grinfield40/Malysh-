import { motion } from "motion/react";
import { Home, ShoppingBag, BookOpen, MessageCircle, User, ShieldCheck } from "lucide-react";
import { useUserProfile } from "../../lib/userProfile";

interface MobileBottomNavProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

const mainItems = [
  { id: "home", icon: Home, label: "Главная" },
  { id: "shopping", icon: ShoppingBag, label: "Купить" },
  { id: "tips", icon: BookOpen, label: "Советы" },
  { id: "forum", icon: MessageCircle, label: "Форум" },
  { id: "profile", icon: User, label: "Профиль" },
];

export function MobileBottomNav({ activeScreen, onNavigate }: MobileBottomNavProps) {
  const [profile] = useUserProfile();
  const isAdmin = profile.role === "Администратор";
  const visibleItems = isAdmin
    ? [
        ...mainItems.slice(0, 4),
        { id: "admin", icon: ShieldCheck, label: "Админка" },
        mainItems[4],
      ]
    : mainItems;

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t-2 border-primary/10 shadow-2xl"
    >
      <div className={`grid ${isAdmin ? "grid-cols-6 px-1" : "grid-cols-5 px-2"} py-3 safe-bottom`}>
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeScreen === item.id;

          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-center gap-1 px-1 py-2 rounded-2xl transition-all relative"
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <Icon
                className={`w-6 h-6 relative z-10 transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              />
              <span
                className={`${isAdmin ? "text-[9px]" : "text-[10px]"} font-medium relative z-10 transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </motion.nav>
  );
}

import { Button } from "../ui/button";
import { ChevronLeft } from "lucide-react";
import { useState } from "react";

interface OnboardingScreenProps {
  onComplete: () => void;
  onBack: () => void;
}

const situations = [
  { id: "preparing", label: "Готовимся к рождению" },
  { id: "0-3", label: "Ребенок 0–3 месяца" },
  { id: "3-6", label: "Ребенок 3–6 месяцев" },
  { id: "6-12", label: "Ребенок 6–12 месяцев" },
];

const interests = [
  { id: "sleep", label: "Сон", icon: "🌙" },
  { id: "feeding", label: "Кормление", icon: "🍼" },
  { id: "health", label: "Здоровье", icon: "💊" },
  { id: "shopping", label: "Покупки", icon: "🛒" },
  { id: "development", label: "Развитие", icon: "🧸" },
  { id: "anxiety", label: "Тревожные вопросы", icon: "💭" },
];

export function OnboardingScreen({ onComplete, onBack }: OnboardingScreenProps) {
  const [selectedSituation, setSelectedSituation] = useState<string>("");
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const toggleInterest = (id: string) => {
    setSelectedInterests(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="p-4">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="flex-1 px-6 flex flex-col overflow-y-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-foreground mb-2">Расскажите о себе</h1>
          <p className="text-muted-foreground">Это поможет нам подобрать полезный контент</p>
        </div>

        <div className="space-y-8">
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Ваша ситуация</h3>
            <div className="space-y-3">
              {situations.map((situation) => (
                <button
                  key={situation.id}
                  onClick={() => setSelectedSituation(situation.id)}
                  className={`w-full h-14 rounded-xl border-2 transition-all text-left px-5 ${
                    selectedSituation === situation.id
                      ? "border-primary bg-primary/5 text-foreground"
                      : "border-border bg-transparent text-muted-foreground"
                  }`}
                >
                  {situation.label}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-medium">Что вас интересует?</h3>
            <p className="text-sm text-muted-foreground -mt-2">Выберите несколько тем</p>
            <div className="grid grid-cols-2 gap-3">
              {interests.map((interest) => (
                <button
                  key={interest.id}
                  onClick={() => toggleInterest(interest.id)}
                  className={`h-24 rounded-xl border-2 transition-all flex flex-col items-center justify-center gap-2 ${
                    selectedInterests.includes(interest.id)
                      ? "border-primary bg-primary/5 text-foreground"
                      : "border-border bg-transparent text-muted-foreground"
                  }`}
                >
                  <span className="text-2xl">{interest.icon}</span>
                  <span className="text-sm">{interest.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-auto py-8">
          <Button
            onClick={onComplete}
            disabled={!selectedSituation}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            Продолжить
          </Button>
        </div>
      </div>
    </div>
  );
}

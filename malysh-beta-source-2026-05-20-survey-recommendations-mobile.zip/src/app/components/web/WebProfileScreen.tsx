import { motion } from "motion/react";
import { Baby, Calendar, Heart, Settings, LogOut, Edit, Bell, Shield, Moon, Save, X, Check, FileText, Camera, Phone, Trash2, LifeBuoy, ShieldCheck } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Logo } from "../Logo";
import { AddNoteModal, Note } from "./AddNoteModal";
import { ThemeToggle } from "../ThemeToggle";
import { useEffect, useRef, useState, type ChangeEvent } from "react";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { normalizeBabyProfile, useBabyProfile, type BabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";
import { PARENT_GOALS, useParentGoals, type ParentGoalId } from "../../lib/parentGoals";
import { notifySuccess, notifyWarning } from "../../lib/notify";
import { BetaFeedbackCard } from "./BetaFeedbackCard";

interface WebProfileScreenProps {
  onLogout?: () => void;
  onNavigate?: (screen: string) => void;
}

type MobileProfileTab = "child" | "goals" | "notes" | "settings";

export function WebProfileScreen({ onLogout, onNavigate }: WebProfileScreenProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [mobileProfileTab, setMobileProfileTab] = useState<MobileProfileTab>("child");
  const [profile, setProfile] = useUserProfile();
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const babyProfileRef = useRef<HTMLDivElement>(null);
  const [pediatricianDraft, setPediatricianDraft] = useState(profile.pediatricianPhone ?? "");
  const { baby, setBaby, age } = useBabyProfile();
  const { goals, setGoals } = useParentGoals();
  const [isEditingBaby, setIsEditingBaby] = useState(false);
  const [babyDraft, setBabyDraft] = useState<BabyProfile>(baby);
  const [notes, setNotes] = useLocalStorageState("mvp.profile.notes", [
    { id: 1, text: "Спросить врача про витамин D на следующем приеме", icon: "🩺", color: "from-blue-100 to-blue-200", date: "сегодня" },
  ]);

  useEffect(() => {
    setPediatricianDraft(profile.pediatricianPhone ?? "");
  }, [profile.pediatricianPhone]);

  const handleAvatarChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      notifyWarning("Выберите картинку для аватарки");
      return;
    }

    if (file.size > 1.5 * 1024 * 1024) {
      notifyWarning("Аватарка должна быть до 1.5 МБ");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") return;
      setProfile((prev) => ({ ...prev, avatarDataUrl: reader.result as string }));
      notifySuccess("Аватарка обновлена");
    };
    reader.readAsDataURL(file);
  };

  const removeAvatar = () => {
    setProfile((prev) => ({ ...prev, avatarDataUrl: undefined }));
    notifySuccess("Аватарка удалена");
  };

  const savePediatricianPhone = () => {
    const phone = pediatricianDraft.trim();
    setProfile((prev) => ({ ...prev, pediatricianPhone: phone }));
    notifySuccess(phone ? "Номер педиатра сохранен" : "Номер педиатра очищен");
  };

  const handleAddNote = (note: Note) => {
    setNotes((prev) => [
      {
        id: Date.now(),
        ...note,
        date: new Date().toLocaleDateString("ru-RU", {
          day: "numeric",
          month: "long",
        }),
      },
      ...prev,
    ]);
  };

  const startBabyEdit = () => {
    setBabyDraft(baby);
    setIsEditingBaby(true);
  };

  const openBabyEditorFromSettings = () => {
    startBabyEdit();
    setMobileProfileTab("child");
    window.setTimeout(() => {
      babyProfileRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 0);
  };

  const cancelBabyEdit = () => {
    setBabyDraft(baby);
    setIsEditingBaby(false);
  };

  const saveBabyProfile = () => {
    setBaby(normalizeBabyProfile({ ...babyDraft, birthDate: babyDraft.birthDate || baby.birthDate }));
    setIsEditingBaby(false);
  };

  const handleSettingsAction = (item: { target?: string; action?: "editBaby" | "support" }) => {
    if (item.target) {
      onNavigate?.(item.target);
      return;
    }

    if (item.action === "editBaby") {
      openBabyEditorFromSettings();
      return;
    }

    if (item.action === "support") {
      setIsSupportOpen((prev) => !prev);
    }
  };

  const toggleGoal = (goalId: ParentGoalId) => {
    setGoals((prev) =>
      prev.includes(goalId)
        ? prev.length > 1
          ? prev.filter((id) => id !== goalId)
          : prev
        : [...prev, goalId]
    );
  };

  const birthDateLabel = Number.isNaN(Date.parse(baby.birthDate))
    ? "Дата не указана"
    : new Intl.DateTimeFormat("ru-RU", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }).format(new Date(baby.birthDate));
  const userInitial = (profile.name?.trim() || "Р").charAt(0).toUpperCase();
  const isAdmin = profile.role === "Администратор";
  const settingsItems = [
    { icon: Bell, label: "Уведомления", target: "reminders" },
    { icon: Shield, label: "Приватность", target: "privacy" },
    { icon: FileText, label: "Условия beta", target: "terms" },
    { icon: Settings, label: "Профиль ребенка", action: "editBaby" as const },
    ...(isAdmin ? [{ icon: ShieldCheck, label: "Админ-панель", target: "admin" }] : []),
    { icon: LifeBuoy, label: "Поддержка", action: "support" as const },
  ];
  const mobileTabs: Array<{ id: MobileProfileTab; label: string; icon: typeof Baby }> = [
    { id: "child", label: "Ребенок", icon: Baby },
    { id: "goals", label: "Цели", icon: Heart },
    { id: "notes", label: "Заметки", icon: Edit },
    { id: "settings", label: "Настройки", icon: Settings },
  ];

  const stats = [
    { label: "Сохраненных статей", value: "3", icon: "📚" },
    { label: "Постов на форуме", value: "0", icon: "💬" },
    { label: "Заметок", value: String(notes.length), icon: "📅" },
  ];

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-2">Профиль</h1>
        <p className="text-sm md:text-lg text-muted-foreground">Ваши данные и настройки</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.06 }}
        className="mb-4 rounded-2xl border border-border bg-card p-4 shadow-sm lg:hidden"
      >
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => avatarInputRef.current?.click()}
            className="relative h-14 w-14 flex-shrink-0 overflow-hidden rounded-2xl bg-gradient-to-br from-primary/25 to-accent/25 text-lg font-medium text-primary"
            aria-label="Загрузить аватарку"
          >
            {profile.avatarDataUrl ? (
              <img src={profile.avatarDataUrl} alt="Аватар профиля" className="h-full w-full object-cover" />
            ) : (
              <span className="flex h-full w-full items-center justify-center">{userInitial}</span>
            )}
            <span className="absolute bottom-1 right-1 flex h-5 w-5 items-center justify-center rounded-full bg-background/95 shadow">
              <Camera className="h-3 w-3 text-primary" />
            </span>
          </button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-base font-medium text-foreground">{profile.name || "Родитель"}</div>
            <div className="truncate text-xs text-muted-foreground">{profile.email || "parent@example.com"}</div>
            <div className="mt-1 text-xs text-primary">{profile.role ?? "Родитель"}</div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setMobileProfileTab("child")}
          className="mt-4 flex w-full items-center gap-3 rounded-2xl border border-primary/10 bg-primary/5 px-3 py-3 text-left"
        >
          <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-2xl bg-background text-3xl">
            {baby.emoji}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium text-foreground">{baby.name}, {age.label}</div>
            <div className="truncate text-xs text-muted-foreground">{age.stageLabel}</div>
          </div>
          <Edit className="h-4 w-4 flex-shrink-0 text-primary" />
        </button>
      </motion.div>

      <div className="mb-4 grid grid-cols-4 gap-2 rounded-2xl border border-border bg-card p-1.5 lg:hidden">
        {mobileTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = mobileProfileTab === tab.id;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setMobileProfileTab(tab.id)}
              className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl px-1 text-[10px] font-medium transition-colors ${
                isActive
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:bg-secondary"
              }`}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
        {/* Left Column */}
        <div className={`${mobileProfileTab === "settings" ? "hidden" : "space-y-4"} lg:col-span-2 lg:block md:space-y-6`}>
          {/* User Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="hidden bg-gradient-to-br from-purple-100/50 via-pink-100/50 to-blue-100/50 rounded-2xl md:rounded-3xl p-4 md:p-8 border-2 border-white/50 lg:block"
          >
            <div className="flex flex-col md:flex-row items-start gap-4 md:gap-6">
              <div className="flex flex-col items-start gap-3">
                <input
                  ref={avatarInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={handleAvatarChange}
                  className="hidden"
                />
                <motion.button
                  type="button"
                  whileHover={{ scale: 1.05, rotate: 3 }}
                  onClick={() => avatarInputRef.current?.click()}
                  className="relative w-20 h-20 md:w-24 md:h-24 bg-gradient-to-br from-primary/30 to-accent/30 rounded-2xl md:rounded-3xl flex items-center justify-center text-2xl md:text-3xl font-medium text-primary cursor-pointer shadow-lg overflow-hidden"
                  aria-label="Загрузить аватарку"
                >
                  {profile.avatarDataUrl ? (
                    <img src={profile.avatarDataUrl} alt="Аватар профиля" className="w-full h-full object-cover" />
                  ) : (
                    userInitial
                  )}
                  <span className="absolute right-2 bottom-2 w-8 h-8 rounded-full bg-background/90 border border-border flex items-center justify-center shadow-md">
                    <Camera className="w-4 h-4 text-primary" />
                  </span>
                </motion.button>
                {profile.avatarDataUrl && (
                  <button
                    type="button"
                    onClick={removeAvatar}
                    className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-destructive transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                    Удалить фото
                  </button>
                )}
              </div>
              <div className="flex-1 w-full">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4 gap-3">
                  <div>
                    <h2 className="text-xl md:text-3xl font-medium text-muted-foreground mb-1 md:mb-2">
                      {profile.name || "Родитель"}
                    </h2>
                    <p className="text-sm md:text-base text-muted-foreground">{profile.email || "parent@example.com"}</p>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => avatarInputRef.current?.click()}
                    className="rounded-xl md:rounded-2xl text-sm w-full md:w-auto"
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Аватар
                  </Button>
                </div>
                <div className="grid grid-cols-3 gap-2 md:gap-4">
                  {stats.map((stat, idx) => (
                    <div key={idx} className="bg-white/60 rounded-xl md:rounded-2xl px-2 md:px-4 py-2 md:py-3">
                      <div className="text-lg md:text-2xl font-medium text-foreground">{stat.value}</div>
                      <div className="text-[10px] md:text-xs text-muted-foreground leading-tight">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Pediatrician */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className={`${mobileProfileTab === "child" ? "block" : "hidden"} bg-card border border-border rounded-2xl md:rounded-3xl p-4 md:p-6 lg:block`}
          >
            <div className="flex items-center gap-2 mb-3 md:mb-4">
              <Phone className="w-5 h-5 text-primary" />
              <h3 className="text-base md:text-xl font-medium text-foreground">Педиатр</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-3">
              <Input
                value={pediatricianDraft}
                onChange={(event) => setPediatricianDraft(event.target.value)}
                placeholder="+7 (___) ___-__-__"
                inputMode="tel"
                className="h-11 rounded-xl bg-background"
              />
              <Button onClick={savePediatricianPhone} className="rounded-xl bg-primary hover:bg-primary/90">
                Сохранить
              </Button>
            </div>
            <p className="mt-3 text-xs md:text-sm text-muted-foreground">
              Номер появится в срочных контактах и будет сохранен в вашем аккаунте.
            </p>
          </motion.div>

          {/* Baby Info */}
          <motion.div
            ref={babyProfileRef}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className={`${mobileProfileTab === "child" ? "block" : "hidden"} scroll-mt-24 lg:block`}
          >
            <div className="flex items-center justify-between gap-3 mb-3 md:mb-4">
              <div className="flex items-center gap-2">
                <Baby className="w-5 h-5 text-primary" />
                <h3 className="text-base md:text-xl font-medium text-foreground">Профиль ребенка</h3>
              </div>
              {isEditingBaby ? (
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={cancelBabyEdit}
                    className="rounded-xl md:rounded-2xl text-sm"
                  >
                    <X className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Отмена</span>
                  </Button>
                  <Button
                    onClick={saveBabyProfile}
                    className="rounded-xl md:rounded-2xl text-sm bg-primary hover:bg-primary/90"
                  >
                    <Save className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Сохранить</span>
                  </Button>
                </div>
              ) : (
                <Button
                  onClick={startBabyEdit}
                  variant="outline"
                  className="rounded-xl md:rounded-2xl text-sm"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Редактировать
                </Button>
              )}
            </div>
            <div className="bg-card border border-border rounded-2xl md:rounded-3xl p-4 md:p-6">
              <div className="flex flex-col md:flex-row items-start gap-4 md:gap-6">
                <div className="w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl md:rounded-2xl flex items-center justify-center text-4xl md:text-5xl">
                  {isEditingBaby ? (
                    <Input
                      value={babyDraft.emoji}
                      onChange={(e) => setBabyDraft((prev) => ({ ...prev, emoji: e.target.value }))}
                      className="h-12 w-12 p-0 text-center text-2xl bg-white/70"
                      aria-label="Иконка ребенка"
                    />
                  ) : (
                    baby.emoji
                  )}
                </div>
                <div className="flex-1 w-full">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-3 md:mb-4 gap-2">
                    <div>
                      {isEditingBaby ? (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div>
                            <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Имя</div>
                            <Input
                              value={babyDraft.name}
                              onChange={(e) => setBabyDraft((prev) => ({ ...prev, name: e.target.value }))}
                              className="h-10 rounded-xl bg-background"
                            />
                          </div>
                          <div>
                            <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Дата рождения</div>
                            <Input
                              type="date"
                              value={babyDraft.birthDate}
                              onChange={(e) => setBabyDraft((prev) => ({ ...prev, birthDate: e.target.value }))}
                              className="h-10 rounded-xl bg-background"
                            />
                          </div>
                          <div>
                            <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Этап</div>
                            <select
                              value={babyDraft.stage}
                              onChange={(e) =>
                                setBabyDraft((prev) => ({ ...prev, stage: e.target.value as BabyProfile["stage"] }))
                              }
                              className="h-10 w-full rounded-xl bg-background border border-border px-3 text-sm text-foreground"
                            >
                              <option value="pregnancy">Ожидание</option>
                              <option value="0-3">0-3 месяца</option>
                              <option value="3-6">3-6 месяцев</option>
                              <option value="6-12">6-12 месяцев</option>
                            </select>
                          </div>
                        </div>
                      ) : (
                        <>
                          <h4 className="text-xl md:text-2xl font-medium text-foreground mb-1">{baby.name}</h4>
                          <div className="flex items-center gap-2 text-xs md:text-sm text-muted-foreground">
                            <Calendar className="w-3 h-3 md:w-4 md:h-4" />
                            <span>{birthDateLabel}</span>
                          </div>
                        </>
                      )}
                    </div>
                    <div className="bg-primary/10 text-primary px-3 md:px-4 py-1 md:py-2 rounded-lg md:rounded-xl text-sm md:text-base font-medium">
                      {age.label}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 md:gap-4">
                    <div className="bg-secondary rounded-xl md:rounded-2xl p-2 md:p-4">
                      <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Рост</div>
                      {isEditingBaby ? (
                        <Input
                          value={babyDraft.heightCm}
                          onChange={(e) => setBabyDraft((prev) => ({ ...prev, heightCm: e.target.value }))}
                          className="h-9 rounded-xl bg-background"
                        />
                      ) : (
                        <div className="text-sm md:text-lg font-medium text-foreground">{baby.heightCm || "—"} см</div>
                      )}
                    </div>
                    <div className="bg-secondary rounded-xl md:rounded-2xl p-2 md:p-4">
                      <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Вес</div>
                      {isEditingBaby ? (
                        <Input
                          value={babyDraft.weightKg}
                          onChange={(e) => setBabyDraft((prev) => ({ ...prev, weightKg: e.target.value }))}
                          className="h-9 rounded-xl bg-background"
                        />
                      ) : (
                        <div className="text-sm md:text-lg font-medium text-foreground">{baby.weightKg || "—"} кг</div>
                      )}
                    </div>
                    <div className="bg-secondary rounded-xl md:rounded-2xl p-2 md:p-4">
                      <div className="text-[10px] md:text-xs text-muted-foreground mb-1">Группа крови</div>
                      {isEditingBaby ? (
                        <Input
                          value={babyDraft.bloodType}
                          onChange={(e) => setBabyDraft((prev) => ({ ...prev, bloodType: e.target.value }))}
                          className="h-9 rounded-xl bg-background"
                        />
                      ) : (
                        <div className="text-xs md:text-lg font-medium text-foreground">{baby.bloodType || "—"}</div>
                      )}
                    </div>
                  </div>
                  <div className="mt-4 rounded-xl bg-primary/5 border border-primary/10 px-4 py-3">
                    <div className="text-xs font-medium text-primary mb-1">{age.stageLabel}</div>
                    <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
                      Сейчас фокус: {age.focus}.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Parent Goals */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className={`${mobileProfileTab === "goals" ? "block" : "hidden"} lg:block`}
          >
            <div className="flex items-center gap-2 mb-3 md:mb-4">
              <Heart className="w-5 h-5 text-primary" />
              <h3 className="text-base md:text-xl font-medium text-foreground">Цели родителя</h3>
            </div>
            <div className="bg-card border border-border rounded-2xl p-3 md:rounded-3xl md:p-6">
              <div className="grid grid-cols-2 gap-2 md:grid-cols-2 md:gap-3">
                {PARENT_GOALS.map((goal) => {
                  const isSelected = goals.includes(goal.id);

                  return (
                    <button
                      key={goal.id}
                      type="button"
                      onClick={() => toggleGoal(goal.id)}
                      aria-pressed={isSelected}
                      className={`flex min-h-[76px] items-center gap-2 rounded-xl border px-3 py-2 text-left transition-all md:min-h-0 md:items-start md:gap-3 md:p-4 ${
                        isSelected
                          ? "border-primary bg-primary/10"
                          : "border-border bg-background hover:border-primary/30"
                      }`}
                    >
                      <div className="w-9 h-9 md:w-10 md:h-10 rounded-xl bg-secondary flex items-center justify-center text-lg md:text-xl flex-shrink-0">
                        {goal.icon}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <div className="text-xs font-medium leading-snug text-foreground md:text-sm">{goal.label}</div>
                          {isSelected && (
                            <div className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0">
                              <Check className="w-3.5 h-3.5 md:w-4 md:h-4" />
                            </div>
                          )}
                        </div>
                        <p className="mt-1 hidden text-xs text-muted-foreground leading-relaxed md:block">
                          {goal.homeHint}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </motion.div>

          {/* Notes */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className={`${mobileProfileTab === "notes" ? "block" : "hidden"} lg:block`}
          >
            <div className="flex items-center justify-between mb-3 md:mb-4">
              <h3 className="text-base md:text-xl font-medium text-foreground">Заметки</h3>
              <Button
                onClick={() => setIsModalOpen(true)}
                variant="outline"
                className="rounded-xl md:rounded-2xl text-sm"
              >
                <Edit className="w-4 h-4 mr-2" />
                <span className="hidden md:inline">Добавить</span>
                <span className="md:hidden">+</span>
              </Button>
            </div>
            <div className="space-y-2 md:space-y-3">
              {notes.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-secondary/30 border-2 border-dashed border-border rounded-xl md:rounded-2xl p-8 md:p-12 text-center"
                >
                  <div className="text-4xl md:text-5xl mb-4">📝</div>
                  <p className="text-sm md:text-base text-muted-foreground">Заметок пока нет</p>
                  <p className="text-xs md:text-sm text-muted-foreground mt-2">Добавьте свою первую заметку</p>
                  <Button
                    type="button"
                    onClick={() => setIsModalOpen(true)}
                    className="mt-5 h-10 rounded-xl px-4"
                  >
                    Добавить заметку
                  </Button>
                </motion.div>
              ) : (
                notes.map((note, idx) => (
                  <motion.div
                    key={note.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + idx * 0.1 }}
                    whileHover={{ x: 4 }}
                    className="bg-card border border-border rounded-xl md:rounded-2xl p-3 md:p-5 hover:border-primary/30 transition-all cursor-pointer"
                  >
                    <div className="flex items-start gap-3 md:gap-4">
                      <div className="w-10 h-10 md:w-12 md:h-12 bg-secondary rounded-lg md:rounded-xl flex items-center justify-center text-xl md:text-2xl flex-shrink-0">
                        {note.icon}
                      </div>
                      <div className="flex-1">
                        <p className="text-sm md:text-base text-foreground mb-1">{note.text}</p>
                        <p className="text-xs md:text-sm text-muted-foreground">{note.date}</p>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>
        </div>

        {/* Right Column - Settings */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className={`${mobileProfileTab === "settings" ? "space-y-4" : "hidden"} lg:block lg:space-y-6`}
        >
          <div className="bg-card border border-border rounded-2xl p-4 md:rounded-3xl md:p-6">
            <h3 className="font-medium text-foreground mb-4">Настройки</h3>
            <div className="space-y-2">
              {/* Theme Toggle */}
              <div className="flex items-center justify-between px-4 py-3 rounded-xl bg-secondary/50">
                <div className="flex items-center gap-3">
                  <Moon className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-foreground">Темная тема</span>
                </div>
                <ThemeToggle compact />
              </div>

              {settingsItems.map((item, idx) => {
                const Icon = item.icon;
                const isActive = item.action === "support" && isSupportOpen;

                return (
                  <motion.button
                    key={idx}
                    type="button"
                    whileHover={{ x: 4 }}
                    onClick={() => handleSettingsAction(item)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all text-left ${
                      isActive ? "bg-primary/10 text-primary" : "hover:bg-secondary"
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                    <span className="text-sm text-foreground">{item.label}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>

          {isSupportOpen && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-3"
            >
              <div className="rounded-3xl border border-primary/20 bg-primary/5 p-4 md:p-5">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                    <LifeBuoy className="h-5 w-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-foreground">Поддержка по работе сайта</h4>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                      Пишите сюда, если не получается войти, что-то не сохранилось, кнопка не работает, страница выглядит неправильно или нужна новая функция.
                    </p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] font-medium text-muted-foreground">
                  <div className="rounded-xl bg-background/80 px-3 py-2">Вход и доступ</div>
                  <div className="rounded-xl bg-background/80 px-3 py-2">Ошибки и баги</div>
                  <div className="rounded-xl bg-background/80 px-3 py-2">Потеря данных</div>
                  <div className="rounded-xl bg-background/80 px-3 py-2">Идеи по сайту</div>
                </div>
              </div>
              <BetaFeedbackCard screen="support" />
            </motion.div>
          )}

          <div className="bg-gradient-to-br from-destructive/10 to-destructive/5 border border-destructive/20 rounded-2xl p-4 md:rounded-3xl md:p-6">
            <Button
              variant="ghost"
              onClick={onLogout}
              className="w-full text-destructive hover:text-destructive hover:bg-destructive/5"
            >
              <LogOut className="w-5 h-5 mr-2" />
              Выйти из аккаунта
            </Button>
          </div>

          <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-4 text-center md:rounded-3xl md:p-6">
            <div className="mb-4 flex justify-center">
              <Logo size={64} />
            </div>
            <h4 className="font-medium text-foreground mb-2">Малыш+</h4>
            <p className="text-sm text-muted-foreground">Версия 1.0.0</p>
          </div>
        </motion.div>
      </div>

      {/* Add Note Modal */}
      <AddNoteModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddNote}
      />
    </div>
  );
}

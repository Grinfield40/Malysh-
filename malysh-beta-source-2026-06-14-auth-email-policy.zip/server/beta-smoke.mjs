import { spawn, spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { mkdir, rm, unlink } from "node:fs/promises";
import { createServer } from "node:net";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(join(__dirname, ".."));
const smokeId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const dataDir = resolve(process.env.MALYSH_SMOKE_DATA_DIR || join(projectRoot, "server", "data"));
const dbFile = resolve(dataDir, `beta-smoke-${smokeId}.db`);
const backupDir = resolve(
  process.env.MALYSH_SMOKE_BACKUP_DIR || join(projectRoot, "server", "backups", `beta-smoke-${smokeId}`)
);
const distDir = resolve(process.env.MALYSH_SMOKE_DIST_DIR || join(projectRoot, "dist"));
const inviteCode = "smoke-invite-123";
const adminEmail = "smoke-admin@yandex.ru";
const adminPassword = "SmokeAdmin123!";
const testerEmail = "smoke-tester@mail.ru";
const testerPassword = "SmokeTester123!";
const port = await getFreePort();
const baseUrl = `http://127.0.0.1:${port}`;
const registrationConsents = {
  personalData: {
    accepted: true,
    documentKey: "personalDataConsent",
    documentVersion: "2026-05-21",
  },
  childRepresentative: {
    accepted: true,
    documentKey: "childDataConsent",
    documentVersion: "2026-05-21",
  },
  sensitiveDataWarning: {
    accepted: true,
    documentKey: "privacy",
    documentVersion: "2026-05-21",
  },
};

const smokeEnv = {
  ...process.env,
  NODE_ENV: "test",
  MALYSH_HOST: "127.0.0.1",
  MALYSH_API_PORT: String(port),
  MALYSH_PUBLIC_URL: baseUrl,
  MALYSH_ALLOWED_ORIGINS: baseUrl,
  MALYSH_DATA_DIR: dataDir,
  MALYSH_DB_FILE: dbFile,
  MALYSH_BACKUP_DIR: backupDir,
  MALYSH_BACKUP_KEEP: "5",
  MALYSH_DIST_DIR: distDir,
  MALYSH_SERVE_WEB: "false",
  MALYSH_HEALTH_DETAILS: "true",
  MALYSH_ACCESS_LOGS: "false",
  MALYSH_ERROR_STACKS: "false",
  MALYSH_REGISTRATION_MODE: "closed",
  MALYSH_BETA_INVITE_CODE: inviteCode,
  MALYSH_ADMIN_EMAIL: adminEmail,
  MALYSH_ADMIN_NAME: "Smoke Admin",
  MALYSH_ADMIN_PASSWORD: adminPassword,
  MALYSH_AUTH_RATE_LIMIT_WINDOW_MS: "60000",
  MALYSH_AUTH_LOGIN_IP_LIMIT: "50",
  MALYSH_AUTH_LOGIN_EMAIL_LIMIT: "50",
  MALYSH_AUTH_REGISTER_IP_LIMIT: "50",
  MALYSH_MAX_JSON_BODY_BYTES: "1500",
  MALYSH_MAX_STORAGE_VALUE_BYTES: "1200",
  MALYSH_MAX_FRIDGE_IMAGE_BYTES: "20",
  MALYSH_MAX_FRIDGE_TOTAL_IMAGE_BYTES: "40",
  MALYSH_FORUM_TITLE_MAX_LENGTH: "80",
  MALYSH_FORUM_POST_MAX_LENGTH: "80",
  MALYSH_FORUM_COMMENT_MAX_LENGTH: "40",
  MALYSH_FORUM_REPORT_DETAILS_MAX_LENGTH: "80",
};

let serverProcess;

try {
  await mkdir(dataDir, { recursive: true });
  await mkdir(backupDir, { recursive: true });

  runCreateAdmin();

  serverProcess = spawn(process.execPath, ["server/index.mjs"], {
    cwd: projectRoot,
    env: smokeEnv,
    stdio: ["ignore", "pipe", "pipe"],
  });

  const stderr = [];
  serverProcess.stderr.on("data", (chunk) => {
    stderr.push(chunk.toString("utf8"));
  });

  await waitForHealth();

  const health = await requestJson("GET", "/api/health");
  assertStatus(health, 200, "health");
  assert(health.requestId, "health response should include request id header");
  assert(health.data.registrationMode === "closed", "health should expose closed registration mode");

  const adminLogin = await requestJson("POST", "/api/auth/login", {
    email: adminEmail,
    password: adminPassword,
  });
  assertStatus(adminLogin, 200, "admin login");
  assert(adminLogin.data.user.role === "admin", "bootstrap account should be admin");
  assert(adminLogin.data.consentStatus?.required === true, "legacy bootstrap admin should require consents");
  const adminToken = adminLogin.data.token;

  const blockedAdminOverview = await requestJson("GET", "/api/admin/overview", undefined, adminToken);
  assertStatus(blockedAdminOverview, 451, "legacy account should be gated before consents");

  const adminConsent = await requestJson(
    "POST",
    "/api/account/consents/accept",
    { consents: registrationConsents },
    adminToken
  );
  assertStatus(adminConsent, 200, "legacy admin consent acceptance");
  assert(adminConsent.data.consentStatus?.required === false, "accepted consents should unlock legacy admin");

  const adminInvite = await requestJson(
    "POST",
    "/api/admin/invites",
    {
      label: "Smoke invite",
      maxUses: 1,
    },
    adminToken
  );
  assertStatus(adminInvite, 201, "admin invite create");
  assert(adminInvite.data.invite?.code?.startsWith("BETA-"), "admin invite should return generated code");
  assert(adminInvite.data.config?.activeInviteCount >= 1, "admin config should expose active invite count");

  const unsupportedEmailRegister = await requestJson("POST", "/api/auth/register", {
    name: "Foreign Mail",
    email: "foreign-user@gmail.com",
    password: testerPassword,
    inviteCode,
    consents: registrationConsents,
  });
  assertStatus(unsupportedEmailRegister, 400, "foreign email domain should be rejected");

  const noInviteRegister = await requestJson("POST", "/api/auth/register", {
    name: "No Invite",
    email: "no-invite@mail.ru",
    password: testerPassword,
    consents: registrationConsents,
  });
  assertStatus(noInviteRegister, 403, "registration without invite");

  const testerRegister = await requestJson("POST", "/api/auth/register", {
    name: "Smoke Tester",
    email: testerEmail,
    password: testerPassword,
    inviteCode: adminInvite.data.invite.code,
    consents: registrationConsents,
  });
  assertStatus(testerRegister, 201, "registration with invite");
  assert(testerRegister.data.user.role === "user", "tester should not become admin");
  assert(testerRegister.data.consentStatus?.required === false, "new tester should not require repeat consent");

  const reusedInviteRegister = await requestJson("POST", "/api/auth/register", {
    name: "Reuse Invite",
    email: "reuse-invite@mail.ru",
    password: testerPassword,
    inviteCode: adminInvite.data.invite.code,
    consents: registrationConsents,
  });
  assertStatus(reusedInviteRegister, 403, "single-use invite should not be reusable");

  const testerToken = testerRegister.data.token;

  const disposableRegister = await requestJson("POST", "/api/auth/register", {
    name: "Disposable Tester",
    email: "delete-me@yandex.ru",
    password: testerPassword,
    inviteCode,
    consents: registrationConsents,
  });
  assertStatus(disposableRegister, 201, "disposable tester registration with env invite");

  const storagePatch = await requestJson(
    "PATCH",
    "/api/account/storage",
    {
      key: "mvp.baby.profile",
      value: {
        name: "Beta Baby",
        birthDate: "2026-01-01",
        stage: "baby",
        emoji: "baby",
      },
    },
    testerToken
  );
  assertStatus(storagePatch, 200, "storage patch");

  const diaryPatch = await requestJson(
    "PATCH",
    "/api/account/storage",
    {
      key: "mvp.tracker.entries",
      value: [
        {
          id: "smoke-diary-entry",
          type: "feeding",
          time: "09:10",
          details: "90 ml formula",
          icon: "feeding",
          category: "feeding",
          date: "2026-05-14",
          source: "tracker",
        },
      ],
    },
    testerToken
  );
  assertStatus(diaryPatch, 200, "diary storage patch");

  const forumPost = await requestJson(
    "POST",
    "/api/forum/posts",
    {
      title: "Smoke forum post",
      content: "A short but valid beta smoke forum question.",
      category: "other",
      tags: ["beta", "smoke"],
    },
    testerToken
  );
  assertStatus(forumPost, 201, "forum post create");

  const postId = forumPost.data.post.id;

  const forumComment = await requestJson(
    "POST",
    `/api/forum/posts/${postId}/comments`,
    { content: "Short helpful answer." },
    testerToken
  );
  assertStatus(forumComment, 201, "forum comment create");

  const report = await requestJson(
    "POST",
    "/api/forum/reports",
    {
      targetType: "post",
      targetId: postId,
      reason: "other",
      details: "Smoke moderation check.",
    },
    testerToken
  );
  assertStatus(report, 201, "forum report create");

  const fridgePatch = await requestJson(
    "PATCH",
    "/api/account/storage",
    {
      key: "mvp.fridge.drawings",
      value: [
        {
          id: "smoke-fridge-upload",
          title: "Smoke fridge upload",
          imageSrc: "data:image/png;base64,AA==",
        },
      ],
    },
    testerToken
  );
  assertStatus(fridgePatch, 200, "fridge image upload audit");

  const analyticsEvents = await requestJson(
    "POST",
    "/api/analytics/events",
    {
      events: [
        {
          name: "screen_view",
          screen: "home",
          sessionId: "smoke-session",
          meta: { source: "beta-smoke" },
        },
        {
          name: "screen_time",
          screen: "tracker",
          sessionId: "smoke-session",
          durationMs: 42000,
          meta: { source: "beta-smoke" },
        },
        {
          name: "tracker_entry_added",
          screen: "tracker",
          sessionId: "smoke-session",
          meta: { type: "feeding" },
        },
        {
          name: "app_error",
          screen: "fridge",
          sessionId: "smoke-session",
          meta: { source: "beta-smoke", message: "Smoke client error" },
        },
      ],
    },
    testerToken
  );
  assertStatus(analyticsEvents, 201, "analytics events create");
  assert(analyticsEvents.data.accepted === 4, "analytics should accept all smoke events");

  const tooLongPost = await requestJson(
    "POST",
    "/api/forum/posts",
    {
      title: "Too long smoke post",
      content: "x".repeat(81),
      category: "other",
      tags: [],
    },
    testerToken
  );
  assertStatus(tooLongPost, 400, "forum post length guard");

  const badFridge = await requestJson(
    "PATCH",
    "/api/account/storage",
    {
      key: "mvp.fridge.drawings",
      value: [
        {
          id: 1,
          type: "upload",
          imageSrc: `data:image/png;base64,${Buffer.alloc(32).toString("base64")}`,
        },
      ],
    },
    testerToken
  );
  assertStatus(badFridge, 400, "fridge image size guard");

  const badStorageKey = await requestJson(
    "PATCH",
    "/api/account/storage",
    { key: "not.mvp.key", value: "bad" },
    testerToken
  );
  assertStatus(badStorageKey, 400, "storage key guard");

  const resetSessions = await requestJson("POST", `/api/admin/users/${testerRegister.data.user.id}/sessions/reset`, undefined, adminToken);
  assertStatus(resetSessions, 200, "admin reset user sessions");
  assert(resetSessions.data.sessionsDeleted >= 1, "reset should delete tester session");

  const blockUser = await requestJson(
    "PATCH",
    `/api/admin/users/${testerRegister.data.user.id}/status`,
    { blocked: true },
    adminToken
  );
  assertStatus(blockUser, 200, "admin block user");

  const blockedLogin = await requestJson("POST", "/api/auth/login", {
    email: testerEmail,
    password: testerPassword,
  });
  assertStatus(blockedLogin, 401, "blocked user cannot log in");

  const unblockUser = await requestJson(
    "PATCH",
    `/api/admin/users/${testerRegister.data.user.id}/status`,
    { blocked: false },
    adminToken
  );
  assertStatus(unblockUser, 200, "admin unblock user");

  const unsafeDelete = await requestJson(
    "DELETE",
    `/api/admin/users/${disposableRegister.data.user.id}`,
    { confirmEmail: "delete-me@yandex.ru" },
    adminToken
  );
  assertStatus(unsafeDelete, 409, "safe mode blocks deleting active users");

  const blockDisposableUser = await requestJson(
    "PATCH",
    `/api/admin/users/${disposableRegister.data.user.id}/status`,
    { blocked: true },
    adminToken
  );
  assertStatus(blockDisposableUser, 200, "admin block disposable user before delete");

  const resetDisposableSessions = await requestJson(
    "POST",
    `/api/admin/users/${disposableRegister.data.user.id}/sessions/reset`,
    undefined,
    adminToken
  );
  assertStatus(resetDisposableSessions, 200, "admin reset disposable sessions before delete");

  const deleteUser = await requestJson(
    "DELETE",
    `/api/admin/users/${disposableRegister.data.user.id}`,
    { confirmEmail: "delete-me@yandex.ru" },
    adminToken
  );
  assertStatus(deleteUser, 200, "admin delete disposable user");

  const tooLargeBody = await requestJson("POST", "/api/auth/login", {
    email: `${"a".repeat(1800)}@mail.ru`,
    password: testerPassword,
  });
  assertStatus(tooLargeBody, 413, "json body size guard");

  const adminOverview = await requestJson("GET", "/api/admin/overview", undefined, adminToken);
  assertStatus(adminOverview, 200, "admin overview");
  assert(adminOverview.data.stats.users === 2, "admin overview should see admin and tester");
  assert(adminOverview.data.stats.diaryEntries === 1, "admin overview should see diary entries");
  assert(adminOverview.data.stats.fridgeItems === 1, "admin overview should see fridge uploads");
  assert(adminOverview.data.stats.forumPosts === 1, "admin overview should see smoke forum post");
  assert(adminOverview.data.stats.analyticsEvents === 4, "admin overview should see analytics events");
  assert(adminOverview.data.stats.userConsents === 6, "admin overview should count admin and tester consents");
  assert(adminOverview.data.stats.consentMissing === 0, "admin overview should count users missing required consents");
  assert(adminOverview.data.consents?.stats?.accepted === 2, "admin consent summary should count accepted users");
  assert(adminOverview.data.consents?.stats?.missing === 0, "admin consent summary should count missing consent users");
  assert(adminOverview.data.consents?.recent?.length === 6, "admin consent summary should include recent consent records");
  assert(adminOverview.data.config.inviteCodes[0].usedCount === 1, "admin overview should show invite usage");
  assert(
    adminOverview.data.analytics.topScreens.some((screen) => screen.screen === "home" || screen.screen === "tracker"),
    "admin analytics should include beta screens"
  );
  assert(
    adminOverview.data.analytics.topActions.some((action) => action.name === "tracker_entry_added"),
    "admin analytics should include tracked actions"
  );
  assert(
    adminOverview.data.analytics.topActions.some((action) => action.name === "app_error"),
    "admin analytics should include app errors"
  );
  const testerOverview = adminOverview.data.users.find((user) => user.email === testerEmail);
  assert(testerOverview, "admin overview should include tester user");
  assert(testerOverview.consentStatus?.required === false, "tester card should include current consent status");
  assert(testerOverview.legalConsentAcceptedAt, "tester card should include consent acceptance date");
  assert(testerOverview.diaryEntries === 1, "tester card should include diary entry count");
  assert(testerOverview.fridgeItems === 1, "tester card should include fridge item count");
  assert(testerOverview.recentDiaryEntries.some((entry) => entry.id === "smoke-diary-entry"), "tester card should include recent diary entry");
  assert(testerOverview.recentActivity.some((event) => event.kind === "registration"), "history should include registration");
  assert(testerOverview.recentActivity.some((event) => event.kind === "data"), "history should include storage data changes");
  assert(testerOverview.recentActivity.some((event) => event.kind === "forum"), "history should include forum activity");
  assert(testerOverview.recentActivity.some((event) => event.kind === "fridge"), "history should include fridge uploads");
  assert(testerOverview.recentActivity.some((event) => event.kind === "screen"), "history should include analytics screen activity");

  const adminExport = await requestJson("GET", "/api/admin/export", undefined, adminToken);
  assertStatus(adminExport, 200, "admin export");
  assert(adminExport.data.userConsents?.length === 6, "admin export should include admin and tester consent records");
  assert(
    adminExport.data.personalDataRegistry?.categories?.some((category) => category.name === "Согласия"),
    "admin export should include personal data registry"
  );

  const backup = await requestJson("POST", "/api/admin/backup", undefined, adminToken);
  assertStatus(backup, 201, "admin backup");
  assert(backup.data.backup?.fileName?.endsWith(".db"), "backup response should include db file");

  const backupPath = resolve(backupDir, backup.data.backup.fileName);
  assert(backupPath.startsWith(`${backupDir}\\`) || backupPath.startsWith(`${backupDir}/`), "backup path should stay in smoke backup dir");
  assert(existsSync(backupPath), "backup file should exist");

  console.log("");
  console.log("Malysh+ beta smoke: OK");
  console.log(`Checked: invite gate, admin login, invite codes, consent records, safe user admin actions, tester registration, diary, fridge, analytics, forum, moderation report, data limits, backup.`);
  console.log("");
} catch (error) {
  console.error("");
  console.error(error instanceof Error ? error.message : error);
  console.error("");
  process.exitCode = 1;
} finally {
  if (serverProcess) {
    serverProcess.kill("SIGTERM");
    await sleep(250);
  }

  await cleanupSmokeFiles();
}

function runCreateAdmin() {
  const result = spawnSync(process.execPath, ["server/create-admin.mjs"], {
    cwd: projectRoot,
    env: smokeEnv,
    encoding: "utf8",
  });

  if (result.status !== 0) {
    throw new Error(`Could not create smoke admin.\n${result.stderr || result.stdout}`);
  }
}

async function requestJson(method, path, body, token) {
  let response;

  try {
    response = await fetch(`${baseUrl}${path}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch (error) {
    throw new Error(`Request failed: ${method} ${path}. ${error instanceof Error ? error.message : error}`);
  }

  const data = await response.json().catch(() => ({}));

  return { status: response.status, data, requestId: response.headers.get("x-request-id") };
}

async function waitForHealth() {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    if (serverProcess.exitCode != null) {
      throw new Error("Smoke API stopped before health check passed.");
    }

    const response = await fetch(`${baseUrl}/api/health`).catch(() => null);

    if (response?.ok) return;

    await sleep(150);
  }

  throw new Error("Smoke API did not start in time.");
}

function assertStatus(response, expectedStatus, label) {
  if (response.status !== expectedStatus) {
    throw new Error(`${label} expected ${expectedStatus}, got ${response.status}: ${JSON.stringify(response.data)}`);
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function sleep(ms) {
  return new Promise((resolveSleep) => setTimeout(resolveSleep, ms));
}

async function getFreePort() {
  return new Promise((resolvePort, rejectPort) => {
    const server = createServer();

    server.once("error", rejectPort);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const selectedPort = typeof address === "object" && address ? address.port : 0;

      server.close(() => resolvePort(selectedPort));
    });
  });
}

async function cleanupSmokeFiles() {
  const allowedDataPrefix = resolve(projectRoot, "server", "data", "beta-smoke-");
  const allowedBackupPrefix = resolve(projectRoot, "server", "backups", "beta-smoke-");

  for (const suffix of ["", "-wal", "-shm"]) {
    const filePath = resolve(`${dbFile}${suffix}`);

    if (filePath.startsWith(allowedDataPrefix) && existsSync(filePath)) {
      await unlink(filePath).catch(() => undefined);
    }
  }

  if (backupDir.startsWith(allowedBackupPrefix) && existsSync(backupDir)) {
    await rm(backupDir, { recursive: true, force: true }).catch(() => undefined);
  }
}

import type { ReactNode } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "../ui/button";

interface EmptyStateAction {
  label: string;
  onClick: () => void;
  variant?: "default" | "outline";
}

interface ActionEmptyStateProps {
  icon: ReactNode;
  title: string;
  description: string;
  primaryAction?: EmptyStateAction;
  secondaryAction?: EmptyStateAction;
  compact?: boolean;
  className?: string;
  children?: ReactNode;
}

export function ActionEmptyState({
  icon,
  title,
  description,
  primaryAction,
  secondaryAction,
  compact = false,
  className = "",
  children,
}: ActionEmptyStateProps) {
  return (
    <div
      className={`rounded-2xl border border-dashed border-primary/25 bg-card px-5 text-center shadow-sm ${
        compact ? "py-7" : "py-10 md:py-14"
      } ${className}`}
    >
      <div
        className={`mx-auto mb-4 flex items-center justify-center rounded-2xl bg-primary/10 text-primary ${
          compact ? "h-12 w-12" : "h-14 w-14 md:h-16 md:w-16"
        }`}
      >
        {icon}
      </div>
      <h3 className="mb-2 text-lg font-medium text-foreground md:text-xl">{title}</h3>
      <p className="mx-auto mb-5 max-w-md text-sm leading-relaxed text-muted-foreground">
        {description}
      </p>

      {(primaryAction || secondaryAction) && (
        <div className="flex flex-col justify-center gap-2 sm:flex-row">
          {secondaryAction ? (
            <Button
              type="button"
              variant={secondaryAction.variant || "outline"}
              onClick={secondaryAction.onClick}
              className="h-10 rounded-xl"
            >
              {secondaryAction.label}
            </Button>
          ) : null}
          {primaryAction ? (
            <Button
              type="button"
              variant={primaryAction.variant || "default"}
              onClick={primaryAction.onClick}
              className="h-10 rounded-xl"
            >
              {primaryAction.label}
              <ArrowRight className="h-4 w-4" />
            </Button>
          ) : null}
        </div>
      )}

      {children}
    </div>
  );
}

import { lazy, Suspense } from "react";
import { AlertCircle } from "lucide-react";
import { AuthScreen } from "./AuthScreen";
import { LoadingPanel } from "./LoadingPanel";
import { Button } from "../ui/button";
import { getAuthPromptDescription, screenToPath, type Screen } from "../../lib/routes";
import type { AuthSession } from "../../lib/accountApi";

const WebHomeScreen = lazy(() => import("./WebHomeScreen").then((module) => ({ default: module.WebHomeScreen })));
const WebForumScreen = lazy(() => import("./WebForumScreen").then((module) => ({ default: module.WebForumScreen })));
const WebShoppingScreen = lazy(() => import("./WebShoppingScreen").then((module) => ({ default: module.WebShoppingScreen })));
const WebTrackerScreen = lazy(() => import("./WebTrackerScreen").then((module) => ({ default: module.WebTrackerScreen })));
const WebTipsScreen = lazy(() => import("./WebTipsScreen").then((module) => ({ default: module.WebTipsScreen })));
const WebArticleScreen = lazy(() => import("./WebArticleScreen").then((module) => ({ default: module.WebArticleScreen })));
const WebProfileScreen = lazy(() => import("./WebProfileScreen").then((module) => ({ default: module.WebProfileScreen })));
const WebSavedScreen = lazy(() => import("./WebSavedScreen").then((module) => ({ default: module.WebSavedScreen })));
const WebRemindersScreen = lazy(() => import("./WebRemindersScreen").then((module) => ({ default: module.WebRemindersScreen })));
const WebRoutinesScreen = lazy(() => import("./WebRoutinesScreen").then((module) => ({ default: module.WebRoutinesScreen })));
const WebUrgentScreen = lazy(() => import("./WebUrgentScreen").then((module) => ({ default: module.WebUrgentScreen })));
const WebRecommendationsScreen = lazy(() => import("./WebRecommendationsScreen").then((module) => ({ default: module.WebRecommendationsScreen })));
const GrowthTimelineScreen = lazy(() => import("./GrowthTimelineScreen").then((module) => ({ default: module.GrowthTimelineScreen })));
const GrowthStageDetail = lazy(() => import("./GrowthStageDetail").then((module) => ({ default: module.GrowthStageDetail })));
const NotFoundScreen = lazy(() => import("./NotFoundScreen").then((module) => ({ default: module.NotFoundScreen })));
const WebFridgeScreen = lazy(() => import("./WebFridgeScreen").then((module) => ({ default: module.WebFridgeScreen })));
const StrollerGuideScreen = lazy(() => import("./StrollerGuideScreen").then((module) => ({ default: module.StrollerGuideScreen })));
const SubscriptionScreen = lazy(() => import("./SubscriptionScreen").then((module) => ({ default: module.SubscriptionScreen })));
const TabooScreen = lazy(() => import("./TabooScreen").then((module) => ({ default: module.TabooScreen })));
const DischargeChecklistScreen = lazy(() => import("./DischargeChecklistScreen").then((module) => ({ default: module.DischargeChecklistScreen })));
const WebAdminScreen = lazy(() => import("./WebAdminScreen").then((module) => ({ default: module.WebAdminScreen })));
const WebLegalScreen = lazy(() => import("./WebLegalScreen").then((module) => ({ default: module.WebLegalScreen })));

type LegalScreenType = "privacy" | "personal-consent" | "child-consent" | "data-map" | "terms";

interface AppScreenRendererProps {
  currentScreen: Screen;
  selectedGrowthStageId: string;
  shouldShowGuestAuth: boolean;
  authPromptScreen: Screen;
  isAuthenticated: boolean;
  legalScreenType?: LegalScreenType;
  featureEnabled: (key: string) => boolean;
  onAuth: (session: AuthSession) => void;
  onCloseGuestAuth: () => void;
  onLogout: () => void;
  onNavigate: (screen: string) => void;
  onOpenGuestAuth: (screen?: Screen) => void;
  onOpenGrowthStage: (stageId: string) => void;
}

function FeatureUnavailableScreen({
  title,
  description,
  onNavigate,
}: {
  title: string;
  description: string;
  onNavigate: (screen: Screen) => void;
}) {
  return (
    <div className="p-4 md:p-8 pt-24 md:pt-28 max-w-4xl mx-auto">
      <div className="bg-card border border-border rounded-2xl p-6 md:p-8 shadow-sm">
        <div className="w-12 h-12 rounded-2xl bg-primary/10 text-primary flex items-center justify-center mb-4">
          <AlertCircle className="w-6 h-6" />
        </div>
        <h1 className="text-2xl md:text-3xl font-medium text-foreground mb-2">{title}</h1>
        <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-6">{description}</p>
        <Button onClick={() => onNavigate("home")} className="rounded-xl">
          На главную
        </Button>
      </div>
    </div>
  );
}

export function AppScreenRenderer({
  currentScreen,
  selectedGrowthStageId,
  shouldShowGuestAuth,
  authPromptScreen,
  isAuthenticated,
  legalScreenType,
  featureEnabled,
  onAuth,
  onCloseGuestAuth,
  onLogout,
  onNavigate,
  onOpenGuestAuth,
  onOpenGrowthStage,
}: AppScreenRendererProps) {
  return (
    <Suspense fallback={<LoadingPanel />}>
      {shouldShowGuestAuth ? (
        <AuthScreen
          onAuth={onAuth}
          onNavigate={onNavigate}
          onClose={onCloseGuestAuth}
          reasonDescription={getAuthPromptDescription(authPromptScreen)}
          variant="panel"
        />
      ) : (
        <>
          {currentScreen === "home" && (
            <WebHomeScreen
              onNavigate={onNavigate}
              isAuthenticated={isAuthenticated}
              onRequireAuth={(returnScreen) =>
                onOpenGuestAuth(returnScreen && returnScreen in screenToPath ? (returnScreen as Screen) : "home")
              }
            />
          )}
          {currentScreen === "shopping" && (
            featureEnabled("shopping") ? (
              <WebShoppingScreen />
            ) : (
              <FeatureUnavailableScreen
                title="Покупки временно на паузе"
                description="Этот раздел временно закрыт. Основные дневниковые сценарии работают как обычно."
                onNavigate={onNavigate}
              />
            )
          )}
          {currentScreen === "tracker" && <WebTrackerScreen onNavigate={onNavigate} />}
          {currentScreen === "tips" && <WebTipsScreen onArticleClick={() => onNavigate("article")} onNavigate={onNavigate} />}
          {currentScreen === "article" && <WebArticleScreen onBack={() => onNavigate("tips")} />}
          {currentScreen === "forum" && (
            featureEnabled("forum") ? (
              <WebForumScreen onNavigate={onNavigate} />
            ) : (
              <FeatureUnavailableScreen
                title="Форум временно закрыт"
                description="Мы можем временно закрыть форум, если нужно спокойно разобрать модерацию."
                onNavigate={onNavigate}
              />
            )
          )}
          {currentScreen === "growth-timeline" && (
            <GrowthTimelineScreen onStageClick={onOpenGrowthStage} />
          )}
          {currentScreen === "growth-stage" && (
            <GrowthStageDetail
              stageId={selectedGrowthStageId}
              onBack={() => onNavigate("growth-timeline")}
            />
          )}
          {currentScreen === "recommendations" && (
            featureEnabled("recommendations") ? (
              <WebRecommendationsScreen onNavigate={onNavigate} />
            ) : (
              <FeatureUnavailableScreen
                title="Мамы одобряют временно закрыт"
                description="Раздел можно включить обратно в панели администратора, когда подборка готова к тесту."
                onNavigate={onNavigate}
              />
            )
          )}
          {currentScreen === "fridge" && <WebFridgeScreen />}
          {currentScreen === "stroller-guide" && <StrollerGuideScreen />}
          {currentScreen === "urgent" && <WebUrgentScreen />}
          {currentScreen === "routines" && <WebRoutinesScreen onNavigate={onNavigate} />}
          {currentScreen === "reminders" && <WebRemindersScreen />}
          {currentScreen === "saved" && <WebSavedScreen onNavigate={onNavigate} />}
          {currentScreen === "profile" && <WebProfileScreen onLogout={onLogout} onNavigate={onNavigate} />}
          {currentScreen === "admin" && <WebAdminScreen />}
          {legalScreenType && <WebLegalScreen type={legalScreenType} onNavigate={onNavigate} />}
          {currentScreen === "not-found" && <NotFoundScreen onNavigate={onNavigate} />}
          {currentScreen === "subscription" && (
            featureEnabled("premium") ? (
              <SubscriptionScreen onClose={() => onNavigate("home")} />
            ) : (
              <FeatureUnavailableScreen
                title="Подписка пока не продается"
                description="Платный экран выключен, чтобы тест шел без лишнего давления."
                onNavigate={onNavigate}
              />
            )
          )}
          {currentScreen === "taboo" && <TabooScreen onClose={() => onNavigate("home")} />}
          {currentScreen === "discharge-checklist" && <DischargeChecklistScreen onClose={() => onNavigate("home")} />}
        </>
      )}
    </Suspense>
  );
}

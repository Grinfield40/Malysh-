import { motion } from "motion/react";
import { ArrowLeft, Clock, Bookmark, Share2, Heart } from "lucide-react";
import { Button } from "../ui/button";

interface WebArticleScreenProps {
  onBack: () => void;
}

export function WebArticleScreen({ onBack }: WebArticleScreenProps) {
  const article = {
    title: "Когда обращаться к врачу",
    category: "Здоровье",
    readTime: "5 мин",
    emoji: "🩺",
    author: "Др. Елена Петрова",
    date: "10 апреля 2026",
  };

  const relatedArticles = [
    { title: "Первая аптечка для малыша", emoji: "💊", category: "Здоровье" },
    { title: "Что нормально, а что нет", emoji: "✅", category: "Здоровье" },
    { title: "Температура у новорожденного", emoji: "🌡️", category: "Здоровье" },
  ];

  return (
    <div className="p-8 pt-28 max-w-[900px] mx-auto">
      {/* Back Button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>Назад к советам</span>
      </motion.button>

      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <span className="text-xs bg-primary/20 text-primary px-4 py-2 rounded-full font-medium">
            {article.category}
          </span>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{article.readTime} чтения</span>
          </div>
        </div>

        <h1 className="text-5xl font-medium text-foreground mb-6 leading-tight">
          {article.title}
        </h1>

        <div className="flex items-center justify-between pb-6 border-b border-border">
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>{article.author}</span>
            <span>•</span>
            <span>{article.date}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="rounded-xl">
              <Bookmark className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="sm" className="rounded-xl">
              <Share2 className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Featured Image */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.2 }}
        className="mb-12 bg-gradient-to-br from-primary/10 to-accent/10 rounded-3xl p-16 border-2 border-primary/20 text-center"
      >
        <div className="text-9xl mb-4">{article.emoji}</div>
        <p className="text-muted-foreground">Когда стоит волноваться, а когда можно подождать</p>
      </motion.div>

      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="prose prose-lg max-w-none"
      >
        <p className="text-xl text-foreground/80 leading-relaxed mb-8">
          Первые месяцы жизни малыша — время, когда родители часто волнуются о здоровье ребенка. Важно знать, в каких ситуациях стоит немедленно обратиться к врачу, а когда можно подождать и понаблюдать.
        </p>

        <h2 className="text-3xl font-medium text-foreground mt-12 mb-6">Срочно к врачу</h2>

        <div className="bg-gradient-to-br from-destructive/10 to-orange-200/20 border-2 border-destructive/30 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-white/80 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
              🚨
            </div>
            <div>
              <h3 className="text-xl font-medium text-foreground mb-4">Когда нужна неотложная помощь</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex gap-2">
                  <span className="text-destructive">•</span>
                  <span>Температура выше 38°C у детей младше 3 месяцев</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">•</span>
                  <span>Затрудненное дыхание, хрипы, свист при дыхании</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">•</span>
                  <span>Необычная вялость, ребенок не просыпается для кормления</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">•</span>
                  <span>Судороги или подергивания</span>
                </li>
                <li className="flex gap-2">
                  <span className="text-destructive">•</span>
                  <span>Рвота фонтаном несколько раз подряд</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <p className="text-foreground/80 leading-relaxed mb-8">
          В этих случаях не стоит ждать — вызывайте скорую помощь или срочно обращайтесь к педиатру. Лучше перестраховаться, чем упустить важные симптомы.
        </p>

        <h2 className="text-3xl font-medium text-foreground mt-12 mb-6">Можно подождать и понаблюдать</h2>

        <p className="text-foreground/80 leading-relaxed mb-6">
          Не все симптомы требуют немедленного визита к врачу. Вот ситуации, когда можно понаблюдать за ребенком в течение 24 часов:
        </p>

        <ul className="space-y-3 text-foreground/80 mb-8">
          <li className="flex gap-2">
            <span className="text-primary">✓</span>
            <span>Небольшой насморк без температуры и затруднения дыхания</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">✓</span>
            <span>Редкое чихание (это нормальный рефлекс очищения носа)</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">✓</span>
            <span>Срыгивания небольшим количеством после кормления</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">✓</span>
            <span>Небольшое беспокойство, если ребенок хорошо ест и спит</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">✓</span>
            <span>Легкая сыпь без температуры и зуда</span>
          </li>
        </ul>

        <div className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-2xl p-8 mb-8">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-white/80 rounded-xl flex items-center justify-center text-2xl flex-shrink-0">
              💡
            </div>
            <div>
              <h3 className="text-xl font-medium text-foreground mb-3">Полезный совет</h3>
              <p className="text-foreground/80 leading-relaxed">
                Ведите дневник симптомов: записывайте температуру, частоту кормлений, характер стула, поведение малыша. Это очень поможет врачу при постановке диагноза и отслеживании динамики.
              </p>
            </div>
          </div>
        </div>

        <h2 className="text-3xl font-medium text-foreground mt-12 mb-6">Когда звонить педиатру</h2>

        <p className="text-foreground/80 leading-relaxed mb-6">
          Есть ситуации, когда нужна консультация врача, но не срочная помощь. Позвоните своему педиатру в рабочее время, если:
        </p>

        <ul className="space-y-3 text-foreground/80 mb-8">
          <li className="flex gap-2">
            <span className="text-primary">→</span>
            <span>Температура 37.5-38°C держится более суток</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">→</span>
            <span>Диарея или запор более 2-3 дней</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">→</span>
            <span>Постоянный плач более 3 часов подряд</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">→</span>
            <span>Отказ от еды более 8 часов</span>
          </li>
          <li className="flex gap-2">
            <span className="text-primary">→</span>
            <span>Сыпь распространяется или появляется температура</span>
          </li>
        </ul>

        <h2 className="text-3xl font-medium text-foreground mt-12 mb-6">Доверяйте себе</h2>

        <p className="text-foreground/80 leading-relaxed mb-6">
          Родительская интуиция — мощный инструмент. Вы знаете своего ребенка лучше всех. Если вам кажется, что что-то не так, даже при отсутствии явных симптомов, лучше проконсультироваться с врачом.
        </p>

        <div className="bg-gradient-to-br from-accent/20 to-pink-200/20 border-2 border-accent/30 rounded-2xl p-8 text-center my-12">
          <div className="text-5xl mb-4">💜</div>
          <h3 className="text-2xl font-medium text-foreground mb-3">Вы справляетесь отлично!</h3>
          <p className="text-foreground/80 leading-relaxed max-w-xl mx-auto">
            Забота о малыше — это большая ответственность. Не бойтесь задавать вопросы врачу и доверяйте своим ощущениям. Каждый родитель учится, и это нормально.
          </p>
        </div>

        <p className="text-foreground/80 leading-relaxed mb-8">
          Помните: лучше лишний раз обратиться к врачу и убедиться, что всё в порядке, чем переживать в одиночку. Ваш педиатр всегда готов помочь и ответить на вопросы.
        </p>
      </motion.div>

      {/* Related Articles */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-16 pt-8 border-t border-border"
      >
        <h3 className="text-2xl font-medium text-foreground mb-6">Похожие статьи</h3>
        <div className="grid md:grid-cols-3 gap-4">
          {relatedArticles.map((related, idx) => (
            <motion.button
              key={idx}
              whileHover={{ y: -4 }}
              className="bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-all text-left"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center text-2xl mb-3">
                {related.emoji}
              </div>
              <div className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full inline-block mb-2">
                {related.category}
              </div>
              <h4 className="text-sm font-medium text-foreground">{related.title}</h4>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-12 bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-3xl p-8 text-center"
      >
        <h3 className="text-xl font-medium text-foreground mb-3">Была ли статья полезна?</h3>
        <div className="flex items-center justify-center gap-3">
          <Button className="rounded-2xl bg-primary hover:bg-primary/90">
            <Heart className="w-5 h-5 mr-2" />
            Да, помогло
          </Button>
          <Button variant="outline" className="rounded-2xl">
            Хочу узнать больше
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

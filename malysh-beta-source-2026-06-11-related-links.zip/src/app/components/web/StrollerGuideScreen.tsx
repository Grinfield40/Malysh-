import { motion } from "motion/react";
import { Check, X, Baby, Star, Filter, ChevronRight, Search } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";
import { Input } from "../ui/input";
import { StrollerDetailModal } from "./StrollerDetailModal";

// Быстрые карточки
const quickGuides = [
  { id: "newborn", title: "Для новорождённого", emoji: "👶", color: "from-blue-200/40 to-purple-200/40" },
  { id: "city", title: "На каждый день по городу", emoji: "🏙️", color: "from-purple-200/40 to-pink-200/40" },
  { id: "travel", title: "Для путешествий", emoji: "✈️", color: "from-pink-200/40 to-orange-200/40" },
  { id: "winter", title: "Для зимы", emoji: "❄️", color: "from-blue-300/40 to-cyan-200/40" },
  { id: "twins", title: "Для двойни / погодок", emoji: "👶👶", color: "from-green-200/40 to-yellow-200/40" },
  { id: "premium", title: "Премиум-сегмент", emoji: "✨", color: "from-purple-300/40 to-pink-300/40" },
];

// Детальные данные для quick guides
const quickGuidesDetails: Record<string, any> = {
  newborn: {
    id: "newborn",
    title: "Для новорождённого",
    emoji: "👶",
    recommendations: [
      "Выбирайте люльку или 3 в 1 с жёстким дном и хорошей вентиляцией",
      "Проверьте, чтобы спинка была полностью горизонтальной (180°)",
      "Убедитесь, что есть защита головы и боковые борта",
      "Козырёк должен защищать от солнца и ветра",
      "Желательна система амортизации для комфортного сна"
    ],
    bestModels: [
      { name: "Bugaboo Donkey", why: "Превосходная люлька с идеальной вентиляцией" },
      { name: "CYBEX Priam 3 в 1", why: "Премиум качество и максимальная безопасность" },
      { name: "Anex Cross 2 в 1", why: "Отличное соотношение цена/качество" }
    ]
  },
  city: {
    id: "city",
    title: "На каждый день по городу",
    emoji: "🏙️",
    recommendations: [
      "Вес коляски не должен превышать 12 кг для удобства",
      "Ширина шасси до 60 см, чтобы проходить в лифты и двери",
      "Маневренные поворотные передние колёса",
      "Компактное складывание для хранения дома",
      "Хорошая амортизация для городских тротуаров"
    ],
    bestModels: [
      { name: "CYBEX Libelle", why: "Всего 6 кг и очень компактная" },
      { name: "Jovola Pepper", why: "Легко маневрирует и недорогая" },
      { name: "Anex Cross", why: "Идеальная ширина 56 см" }
    ]
  },
  travel: {
    id: "travel",
    title: "Для путешествий",
    emoji: "✈️",
    recommendations: [
      "Максимально лёгкий вес - до 7 кг",
      "Складывание одной рукой и компактные размеры",
      "Возможность брать в ручную кладь самолёта",
      "Прочная конструкция для частых перевозок",
      "Быстрая трансформация для общественного транспорта"
    ],
    bestModels: [
      { name: "CYBEX Libelle", why: "Лучшая travel-коляска на рынке" },
      { name: "Babyzen YOYO", why: "Помещается в ручную кладь" },
      { name: "GB Pockit", why: "Самая компактная в мире" }
    ]
  },
  winter: {
    id: "winter",
    title: "Для зимы",
    emoji: "❄️",
    recommendations: [
      "Большие надувные колёса диаметром от 30 см",
      "Усиленная амортизация для снега и льда",
      "Высокая проходимость шасси",
      "Утеплённый чехол и защита от ветра",
      "Хорошие тормоза для скользких поверхностей"
    ],
    bestModels: [
      { name: "Tutis Zippy", why: "Отличная проходимость по снегу" },
      { name: "Noordi Polaris", why: "Большие колёса и утеплённая люлька" },
      { name: "Verdi Mirage", why: "Усиленное шасси для зимы" }
    ]
  },
  twins: {
    id: "twins",
    title: "Для двойни / погодок",
    emoji: "👶👶",
    recommendations: [
      "Выбирайте между параллельным и тандемным расположением",
      "Параллельные шире, но дети видят друг друга",
      "Тандемные проще проходят в двери (60-65 см)",
      "Проверьте возможность раздельного управления сиденьями",
      "Учитывайте вес - коляски для двойни тяжелее"
    ],
    bestModels: [
      { name: "Bugaboo Donkey Twin", why: "Трансформируется из одинарной в двойную" },
      { name: "Baby Jogger City Mini GT2 Double", why: "Параллельная, но узкая (71 см)" },
      { name: "Joie Evalite Duo", why: "Бюджетная и лёгкая для двойни" }
    ]
  },
  premium: {
    id: "premium",
    title: "Премиум-сегмент",
    emoji: "✨",
    recommendations: [
      "Премиальные материалы: кожа, эко-текстиль, алюминий",
      "Максимальная функциональность и удобство",
      "Известные бренды: CYBEX, Bugaboo, Stokke, Silver Cross",
      "Долговечность и высокое качество сборки",
      "Стильный дизайн и эксклюзивные расцветки"
    ],
    bestModels: [
      { name: "CYBEX Priam", why: "Эталон премиум качества" },
      { name: "Bugaboo Fox", why: "Легендарный голландский бренд" },
      { name: "Stokke Xplory", why: "Уникальная высокая посадка" }
    ]
  }
};

// Подборки
const collections = [
  { id: "budget", title: "Топ бюджетных", subtitle: "От 10 000 ₽", icon: "💰", count: 8 },
  { id: "value", title: "Топ выгодных", subtitle: "Лучшее за свои деньги", icon: "🎯", count: 12 },
  { id: "premium", title: "Топ премиум", subtitle: "Люксовые модели", icon: "👑", count: 6 },
  { id: "light", title: "Топ лёгких", subtitle: "До 7 кг", icon: "🪶", count: 10 },
  { id: "winter", title: "Топ для плохих дорог", subtitle: "Большие колёса", icon: "🛞", count: 8 },
  { id: "compact", title: "Топ для маленького багажника", subtitle: "Компактные", icon: "📦", count: 7 },
];

// Детальные данные для подборок
const collectionsDetails: Record<string, any> = {
  budget: {
    id: "budget",
    title: "Топ бюджетных",
    subtitle: "От 10 000 ₽",
    icon: "💰",
    models: [
      { name: "Rant Kira", price: "10 990 ₽", highlight: "Самая доступная 3 в 1" },
      { name: "Adamex Vicco", price: "12 500 ₽", highlight: "Хорошее качество за свои деньги" },
      { name: "Riko Brano", price: "14 900 ₽", highlight: "Польское качество" },
      { name: "Tutis Mimi", price: "16 900 ₽", highlight: "Лёгкая и манёвренная" },
      { name: "Anex Sport", price: "18 500 ₽", highlight: "Отличная амортизация" },
      { name: "Camarelo Sirion", price: "19 900 ₽", highlight: "Большие колёса" },
      { name: "Noordi Sun", price: "20 500 ₽", highlight: "Стильный дизайн" },
      { name: "Verdi Mirage", price: "22 900 ₽", highlight: "Надёжное шасси" }
    ]
  },
  value: {
    id: "value",
    title: "Топ выгодных",
    subtitle: "Лучшее за свои деньги",
    icon: "🎯",
    models: [
      { name: "Jovola Pepper", price: "25 000 ₽", highlight: "Идеальное соотношение цена/качество" },
      { name: "Anex Cross", price: "42 990 ₽", highlight: "Премиум качество по доступной цене" },
      { name: "Tutis Zippy", price: "24 990 ₽", highlight: "Отлично для зимы" },
      { name: "Riko Swift", price: "28 500 ₽", highlight: "Очень лёгкая для 3 в 1" },
      { name: "Adamex Reggio", price: "32 900 ₽", highlight: "Большая корзина" },
      { name: "Camarelo Lux", price: "29 900 ₽", highlight: "Эко-кожа в комплекте" },
      { name: "Noordi Polaris", price: "35 500 ₽", highlight: "Надувные колёса" },
      { name: "Verdi Pepe", price: "27 900 ₽", highlight: "Компактное складывание" },
      { name: "Baby Design Bueno", price: "31 500 ₽", highlight: "Стильный дизайн" },
      { name: "Roan Bass", price: "26 900 ₽", highlight: "Проверенное качество" },
      { name: "Tutis Uno", price: "29 500 ₽", highlight: "Много расцветок" },
      { name: "Anex Sport Q1", price: "38 900 ₽", highlight: "Спортивный дизайн" }
    ]
  },
  premium: {
    id: "premium",
    title: "Топ премиум",
    subtitle: "Люксовые модели",
    icon: "👑",
    models: [
      { name: "CYBEX Priam", price: "156 990 ₽", highlight: "Эталон премиум класса" },
      { name: "Bugaboo Fox 5", price: "128 990 ₽", highlight: "Легендарное качество" },
      { name: "Stokke Xplory X", price: "145 000 ₽", highlight: "Уникальная высокая посадка" },
      { name: "Silver Cross Wave", price: "132 500 ₽", highlight: "Британская роскошь" },
      { name: "Bugaboo Donkey", price: "89 990 ₽", highlight: "Трансформируется для двойни" },
      { name: "Joolz Day+", price: "98 900 ₽", highlight: "Голландский дизайн" }
    ]
  },
  light: {
    id: "light",
    title: "Топ лёгких",
    subtitle: "До 7 кг",
    icon: "🪶",
    models: [
      { name: "CYBEX Libelle", price: "24 990 ₽", highlight: "Всего 6 кг!" },
      { name: "Babyzen YOYO2", price: "54 900 ₽", highlight: "6.2 кг, в ручную кладь" },
      { name: "GB Pockit+", price: "32 500 ₽", highlight: "Самая компактная в мире" },
      { name: "Nuna TRVL", price: "42 900 ₽", highlight: "6.7 кг, премиум качество" },
      { name: "Joie Pact", price: "18 900 ₽", highlight: "5.9 кг, очень доступная" },
      { name: "Recaro Easylife", price: "29 500 ₽", highlight: "6.1 кг, немецкое качество" },
      { name: "Chicco Lite Way", price: "16 900 ₽", highlight: "6.5 кг, бюджетная" },
      { name: "Maclaren Quest", price: "35 900 ₽", highlight: "5.8 кг, классика жанра" },
      { name: "Silver Cross Jet", price: "38 500 ₽", highlight: "6.2 кг, премиум travel" },
      { name: "Bugaboo Butterfly", price: "46 900 ₽", highlight: "7 кг, складывание одной рукой" }
    ]
  },
  winter: {
    id: "winter",
    title: "Топ для плохих дорог",
    subtitle: "Большие колёса",
    icon: "🛞",
    models: [
      { name: "Tutis Zippy", price: "24 990 ₽", highlight: "Большие надувные колёса" },
      { name: "Noordi Polaris", price: "35 500 ₽", highlight: "Проходимость как у внедорожника" },
      { name: "Verdi Mirage", price: "22 900 ₽", highlight: "Усиленное шасси" },
      { name: "Anex Sport", price: "38 900 ₽", highlight: "Спортивная подвеска" },
      { name: "Camarelo Lux", price: "29 900 ₽", highlight: "Большие гелевые колёса" },
      { name: "Roan Bass", price: "26 900 ₽", highlight: "Отлично для зимы" },
      { name: "Adamex Reggio", price: "32 900 ₽", highlight: "Высокая проходимость" },
      { name: "Tutis Uno", price: "29 500 ₽", highlight: "Надувные колёса 30 см" }
    ]
  },
  compact: {
    id: "compact",
    title: "Топ для маленького багажника",
    subtitle: "Компактные",
    icon: "📦",
    models: [
      { name: "GB Pockit+", price: "32 500 ₽", highlight: "Самая компактная в мире" },
      { name: "CYBEX Libelle", price: "24 990 ₽", highlight: "Компактное складывание" },
      { name: "Babyzen YOYO2", price: "54 900 ₽", highlight: "Помещается в ручную кладь" },
      { name: "Joie Pact", price: "18 900 ₽", highlight: "Очень маленькая в сложенном виде" },
      { name: "Recaro Easylife", price: "29 500 ₽", highlight: "Компактная и лёгкая" },
      { name: "Silver Cross Jet", price: "38 500 ₽", highlight: "Складывается до размера сумки" },
      { name: "Bugaboo Butterfly", price: "46 900 ₽", highlight: "Компактная премиум" }
    ]
  }
};

// Образовательные блоки
const eduBlocks = [
  {
    title: "Чем отличается люлька от 2 в 1",
    content: "Люлька — только для сна первые 6 месяцев. 2 в 1 — люлька + прогулочный блок на одном шасси до 3-4 лет.",
  },
  {
    title: "Когда нужна 3 в 1",
    content: "Если у вас есть машина. 3 в 1 = люлька + прогулка + автокресло. Сразу готовый комплект.",
  },
  {
    title: "Когда прогулочная подходит с рождения",
    content: "Если спинка раскладывается до 180°, есть защита головы и жёсткое дно. Проверяйте маркировку 'с рождения'.",
  },
  {
    title: "Почему вес важнее бренда",
    content: "Тяжелую коляску (15+ кг) сложно поднимать в лифт, носить по ступенькам и грузить в машину каждый день.",
  },
];

// Детальные данные для образовательных блоков
const eduBlocksDetails = [
  {
    title: "Чем отличается люлька от 2 в 1",
    content: "Люлька — только для сна первые 6 месяцев. 2 в 1 — люлька + прогулочный блок на одном шасси до 3-4 лет.",
    diagram: "bassinet" as const,
    details: [
      "Люлька используется только первые 6 месяцев, пока ребёнок не сидит самостоятельно",
      "2 в 1 включает люльку для новорождённого и прогулочный блок для подросшего малыша",
      "Оба блока устанавливаются на одно шасси, не нужно покупать вторую коляску",
      "Люлька даёт жёсткую горизонтальную поверхность, необходимую для правильного формирования позвоночника",
      "Прогулочный блок позволяет регулировать наклон спинки и использовать коляску до 3-4 лет",
      "2 в 1 выгоднее, чем покупать люльку и прогулочную коляску отдельно"
    ]
  },
  {
    title: "Когда нужна 3 в 1",
    content: "Если у вас есть машина. 3 в 1 = люлька + прогулка + автокресло. Сразу готовый комплект.",
    diagram: "3in1" as const,
    details: [
      "3 в 1 идеальна для семей с автомобилем - не нужно покупать автокресло отдельно",
      "Автокресло группы 0+ подходит с рождения до 12-15 месяцев (до 13 кг)",
      "Все три модуля устанавливаются на одно шасси с помощью адаптеров",
      "Можно быстро переставить спящего ребёнка из машины в коляску без пробуждения",
      "Автокресло можно использовать как переноску и качалку дома",
      "Экономия 10-20 тысяч рублей по сравнению с покупкой автокресла отдельно"
    ]
  },
  {
    title: "Когда прогулочная подходит с рождения",
    content: "Если спинка раскладывается до 180°, есть защита головы и жёсткое дно. Проверяйте маркировку 'с рождения'.",
    diagram: "transformer" as const,
    details: [
      "Прогулочная коляска подходит с рождения, если спинка полностью раскладывается до 180°",
      "Должно быть жёсткое дно или вкладыш для новорождённых",
      "Обязательна защита головы и боковая поддержка для малыша",
      "Ищите маркировку '0+' или 'с рождения' от производителя",
      "Козырёк должен полностью защищать от солнца и ветра",
      "Такие коляски легче классических 2 в 1, но менее комфортны для новорождённого"
    ]
  },
  {
    title: "Почему вес важнее бренда",
    content: "Тяжелую коляску (15+ кг) сложно поднимать в лифт, носить по ступенькам и грузить в машину каждый день.",
    diagram: undefined,
    details: [
      "Коляску весом 15+ кг тяжело поднимать в лифт и носить по ступенькам ежедневно",
      "Оптимальный вес для городской коляски - 9-12 кг, для travel - до 7 кг",
      "Лёгкая коляска не значит хрупкая - современные материалы очень прочные",
      "При выборе учитывайте свою физическую форму и наличие лифта в доме",
      "Тяжёлые коляски обычно лучше для плохих дорог, но в городе это не критично",
      "Разница в 3-4 кг очень ощутима при ежедневном использовании"
    ]
  }
];

// Топ модели для каталога
const topModels = [
  {
    id: 1,
    name: "CYBEX Priam",
    type: "3 в 1",
    price: "156 990 ₽",
    image: "https://images.unsplash.com/photo-1583774195659-f2ba5c940d51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.9,
    reviews: 178,
    badges: ["Премиум", "С рождения", "Для зимы"],
    weight: "9.8 кг",
    age: "С рождения до 22 кг",
    width: "50 см",
    verdict: "Премиум и очень надёжная",
  },
  {
    id: 2,
    name: "Jovola Pepper",
    type: "3 в 1",
    price: "25 000 ₽",
    image: "https://images.unsplash.com/photo-1544963280-37ead66d259a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.7,
    reviews: 289,
    badges: ["Выгодно", "С рождения"],
    weight: "12 кг",
    age: "С рождения до 3 лет",
    width: "58 см",
    verdict: "Сильный вариант по цене/качеству",
  },
  {
    id: 3,
    name: "Bugaboo Donkey",
    type: "Люлька",
    price: "89 990 ₽",
    image: "https://images.unsplash.com/photo-1636384919179-d936e55c5cca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.9,
    reviews: 342,
    badges: ["С рождения", "Для двойни"],
    weight: "14 кг",
    age: "С рождения до 6 месяцев",
    width: "60 см",
    verdict: "Лучшая для новорождённых",
  },
  {
    id: 4,
    name: "CYBEX Libelle",
    type: "Travel",
    price: "24 990 ₽",
    image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.6,
    reviews: 456,
    badges: ["Лёгкая", "Travel", "В маленький лифт"],
    weight: "6 кг",
    age: "С 6 месяцев до 22 кг",
    width: "52 см",
    verdict: "Идеальна для путешествий",
  },
  {
    id: 5,
    name: "Tutis Zippy",
    type: "Трансформер",
    price: "24 990 ₽",
    image: "https://images.unsplash.com/photo-1587393855524-087f8e04c1b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.5,
    reviews: 523,
    badges: ["Для зимы", "Для плохих дорог"],
    weight: "16 кг",
    age: "С рождения до 3 лет",
    width: "60 см",
    verdict: "Хороша для зимы, но тяжеловата",
  },
  {
    id: 6,
    name: "Anex Cross",
    type: "2 в 1",
    price: "42 990 ₽",
    image: "https://images.unsplash.com/photo-1519689373023-dd07c7988603?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800",
    rating: 4.8,
    reviews: 234,
    badges: ["Выгодно", "С рождения"],
    weight: "11 кг",
    age: "С рождения до 3 лет",
    width: "56 см",
    verdict: "Отличное соотношение цена/качество",
  },
];

// Детальные данные для моделей
const topModelsDetails: Record<number, any> = {
  1: {
    ...topModels[0],
    description: "CYBEX Priam — это флагман немецкого бренда, воплощение премиум качества и инноваций. Идеальна для требовательных родителей.",
    diagram: "3in1" as const,
    pros: [
      "Непревзойдённое качество материалов и сборки",
      "Инновационная система амортизации",
      "Роскошные ткани и кожаные детали",
      "Плавный ход и отличная управляемость",
      "Большая комплектация 3 в 1"
    ],
    cons: [
      "Очень высокая цена",
      "Тяжеловата для ежедневного подъёма",
      "Требует бережного ухода"
    ],
    specs: [
      { label: "Вес шасси", value: "9.8 кг" },
      { label: "Вес с люлькой", value: "14.2 кг" },
      { label: "Ширина", value: "50 см" },
      { label: "Диаметр колёс", value: "28 см" },
      { label: "Размер люльки", value: "78x35 см" },
      { label: "Складывание", value: "Книжкой с колёсами" }
    ]
  },
  2: {
    ...topModels[1],
    description: "Jovola Pepper — отличный выбор для практичных родителей. Сочетает достойное качество и доступную цену.",
    diagram: "3in1" as const,
    pros: [
      "Отличное соотношение цена/качество",
      "Большая комплектация",
      "Хорошая проходимость",
      "Просторная люлька",
      "Много положительных отзывов"
    ],
    cons: [
      "Тяжеловата (12 кг)",
      "Не самые премиальные материалы",
      "Широковата для узких лифтов"
    ],
    specs: [
      { label: "Вес", value: "12 кг" },
      { label: "Ширина", value: "58 см" },
      { label: "Диаметр колёс", value: "26 см" },
      { label: "Размер люльки", value: "75x32 см" },
      { label: "Макс. вес ребёнка", value: "22 кг" },
      { label: "Складывание", value: "Книжкой" }
    ]
  },
  3: {
    ...topModels[2],
    description: "Bugaboo Donkey — легендарная голландская коляска, которая трансформируется из одинарной в двойную. Лучший выбор для новорождённых.",
    diagram: "bassinet" as const,
    pros: [
      "Превосходная люлька для новорождённого",
      "Трансформируется для двойни",
      "Отличная амортизация",
      "Премиум материалы",
      "Большая боковая корзина"
    ],
    cons: [
      "Высокая цена",
      "Тяжёлая (14 кг)",
      "Широкая (60 см)"
    ],
    specs: [
      { label: "Вес", value: "14 кг" },
      { label: "Ширина", value: "60 см" },
      { label: "Диаметр колёс", value: "30 см" },
      { label: "Размер люльки", value: "82x37 см" },
      { label: "Возраст", value: "0-6 месяцев" },
      { label: "Трансформация", value: "В двойную коляску" }
    ]
  },
  4: {
    ...topModels[3],
    description: "CYBEX Libelle — компактная и лёгкая travel-коляска от премиум бренда. Идеальна для путешествий и городских прогулок.",
    diagram: "transformer" as const,
    pros: [
      "Очень лёгкая (всего 6 кг)",
      "Компактное складывание одной рукой",
      "Качество CYBEX",
      "Удобная для транспорта",
      "Хорошая цена для бренда"
    ],
    cons: [
      "Только с 6 месяцев",
      "Маленькие колёса",
      "Не для плохих дорог"
    ],
    specs: [
      { label: "Вес", value: "6 кг" },
      { label: "Ширина", value: "52 см" },
      { label: "Диаметр колёс", value: "14 см" },
      { label: "Возраст", value: "6 мес - 4 года" },
      { label: "Макс. вес", value: "22 кг" },
      { label: "Складывание", value: "Одной рукой" }
    ]
  },
  5: {
    ...topModels[4],
    description: "Tutis Zippy — польская коляска-трансформер с большими колёсами. Отлично подходит для зимы и плохих дорог.",
    diagram: "transformer" as const,
    pros: [
      "Отличная проходимость",
      "Большие надувные колёса",
      "Хорошая цена",
      "Трансформируется из люльки в прогулку",
      "Тёплый чехол в комплекте"
    ],
    cons: [
      "Тяжёлая (16 кг)",
      "Широкая (60 см)",
      "Сложно поднимать в лифт"
    ],
    specs: [
      { label: "Вес", value: "16 кг" },
      { label: "Ширина", value: "60 см" },
      { label: "Диаметр колёс", value: "30 см" },
      { label: "Возраст", value: "0-3 года" },
      { label: "Тип колёс", value: "Надувные" },
      { label: "Складывание", value: "Не складывается" }
    ]
  },
  6: {
    ...topModels[5],
    description: "Anex Cross — современная модульная коляска 2 в 1 с отличным балансом характеристик. Один из лучших вариантов в среднем ценовом сегменте.",
    diagram: "bassinet" as const,
    pros: [
      "Отличное соотношение цена/качество",
      "Оптимальный вес (11 кг)",
      "Идеальная ширина (56 см)",
      "Качественные материалы",
      "Хорошая амортизация"
    ],
    cons: [
      "Средние колёса (не для совсем плохих дорог)",
      "Не самый компактный в сложенном виде",
      "Менее известный бренд"
    ],
    specs: [
      { label: "Вес", value: "11 кг" },
      { label: "Ширина", value: "56 см" },
      { label: "Диаметр колёс", value: "24 см" },
      { label: "Размер люльки", value: "76x33 см" },
      { label: "Возраст", value: "0-3 года" },
      { label: "Складывание", value: "Книжкой" }
    ]
  }
};

export function StrollerGuideScreen() {
  const [activeTab, setActiveTab] = useState<"catalog" | "compare">("catalog");
  const [searchQuery, setSearchQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"quickGuide" | "education" | "collection" | "product">("quickGuide");
  const [modalData, setModalData] = useState<any>(null);
  const normalizedSearch = searchQuery.trim().toLowerCase();
  const filteredTopModels = topModels.filter((model) => {
    if (!normalizedSearch) return true;

    return `${model.name} ${model.type} ${model.verdict} ${model.badges.join(" ")}`
      .toLowerCase()
      .includes(normalizedSearch);
  });

  const openModal = (type: "quickGuide" | "education" | "collection" | "product", data: any) => {
    setModalType(type);
    setModalData(data);
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      {/* Hero Block */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12 md:mb-16"
      >
        <h1 className="text-3xl md:text-5xl font-medium text-foreground mb-4 md:mb-6">
          Поможем выбрать коляску без хаоса
        </h1>
        <p className="text-base md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
          Объясним типы, сравним модели и покажем выгодные предложения
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            type="button"
            onClick={() => openModal("quickGuide", quickGuidesDetails[quickGuides[0].id])}
            className="rounded-2xl bg-primary hover:bg-primary/90 h-12 px-8 text-base"
          >
            <Baby className="w-5 h-5 mr-2" />
            Подобрать коляску
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => document.getElementById("stroller-catalog")?.scrollIntoView({ behavior: "smooth", block: "start" })}
            className="rounded-2xl h-12 px-8 text-base"
          >
            <Star className="w-5 h-5 mr-2" />
            Смотреть топы
          </Button>
        </div>
      </motion.div>

      {/* Quick Guide Cards */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-12 md:mb-16"
      >
        <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-6">
          Быстрый гид
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
          {quickGuides.map((guide, idx) => (
            <motion.button
              key={guide.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 + idx * 0.05 }}
              whileHover={{ y: -4 }}
              onClick={() => openModal("quickGuide", quickGuidesDetails[guide.id])}
              className={`bg-gradient-to-br ${guide.color} backdrop-blur-sm border border-primary/20 rounded-2xl p-4 md:p-6 hover:shadow-xl transition-all`}
            >
              <div className="text-4xl md:text-5xl mb-3">{guide.emoji}</div>
              <div className="text-xs md:text-sm font-medium text-foreground text-center leading-tight">
                {guide.title}
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Educational Module */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-12 md:mb-16"
      >
        <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-6">
          Как выбрать коляску
        </h2>
        <div className="grid md:grid-cols-2 gap-4 md:gap-6">
          {eduBlocks.map((block, idx) => (
            <motion.button
              key={idx}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + idx * 0.1 }}
              onClick={() => openModal("education", eduBlocksDetails[idx])}
              className="bg-gradient-to-br from-primary/5 to-accent/5 border-2 border-primary/10 rounded-2xl p-5 md:p-6 hover:border-primary/30 transition-all text-left"
            >
              <h3 className="text-base md:text-lg font-medium text-foreground mb-3">
                {block.title}
              </h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                {block.content}
              </p>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Collections */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mb-12 md:mb-16"
      >
        <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-6">
          Подборки
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {collections.map((collection, idx) => (
            <motion.button
              key={collection.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + idx * 0.05 }}
              whileHover={{ y: -6 }}
              onClick={() => openModal("collection", collectionsDetails[collection.id])}
              className="bg-card border-2 border-border rounded-2xl p-5 md:p-6 hover:border-primary/30 transition-all text-left group"
            >
              <div className="text-4xl mb-3">{collection.icon}</div>
              <h3 className="text-base md:text-lg font-medium text-foreground mb-1 group-hover:text-primary transition-colors">
                {collection.title}
              </h3>
              <p className="text-xs md:text-sm text-muted-foreground mb-3">
                {collection.subtitle}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {collection.count} моделей
                </span>
                <ChevronRight className="w-4 h-4 text-primary group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Catalog Section */}
      <motion.div
        id="stroller-catalog"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
          <h2 className="text-2xl md:text-3xl font-medium text-foreground">
            Каталог
          </h2>
          <div className="flex gap-2">
            <Button
              variant={activeTab === "catalog" ? "default" : "outline"}
              onClick={() => setActiveTab("catalog")}
              className="rounded-xl"
            >
              Все модели
            </Button>
            <Button
              variant={activeTab === "compare" ? "default" : "outline"}
              onClick={() => setActiveTab("compare")}
              className="rounded-xl"
            >
              Сравнить
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Поиск по моделям..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-12 pl-12 rounded-xl"
            />
          </div>
          <Button
            type="button"
            variant="outline"
            disabled={!searchQuery.trim()}
            onClick={() => setSearchQuery("")}
            className="rounded-xl h-12"
          >
            <Filter className="w-5 h-5 mr-2" />
            Сбросить
          </Button>
        </div>

        {/* Product Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {filteredTopModels.map((model, idx) => (
            <motion.div
              key={model.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + idx * 0.05 }}
              onClick={() => openModal("product", topModelsDetails[model.id])}
              className="bg-card border-2 border-border rounded-2xl overflow-hidden hover:border-primary/30 transition-all group cursor-pointer"
            >
              {/* Image */}
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={model.image}
                  alt={model.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 right-3 flex flex-col gap-2">
                  {model.badges.map((badge, i) => (
                    <span
                      key={i}
                      className="bg-primary/90 text-primary-foreground text-xs px-2 py-1 rounded-full backdrop-blur-sm"
                    >
                      {badge}
                    </span>
                  ))}
                </div>
              </div>

              {/* Content */}
              <div className="p-4 md:p-5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-base md:text-lg font-medium text-foreground group-hover:text-primary transition-colors">
                      {model.name}
                    </h3>
                    <p className="text-xs md:text-sm text-muted-foreground">
                      {model.type}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-primary text-primary" />
                    <span className="text-sm font-medium">{model.rating}</span>
                  </div>
                </div>

                {/* Key params */}
                <div className="grid grid-cols-2 gap-2 mb-4 text-xs md:text-sm">
                  <div>
                    <span className="text-muted-foreground">Вес: </span>
                    <span className="font-medium">{model.weight}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Ширина: </span>
                    <span className="font-medium">{model.width}</span>
                  </div>
                </div>

                {/* Verdict */}
                <div className="bg-primary/5 rounded-xl p-3 mb-4">
                  <p className="text-xs md:text-sm text-foreground">
                    💡 {model.verdict}
                  </p>
                </div>

                {/* Price and CTA */}
                <div className="flex items-center justify-between">
                  <div className="text-xl md:text-2xl font-medium text-foreground">
                    {model.price}
                  </div>
                  <Button
                    size="sm"
                    className="rounded-xl"
                    onClick={(e: React.MouseEvent) => {
                      e.stopPropagation();
                      openModal("product", topModelsDetails[model.id]);
                    }}
                  >
                    <Info className="w-4 h-4 mr-1" />
                    Смотреть
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        {filteredTopModels.length === 0 && (
          <div className="mt-4 rounded-2xl border-2 border-dashed border-border bg-secondary/30 p-8 text-center">
            <div className="mb-3 text-4xl">🔎</div>
            <h3 className="mb-2 text-lg font-medium text-foreground">Модели не найдены</h3>
            <p className="mb-4 text-sm text-muted-foreground">Попробуйте другое название или сбросьте поиск.</p>
            <Button type="button" onClick={() => setSearchQuery("")} className="rounded-xl">
              Сбросить поиск
            </Button>
          </div>
        )}
      </motion.div>

      {/* Modal */}
      <StrollerDetailModal
        isOpen={modalOpen}
        onClose={closeModal}
        type={modalType}
        data={modalData}
      />
    </div>
  );
}

# Подготовка Малыш+ к VPS

Это не перенос на сервер, а готовый контур, чтобы переезд позже был спокойным.

## Что уже готово

- Сервер читает настройки из `.env`.
- Сайт и API могут работать на одном Node-сервере.
- SQLite лежит в отдельном пути, который задается через `MALYSH_DB_FILE`.
- Backup делает `.db`-копию через `VACUUM INTO` и пишет `.json` manifest.
- При старте сервер сам создает недостающие таблицы и обновляет `schema_meta.schema_version`.
- Для VPS есть примеры `systemd`, `nginx` и `cron`.

## Локальная проверка production-режима

```powershell
cd C:\Users\aleks\Documents\Codex\2026-05-12\new-chat\design-from-code
Copy-Item .env.example .env
npm.cmd run build
npm.cmd run start:prod
```

Открыть:

```text
http://localhost:8787
```

Backup:

```powershell
npm.cmd run backup
```

## Будущий VPS-чеклист

1. Взять VPS с Ubuntu/Debian, 1-2 CPU, 1-2 GB RAM на старт достаточно.
2. Установить Node.js 22+ и nginx или Caddy.
3. Разместить проект, например в `/opt/malysh`.
4. Выполнить `npm ci`.
5. Скопировать `.env.production.example` в `.env`.
6. Заменить `example.com` на реальный домен.
7. Создать папки:

```bash
sudo mkdir -p /var/lib/malysh /var/backups/malysh
sudo chown -R malysh:malysh /var/lib/malysh /var/backups/malysh /opt/malysh
```

8. Собрать сайт:

```bash
npm run build
```

9. Запустить Node через `systemd`.
10. Подключить домен к IP VPS.
11. Настроить nginx reverse proxy.
12. Выпустить HTTPS-сертификат Let's Encrypt.
13. Добавить cron для backup.
14. Проверить открытую beta-регистрацию, вход, трекер, форум, метрики и админку на домене.

## Важные правила перед переносом базы

- Перед любым обновлением делать `npm run backup`.
- Не хранить production-базу внутри git.
- Не коммитить `.env`.
- Не открывать Node-порт `8787` наружу напрямую; наружу смотрит только nginx/Caddy на `80/443`.
- `MALYSH_HEALTH_DETAILS=false` на VPS, чтобы публичный `/api/health` не показывал путь к базе.
- Для тихой первой beta можно оставить `MALYSH_REGISTRATION_MODE=open`; если начнется мусорная регистрация, переключить на `closed` или `disabled`.

## Миграции

Сейчас миграции простые и idempotent: сервер при старте выполняет `CREATE TABLE IF NOT EXISTS` и обновляет версию схемы в `schema_meta`.

Перед более публичным запуском стоит выделить отдельный файл миграций с нумерацией:

```text
server/migrations/001_initial.sql
server/migrations/002_forum_reports.sql
```

На текущем этапе этого достаточно: база не теряется, новые таблицы создаются автоматически, backup есть.

## Домен и HTTPS

План:

```text
browser -> https://your-domain.ru -> nginx/Caddy -> http://127.0.0.1:8787 -> Node -> SQLite
```

Node остается закрытым на localhost. HTTPS, домен, лимиты запросов и сжатие берет на себя nginx/Caddy.

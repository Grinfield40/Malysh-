import { toast } from "sonner";
import { trackError } from "./analytics";

type NotifyOptions = {
  description?: string;
};

export function notifySuccess(message: string, options?: NotifyOptions) {
  toast.success(message, {
    description: options?.description,
  });
}

export function notifyInfo(message: string, options?: NotifyOptions) {
  toast(message, {
    description: options?.description,
  });
}

export function notifyError(error: unknown, fallback = "Не получилось выполнить действие.") {
  const message = error instanceof Error ? error.message : fallback;

  trackError(error, {
    source: "notify_error",
    meta: {
      fallback,
    },
  });
  toast.error(message);
}

export function notifyWarning(message: string, options?: NotifyOptions) {
  toast.warning(message, {
    description: options?.description,
  });
}


  # Design from Code

  This is a code bundle for Design from Code. The original project is available at https://www.figma.com/design/SMAZxURbTSfBNPEJjT4G5t/Design-from-Code.

  ## Running the code

  Run `npm.cmd install` to install the dependencies on Windows PowerShell.

  Run `npm.cmd run dev` to start the development server.

  Run `npm.cmd run build` to verify a production build.

  ## Beta package

  For the first local beta package, use [`BETA_PACKAGE.md`](./BETA_PACKAGE.md).

  It includes launch commands, demo credentials, backup/restore, and known MVP stubs.

  For VPS preparation and the first open beta test, use [`VPS_LAUNCH.md`](./VPS_LAUNCH.md)
  and [`CLOSED_BETA.md`](./CLOSED_BETA.md).

  For tester-facing rules, use [`BETA_PRIVACY.md`](./BETA_PRIVACY.md)
  and [`BETA_TERMS.md`](./BETA_TERMS.md). The same pages are available in the app at
  `/privacy` and `/terms`.

  If we decide to close registration later, use [`BETA_INVITES.md`](./BETA_INVITES.md).

  Before giving the build to testers, use [`BETA_LAUNCH_PACK.md`](./BETA_LAUNCH_PACK.md)
  or run `npm.cmd run beta:launch`.

  To run only the isolated closed-beta API smoke test, use [`BETA_SMOKE.md`](./BETA_SMOKE.md)
  or run `npm.cmd run beta:smoke`.

  ## MVP local state

  This local MVP keeps auth, profile notes, shopping checklist, tracker entries,
  reminders, routines, forum posts, and notification state in the browser's
  `localStorage`. Clear site data in the browser to reset the demo state.
  

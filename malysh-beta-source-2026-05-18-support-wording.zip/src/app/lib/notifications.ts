export interface NotificationItem {
  id: string;
  type: "system" | "reminder" | "checklist" | "forum" | "milestone" | "shopping";
  title: string;
  message: string;
  time: string;
  read: boolean;
  icon: string;
  targetScreen?: string;
}

export interface ReminderNotificationSource {
  id: number;
  title: string;
  date?: string;
  time?: string;
  notes?: string;
  emoji?: string;
}

export interface ChecklistNotificationSource {
  id: number;
  title: string;
  checked: boolean;
}

export const DEFAULT_NOTIFICATIONS: NotificationItem[] = [
  {
    id: "system-beta",
    type: "system",
    title: "Бета запущена",
    message: "Малыш+ уже сохраняет данные аккаунта, дневник, форум и заметки.",
    time: "сейчас",
    read: false,
    icon: "✨",
    targetScreen: "home",
  },
  {
    id: "system-reminders",
    type: "reminder",
    title: "Напоминания готовы",
    message: "Добавьте визит, прием лекарства или важную задачу, и она появится здесь.",
    time: "подсказка",
    read: true,
    icon: "🔔",
    targetScreen: "reminders",
  },
];

interface BuildNotificationInput {
  storedItems: NotificationItem[];
  reminders: ReminderNotificationSource[];
  checklist: ChecklistNotificationSource[];
  readIds: string[];
  hiddenIds: string[];
}

function formatReminderMessage(reminder: ReminderNotificationSource) {
  const parts = [reminder.date, reminder.time].filter(Boolean).join(" в ");
  return reminder.notes ? `${parts}: ${reminder.notes}` : parts || "Напоминание без времени";
}

function formatReminderTime(reminder: ReminderNotificationSource) {
  if (!reminder.date) return "без даты";

  const today = new Date();
  const date = new Date(`${reminder.date}T00:00:00`);

  if (Number.isNaN(date.getTime())) return reminder.date;

  const todayKey = today.toISOString().slice(0, 10);
  if (reminder.date === todayKey) return reminder.time ? `сегодня, ${reminder.time}` : "сегодня";

  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "short",
  }).format(date);
}

export function buildNotificationItems({
  storedItems,
  reminders,
  checklist,
  readIds,
  hiddenIds,
}: BuildNotificationInput) {
  const readSet = new Set(readIds);
  const hiddenSet = new Set(hiddenIds);

  const reminderItems = reminders
    .filter((reminder) => reminder.title?.trim())
    .slice()
    .sort((a, b) => `${a.date ?? ""} ${a.time ?? ""}`.localeCompare(`${b.date ?? ""} ${b.time ?? ""}`))
    .slice(0, 5)
    .map<NotificationItem>((reminder) => {
      const id = `reminder-${reminder.id}`;

      return {
        id,
        type: "reminder",
        title: reminder.title,
        message: formatReminderMessage(reminder),
        time: formatReminderTime(reminder),
        read: readSet.has(id),
        icon: reminder.emoji || "⏰",
        targetScreen: "reminders",
      };
    });

  const uncheckedChecklist = checklist.filter((item) => !item.checked);
  const checklistItems: NotificationItem[] =
    uncheckedChecklist.length > 0
      ? [
          {
            id: "checklist-today",
            type: "checklist",
            title: "Чек-лист на сегодня",
            message: `Осталось задач: ${uncheckedChecklist.length}`,
            time: "сегодня",
            read: readSet.has("checklist-today"),
            icon: "✅",
            targetScreen: "reminders",
          },
        ]
      : [];

  const baseItems = storedItems.map((item) => {
    const id = String(item.id);
    return {
      ...item,
      id,
      read: item.read || readSet.has(id),
    };
  });

  return [...reminderItems, ...checklistItems, ...baseItems].filter((item) => !hiddenSet.has(item.id));
}

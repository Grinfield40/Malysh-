import { motion } from "motion/react";
import { Check, Crown, X, Sparkles, Users, TrendingUp, Calendar, Bell, Star } from "lucide-react";
import { useState } from "react";

interface SubscriptionScreenProps {
  onClose?: () => void;
}

const premiumFeatures = [
  {
    icon: Sparkles,
    title: "Что важно именно сейчас",
    description: "Персональные подсказки по возрасту малыша",
    color: "from-primary to-primary/70",
  },
  {
    icon: TrendingUp,
    title: "Умный трекер и аналитика",
    description: "Графики, закономерности и история по дням",
    color: "from-accent to-accent/70",
  },
  {
    icon: Calendar,
    title: "Режим дня с подсказками",
    description: "Адаптивные рекомендации и окна бодрствования",
    color: "from-accent-soft to-accent-soft/70",
  },
  {
    icon: Users,
    title: "Семейный доступ",
    description: "Общий доступ для двух взрослых",
    color: "from-primary to-accent",
  },
];

const comparisonFeatures = [
  { feature: "Базовые советы и статьи", free: true, premium: true },
  { feature: "Простой режим дня", free: true, premium: true },
  { feature: "Базовый трекер", free: true, premium: true },
  { feature: "Ограниченные напоминания (до 3)", free: true, premium: false },
  { feature: "Персональные подборки по возрасту", free: false, premium: true },
  { feature: "Расширенный трекер с аналитикой", free: false, premium: true },
  { feature: "Умные напоминания без ограничений", free: false, premium: true },
  { feature: "Адаптивный режим дня", free: false, premium: true },
  { feature: "Семейный доступ", free: false, premium: true },
  { feature: "История и графики", free: false, premium: true },
  { feature: "Персональные коллекции", free: false, premium: true },
];

export function SubscriptionScreen({ onClose }: SubscriptionScreenProps) {
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("yearly");

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 p-4 md:p-8 pt-20 md:pt-28">
      <div className="max-w-6xl mx-auto">
        {/* Close Button */}
        {onClose && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={onClose}
            className="fixed top-24 right-8 w-10 h-10 rounded-full bg-card border border-border hover:bg-secondary transition-all flex items-center justify-center z-50"
          >
            <X className="w-5 h-5" />
          </motion.button>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-primary/20 to-accent/20 px-4 py-2 rounded-full mb-4">
            <Crown className="w-5 h-5 text-primary" />
            <span className="text-sm font-semibold text-primary">Премиум подписка</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-medium text-foreground mb-4">
            Экономьте время и снижайте хаос
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Персональные подсказки, умный режим дня, расширенный трекер и семейный доступ — в одном месте
          </p>
        </motion.div>

        {/* Premium Features */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12"
        >
          {premiumFeatures.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + idx * 0.1 }}
                className="bg-card border border-border rounded-2xl p-6 hover:border-primary/30 transition-all"
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-4`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Pricing Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="max-w-4xl mx-auto mb-12"
        >
          <div className="grid md:grid-cols-2 gap-6">
            {/* Monthly Plan */}
            <motion.div
              whileHover={{ y: -4 }}
              onClick={() => setSelectedPlan("monthly")}
              className={`bg-card border-2 rounded-3xl p-8 text-left transition-all cursor-pointer ${
                selectedPlan === "monthly"
                  ? "border-primary shadow-lg shadow-primary/20"
                  : "border-border hover:border-primary/30"
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-1">Месячная</h3>
                  <p className="text-sm text-muted-foreground">Гибкий вход</p>
                </div>
                {selectedPlan === "monthly" && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
              <div className="mb-6">
                <div className="rounded-2xl border border-border bg-secondary/50 p-5">
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-primary">
                    Beta-план
                  </div>
                  <div className="text-2xl font-semibold text-foreground">Цена появится позже</div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Платежи не подключены: сейчас можно спокойно пользоваться beta без оплаты.
                  </p>
                </div>
              </div>
              <div className="flex h-12 w-full items-center justify-center rounded-xl border border-primary/20 bg-primary/10 text-sm font-medium text-primary">
                Продажи откроются после beta
              </div>
            </motion.div>

            {/* Yearly Plan */}
            <motion.div
              whileHover={{ y: -4 }}
              onClick={() => setSelectedPlan("yearly")}
              className={`bg-gradient-to-br from-primary/10 to-accent/10 border-2 rounded-3xl p-8 text-left transition-all relative overflow-hidden cursor-pointer ${
                selectedPlan === "yearly"
                  ? "border-primary shadow-xl shadow-primary/30"
                  : "border-primary/20 hover:border-primary/40"
              }`}
            >
              <div className="absolute top-4 right-4 bg-accent text-accent-foreground px-3 py-1 rounded-full text-xs font-semibold">
                План
              </div>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-foreground mb-1">Годовая</h3>
                  <p className="text-sm text-muted-foreground">Лучшее предложение</p>
                </div>
                {selectedPlan === "yearly" && (
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>
              <div className="mb-2">
                <div className="rounded-2xl border border-primary/20 bg-white/70 p-5">
                  <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-primary">
                    Будущий тариф
                  </div>
                  <div className="text-2xl font-semibold text-foreground">Условия уточняются</div>
                  <p className="mt-2 text-sm text-muted-foreground">
                    Здесь позже появятся пробный период, цена и понятные правила подписки.
                  </p>
                </div>
              </div>
              <div className="flex h-12 w-full items-center justify-center rounded-xl bg-gradient-to-r from-primary/15 to-accent/15 text-sm font-medium text-primary">
                Пока без оформления и списаний
              </div>
            </motion.div>
          </div>

          <p className="text-center text-sm text-muted-foreground mt-6">
            Премиум-доступ пока не подключен. Экран показывает, какие возможности появятся позже.
          </p>
        </motion.div>

        {/* Comparison Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="max-w-4xl mx-auto"
        >
          <h2 className="text-2xl font-semibold text-foreground mb-6 text-center">
            Сравнение тарифов
          </h2>
          <div className="bg-card border border-border rounded-3xl overflow-hidden">
            {/* Table Header */}
            <div className="grid grid-cols-3 gap-4 p-6 bg-secondary/30 border-b border-border">
              <div className="text-sm font-semibold text-muted-foreground">Функция</div>
              <div className="text-sm font-semibold text-foreground text-center">Бесплатно</div>
              <div className="text-sm font-semibold text-primary text-center flex items-center justify-center gap-2">
                <Crown className="w-4 h-4" />
                Премиум
              </div>
            </div>

            {/* Table Body */}
            <div className="divide-y divide-border">
              {comparisonFeatures.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + idx * 0.05 }}
                  className="grid grid-cols-3 gap-4 p-6 hover:bg-secondary/20 transition-colors"
                >
                  <div className="text-sm text-foreground">{item.feature}</div>
                  <div className="flex justify-center">
                    {item.free ? (
                      <Check className="w-5 h-5 text-primary" />
                    ) : (
                      <X className="w-5 h-5 text-muted-foreground/30" />
                    )}
                  </div>
                  <div className="flex justify-center">
                    {item.premium ? (
                      <Check className="w-5 h-5 text-primary" />
                    ) : (
                      <X className="w-5 h-5 text-muted-foreground/30" />
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center"
        >
          <div className="flex items-center justify-center gap-8 flex-wrap text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-primary fill-primary" />
              <span>Сценарий подписки в разработке</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5 text-primary" />
              <span>Оплата не подключена</span>
            </div>
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              <span>Можно спокойно тестировать</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

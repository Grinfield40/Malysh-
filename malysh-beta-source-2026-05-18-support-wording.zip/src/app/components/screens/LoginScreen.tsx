import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { ChevronLeft } from "lucide-react";

interface LoginScreenProps {
  onLogin: () => void;
  onBack: () => void;
}

export function LoginScreen({ onLogin, onBack }: LoginScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="p-4">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="flex-1 px-6 flex flex-col">
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-foreground mb-2">Вход</h1>
          <p className="text-muted-foreground">Войдите в свой аккаунт</p>
        </div>

        <div className="space-y-5">
          <div className="space-y-2">
            <Label>Email</Label>
            <Input
              type="email"
              placeholder="example@email.com"
              className="h-12 rounded-xl bg-input-background border-0"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>Пароль</Label>
              <button className="text-sm text-primary">Забыли?</button>
            </div>
            <Input
              type="password"
              placeholder="Введите пароль"
              className="h-12 rounded-xl bg-input-background border-0"
            />
          </div>
        </div>

        <div className="mt-auto pb-8 space-y-4">
          <Button
            onClick={onLogin}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Войти
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-background px-4 text-muted-foreground">или войти через</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button variant="outline" className="flex-1 h-12 rounded-xl border-border">
              Google
            </Button>
            <Button variant="outline" className="flex-1 h-12 rounded-xl border-border">
              Apple
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { CheckCircle2, Send, Sparkles } from "lucide-react";
import { Button } from "../ui/button";
import { Textarea } from "../ui/textarea";
import { getStoredSession, submitBetaFeedback, type BetaFeedbackTopic } from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess } from "../../lib/notify";

const surveyFields = [
  {
    key: "useful",
    label: "Что удобно?",
    placeholder: "Например: быстро добавить кормление",
  },
  {
    key: "unclear",
    label: "Что непонятно?",
    placeholder: "Например: не сразу ясно, где профиль",
  },
  {
    key: "broken",
    label: "Что сломалось?",
    placeholder: "Например: кнопка не нажалась на телефоне",
  },
  {
    key: "missing",
    label: "Чего не хватает?",
    placeholder: "Например: быстрый список лекарств",
  },
] as const;

type SurveyKey = (typeof surveyFields)[number]["key"];
type SurveyAnswers = Record<SurveyKey, string>;

const emptyAnswers: SurveyAnswers = {
  useful: "",
  unclear: "",
  broken: "",
  missing: "",
};

function getSurveyTopic(answers: SurveyAnswers): BetaFeedbackTopic {
  if (answers.broken.trim()) return "bug";
  if (answers.missing.trim()) return "idea";
  return "feedback";
}

function buildSurveyMessage(answers: SurveyAnswers) {
  return [
    "Beta-опрос",
    `Что удобно: ${answers.useful.trim() || "-"}`,
    `Что непонятно: ${answers.unclear.trim() || "-"}`,
    `Что сломалось: ${answers.broken.trim() || "-"}`,
    `Чего не хватает: ${answers.missing.trim() || "-"}`,
  ].join("\n");
}

export function BetaSurveyCard({ screen = "survey" }: { screen?: string }) {
  const [answers, setAnswers] = useState<SurveyAnswers>(emptyAnswers);
  const [rating, setRating] = useState(0);
  const [isSending, setIsSending] = useState(false);
  const filledLength = Object.values(answers).join(" ").trim().length;

  const handleAnswerChange = (key: SurveyKey, value: string) => {
    setAnswers((current) => ({
      ...current,
      [key]: value,
    }));
  };

  const handleSubmit = async () => {
    const session = getStoredSession();

    if (!session) {
      notifyError(new Error("Нужно войти в аккаунт, чтобы отправить beta-опрос."));
      return;
    }

    if (filledLength < 4) {
      notifyError(new Error("Ответьте хотя бы на один вопрос несколькими словами."));
      return;
    }

    setIsSending(true);

    try {
      await submitBetaFeedback(session.token, {
        message: buildSurveyMessage(answers),
        rating: rating || null,
        screen,
        topic: getSurveyTopic(answers),
      });
      trackEvent("beta_survey_sent", {
        screen,
        meta: {
          rating: rating || null,
          hasBroken: Boolean(answers.broken.trim()),
          hasMissing: Boolean(answers.missing.trim()),
        },
      });
      notifySuccess("Опрос отправлен", {
        description: "Спасибо, ответ попадет администратору.",
      });
      setAnswers(emptyAnswers);
      setRating(0);
    } catch (error) {
      notifyError(error, "Не получилось отправить опрос");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6">
      <div className="mb-4 flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Sparkles className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <h3 className="text-sm md:text-base font-medium text-foreground">Beta-опросник</h3>
          <p className="text-xs md:text-sm text-muted-foreground">
            Помогите понять, что оставить, исправить и добавить перед тестерами.
          </p>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-2">
        {[1, 2, 3, 4, 5].map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => setRating(value)}
            className={`h-8 min-w-8 rounded-lg border px-2 text-xs font-medium transition-colors ${
              rating === value
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-background text-muted-foreground hover:border-primary/40"
            }`}
            aria-label={`Оценка beta ${value}`}
          >
            {value}
          </button>
        ))}
        <span className="flex items-center text-xs text-muted-foreground">общая оценка, если удобно</span>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {surveyFields.map((field) => (
          <label key={field.key} className="block">
            <span className="mb-1.5 block text-xs font-medium text-foreground">{field.label}</span>
            <Textarea
              value={answers[field.key]}
              onChange={(event) => handleAnswerChange(field.key, event.target.value)}
              maxLength={500}
              placeholder={field.placeholder}
              className="min-h-[74px] resize-none rounded-xl text-sm"
            />
          </label>
        ))}
      </div>

      <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          Ответ увиден в разделе “Обращения”.
        </div>
        <Button
          type="button"
          onClick={() => void handleSubmit()}
          disabled={isSending || filledLength < 4}
          className="h-10 rounded-xl"
        >
          <Send className="h-4 w-4" />
          {isSending ? "Отправляем..." : "Отправить"}
        </Button>
      </div>
    </div>
  );
}

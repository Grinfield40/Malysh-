import { Button } from "../ui/button";
import { ChevronLeft } from "lucide-react";
import { useState } from "react";

interface OnboardingStageScreenProps {
  onNext: () => void;
  onBack: () => void;
}

const stages = [
  { id: "preparing", label: "Готовимся к рождению", icon: "🤰" },
  { id: "0-3", label: "Ребенок 0–3 месяца", icon: "👶" },
  { id: "3-6", label: "Ребенок 3–6 месяцев", icon: "🍼" },
  { id: "6-12", label: "Ребенок 6–12 месяцев", icon: "🧸" },
];

export function OnboardingStageScreen({ onNext, onBack }: OnboardingStageScreenProps) {
  const [selectedStage, setSelectedStage] = useState<string>("");

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="p-4">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="flex-1 px-6 flex flex-col">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-1 flex-1 bg-primary rounded-full"></div>
            <div className="h-1 flex-1 bg-muted rounded-full"></div>
          </div>
          <h1 className="text-3xl font-medium text-foreground mb-2">Ваша ситуация</h1>
          <p className="text-muted-foreground">Выберите текущий этап</p>
        </div>

        <div className="space-y-3">
          {stages.map((stage) => (
            <button
              key={stage.id}
              onClick={() => setSelectedStage(stage.id)}
              className={`w-full rounded-2xl border-2 transition-all p-5 flex items-center gap-4 ${
                selectedStage === stage.id
                  ? "border-primary bg-primary/5"
                  : "border-border bg-card"
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                {stage.icon}
              </div>
              <span className="text-base font-medium text-foreground">{stage.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-auto py-8">
          <Button
            onClick={onNext}
            disabled={!selectedStage}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            Продолжить
          </Button>
        </div>
      </div>
    </div>
  );
}

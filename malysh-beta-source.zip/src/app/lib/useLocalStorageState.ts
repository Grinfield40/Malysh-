import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { queueAccountStorageSync } from "./accountApi";

export function useLocalStorageState<T>(
  key: string,
  initialValue: T
): readonly [T, Dispatch<SetStateAction<T>>] {
  const [state, setState] = useState<T>(() => {
    try {
      const storedValue = window.localStorage.getItem(key);
      return storedValue ? (JSON.parse(storedValue) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(key, JSON.stringify(state));
      queueAccountStorageSync(key, state);
    } catch {
      // Local persistence should never break the core UI.
    }
  }, [key, state]);

  return [state, setState] as const;
}

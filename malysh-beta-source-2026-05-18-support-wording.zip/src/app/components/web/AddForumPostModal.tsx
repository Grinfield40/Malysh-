import { motion, AnimatePresence } from "motion/react";
import { X, Baby, Milk, Moon, ShoppingBag, Stethoscope, MessageCircle, CalendarClock } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface AddForumPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (post: ForumPost) => void | Promise<void>;
}

export interface ForumPost {
  category: string;
  title: string;
  content: string;
  tags: string[];
}

const categories = [
  { id: "health", label: "Здоровье", icon: Stethoscope, color: "from-red-200/40 to-pink-200/40" },
  { id: "feeding", label: "Кормление", icon: Milk, color: "from-blue-200/40 to-cyan-200/40" },
  { id: "sleep", label: "Сон", icon: Moon, color: "from-purple-200/40 to-indigo-200/40" },
  { id: "development", label: "Развитие", icon: Baby, color: "from-green-200/40 to-emerald-200/40" },
  { id: "routine", label: "Режим", icon: CalendarClock, color: "from-teal-200/40 to-sky-200/40" },
  { id: "shopping", label: "Покупки", icon: ShoppingBag, color: "from-yellow-200/40 to-orange-200/40" },
  { id: "other", label: "Общее", icon: MessageCircle, color: "from-pink-200/40 to-purple-200/40" },
];

const popularTags = [
  "новорожденный",
  "грудное вскармливание",
  "прикорм",
  "колики",
  "сон",
  "зубы",
  "прививки",
  "развитие",
  "игрушки",
  "коляски",
  "детская комната",
  "режим дня",
];

const maxTitleLength = 160;
const maxContentLength = 4000;
const maxTagLength = 32;
const maxTags = 8;

export function AddForumPostModal({ isOpen, onClose, onAdd }: AddForumPostModalProps) {
  const [selectedCategory, setSelectedCategory] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [customTag, setCustomTag] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const trimmedTitle = title.trim();
  const trimmedContent = content.trim();
  const validationMessage = !selectedCategory
    ? "Выберите категорию обсуждения."
    : trimmedTitle.length < 6
    ? "Заголовок должен быть хотя бы 5 символов."
    : trimmedContent.length < 20
    ? "Описание должно быть хотя бы 20 символов."
    : "";
  const shouldShowValidation = Boolean(validationMessage && (selectedCategory || title || content));

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag].slice(0, maxTags));
    }
  };

  const addCustomTag = () => {
    const tag = customTag.trim();

    if (tag && !selectedTags.includes(tag) && selectedTags.length < maxTags) {
      setSelectedTags([...selectedTags, tag.slice(0, maxTagLength)]);
      setCustomTag("");
    }
  };

  const handleSubmit = async () => {
    if (validationMessage) return;

    setIsSubmitting(true);

    try {
      await onAdd({
        category: selectedCategory,
        title: trimmedTitle,
        content: trimmedContent,
        tags: selectedTags,
      });

      onClose();
      resetForm();
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setSelectedCategory("");
    setTitle("");
    setContent("");
    setSelectedTags([]);
    setCustomTag("");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-3xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <h2 className="text-2xl font-medium text-foreground">Создать обсуждение</h2>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Категория</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {categories.map((category) => {
                    const Icon = category.icon;
                    return (
                      <button
                        key={category.id}
                        onClick={() => setSelectedCategory(category.id)}
                        className={`bg-gradient-to-br ${category.color} border-2 rounded-xl p-4 transition-all ${
                          selectedCategory === category.id
                            ? "border-primary shadow-lg"
                            : "border-white/50 hover:border-primary/30"
                        }`}
                      >
                        <Icon className="w-6 h-6 text-primary mx-auto mb-2" />
                        <div className="text-sm font-medium text-foreground">{category.label}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Заголовок</label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  maxLength={maxTitleLength}
                  placeholder="Например: Как справиться с коликами у новорождённого?"
                  className="rounded-xl"
                  required
                />
              </div>

              {/* Content */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Вопрос или описание</label>
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  maxLength={maxContentLength}
                  placeholder="Расскажите подробнее о вашей ситуации или вопросе..."
                  className="w-full h-40 px-4 py-3 rounded-xl border-2 border-border bg-background focus:border-primary focus:outline-none resize-none"
                  required
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Минимум 20 символов. Чем подробнее опишете, тем больше полезных советов получите.
                </p>
              </div>

              {/* Tags */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Теги (необязательно)</label>
                <div className="flex flex-wrap gap-2 mb-3">
                  {popularTags.map((tag) => (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-full text-sm border-2 transition-all ${
                        selectedTags.includes(tag)
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-secondary border-border hover:border-primary/30"
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>

                {/* Custom tag */}
                <div className="flex gap-2">
                  <Input
                    value={customTag}
                    onChange={(e) => setCustomTag(e.target.value)}
                    maxLength={maxTagLength}
                    onKeyPress={(e) => e.key === "Enter" && addCustomTag()}
                    placeholder="Добавить свой тег"
                    className="rounded-xl flex-1"
                  />
                  <Button onClick={addCustomTag} variant="outline" className="rounded-xl">
                    Добавить
                  </Button>
                </div>

                {selectedTags.length > 0 && (
                  <div className="mt-3 text-sm text-muted-foreground">
                    Выбрано тегов: {selectedTags.length}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
              {shouldShowValidation ? (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                  {validationMessage}
                </div>
              ) : null}
              <Button variant="outline" onClick={onClose} disabled={isSubmitting} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button onClick={handleSubmit} disabled={Boolean(validationMessage) || isSubmitting} className="flex-1 rounded-xl">
                Опубликовать
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { motion } from "motion/react";
import { Bell, Calendar, Check, Clock, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { useState } from "react";
import { AddReminderModal, Reminder } from "./AddReminderModal";
import { ConfirmActionDialog } from "./ConfirmActionDialog";
import { ActionEmptyState } from "./ActionEmptyState";
import { ScreenHeader } from "./ScreenHeader";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { notifySuccess, notifyWarning } from "../../lib/notify";

type StoredReminder = Reminder & { id: number };
type ChecklistItem = { id: number; title: string; checked: boolean };
type PendingDelete =
  | { kind: "reminder"; id: number; title: string }
  | { kind: "checklist"; id: number; title: string };

const upcomingReminders: StoredReminder[] = [];

const checklistItems: ChecklistItem[] = [];

function sortReminders(reminders: StoredReminder[]) {
  return [...reminders].sort((a, b) => {
    const dateCompare = a.date.localeCompare(b.date);

    if (dateCompare !== 0) return dateCompare;

    return (a.time || "23:59").localeCompare(b.time || "23:59");
  });
}

export function WebRemindersScreen() {
  const [reminders, setReminders] = useLocalStorageState<StoredReminder[]>("mvp.reminders.items", upcomingReminders);
  const [checklist, setChecklist] = useLocalStorageState<ChecklistItem[]>("mvp.reminders.checklist", checklistItems);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReminder, setEditingReminder] = useState<StoredReminder | null>(null);
  const [newChecklistTitle, setNewChecklistTitle] = useState("");
  const [pendingDelete, setPendingDelete] = useState<PendingDelete | null>(null);
  const completedCount = checklist.filter((item) => item.checked).length;
  const remainingCount = checklist.length - completedCount;

  const toggleItem = (id: number) => {
    const targetItem = checklist.find((item) => item.id === id);
    const nextChecked = !targetItem?.checked;

    setChecklist((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
    notifySuccess(nextChecked ? "Задача выполнена" : "Задача снова активна");
  };

  const openNewReminder = () => {
    setEditingReminder(null);
    setIsModalOpen(true);
  };

  const openEditReminder = (reminder: StoredReminder) => {
    setEditingReminder(reminder);
    setIsModalOpen(true);
  };

  const closeReminderModal = () => {
    setIsModalOpen(false);
    setEditingReminder(null);
  };

  const handleSaveReminder = (reminder: Reminder) => {
    if (editingReminder) {
      setReminders((prev) =>
        sortReminders(
          prev.map((item) =>
            item.id === editingReminder.id ? { ...item, ...reminder } : item
          )
        )
      );
      setEditingReminder(null);
      notifySuccess("Напоминание обновлено");
      return;
    }

    setReminders((prev) => sortReminders([{ id: Date.now(), ...reminder }, ...prev]));
    notifySuccess("Напоминание добавлено");
  };

  const handleDeleteReminder = (id: number) => {
    setReminders((prev) => prev.filter((reminder) => reminder.id !== id));
    setPendingDelete(null);
    if (editingReminder?.id === id) {
      closeReminderModal();
    }
    notifySuccess("Напоминание удалено");
  };

  const handleAddChecklistItem = () => {
    const title = newChecklistTitle.trim();
    if (!title) {
      notifyWarning("Введите название задачи");
      return;
    }

    setChecklist((prev) => [{ id: Date.now(), title, checked: false }, ...prev]);
    setNewChecklistTitle("");
    notifySuccess("Задача добавлена");
  };

  const handleDeleteChecklistItem = (id: number) => {
    setChecklist((prev) => prev.filter((item) => item.id !== id));
    setPendingDelete(null);
    notifySuccess("Задача удалена");
  };

  return (
    <div className="p-4 md:p-8 max-w-[1400px] mx-auto">
      <ScreenHeader
        icon={<Bell className="h-6 w-6" />}
        title="Напоминания"
        description="Важные события, задачи и чек-лист на сегодня."
        action={
          <Button
            onClick={openNewReminder}
            className="h-12 w-full sm:w-auto min-w-[160px] justify-center rounded-2xl bg-primary hover:bg-primary/90"
          >
            <Plus className="w-5 h-5 mr-2" />
            Добавить
          </Button>
        }
      />

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Upcoming Reminders */}
        <div className="space-y-6">
          <h2 className="text-lg font-medium text-foreground">Ближайшие</h2>
          {reminders.length === 0 ? (
            <ActionEmptyState
              icon={<Clock className="h-7 w-7" />}
              title="Добавьте первое напоминание"
              description="Запланируйте прием, покупку или бытовую задачу, чтобы она не потерялась в течение дня."
              primaryAction={{ label: "Создать напоминание", onClick: openNewReminder }}
              className="rounded-xl bg-secondary/30 shadow-none"
            />
          ) : (
            <div className="space-y-3">
              {reminders.map((reminder, idx) => (
                <motion.div
                  key={reminder.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 + idx * 0.1 }}
                  whileHover={{ x: 4 }}
                  className={`rounded-xl p-4 transition-all border ${
                    reminder.type === "important"
                      ? "bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30 hover:border-primary/50"
                      : "bg-card border-border hover:border-primary/30"
                  }`}
                >
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
                    <div className="flex flex-1 items-start gap-4 min-w-0">
                      <div className="w-11 h-11 bg-white/80 rounded-xl flex items-center justify-center text-2xl shadow-sm shrink-0">
                        {reminder.emoji}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-foreground mb-1 break-words">{reminder.title}</h3>
                        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>{reminder.date}</span>
                          </div>
                          {reminder.time && (
                            <>
                              <span>•</span>
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                <span>{reminder.time}</span>
                              </div>
                            </>
                          )}
                        </div>
                        {reminder.notes ? (
                          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                            {reminder.notes}
                          </p>
                        ) : null}
                      </div>
                    </div>
                    <div className="flex shrink-0 gap-2 sm:self-start">
                      <button
                        type="button"
                        onClick={() => openEditReminder(reminder)}
                        className="h-10 flex-1 rounded-xl border border-border bg-white/70 text-muted-foreground transition-colors hover:border-primary/40 hover:text-primary sm:w-10 sm:flex-none"
                        aria-label="Редактировать напоминание"
                      >
                        <Pencil className="mx-auto h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setPendingDelete({
                            kind: "reminder",
                            id: reminder.id,
                            title: reminder.title,
                          })
                        }
                        className="h-10 flex-1 rounded-xl border border-border bg-white/70 text-muted-foreground transition-colors hover:border-destructive/40 hover:text-destructive sm:w-10 sm:flex-none"
                        aria-label="Удалить напоминание"
                      >
                        <Trash2 className="mx-auto h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Checklist */}
        <div className="space-y-6">
          <h2 className="text-lg font-medium text-foreground">Чек-лист на сегодня</h2>
          <div className="rounded-xl border border-border bg-card p-4">
            {checklist.length === 0 ? (
              <ActionEmptyState
                compact
                icon={<Check className="h-6 w-6" />}
                title="Добавьте первую задачу"
                description="Напишите короткую задачу в поле ниже: например, проверить аптечку или купить подгузники."
                className="border-border bg-secondary/30 shadow-none"
              />
            ) : (
              <div className="space-y-3">
                {checklist.map((item, idx) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + idx * 0.05 }}
                    className="flex items-center gap-2 rounded-xl hover:bg-secondary transition-all"
                  >
                    <button
                      type="button"
                      onClick={() => toggleItem(item.id)}
                      className="flex min-w-0 flex-1 items-center gap-4 p-4 text-left"
                    >
                      <div
                        className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                          item.checked
                            ? "bg-primary border-primary"
                            : "border-border bg-transparent"
                        }`}
                      >
                        {item.checked && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <span
                        className={`flex-1 ${
                          item.checked
                            ? "text-muted-foreground line-through"
                            : "text-foreground"
                        }`}
                      >
                        {item.title}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setPendingDelete({
                          kind: "checklist",
                          id: item.id,
                          title: item.title,
                        })
                      }
                      className="mr-2 h-9 w-9 shrink-0 rounded-xl text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                      aria-label="Удалить задачу"
                    >
                      <Trash2 className="mx-auto h-4 w-4" />
                    </button>
                  </motion.div>
                ))}
              </div>
            )}

            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <Input
                value={newChecklistTitle}
                onChange={(event) => setNewChecklistTitle(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    handleAddChecklistItem();
                  }
                }}
                placeholder="Новая задача на сегодня"
                className="h-11 rounded-xl"
              />
              <Button
                type="button"
                onClick={handleAddChecklistItem}
                variant="outline"
                className="h-11 rounded-xl sm:min-w-[120px]"
              >
                <Plus className="w-4 h-4 mr-2" />
                Добавить
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 to-accent/10 p-4">
            <h3 className="mb-3 font-medium text-foreground">Прогресс на сегодня</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-white/60 p-3">
                <div className="text-2xl font-medium text-foreground">
                  {completedCount}
                </div>
                <div className="text-xs text-muted-foreground">Выполнено</div>
              </div>
              <div className="rounded-xl bg-white/60 p-3">
                <div className="text-2xl font-medium text-foreground">
                  {remainingCount}
                </div>
                <div className="text-xs text-muted-foreground">Осталось</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Reminder Modal */}
      <AddReminderModal
        isOpen={isModalOpen}
        onClose={closeReminderModal}
        onAdd={handleSaveReminder}
        initialReminder={editingReminder}
      />
      <ConfirmActionDialog
        open={Boolean(pendingDelete)}
        onOpenChange={(open) => {
          if (!open) setPendingDelete(null);
        }}
        title={pendingDelete?.kind === "reminder" ? "Удалить напоминание?" : "Удалить задачу?"}
        description={
          pendingDelete?.kind === "reminder"
            ? "Напоминание исчезнет из ближайших событий. Действие нельзя отменить."
            : "Задача исчезнет из чек-листа на сегодня. Действие нельзя отменить."
        }
        confirmLabel="Удалить"
        destructive
        onConfirm={() => {
          if (!pendingDelete) return;

          if (pendingDelete.kind === "reminder") {
            handleDeleteReminder(pendingDelete.id);
            return;
          }

          handleDeleteChecklistItem(pendingDelete.id);
        }}
      />
    </div>
  );
}

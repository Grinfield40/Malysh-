import { motion } from "motion/react";

interface PacifierRatingProps {
  rating: number; // 1-5
  size?: number;
  showNumber?: boolean;
}

export function PacifierRating({ rating, size = 20, showNumber = false }: PacifierRatingProps) {
  const maxRating = 5;

  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: maxRating }).map((_, idx) => {
        const isFilled = idx < rating;
        return (
          <motion.div
            key={idx}
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: idx * 0.05, type: "spring" }}
            whileHover={{ scale: 1.2, rotate: 10 }}
          >
            <svg
              width={size}
              height={size}
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id={`pacifierGrad${idx}`} x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#E8B4D9" />
                  <stop offset="100%" stopColor="#9B87D4" />
                </linearGradient>
              </defs>
              {/* Pacifier Handle */}
              <rect
                x="10"
                y="14"
                width="4"
                height="6"
                rx="2"
                fill={isFilled ? "url(#pacifierGrad" + idx + ")" : "#E5E0DB"}
                opacity={isFilled ? 1 : 0.3}
              />
              {/* Pacifier Shield */}
              <ellipse
                cx="12"
                cy="10"
                rx="8"
                ry="6"
                fill={isFilled ? "url(#pacifierGrad" + idx + ")" : "#E5E0DB"}
                opacity={isFilled ? 1 : 0.3}
              />
              {/* Pacifier Nipple */}
              <circle
                cx="12"
                cy="10"
                r="3"
                fill={isFilled ? "#FFFFFF" : "#F5F2FB"}
                opacity={isFilled ? 0.6 : 0.3}
              />
              {/* Center Hole */}
              <circle
                cx="12"
                cy="10"
                r="1"
                fill={isFilled ? "#9B87D4" : "#C0B8D3"}
                opacity={isFilled ? 0.5 : 0.2}
              />
            </svg>
          </motion.div>
        );
      })}
      {showNumber && (
        <span className="ml-2 text-sm font-medium text-muted-foreground">
          {rating}/5
        </span>
      )}
    </div>
  );
}

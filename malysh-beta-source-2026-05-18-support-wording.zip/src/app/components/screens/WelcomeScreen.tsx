import { motion } from "motion/react";
import { Button } from "../ui/button";

interface WelcomeScreenProps {
  onSignUp: () => void;
  onLogin: () => void;
}

export function WelcomeScreen({ onSignUp, onLogin }: WelcomeScreenProps) {
  return (
    <div className="h-screen bg-gradient-to-b from-secondary via-background to-background flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center px-8">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="text-center space-y-6 max-w-[320px]"
        >
          <div className="space-y-4">
            <h1 className="text-4xl font-medium text-foreground tracking-tight">
              Семья
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Спокойная опора для родителей
            </p>
          </div>

          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-3 text-sm text-foreground/70">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-base">📚</span>
              </div>
              <span>Проверенные советы экспертов</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-foreground/70">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-base">✓</span>
              </div>
              <span>Полезные чеклисты и трекеры</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-foreground/70">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <span className="text-base">💬</span>
              </div>
              <span>Поддержка родительского сообщества</span>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="px-8 pb-12 space-y-3"
      >
        <Button
          onClick={onSignUp}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90"
        >
          Создать аккаунт
        </Button>
        <Button
          onClick={onLogin}
          variant="outline"
          className="w-full h-14 rounded-2xl border-2 border-border hover:bg-secondary"
        >
          Войти
        </Button>
      </motion.div>
    </div>
  );
}

param(
  [string]$OutputPath
)

$ErrorActionPreference = "Stop"

$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptPath "..\..")
$DefaultOutput = Join-Path (Split-Path -Parent $ProjectRoot) "malysh-beta-source.zip"

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = $DefaultOutput
}

$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$TempRoot = Join-Path (Split-Path -Parent $ProjectRoot) (".malysh-release-" + [System.Guid]::NewGuid().ToString("N"))

$ExcludedDirs = @(
  ".git",
  ".npm-cache",
  "node_modules",
  "dist",
  "server\data",
  "server\backups"
)

$ExcludedFileNames = @(
  ".env"
)

$ExcludedExtensions = @(
  ".log"
)

function Test-IsExcludedPath {
  param([string]$RelativePath, [bool]$IsDirectory)

  $normalized = $RelativePath.Replace("/", "\").TrimStart("\")

  foreach ($dir in $ExcludedDirs) {
    if ($normalized -eq $dir -or $normalized.StartsWith("$dir\")) {
      return $true
    }
  }

  if (-not $IsDirectory) {
    $fileName = Split-Path -Leaf $normalized
    $extension = [System.IO.Path]::GetExtension($normalized)

    if ($ExcludedFileNames -contains $fileName) {
      return $true
    }

    if ($ExcludedExtensions -contains $extension) {
      return $true
    }
  }

  return $false
}

if (Test-Path -LiteralPath $TempRoot) {
  Remove-Item -LiteralPath $TempRoot -Recurse -Force
}

New-Item -ItemType Directory -Path $TempRoot | Out-Null

try {
  Get-ChildItem -LiteralPath $ProjectRoot -Force -Recurse | ForEach-Object {
    $relativePath = $_.FullName.Substring($ProjectRoot.Path.Length).TrimStart("\")

    if ([string]::IsNullOrWhiteSpace($relativePath)) {
      return
    }

    if (Test-IsExcludedPath -RelativePath $relativePath -IsDirectory $_.PSIsContainer) {
      return
    }

    $targetPath = Join-Path $TempRoot $relativePath

    if ($_.PSIsContainer) {
      New-Item -ItemType Directory -Path $targetPath -Force | Out-Null
      return
    }

    $targetDir = Split-Path -Parent $targetPath
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $targetPath -Force
  }

  if (Test-Path -LiteralPath $OutputPath) {
    Remove-Item -LiteralPath $OutputPath -Force
  }

  $outputDir = Split-Path -Parent $OutputPath
  if (-not [string]::IsNullOrWhiteSpace($outputDir)) {
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
  }

  Compress-Archive -Path (Join-Path $TempRoot "*") -DestinationPath $OutputPath -Force

  $archive = Get-Item -LiteralPath $OutputPath
  Write-Host "Release archive created:"
  Write-Host $archive.FullName
  Write-Host ("Size: {0:N2} MB" -f ($archive.Length / 1MB))
}
finally {
  if (Test-Path -LiteralPath $TempRoot) {
    Remove-Item -LiteralPath $TempRoot -Recurse -Force
  }
}

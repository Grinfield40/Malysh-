export const DEFAULT_ALLOWED_AUTH_EMAIL_DOMAINS = [
  "yandex.ru",
  "ya.ru",
  "mail.ru",
  "bk.ru",
  "inbox.ru",
  "list.ru",
  "internet.ru",
  "xmail.ru",
  "vk.com",
  "rambler.ru",
  "lenta.ru",
  "autorambler.ru",
  "myrambler.ru",
  "ro.ru",
] as const;

export const AUTH_EMAIL_PROVIDER_LABEL = "Яндекс, Mail.ru, VK или Rambler";
export const AUTH_EMAIL_POLICY_NOTICE =
  "Вход через Google в России запрещен для российских сайтов. Используйте Яндекс ID или российскую почту.";
export const AUTH_EMAIL_POLICY_ERROR =
  "Для регистрации используйте российскую почту: Яндекс, Mail.ru, VK или Rambler.";

export function normalizeAuthEmailDomain(domain: string) {
  return String(domain || "").trim().toLowerCase().replace(/^@+/, "");
}

export function getAuthEmailDomain(email: string) {
  const normalizedEmail = String(email || "").trim().toLowerCase();
  const domain = normalizedEmail.split("@")[1] || "";

  return normalizeAuthEmailDomain(domain).slice(0, 80);
}

export function normalizeAllowedAuthEmailDomains(domains?: readonly string[] | null) {
  const normalized = Array.from(new Set((domains || DEFAULT_ALLOWED_AUTH_EMAIL_DOMAINS).map(normalizeAuthEmailDomain)))
    .filter(Boolean)
    .sort();

  return normalized.length ? normalized : [...DEFAULT_ALLOWED_AUTH_EMAIL_DOMAINS];
}

export function isAllowedAuthEmail(email: string, allowedDomains: readonly string[] = DEFAULT_ALLOWED_AUTH_EMAIL_DOMAINS) {
  const domain = getAuthEmailDomain(email);

  if (!domain) return false;

  return new Set(allowedDomains.map(normalizeAuthEmailDomain)).has(domain);
}

export function formatAllowedAuthEmailDomains(allowedDomains: readonly string[]) {
  const normalized = normalizeAllowedAuthEmailDomains(allowedDomains);
  const primary = ["yandex.ru", "ya.ru", "mail.ru", "bk.ru", "inbox.ru", "list.ru", "vk.com", "rambler.ru"]
    .filter((domain) => normalized.includes(domain))
    .map((domain) => `@${domain}`);

  return primary.length > 0
    ? `${primary.join(", ")} и другие российские домены`
    : normalized.map((domain) => `@${domain}`).join(", ");
}

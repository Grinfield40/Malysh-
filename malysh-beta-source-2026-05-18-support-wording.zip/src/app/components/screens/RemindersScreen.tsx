import { Calendar, Check, Plus } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";

const upcomingReminders = [
  { id: 1, title: "Визит к педиатру", date: "12 апреля", time: "10:00", icon: "🩺" },
  { id: 2, title: "Купить подгузники", date: "13 апреля", time: "", icon: "🛒" },
  { id: 3, title: "Прививка", date: "15 апреля", time: "11:30", icon: "💉" },
];

const checklistItems = [
  { id: 1, title: "Стерилизовать бутылочки", checked: true },
  { id: 2, title: "Собрать сумку для прогулки", checked: false },
  { id: 3, title: "Постирать детское белье", checked: true },
  { id: 4, title: "Купить витамин D", checked: false },
  { id: 5, title: "Записаться на массаж", checked: false },
];

export function RemindersScreen() {
  const [checklist, setChecklist] = useState(checklistItems);

  const toggleItem = (id: number) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-6 bg-gradient-to-b from-secondary/50 to-transparent">
        <h1 className="text-2xl font-medium text-foreground mb-2">Напоминания</h1>
        <p className="text-sm text-muted-foreground">Не забудьте важное</p>
      </div>

      <div className="px-6 pb-6">
        <div className="mb-6">
          <h3 className="text-base font-medium text-foreground mb-4">Ближайшие</h3>
          <div className="space-y-3">
            {upcomingReminders.map((reminder) => (
              <div
                key={reminder.id}
                className="rounded-xl bg-card border border-border p-4 flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                  {reminder.icon}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-foreground mb-1">{reminder.title}</h4>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-3 h-3" />
                    <span>{reminder.date}</span>
                    {reminder.time && (
                      <>
                        <span>•</span>
                        <span>{reminder.time}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-base font-medium text-foreground mb-4">Чеклист</h3>
          <div className="space-y-2">
            {checklist.map((item) => (
              <button
                key={item.id}
                onClick={() => toggleItem(item.id)}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
              >
                <div
                  className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    item.checked
                      ? "bg-primary border-primary"
                      : "border-border bg-transparent"
                  }`}
                >
                  {item.checked && <Check className="w-4 h-4 text-white" />}
                </div>
                <span
                  className={`text-left flex-1 ${
                    item.checked ? "text-muted-foreground line-through" : "text-foreground"
                  }`}
                >
                  {item.title}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="fixed bottom-24 right-6">
        <Button
          size="lg"
          className="h-14 w-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}

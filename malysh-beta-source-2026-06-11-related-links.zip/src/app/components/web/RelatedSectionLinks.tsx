import {
  ArrowRight,
  Baby,
  Bell,
  BookOpen,
  Bookmark,
  ClipboardList,
  Clock,
  Heart,
  Image,
  MessageCircle,
  ShieldAlert,
  ShieldCheck,
  ShoppingBag,
  User,
  Activity,
  type LucideIcon,
} from "lucide-react";
import type { Screen } from "../../lib/routes";

interface RelatedAction {
  screen: Screen;
  label: string;
  description: string;
  icon: LucideIcon;
}

interface RelatedSectionLinksProps {
  currentScreen: Screen;
  onNavigate: (screen: string) => void;
}

const relatedActionsByScreen: Partial<Record<Screen, RelatedAction[]>> = {
  tracker: [
    { screen: "routines", label: "Собрать режим", description: "Сон, кормления и прогулки рядом", icon: Clock },
    { screen: "reminders", label: "Поставить напоминание", description: "Чтобы важное не потерялось", icon: Bell },
    { screen: "profile", label: "Профиль ребенка", description: "Возраст и цели для подсказок", icon: User },
  ],
  routines: [
    { screen: "tracker", label: "Отметить событие", description: "Сон, кормление или подгузник", icon: Activity },
    { screen: "reminders", label: "Добавить напоминание", description: "Связать режим с задачами", icon: Bell },
    { screen: "growth-timeline", label: "Фокусы возраста", description: "Что сейчас может быть полезно", icon: Baby },
  ],
  reminders: [
    { screen: "routines", label: "Вернуться к режиму", description: "Понять, куда поставить задачу", icon: Clock },
    { screen: "tracker", label: "Открыть трекер", description: "Быстро записать факт ухода", icon: Activity },
    { screen: "profile", label: "Настройки семьи", description: "Проверить данные и цели", icon: User },
  ],
  fridge: [
    { screen: "shopping", label: "Покупки", description: "Дописать, что заканчивается", icon: ShoppingBag },
    { screen: "reminders", label: "Напомнить", description: "Поставить задачу на потом", icon: Bell },
    { screen: "tracker", label: "Трекер", description: "Связать питание с днем", icon: Activity },
  ],
  "growth-timeline": [
    { screen: "tips", label: "Советы", description: "Короткие материалы по возрасту", icon: BookOpen },
    { screen: "recommendations", label: "Мамы одобряют", description: "Спокойные идеи и товары", icon: Heart },
    { screen: "saved", label: "Сохраненное", description: "Вернуться к отмеченному", icon: Bookmark },
  ],
  "growth-stage": [
    { screen: "growth-timeline", label: "Все этапы", description: "Вернуться к возрастам", icon: Baby },
    { screen: "tips", label: "Советы", description: "Почитать по теме", icon: BookOpen },
    { screen: "recommendations", label: "Подборки", description: "Идеи для этого периода", icon: Heart },
  ],
  tips: [
    { screen: "growth-timeline", label: "Развитие малыша", description: "Сверить советы с возрастом", icon: Baby },
    { screen: "saved", label: "Сохраненное", description: "Открыть избранные материалы", icon: Bookmark },
    { screen: "forum", label: "Форум", description: "Обсудить с другими родителями", icon: MessageCircle },
  ],
  article: [
    { screen: "tips", label: "Все советы", description: "Вернуться к подборке", icon: BookOpen },
    { screen: "saved", label: "Сохраненное", description: "Посмотреть отмеченное", icon: Bookmark },
    { screen: "forum", label: "Обсудить", description: "Задать вопрос сообществу", icon: MessageCircle },
  ],
  recommendations: [
    { screen: "shopping", label: "Покупки", description: "Перенести идею в список", icon: ShoppingBag },
    { screen: "saved", label: "Сохраненное", description: "Открыть отмеченные товары", icon: Bookmark },
    { screen: "forum", label: "Отзывы родителей", description: "Спросить мнение", icon: MessageCircle },
  ],
  shopping: [
    { screen: "discharge-checklist", label: "На выписку", description: "Проверить самое нужное", icon: ClipboardList },
    { screen: "stroller-guide", label: "Коляска", description: "Выбрать без лишней суеты", icon: Baby },
    { screen: "taboo", label: "Табу", description: "Что можно не покупать", icon: ShieldAlert },
  ],
  "discharge-checklist": [
    { screen: "shopping", label: "Покупки", description: "Дописать недостающее", icon: ShoppingBag },
    { screen: "stroller-guide", label: "Коляска", description: "Подготовить прогулки", icon: Baby },
    { screen: "profile", label: "Профиль ребенка", description: "Проверить базовые данные", icon: User },
  ],
  "stroller-guide": [
    { screen: "shopping", label: "Покупки", description: "Сохранить выбранное", icon: ShoppingBag },
    { screen: "taboo", label: "Табу", description: "Не брать лишнее", icon: ShieldAlert },
    { screen: "forum", label: "Спросить родителей", description: "Сравнить опыт", icon: MessageCircle },
  ],
  taboo: [
    { screen: "shopping", label: "Покупки", description: "Вернуться к списку", icon: ShoppingBag },
    { screen: "tips", label: "Советы", description: "Почитать спокойные объяснения", icon: BookOpen },
    { screen: "forum", label: "Обсудить", description: "Уточнить спорный вопрос", icon: MessageCircle },
  ],
  forum: [
    { screen: "tips", label: "Советы", description: "Почитать перед вопросом", icon: BookOpen },
    { screen: "saved", label: "Сохраненное", description: "Вернуться к полезному", icon: Bookmark },
    { screen: "profile", label: "Профиль", description: "Настройки и поддержка", icon: User },
  ],
  saved: [
    { screen: "tips", label: "Советы", description: "Найти новые материалы", icon: BookOpen },
    { screen: "recommendations", label: "Мамы одобряют", description: "Посмотреть подборки", icon: Heart },
    { screen: "forum", label: "Форум", description: "Открыть сохраненные идеи в разговоре", icon: MessageCircle },
  ],
  profile: [
    { screen: "tracker", label: "Трекер", description: "Начать дневник ухода", icon: Activity },
    { screen: "reminders", label: "Напоминания", description: "Поставить важные задачи", icon: Bell },
    { screen: "privacy", label: "Приватность", description: "Документы и согласия", icon: ShieldCheck },
  ],
  urgent: [
    { screen: "tracker", label: "Записать состояние", description: "Зафиксировать температуру и заметку", icon: Activity },
    { screen: "reminders", label: "Напомнить проверить", description: "Вернуться к вопросу позже", icon: Bell },
    { screen: "profile", label: "Контакт специалиста", description: "Проверить данные в профиле", icon: User },
  ],
  privacy: [
    { screen: "profile", label: "Профиль", description: "Вернуться к настройкам", icon: User },
    { screen: "saved", label: "Сохраненное", description: "Открыть личные материалы", icon: Bookmark },
  ],
};

export function RelatedSectionLinks({ currentScreen, onNavigate }: RelatedSectionLinksProps) {
  const actions = relatedActionsByScreen[currentScreen];

  if (!actions?.length) {
    return null;
  }

  return (
    <section className="px-4 md:px-8 pb-8 md:pb-10">
      <div className="mx-auto max-w-[1400px]">
        <div className="mb-3 flex items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-medium text-foreground md:text-lg">Дальше удобно</h2>
            <p className="text-xs text-muted-foreground md:text-sm">Что может пригодиться рядом.</p>
          </div>
        </div>

        <div className="grid gap-2 md:grid-cols-3">
          {actions.map((action) => {
            const Icon = action.icon;

            return (
              <button
                key={`${currentScreen}-${action.screen}`}
                type="button"
                onClick={() => onNavigate(action.screen)}
                className="group flex min-h-[76px] items-center gap-3 rounded-xl border border-border bg-background/70 px-3 py-3 text-left transition hover:border-primary/30 hover:bg-primary/5"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Icon className="h-5 w-5" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-semibold text-foreground">{action.label}</span>
                  <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">{action.description}</span>
                </span>
                <ArrowRight className="h-4 w-4 shrink-0 text-muted-foreground transition group-hover:translate-x-0.5 group-hover:text-primary" />
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

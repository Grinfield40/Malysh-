import type { RegistrationConsentsPayload } from "./legal";

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: "admin" | "user" | string;
  authProvider?: "password" | "yandex" | "password+yandex" | string;
  yandexLinked?: boolean;
  emailVerifiedAt?: string | null;
  blockedAt?: string | null;
  createdAt?: string;
  lastLoginAt?: string;
}

export interface AuthSession {
  token: string;
  user: AuthUser;
  consentStatus?: LegalConsentStatus;
}

export interface AuthResponse extends AuthSession {
  storage: Record<string, unknown>;
}

export interface LegalConsentItem {
  key: string;
  documentKey: string;
  documentTitle: string;
  documentVersion: string;
  documentPath: string;
  acceptedAt?: string | null;
  accepted: boolean;
}

export interface LegalConsentStatus {
  required: boolean;
  documentVersion: string;
  missing: string[];
  requiredConsents: LegalConsentItem[];
}

export interface FeatureFlag {
  key: string;
  label: string;
  description?: string;
  enabled: boolean;
  updatedAt?: string;
  updatedBy?: string | null;
}

export interface PublicConfig {
  appName: string;
  publicUrl: string;
  registrationMode: "open" | "closed" | "disabled" | string;
  registrationRequiresInvite: boolean;
  authProviders?: {
    yandex?: {
      enabled: boolean;
    };
  };
  featureFlags?: FeatureFlag[];
  legalDocuments?: Record<
    string,
    {
      title: string;
      shortTitle?: string;
      version: string;
      path?: string;
      screen?: string;
    }
  >;
}

export interface AdminBackupInfo {
  fileName: string;
  path: string;
  sizeBytes: number;
  createdAt: string;
  updatedAt: string;
}

export interface AdminBabyProfile {
  name: string;
  birthDate?: string;
  stage?: string;
  heightCm?: string;
  weightKg?: string;
  bloodType?: string;
  emoji?: string;
}

export interface AdminUserForumPost {
  id: string;
  title: string;
  content: string;
  preview: string;
  categoryId: string;
  category: string;
  tags: string[];
  views: number;
  comments: number;
  reports?: number;
  status?: ForumContentStatus;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
  lastActivityAt?: string;
}

export interface AdminUserActivity {
  id: string;
  type: "audit" | "analytics" | string;
  kind?: "registration" | "login" | "forum" | "data" | "fridge" | "screen" | "admin" | "error" | "activity" | string;
  label: string;
  title?: string;
  description?: string;
  screen?: string;
  durationMs?: number | null;
  createdAt: string;
  meta?: Record<string, unknown>;
}

export interface AdminUser extends AuthUser {
  activeSessions: number;
  storageKeys: number;
  diaryEntries: number;
  routines: number;
  shoppingItems: number;
  shoppingChecked: number;
  forumPosts: number;
  forumComments: number;
  fridgeItems: number;
  babyName?: string;
  goals: string[];
  consentStatus?: LegalConsentStatus;
  legalConsentAcceptedAt?: string | null;
  babyProfile: AdminBabyProfile | null;
  recentDiaryEntries: AdminDiaryEntry[];
  recentForumPosts: AdminUserForumPost[];
  recentActivity: AdminUserActivity[];
}

export interface AdminDiaryEntry {
  id: string;
  type?: string;
  time?: string;
  details?: string;
  icon?: string;
  category?: string;
  date?: string;
  updatedAt: string;
  userId: string;
  userName: string;
  userEmail: string;
  babyName?: string;
}

export interface AdminAuditEvent {
  id: string;
  userId: string | null;
  userName?: string;
  userEmail?: string;
  action: string;
  kind?: "registration" | "login" | "forum" | "data" | "fridge" | "screen" | "admin" | "error" | "activity" | string;
  title?: string;
  description?: string;
  createdAt: string;
  meta?: Record<string, unknown>;
}

export interface AdminAnalyticsEvent {
  id: string;
  name: string;
  screen?: string;
  durationMs?: number;
  meta?: Record<string, unknown>;
  createdAt: string;
  userName?: string;
  userEmail?: string;
}

export interface AdminAnalyticsSummary {
  totalEvents: number;
  eventsToday: number;
  activeUsers7d: number;
  topScreens: Array<{
    screen: string;
    views: number;
    totalDurationMs: number;
    avgDurationMs: number;
  }>;
  topActions: Array<{ name: string; count: number }>;
  recentEvents: AdminAnalyticsEvent[];
}

export type BetaFeedbackStatus = "new" | "reviewed" | "resolved";
export type BetaFeedbackTopic = "feedback" | "login" | "data_loss" | "bug" | "idea" | "other";

export interface BetaFeedbackItem {
  id: string;
  userId?: string | null;
  userName?: string;
  userEmail?: string;
  rating?: number | null;
  message: string;
  screen?: string | null;
  topic?: BetaFeedbackTopic | string | null;
  status: BetaFeedbackStatus;
  createdAt: string;
  resolvedAt?: string | null;
  resolverName?: string | null;
}

export interface AdminFridgeItem {
  id: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  babyName?: string;
  title?: string;
  imageSrc: string;
  updatedAt: string;
}

export interface AdminRecentNote {
  userId: string;
  userName?: string;
  userEmail?: string;
  babyName?: string;
  key: string;
  snippets: string[];
  updatedAt: string;
}

export interface AdminProblemEvent {
  id: string;
  source: "audit" | "analytics" | string;
  name: string;
  label: string;
  screen?: string | null;
  status?: number | string | null;
  meta?: Record<string, unknown>;
  createdAt: string;
  userName?: string;
  userEmail?: string;
}

export interface AdminActivityUser {
  id: string;
  name: string;
  email: string;
  babyName?: string;
  createdAt?: string;
  lastLoginAt?: string | null;
  count?: number;
  lastActivityAt?: string;
  reason?: string;
}

export interface AdminBetaInvite {
  id: string;
  code: string;
  label: string;
  maxUses: number | null;
  usedCount: number;
  createdBy: string;
  createdByEmail: string;
  createdAt: string;
  lastUsedAt?: string | null;
  disabledAt?: string | null;
  active: boolean;
}

export interface AdminConfigInfo {
  publicUrl: string;
  allowedOrigins: string[];
  registrationMode: "open" | "closed" | "disabled" | string;
  registrationRequiresInvite: boolean;
  inviteConfigured: boolean;
  envInviteConfigured: boolean;
  activeInviteCount: number;
  inviteCodes: AdminBetaInvite[];
  serveWeb: boolean;
  healthDetails: boolean;
  accessLogs: boolean;
  errorStacks: boolean;
  limits: {
    maxJsonBodyBytes: number;
    maxStorageKeys: number;
    maxStorageValueBytes: number;
    maxFridgeCards: number;
    maxFridgeImages: number;
    maxFridgeImageBytes: number;
    maxFridgeTotalImageBytes: number;
    forumTitleMaxLength: number;
    forumPostMaxLength: number;
    forumCommentMaxLength: number;
    forumReportDetailsMaxLength: number;
  };
}

export interface AdminConsentUser {
  userId: string;
  name: string;
  email: string;
  role: string;
  createdAt?: string;
  lastLoginAt?: string | null;
  blockedAt?: string | null;
  acceptedAt?: string | null;
  consentStatus: LegalConsentStatus;
}

export interface AdminConsentRecord {
  id: string;
  userId: string;
  userName?: string | null;
  userEmail?: string | null;
  consentKey: string;
  documentKey: string;
  documentTitle: string;
  documentVersion: string;
  acceptedAt: string;
  ipAddress?: string | null;
  userAgent?: string | null;
  meta?: Record<string, unknown>;
}

export interface AdminConsentSummary {
  stats: {
    requiredVersion: string;
    usersTotal: number;
    accepted: number;
    missing: number;
    consentRecords: number;
  };
  users: AdminConsentUser[];
  recent: AdminConsentRecord[];
}

export interface AdminOverview {
  stats: {
    users: number;
    sessions: number;
    userConsents: number;
    consentMissing?: number;
    diaryEntries: number;
    storageKeys: number;
    routines: number;
    shoppingItems: number;
    fridgeItems: number;
    forumPosts: number;
    forumComments: number;
    forumReports: number;
    backups: number;
    analyticsEvents: number;
    betaFeedback: number;
  };
  database: {
    path: string;
    sizeBytes: number;
    backupDir: string;
    backups: AdminBackupInfo[];
  };
  config: AdminConfigInfo;
  analytics: AdminAnalyticsSummary;
  users: AdminUser[];
  forumModeration: AdminForumModeration;
  contentModeration: {
    forum: AdminForumModeration;
    fridgeItems: AdminFridgeItem[];
    notes: AdminRecentNote[];
  };
  productHealth: {
    stats: {
      failedLogins7d: number;
      failedRegistrations7d: number;
      analyticsErrors7d: number;
      problemEvents7d: number;
    };
    recentProblems: AdminProblemEvent[];
    frequentFailures: Array<{ label: string; count: number }>;
  };
  userActivity: {
    loggedInToday: AdminActivityUser[];
    registeredToday: AdminActivityUser[];
    creatorsToday: AdminActivityUser[];
    onboardingDropoffs: AdminActivityUser[];
  };
  feedback: {
    stats: {
      total: number;
      new: number;
      reviewed: number;
      resolved: number;
    };
    items: BetaFeedbackItem[];
  };
  consents: AdminConsentSummary;
  featureFlags: FeatureFlag[];
  recentDiaryEntries: AdminDiaryEntry[];
  audit: AdminAuditEvent[];
}

export interface AdminBackupResponse {
  ok: true;
  backup: AdminBackupInfo;
  backups: AdminBackupInfo[];
}

export interface AdminExport {
  exportedAt: string;
  service: string;
  database: AdminOverview["database"];
  config: AdminConfigInfo;
  personalDataRegistry?: unknown;
  users: AuthUser[];
  accountStorage: Array<{ userId: string; key: string; value: unknown; updatedAt: string }>;
  userConsents?: unknown[];
  babyProfiles: unknown[];
  parentGoals: unknown[];
  diaryEntries: unknown[];
  routines: unknown[];
  shoppingItems: unknown[];
  fridgeItems: unknown[];
  forumPosts: unknown[];
  forumComments: unknown[];
  forumReports: unknown[];
  betaInvites: unknown[];
  betaInviteRedemptions: unknown[];
  betaFeedback: unknown[];
  featureFlags: unknown[];
  analytics: {
    summary: AdminAnalyticsSummary;
    events: AdminAnalyticsEvent[];
  };
  audit: AdminAuditEvent[];
}

export type ForumContentStatus = "published" | "hidden" | "deleted";
export type ForumReportStatus = "open" | "reviewed" | "dismissed";

export interface AdminForumReport {
  id: string;
  targetType: "post" | "comment";
  targetId: string;
  postId?: string;
  reason: string;
  reasonLabel: string;
  details?: string;
  status: ForumReportStatus;
  createdAt: string;
  resolvedAt?: string | null;
  reporterName?: string;
  reporterEmail?: string;
  resolverName?: string;
  targetLabel: string;
  targetPreview?: string;
}

export interface AdminForumCommentRecord extends ForumCommentRecord {
  postTitle: string;
}

export interface AdminForumModeration {
  stats: {
    publishedPosts: number;
    hiddenPosts: number;
    deletedPosts: number;
    publishedComments: number;
    hiddenComments: number;
    deletedComments: number;
    openReports: number;
    totalReports: number;
  };
  reports: AdminForumReport[];
  posts: ForumPostRecord[];
  comments: AdminForumCommentRecord[];
}

export interface AnalyticsEventPayload {
  name: string;
  sessionId: string;
  screen?: string;
  durationMs?: number;
  meta?: Record<string, unknown>;
  createdAt: string;
}

export interface ForumPostRecord {
  id: string;
  title: string;
  content: string;
  preview: string;
  categoryId: string;
  category: string;
  tags: string[];
  views: number;
  comments: number;
  reports?: number;
  status?: ForumContentStatus;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
  lastActivityAt?: string;
}

export interface ForumCommentRecord {
  id: string;
  postId: string;
  content: string;
  status?: ForumContentStatus;
  reports?: number;
  author: string;
  avatar: string;
  authorId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ForumPostDetail {
  post: ForumPostRecord;
  comments: ForumCommentRecord[];
}

export interface ForumPostsResponse {
  posts: ForumPostRecord[];
  stats: {
    posts: number;
    comments: number;
    today: number;
  };
}

const API_URL = import.meta.env.VITE_MALYSH_API_URL || "/api";
const SESSION_STORAGE_KEY = "mvp.server.session";
const STORAGE_OWNER_KEY = "mvp.server.storage.owner";
const SYNC_DEBOUNCE_MS = 450;
const LARGE_LOCAL_STORAGE_KEYS = ["mvp.fridge.drawings"];
let syncTimer: number | undefined;
const pendingStorage = new Map<string, unknown>();

function isQuotaExceededError(error: unknown) {
  if (!(error instanceof DOMException)) return false;

  return (
    error.name === "QuotaExceededError" ||
    error.name === "NS_ERROR_DOM_QUOTA_REACHED" ||
    error.code === 22 ||
    error.code === 1014
  );
}

function removeLocalStorageItem(key: string) {
  try {
    window.localStorage.removeItem(key);
  } catch {
    // Local cleanup should never block login or hydration.
  }
}

function freeLargeLocalStorageKeys() {
  LARGE_LOCAL_STORAGE_KEYS.forEach(removeLocalStorageItem);
}

function removeSyncedLocalStorageKeys() {
  const keysToRemove: string[] = [];

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);

    if (key && shouldSyncStorageKey(key)) {
      keysToRemove.push(key);
    }
  }

  keysToRemove.forEach(removeLocalStorageItem);
}

function setLocalStorageRawItem(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch (error) {
    if (isQuotaExceededError(error)) {
      freeLargeLocalStorageKeys();

      try {
        window.localStorage.setItem(key, value);
        return true;
      } catch {
        return false;
      }
    }

    return false;
  }
}

export function setLocalStorageJsonItem(key: string, value: unknown) {
  return setLocalStorageRawItem(key, JSON.stringify(value));
}

export function getStoredSession(): AuthSession | null {
  try {
    const rawSession = window.localStorage.getItem(SESSION_STORAGE_KEY);

    return rawSession ? (JSON.parse(rawSession) as AuthSession) : null;
  } catch {
    return null;
  }
}

export function saveStoredSession(session: AuthSession) {
  const saved = setLocalStorageJsonItem(SESSION_STORAGE_KEY, session);

  if (!saved) {
    throw new Error("Не удалось сохранить вход в браузере. Освободите память сайта и попробуйте снова.");
  }
}

export function clearStoredSession() {
  window.localStorage.removeItem(SESSION_STORAGE_KEY);
}

export function isServerAuthConfigured() {
  return Boolean(getStoredSession()?.token);
}

export function shouldSyncStorageKey(key: string) {
  if (!key.startsWith("mvp.")) return false;
  if (key === SESSION_STORAGE_KEY) return false;
  if (key === "mvp.authenticated") return false;
  if (key.startsWith("mvp.server.")) return false;

  return true;
}

export function collectLocalAppStorage() {
  const storage: Record<string, unknown> = {};

  for (let index = 0; index < window.localStorage.length; index += 1) {
    const key = window.localStorage.key(index);

    if (!key || !shouldSyncStorageKey(key)) continue;

    const rawValue = window.localStorage.getItem(key);

    try {
      storage[key] = rawValue ? JSON.parse(rawValue) : null;
    } catch {
      storage[key] = rawValue;
    }
  }

  return storage;
}

export function hydrateLocalAppStorage(
  storage: Record<string, unknown>,
  options: { userId?: string; replace?: boolean } = {}
) {
  const previousOwner = window.localStorage.getItem(STORAGE_OWNER_KEY);
  const isDifferentAccount = Boolean(options.userId && previousOwner && previousOwner !== options.userId);

  if (options.replace || isDifferentAccount) {
    removeSyncedLocalStorageKeys();
  }

  Object.entries(storage).forEach(([key, value]) => {
    if (!shouldSyncStorageKey(key)) return;
    setLocalStorageJsonItem(key, value);
  });

  if (options.userId) {
    setLocalStorageRawItem(STORAGE_OWNER_KEY, options.userId);
  }
}

export function setAppStorageItem(key: string, value: unknown) {
  setLocalStorageJsonItem(key, value);
  queueAccountStorageSync(key, value);
}

export function queueAccountStorageSync(key: string, value: unknown) {
  const session = getStoredSession();

  if (!session || !shouldSyncStorageKey(key)) return;

  pendingStorage.set(key, value);

  if (syncTimer) {
    window.clearTimeout(syncTimer);
  }

  syncTimer = window.setTimeout(() => {
    void flushAccountStorageSync();
  }, SYNC_DEBOUNCE_MS);
}

export async function flushAccountStorageSync(options: { keepalive?: boolean } = {}) {
  const session = getStoredSession();

  if (!session || pendingStorage.size === 0) return;

  const items = Array.from(pendingStorage.entries());
  pendingStorage.clear();

  await Promise.all(
    items.map(([key, value]) =>
      apiRequest("/account/storage", {
        method: "PATCH",
        token: session.token,
        keepalive: options.keepalive,
        body: { key, value },
      }).catch(() => {
        pendingStorage.set(key, value);
      })
    )
  );
}

export async function syncAccountStorageItems(storage: Record<string, unknown>) {
  const session = getStoredSession();

  if (!session) return;

  const items = Object.entries(storage).filter(([key]) => shouldSyncStorageKey(key));

  await Promise.all(
    items.map(async ([key, value]) => {
      await apiRequest("/account/storage", {
        method: "PATCH",
        token: session.token,
        body: { key, value },
      });
      pendingStorage.delete(key);
    })
  );
}

export async function replaceAccountStorage(storage: Record<string, unknown>) {
  const session = getStoredSession();

  if (!session) return;

  await apiRequest("/account/storage", {
    method: "PUT",
    token: session.token,
    body: { storage },
  });
}

export async function getPublicConfig() {
  return apiRequest<PublicConfig>("/config", {
    method: "GET",
  });
}

export async function registerAccount(payload: {
  name: string;
  email: string;
  password: string;
  inviteCode?: string;
  consents?: RegistrationConsentsPayload;
}) {
  return apiRequest<AuthResponse>("/auth/register", {
    method: "POST",
    body: payload,
  });
}

export async function loginAccount(payload: { email: string; password: string }) {
  return apiRequest<AuthResponse>("/auth/login", {
    method: "POST",
    body: payload,
  });
}

export function getYandexAuthStartUrl(returnTo = `${window.location.pathname}${window.location.search}`) {
  const searchParams = new URLSearchParams();
  searchParams.set("returnTo", returnTo.startsWith("/") ? returnTo : "/");

  return `${API_URL}/auth/yandex/start?${searchParams.toString()}`;
}

export async function completeYandexLogin(code: string) {
  return apiRequest<AuthResponse>("/auth/yandex/complete", {
    method: "POST",
    body: { code },
  });
}

export async function logoutAccount(token: string) {
  return apiRequest<{ ok: true }>("/auth/logout", {
    method: "POST",
    token,
  });
}

export async function getCurrentAccount(token: string) {
  return apiRequest<AuthResponse>("/auth/me", {
    method: "GET",
    token,
  });
}

export async function acceptAccountConsents(
  token: string,
  payload: { consents: RegistrationConsentsPayload }
) {
  return apiRequest<{ ok: true; consentStatus: LegalConsentStatus }>("/account/consents/accept", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function getAdminOverview(token: string) {
  return apiRequest<AdminOverview>("/admin/overview", {
    method: "GET",
    token,
  });
}

export async function createAdminBackup(token: string) {
  return apiRequest<AdminBackupResponse>("/admin/backup", {
    method: "POST",
    token,
  });
}

export async function updateAdminUserStatus(token: string, userId: string, blocked: boolean) {
  return apiRequest<{ ok: true; user: AuthUser }>(`/admin/users/${userId}/status`, {
    method: "PATCH",
    token,
    body: { blocked },
  });
}

export async function resetAdminUserSessions(token: string, userId: string) {
  return apiRequest<{ ok: true; sessionsDeleted: number }>(`/admin/users/${userId}/sessions/reset`, {
    method: "POST",
    token,
  });
}

export async function deleteAdminUser(token: string, userId: string, confirmEmail: string) {
  return apiRequest<{ ok: true }>(`/admin/users/${userId}`, {
    method: "DELETE",
    token,
    body: { confirmEmail },
  });
}

export async function createAdminInvite(
  token: string,
  payload: { label?: string; maxUses?: number; code?: string }
) {
  return apiRequest<{ ok: true; invite: AdminBetaInvite; config: AdminConfigInfo }>("/admin/invites", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function updateAdminInvite(token: string, inviteId: string, payload: { active: boolean }) {
  return apiRequest<{ ok: true; invite: AdminBetaInvite; config: AdminConfigInfo }>(
    `/admin/invites/${inviteId}`,
    {
      method: "PATCH",
      token,
      body: payload,
    }
  );
}

export async function getAdminExport(token: string) {
  return apiRequest<AdminExport>("/admin/export", {
    method: "GET",
    token,
  });
}

export async function moderateForumPost(token: string, postId: string, status: ForumContentStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/posts/${postId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function moderateForumComment(token: string, commentId: string, status: ForumContentStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/comments/${commentId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function moderateForumReport(token: string, reportId: string, status: ForumReportStatus) {
  return apiRequest<{ ok: true; forumModeration: AdminForumModeration }>(
    `/admin/forum/reports/${reportId}`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function submitBetaFeedback(
  token: string,
  payload: { message: string; rating?: number | null; screen?: string; topic?: BetaFeedbackTopic | string | null }
) {
  return apiRequest<{ ok: true }>("/feedback", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function updateAdminFeedbackStatus(token: string, feedbackId: string, status: BetaFeedbackStatus) {
  return apiRequest<{ ok: true; feedback: AdminOverview["feedback"] }>(
    `/admin/feedback/${feedbackId}/status`,
    {
      method: "PATCH",
      token,
      body: { status },
    }
  );
}

export async function updateAdminFeatureFlag(token: string, key: string, enabled: boolean) {
  return apiRequest<{ ok: true; featureFlags: FeatureFlag[] }>(
    `/admin/feature-flags/${encodeURIComponent(key)}`,
    {
      method: "PATCH",
      token,
      body: { enabled },
    }
  );
}

export async function sendAnalyticsEvents(token: string, events: AnalyticsEventPayload[]) {
  return apiRequest<{ ok: true; accepted: number }>("/analytics/events", {
    method: "POST",
    token,
    body: { events },
  });
}

export async function getForumPosts(
  token: string,
  params: {
    tab?: string;
    search?: string;
    category?: string;
  } = {}
) {
  const searchParams = new URLSearchParams();

  if (params.tab) searchParams.set("tab", params.tab);
  if (params.search) searchParams.set("search", params.search);
  if (params.category) searchParams.set("category", params.category);

  const query = searchParams.toString();

  return apiRequest<ForumPostsResponse>(`/forum/posts${query ? `?${query}` : ""}`, {
    method: "GET",
    token,
  });
}

export async function createForumPost(
  token: string,
  payload: {
    title: string;
    content: string;
    category: string;
    tags: string[];
  }
) {
  return apiRequest<{ post: ForumPostRecord }>("/forum/posts", {
    method: "POST",
    token,
    body: payload,
  });
}

export async function getForumPost(token: string, postId: string) {
  return apiRequest<ForumPostDetail>(`/forum/posts/${postId}`, {
    method: "GET",
    token,
  });
}

export async function createForumComment(token: string, postId: string, content: string) {
  return apiRequest<{ comment: ForumCommentRecord; post: ForumPostRecord }>(
    `/forum/posts/${postId}/comments`,
    {
      method: "POST",
      token,
      body: { content },
    }
  );
}

export async function reportForumContent(
  token: string,
  payload: {
    targetType: "post" | "comment";
    targetId: string;
    reason: string;
    details?: string;
  }
) {
  return apiRequest<{ ok: true; reportId: string; duplicate?: boolean }>("/forum/reports", {
    method: "POST",
    token,
    body: payload,
  });
}

async function apiRequest<T>(
  path: string,
  options: {
    method: string;
    body?: unknown;
    token?: string;
    keepalive?: boolean;
  }
): Promise<T> {
  let response: Response;

  try {
    response = await fetch(`${API_URL}${path}`, {
      method: options.method,
      headers: {
        "Content-Type": "application/json",
        ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
      },
      keepalive: options.keepalive,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
  } catch {
    throw new Error("Не удалось подключиться к локальному серверу. Проверьте, что он запущен.");
  }

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data?.error || "Сервер временно недоступен.");
  }

  return data as T;
}

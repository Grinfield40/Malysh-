import { ChevronRight, Bell, Globe, Palette, Database, HelpCircle, Shield, Info } from "lucide-react";

interface SettingsScreenProps {
  onBack: () => void;
}

const settingsSections = [
  {
    title: "Основные",
    items: [
      { id: "notifications", icon: Bell, label: "Уведомления", value: "Включены" },
      { id: "language", icon: Globe, label: "Язык", value: "Русский" },
      { id: "theme", icon: Palette, label: "Тема", value: "Светлая" },
    ],
  },
  {
    title: "Данные",
    items: [
      { id: "data", icon: Database, label: "Управление данными" },
      { id: "privacy", icon: Shield, label: "Приватность и безопасность" },
    ],
  },
  {
    title: "Поддержка",
    items: [
      { id: "help", icon: HelpCircle, label: "Помощь" },
      { id: "about", icon: Info, label: "О приложении", value: "Версия 1.0.0" },
    ],
  },
];

export function SettingsScreen({ onBack }: SettingsScreenProps) {
  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-6 bg-gradient-to-b from-secondary/50 to-transparent sticky top-0 z-10 backdrop-blur-sm">
        <h1 className="text-2xl font-medium text-foreground">Настройки</h1>
      </div>

      <div className="px-6">
        {settingsSections.map((section, idx) => (
          <div key={section.title} className={idx > 0 ? "mt-8" : ""}>
            <h3 className="text-sm font-medium text-muted-foreground mb-3 px-2">
              {section.title}
            </h3>
            <div className="space-y-2">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
                  >
                    <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-foreground" />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="font-medium text-foreground">{item.label}</div>
                      {item.value && (
                        <div className="text-sm text-muted-foreground">{item.value}</div>
                      )}
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        <div className="mt-8 pt-6 border-t border-border">
          <button className="w-full h-12 rounded-xl text-destructive font-medium hover:bg-destructive/5 transition-all">
            Выйти из аккаунта
          </button>
        </div>
      </div>
    </div>
  );
}

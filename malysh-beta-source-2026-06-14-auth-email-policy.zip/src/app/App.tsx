import { Component, lazy, Suspense, useCallback, useEffect, useState, type ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertCircle, LogOut, RefreshCw } from "lucide-react";
import { Sidebar } from "./components/web/Sidebar";
import { TopBar } from "./components/web/TopBar";
import { SplashScreen } from "./components/web/SplashScreen";
import { MobileBottomNav } from "./components/web/MobileBottomNav";
import { BabyOnboardingScreen } from "./components/web/BabyOnboardingScreen";
import { BetaPrivacyBanner } from "./components/web/BetaPrivacyBanner";
import { CookieConsentBanner } from "./components/web/CookieConsentBanner";
import { AppScreenRenderer } from "./components/web/AppScreenRenderer";
import { LoadingPanel } from "./components/web/LoadingPanel";
import { Button } from "./components/ui/button";
import { Toaster } from "./components/ui/sonner";
import { useLocalStorageState } from "./lib/useLocalStorageState";
import {
  AuthSession,
  clearStoredSession,
  completeYandexLogin,
  FeatureFlag,
  flushAccountStorageSync,
  getCurrentAccount,
  getPublicConfig,
  getStoredSession,
  hydrateLocalAppStorage,
  logoutAccount,
  saveStoredSession,
  setAppStorageItem,
  syncAccountStorageItems,
  type LegalConsentStatus,
} from "./lib/accountApi";
import {
  BABY_ONBOARDING_STORAGE_KEY,
  BABY_PROFILE_STORAGE_KEY,
  type BabyProfile,
} from "./lib/babyProfile";
import { TRACKER_QUICK_ENTRY_STORAGE_KEY } from "./lib/careDiary";
import { PARENT_GOALS_STORAGE_KEY, type ParentGoalId } from "./lib/parentGoals";
import { buildUserProfileFromAuth } from "./lib/userProfile";
import { getGrowthStageById } from "./lib/growthStages";
import {
  flushAnalytics,
  flushCurrentScreenTime,
  installAnalyticsErrorTracking,
  trackError,
  trackEvent,
  trackScreenView,
} from "./lib/analytics";
import { notifyError, notifySuccess } from "./lib/notify";
import { AUTH_EMAIL_POLICY_ERROR } from "./lib/authEmailPolicy";
import {
  getGrowthStageIdFromPath,
  getScreenFromPath,
  guestProtectedScreens,
  legalScreenTypeByScreen,
  screenToPath,
  type Screen,
} from "./lib/routes";

const WebLegalScreen = lazy(() => import("./components/web/WebLegalScreen").then((module) => ({ default: module.WebLegalScreen })));
const LegalConsentGateScreen = lazy(() => import("./components/web/LegalConsentGateScreen").then((module) => ({ default: module.LegalConsentGateScreen })));

function readStoredBoolean(key: string) {
  try {
    return JSON.parse(window.localStorage.getItem(key) || "false") === true;
  } catch {
    return false;
  }
}

function hasStoredBabyProfile() {
  try {
    const rawProfile = window.localStorage.getItem(BABY_PROFILE_STORAGE_KEY);
    const profile = rawProfile ? (JSON.parse(rawProfile) as Partial<BabyProfile>) : null;

    return Boolean(
      profile &&
        typeof profile.name === "string" &&
        profile.name.trim() &&
        typeof profile.birthDate === "string" &&
        profile.birthDate.trim()
    );
  } catch {
    return false;
  }
}

function readBabyOnboardingState() {
  return readStoredBoolean(BABY_ONBOARDING_STORAGE_KEY) || hasStoredBabyProfile();
}

function clearYandexAuthQuery() {
  const params = new URLSearchParams(window.location.search);
  params.delete("malysh_yandex_code");
  params.delete("malysh_yandex_error");
  const nextSearch = params.toString();
  const nextUrl = `${window.location.pathname}${nextSearch ? `?${nextSearch}` : ""}${window.location.hash}`;

  window.history.replaceState(null, "", nextUrl);
}

function ServerIssueScreen({
  message,
  onRetry,
  onLogout,
}: {
  message: string;
  onRetry: () => void;
  onLogout: () => void;
}) {
  return (
    <div className="min-h-screen p-4 flex items-center justify-center bg-background">
      <div className="w-full max-w-xl rounded-3xl border border-border bg-card p-6 md:p-8 shadow-xl">
        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
          <AlertCircle className="h-7 w-7" />
        </div>
        <h1 className="mb-3 text-2xl md:text-3xl font-medium text-foreground">Сервер не отвечает</h1>
        <p className="mb-5 text-sm md:text-base leading-relaxed text-muted-foreground">
          {message || "Не получилось проверить аккаунт. Данные не удалены, можно повторить подключение."}
        </p>
        <div className="rounded-2xl border border-border bg-secondary/50 p-4 text-sm text-muted-foreground">
          Соединение с beta-сервером временно недоступно. Проверьте интернет и нажмите “Повторить”.
          Если ошибка повторяется, сообщите администратору beta.
        </div>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Button onClick={onRetry} className="h-12 rounded-2xl sm:flex-1">
            <RefreshCw className="mr-2 h-4 w-4" />
            Повторить
          </Button>
          <Button onClick={onLogout} variant="outline" className="h-12 rounded-2xl sm:flex-1">
            <LogOut className="mr-2 h-4 w-4" />
            Выйти
          </Button>
        </div>
      </div>
    </div>
  );
}

interface ScreenErrorBoundaryProps {
  children: ReactNode;
  screen: string;
  onRecover: () => void;
}

interface ScreenErrorBoundaryState {
  hasError: boolean;
}

class ScreenErrorBoundary extends Component<ScreenErrorBoundaryProps, ScreenErrorBoundaryState> {
  state: ScreenErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    trackError(error, {
      screen: this.props.screen,
      source: "screen_boundary",
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 md:p-8">
          <div className="rounded-3xl border border-border bg-card p-6 md:p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
              <AlertCircle className="h-6 w-6" />
            </div>
            <h2 className="mb-2 text-2xl font-medium text-foreground">Раздел не открылся</h2>
            <p className="mb-5 text-sm text-muted-foreground">
              Приложение осталось на месте. Вернемся на главную, а проблемный экран можно проверить отдельно.
            </p>
            <Button
              onClick={() => {
                this.setState({ hasError: false });
                this.props.onRecover();
              }}
              className="h-11 rounded-2xl"
            >
              На главную
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>(() =>
    getScreenFromPath(window.location.pathname)
  );
  const [selectedGrowthStageId, setSelectedGrowthStageId] = useState(() =>
    getGrowthStageIdFromPath(window.location.pathname)
  );
  const [isLoading, setIsLoading] = useState(true);
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => getStoredSession());
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [authBootError, setAuthBootError] = useState("");
  const [authRetryKey, setAuthRetryKey] = useState(0);
  const [legalConsentStatus, setLegalConsentStatus] = useState<LegalConsentStatus | null>(null);
  const [isBabyOnboarded, setIsBabyOnboarded] = useLocalStorageState(BABY_ONBOARDING_STORAGE_KEY, false);
  const [isSavingBabyOnboarding, setIsSavingBabyOnboarding] = useState(false);
  const [babyOnboardingSaveError, setBabyOnboardingSaveError] = useState("");
  const [featureFlags, setFeatureFlags] = useState<FeatureFlag[]>([]);
  const [isGuestAuthOpen, setIsGuestAuthOpen] = useState(false);
  const [authReturnScreen, setAuthReturnScreen] = useState<Screen | null>(null);

  const navigateTo = useCallback((screen: string) => {
    const nextScreen = screen in screenToPath ? (screen as Screen) : "home";
    const nextPath = screenToPath[nextScreen];

    if (!authSession && guestProtectedScreens.has(nextScreen)) {
      setAuthReturnScreen(nextScreen);
    } else if (!guestProtectedScreens.has(nextScreen)) {
      setAuthReturnScreen(null);
      setIsGuestAuthOpen(false);
    }

    if (window.location.pathname !== nextPath) {
      window.history.pushState(null, "", nextPath);
    }

    setCurrentScreen(nextScreen);
    window.scrollTo(0, 0);
  }, [authSession]);

  const openGrowthStage = useCallback((stageId: string) => {
    const nextStage = getGrowthStageById(stageId);
    const nextPath = `${screenToPath["growth-stage"]}/${encodeURIComponent(nextStage.id)}`;

    if (window.location.pathname !== nextPath) {
      window.history.pushState(null, "", nextPath);
    }

    setSelectedGrowthStageId(nextStage.id);
    setCurrentScreen("growth-stage");
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 900);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      document.documentElement.classList.add("dark");
    }
  }, []);

  useEffect(() => {
    installAnalyticsErrorTracking(() => currentScreen);
  }, [currentScreen]);

  useEffect(() => {
    let isCancelled = false;

    getPublicConfig()
      .then((config) => {
        if (!isCancelled) {
          setFeatureFlags(config.featureFlags || []);
        }
      })
      .catch(() => undefined);

    return () => {
      isCancelled = true;
    };
  }, []);

  useEffect(() => {
    const storedSession = getStoredSession();
    setAuthBootError("");

    if (!storedSession) {
      setLegalConsentStatus(null);
      setIsAuthReady(true);
      return;
    }

    let isCancelled = false;

    getCurrentAccount(storedSession.token)
      .then((response) => {
        if (isCancelled) return;

        const nextSession = { token: storedSession.token, user: response.user, consentStatus: response.consentStatus };
        const profile = buildUserProfileFromAuth(response.user, response.storage?.["mvp.user.profile"]);
        saveStoredSession(nextSession);
        hydrateLocalAppStorage(response.storage || {}, { userId: response.user.id });
        setAppStorageItem("mvp.user.profile", profile);
        setAuthSession(nextSession);
        setLegalConsentStatus(response.consentStatus || null);
        const nextBabyOnboarded = readBabyOnboardingState();

        if (nextBabyOnboarded && !readStoredBoolean(BABY_ONBOARDING_STORAGE_KEY)) {
          setAppStorageItem(BABY_ONBOARDING_STORAGE_KEY, true);
          void syncAccountStorageItems({ [BABY_ONBOARDING_STORAGE_KEY]: true }).catch(() => undefined);
        }

        setIsBabyOnboarded(nextBabyOnboarded);
      })
      .catch((error) => {
        if (isCancelled) return;

        const message =
          error instanceof Error
            ? error.message
            : "Не получилось проверить аккаунт. Проверьте локальный сервер.";

        if (message.includes("Нужно войти")) {
          clearStoredSession();
          setAuthSession(null);
          setLegalConsentStatus(null);
        } else {
          setAuthSession(storedSession);
          setLegalConsentStatus(storedSession.consentStatus || null);
          setAuthBootError(message);
        }
      })
      .finally(() => {
        if (!isCancelled) {
          setIsAuthReady(true);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [authRetryKey, setIsBabyOnboarded]);

  useEffect(() => {
    const handlePopState = () => {
      const nextScreen = getScreenFromPath(window.location.pathname);
      if (nextScreen === "growth-stage") {
        setSelectedGrowthStageId(getGrowthStageIdFromPath(window.location.pathname));
      }
      setCurrentScreen(nextScreen);
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    if (!authSession || legalConsentStatus?.required || !isBabyOnboarded || !isAuthReady || isLoading) return;

    trackScreenView(currentScreen);
  }, [authSession, currentScreen, isAuthReady, isBabyOnboarded, isLoading, legalConsentStatus?.required]);

  useEffect(() => {
    if (!authSession) return;

    const flushPendingUserData = (keepalive = false) => {
      void flushAccountStorageSync({ keepalive });
    };

    const handleVisibilityChange = () => {
      if (document.hidden) {
        flushCurrentScreenTime();
        flushPendingUserData(true);
        void flushAnalytics();
      }
    };
    const handleBeforeUnload = () => {
      flushCurrentScreenTime();
      flushPendingUserData(true);
      void flushAnalytics();
    };
    const handlePageHide = () => {
      flushCurrentScreenTime();
      flushPendingUserData(true);
      void flushAnalytics();
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("beforeunload", handleBeforeUnload);
    window.addEventListener("pagehide", handlePageHide);

    return () => {
      flushCurrentScreenTime();
      flushPendingUserData();
      void flushAnalytics();
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("beforeunload", handleBeforeUnload);
      window.removeEventListener("pagehide", handlePageHide);
    };
  }, [authSession]);

  const handleAuth = (session: AuthSession) => {
    setAuthSession(session);
    setLegalConsentStatus(session.consentStatus || null);
    const nextBabyOnboarded = readBabyOnboardingState();

    if (nextBabyOnboarded && !readStoredBoolean(BABY_ONBOARDING_STORAGE_KEY)) {
      setAppStorageItem(BABY_ONBOARDING_STORAGE_KEY, true);
      void syncAccountStorageItems({ [BABY_ONBOARDING_STORAGE_KEY]: true }).catch(() => undefined);
    }

    setIsBabyOnboarded(nextBabyOnboarded);
    const nextScreen = nextBabyOnboarded && authReturnScreen ? authReturnScreen : "home";
    const nextPath = screenToPath[nextScreen];

    setIsGuestAuthOpen(false);
    setAuthReturnScreen(null);

    if (window.location.pathname !== nextPath) {
      window.history.pushState(null, "", nextPath);
    }

    setCurrentScreen(nextScreen);
    window.scrollTo(0, 0);
  };

  const handleBabyOnboardingComplete = async (profile: BabyProfile, goals: ParentGoalId[]) => {
    const onboardingStorage = {
      [BABY_PROFILE_STORAGE_KEY]: profile,
      [PARENT_GOALS_STORAGE_KEY]: goals,
      [BABY_ONBOARDING_STORAGE_KEY]: true,
    };

    setBabyOnboardingSaveError("");
    setIsSavingBabyOnboarding(true);

    try {
      Object.entries(onboardingStorage).forEach(([key, value]) => {
        setAppStorageItem(key, value);
      });

      await syncAccountStorageItems(onboardingStorage);

      setIsBabyOnboarded(true);
      trackEvent("onboarding_completed", {
        meta: {
          stage: profile.stage,
          goalsCount: goals.length,
        },
        immediate: true,
      });
      if (!window.localStorage.getItem(TRACKER_QUICK_ENTRY_STORAGE_KEY)) {
        setAppStorageItem(TRACKER_QUICK_ENTRY_STORAGE_KEY, "feeding");
      }

      navigateTo("tracker");
    } catch (error) {
      const message = "Не удалось сохранить профиль ребенка на сервере. Проверьте интернет и нажмите кнопку еще раз.";

      setBabyOnboardingSaveError(message);
      notifyError(new Error(message));
      trackError(error instanceof Error ? error : new Error(message), {
        screen: "baby-onboarding",
        source: "onboarding_save",
      });
    } finally {
      setIsSavingBabyOnboarding(false);
    }
  };

  const handleLogout = () => {
    const token = authSession?.token;

    trackEvent("auth_logout", {
      screen: currentScreen,
      immediate: true,
    });

    if (token) {
      void logoutAccount(token).catch(() => undefined);
    }

    clearStoredSession();
    setAuthSession(null);
    setLegalConsentStatus(null);
    setAuthBootError("");
    setIsGuestAuthOpen(false);
    setAuthReturnScreen(null);
    navigateTo("home");
    notifySuccess("Вы вышли из аккаунта");
  };

  const handleLegalConsentAccepted = (consentStatus: LegalConsentStatus) => {
    setLegalConsentStatus(consentStatus);
    setAuthSession((current) => {
      if (!current) return current;

      const nextSession = { ...current, consentStatus };
      saveStoredSession(nextSession);

      return nextSession;
    });
    navigateTo("home");
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const yandexCode = params.get("malysh_yandex_code");
    const yandexError = params.get("malysh_yandex_error");

    if (!yandexCode && !yandexError) return;

    if (yandexError) {
      clearYandexAuthQuery();
      notifyError(
        new Error(
          yandexError === "unsupported_email_domain"
            ? AUTH_EMAIL_POLICY_ERROR
            : "Не получилось войти через Яндекс ID. Попробуйте еще раз или войдите по email."
        )
      );
      return;
    }

    let isCancelled = false;

    setIsAuthReady(false);
    setAuthBootError("");

    completeYandexLogin(yandexCode || "")
      .then((response) => {
        if (isCancelled) return;

        const session = { token: response.token, user: response.user, consentStatus: response.consentStatus };
        const profile = buildUserProfileFromAuth(response.user, response.storage?.["mvp.user.profile"]);

        saveStoredSession(session);
        hydrateLocalAppStorage(response.storage || {}, { userId: response.user.id });
        setAppStorageItem("mvp.user.profile", profile);
        setAuthSession(session);
        setLegalConsentStatus(response.consentStatus || null);
        setIsGuestAuthOpen(false);
        setAuthReturnScreen(null);

        const nextBabyOnboarded = readBabyOnboardingState();

        if (nextBabyOnboarded && !readStoredBoolean(BABY_ONBOARDING_STORAGE_KEY)) {
          setAppStorageItem(BABY_ONBOARDING_STORAGE_KEY, true);
          void syncAccountStorageItems({ [BABY_ONBOARDING_STORAGE_KEY]: true }).catch(() => undefined);
        }

        setIsBabyOnboarded(nextBabyOnboarded);
        trackEvent("auth_login", {
          meta: {
            provider: "yandex",
            role: response.user.role,
            storageKeys: Object.keys(response.storage || {}).length,
          },
          immediate: true,
        });
        notifySuccess("Вы вошли через Яндекс ID");
      })
      .catch((error) => {
        if (isCancelled) return;

        const message = error instanceof Error
          ? error.message
          : "Не получилось войти через Яндекс ID. Попробуйте еще раз.";

        notifyError(new Error(message));
      })
      .finally(() => {
        if (!isCancelled) {
          clearYandexAuthQuery();
          setIsAuthReady(true);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [setIsBabyOnboarded]);

  const handleRetryAuthCheck = () => {
    setIsAuthReady(false);
    setAuthRetryKey((value) => value + 1);
  };

  const featureEnabled = useCallback(
    (key: string) => {
      const flag = featureFlags.find((item) => item.key === key);

      return flag ? flag.enabled : true;
    },
    [featureFlags]
  );

  const legalScreenType = legalScreenTypeByScreen[currentScreen as keyof typeof legalScreenTypeByScreen];
  const isLegalScreen = Boolean(legalScreenType);
  const isNotFoundScreen = currentScreen === "not-found";
  const isAuthenticated = Boolean(authSession);
  const isGuestBlockedScreen = !isAuthenticated && guestProtectedScreens.has(currentScreen);
  const authPromptScreen = authReturnScreen || (guestProtectedScreens.has(currentScreen) ? currentScreen : "home");
  const shouldShowGuestAuth = !isAuthenticated && (isGuestAuthOpen || isGuestBlockedScreen);
  const requiresLegalConsent = Boolean(authSession && legalConsentStatus?.required);
  const openGuestAuth = (returnScreen: Screen = currentScreen) => {
    setAuthReturnScreen(returnScreen);
    setIsGuestAuthOpen(true);
  };
  const closeGuestAuth = () => {
    setIsGuestAuthOpen(false);

    if (isGuestBlockedScreen) {
      navigateTo("home");
    } else {
      setAuthReturnScreen(null);
    }
  };

  return (
    <div className="size-full bg-background">
      <Toaster position="top-center" richColors closeButton />
      {/* Splash Screen */}
      <AnimatePresence>
        {isLoading && <SplashScreen />}
      </AnimatePresence>

      {!isAuthReady ? (
        <div className="min-h-screen flex items-center justify-center text-muted-foreground">
          Проверяем аккаунт...
        </div>
      ) : authBootError && authSession ? (
        <ServerIssueScreen
          message={authBootError}
          onRetry={handleRetryAuthCheck}
          onLogout={handleLogout}
        />
      ) : requiresLegalConsent && isLegalScreen ? (
        <Suspense fallback={<LoadingPanel label="Открываем правила beta..." />}>
          <WebLegalScreen type={legalScreenType || "privacy"} onNavigate={navigateTo} />
        </Suspense>
      ) : requiresLegalConsent ? (
        <Suspense fallback={<LoadingPanel label="Открываем правила beta..." />}>
          <LegalConsentGateScreen
            session={authSession}
            consentStatus={legalConsentStatus || undefined}
            onAccepted={handleLegalConsentAccepted}
            onLogout={handleLogout}
            onNavigate={navigateTo}
          />
        </Suspense>
      ) : authSession && !isBabyOnboarded ? (
        <BabyOnboardingScreen
          onComplete={handleBabyOnboardingComplete}
          onLogout={handleLogout}
          isSaving={isSavingBabyOnboarding}
          saveError={babyOnboardingSaveError}
        />
      ) : (
        <>
          <Sidebar
            activeScreen={currentScreen}
            onNavigate={navigateTo}
            isAuthenticated={isAuthenticated}
            currentUser={authSession?.user || null}
          />
          <TopBar
            onProfileClick={() => navigateTo("profile")}
            onNavigate={navigateTo}
            isAuthenticated={isAuthenticated}
            currentUser={authSession?.user || null}
            onAuthClick={() => openGuestAuth(currentScreen)}
          />
          <MobileBottomNav
            activeScreen={currentScreen}
            onNavigate={navigateTo}
            isAuthenticated={isAuthenticated}
            currentUser={authSession?.user || null}
          />

      <main className="md:ml-[280px] min-h-screen pt-16 md:pt-20 pb-20 md:pb-0">
        <BetaPrivacyBanner hidden={currentScreen === "home" || isLegalScreen || isNotFoundScreen || shouldShowGuestAuth || !featureEnabled("betaBanner")} onNavigate={navigateTo} />
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15, ease: "easeInOut" }}
          >
            <ScreenErrorBoundary key={currentScreen} screen={currentScreen} onRecover={() => navigateTo("home")}>
              <AppScreenRenderer
                currentScreen={currentScreen}
                selectedGrowthStageId={selectedGrowthStageId}
                shouldShowGuestAuth={shouldShowGuestAuth}
                authPromptScreen={authPromptScreen}
                isAuthenticated={isAuthenticated}
                legalScreenType={legalScreenType}
                featureEnabled={featureEnabled}
                onAuth={handleAuth}
                onCloseGuestAuth={closeGuestAuth}
                onLogout={handleLogout}
                onNavigate={navigateTo}
                onOpenGuestAuth={openGuestAuth}
                onOpenGrowthStage={openGrowthStage}
              />
            </ScreenErrorBoundary>
          </motion.div>
        </AnimatePresence>
        <CookieConsentBanner
          hidden={isLoading || isLegalScreen || shouldShowGuestAuth}
          onNavigate={navigateTo}
        />
      </main>
        </>
      )}
    </div>
  );
}

import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { Logo } from "../Logo";

interface GrowthTimelineScreenProps {
  onStageClick?: (stageId: string) => void;
}

const stages = [
  {
    id: "1week",
    age: "1 неделя",
    emoji: "👶",
    title: "Первые дни жизни",
    description: "Адаптация к новому миру, сон 18-20 часов в сутки, кормление каждые 2-3 часа",
    skills: ["Сосательный рефлекс", "Хватательный рефлекс", "Реагирует на громкие звуки"],
    color: "from-purple-200/50 to-pink-200/50",
    position: 0,
  },
  {
    id: "1month",
    age: "1 месяц",
    emoji: "🍼",
    title: "Первые улыбки",
    description: "Начинает фокусировать взгляд на лицах, появляется социальная улыбка",
    skills: ["Поднимает голову на животе", "Следит за предметами", "Издает звуки"],
    color: "from-pink-200/50 to-purple-200/50",
    position: 1,
  },
  {
    id: "2months",
    age: "2 месяца",
    emoji: "😊",
    title: "Активное общение",
    description: "Улыбается в ответ, начинает гулить, следит за движущимися предметами",
    skills: ["Держит голову 30 секунд", "Гулит 'а-а', 'у-у'", "Узнает родителей"],
    color: "from-purple-200/50 to-blue-200/50",
    position: 2,
  },
  {
    id: "3months",
    age: "3 месяца",
    emoji: "🤲",
    title: "Активные ручки",
    description: "Уверенно держит голову, тянется к игрушкам, смеется в голос",
    skills: ["Держит голову вертикально", "Хватает игрушки", "Опирается на предплечья"],
    color: "from-blue-200/50 to-cyan-200/50",
    position: 3,
  },
  {
    id: "4months",
    age: "4 месяца",
    emoji: "🔄",
    title: "Перевороты",
    description: "Переворачивается со спины на живот, активно гулит, смеется",
    skills: ["Переворачивается", "Смеется в голос", "Захватывает предметы двумя руками"],
    color: "from-cyan-200/50 to-purple-200/50",
    position: 4,
  },
  {
    id: "5months",
    age: "5 месяцев",
    emoji: "👐",
    title: "Захват и исследование",
    description: "Хватает и перекладывает игрушки, различает своих и чужих",
    skills: ["Переворачивается в обе стороны", "Тянет все в рот", "Узнает близких"],
    color: "from-purple-200/50 to-pink-200/50",
    position: 5,
  },
  {
    id: "6months",
    age: "6 месяцев",
    emoji: "🥄",
    title: "Первый прикорм",
    description: "Сидит с поддержкой, начинает ползать по-пластунски, интерес к еде",
    skills: ["Сидит с опорой", "Ползает по-пластунски", "Пробует прикорм"],
    color: "from-pink-200/50 to-orange-200/50",
    position: 6,
  },
  {
    id: "7months",
    age: "7 месяцев",
    emoji: "🪑",
    title: "Сижу самостоятельно",
    description: "Сидит без поддержки, активно ползает, лепечет слоги 'ма-ма', 'ба-ба'",
    skills: ["Сидит самостоятельно", "Перекладывает игрушки", "Лепечет слоги"],
    color: "from-orange-200/50 to-yellow-200/50",
    position: 7,
  },
  {
    id: "8months",
    age: "8 месяцев",
    emoji: "🐛",
    title: "Активное ползание",
    description: "Ползает на четвереньках, встает у опоры, играет в 'ку-ку'",
    skills: ["Ползает на четвереньках", "Встает у опоры", "Понимает 'нельзя'"],
    color: "from-yellow-200/50 to-green-200/50",
    position: 8,
  },
  {
    id: "9months",
    age: "9 месяцев",
    emoji: "🧸",
    title: "Исследователь",
    description: "Ходит вдоль опоры, играет в ладушки, показывает пальцем",
    skills: ["Стоит у опоры", "Играет в ладушки", "Повторяет действия"],
    color: "from-green-200/50 to-emerald-200/50",
    position: 9,
  },
  {
    id: "10months",
    age: "10 месяцев",
    emoji: "🚶",
    title: "Шаги с опорой",
    description: "Делает первые шаги с поддержкой, понимает простые просьбы",
    skills: ["Ходит с поддержкой", "Понимает 'дай', 'на'", "Машет 'пока-пока'"],
    color: "from-emerald-200/50 to-purple-200/50",
    position: 10,
  },
  {
    id: "11months",
    age: "11 месяцев",
    emoji: "👋",
    title: "Готов к ходьбе",
    description: "Стоит без опоры несколько секунд, говорит первые слова",
    skills: ["Стоит без опоры", "Говорит 1-2 слова", "Пьет из чашки"],
    color: "from-purple-200/50 to-pink-200/50",
    position: 11,
  },
  {
    id: "1year",
    age: "12 месяцев (1 год)",
    emoji: "🎂",
    title: "Первый день рождения!",
    description: "Делает первые самостоятельные шаги, говорит 2-10 слов, указывает на предметы",
    skills: ["Ходит самостоятельно", "Говорит 2-10 слов", "Пьет из чашки"],
    color: "from-pink-200/50 to-yellow-200/50",
    position: 12,
  },
  {
    id: "18months",
    age: "1.5 года (18 месяцев)",
    emoji: "🏃",
    title: "Бегаю и говорю",
    description: "Уверенно бегает, словарный запас 10-50 слов, начинает проситься на горшок",
    skills: ["Бегает", "Словарь 10-50 слов", "Ест ложкой"],
    color: "from-yellow-200/50 to-orange-200/50",
    position: 13,
  },
  {
    id: "2years",
    age: "2 года (24 месяца)",
    emoji: "💬",
    title: "Говорю фразами",
    description: "Составляет фразы из 2-4 слов, активные ролевые игры, знает части тела",
    skills: ["Фразы из 2-4 слов", "Играет с другими детьми", "Моет руки"],
    color: "from-orange-200/50 to-red-200/50",
    position: 14,
  },
  {
    id: "2.5years",
    age: "2.5 года (30 месяцев)",
    emoji: "🎪",
    title: "Я сам делаю!",
    description: "Активное желание независимости, одевается с помощью, знает цвета",
    skills: ["Одевается частично сам", "Знает основные цвета", "Строит башни"],
    color: "from-red-200/50 to-purple-200/50",
    position: 15,
  },
  {
    id: "3years",
    age: "3 года (36 месяцев)",
    emoji: "🎨",
    title: "Творец и фантазер",
    description: "Рисует круги и линии, развернутая речь, сложные ролевые игры",
    skills: ["Рисует круги", "Развернутая речь", "Играет в сюжетные игры"],
    color: "from-purple-200/50 to-blue-200/50",
    position: 16,
  },
  {
    id: "3.5years",
    age: "3.5 года (42 месяца)",
    emoji: "🎭",
    title: "Выдумщик и мечтатель",
    description: "Богатая фантазия, задает много вопросов 'почему?', дружит с детьми",
    skills: ["Сложные сюжеты игр", "Задает вопросы", "Делится игрушками"],
    color: "from-blue-200/50 to-cyan-200/50",
    position: 17,
  },
  {
    id: "4years",
    age: "4 года (48 месяцев)",
    emoji: "🌟",
    title: "Большой почемучка",
    description: "Считает до 10, рассказывает истории, активное социальное взаимодействие",
    skills: ["Считает до 10", "Рассказывает истории", "Играет по правилам"],
    color: "from-cyan-200/50 to-green-200/50",
    position: 18,
  },
];

export function GrowthTimelineScreen({ onStageClick }: GrowthTimelineScreenProps) {
  return (
    <div className="p-4 md:p-8 pt-20 md:pt-8 max-w-[1400px] mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8 md:mb-16"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="inline-block mb-4 md:mb-6 bg-white/80 rounded-2xl md:rounded-3xl p-3 md:p-4 shadow-lg"
        >
          <Logo size={64} />
        </motion.div>
        <h1 className="text-2xl md:text-5xl font-medium text-foreground mb-3 md:mb-4 px-4">
          Развитие малыша
        </h1>
        <p className="text-sm md:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
          Следите за ростом и развитием вашего ребенка от первых дней до четырех лет
        </p>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 inline-block bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20 rounded-full px-6 py-2"
        >
          <span className="text-sm md:text-base font-medium text-foreground">
            {stages.length} этапов развития
          </span>
        </motion.div>
      </motion.div>

      {/* Timeline */}
      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary/20 via-accent/20 to-primary/20 md:-translate-x-1/2 rounded-full" />

        {/* Stages */}
        <div className="space-y-8 md:space-y-12">
          {stages.map((stage, idx) => {
            const isLeft = idx % 2 === 0;

            return (
              <motion.div
                key={stage.id}
                initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05, duration: 0.5 }}
                className="relative"
              >
                {/* Mobile: simple vertical layout */}
                <div className="md:hidden pl-14">
                  <motion.div
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onStageClick?.(stage.id)}
                    className="cursor-pointer"
                  >
                    <div className={`bg-gradient-to-br ${stage.color} dark:from-primary/20 dark:to-accent/20 backdrop-blur-sm border-2 border-white/50 dark:border-primary/30 rounded-2xl p-4 shadow-lg`}>
                      <div className="flex items-start gap-3 mb-3">
                        <div className="w-14 h-14 bg-white dark:bg-card rounded-xl flex items-center justify-center text-3xl flex-shrink-0 shadow-lg">
                          {stage.emoji}
                        </div>
                        <div className="flex-1">
                          <div className="text-xs font-medium text-primary mb-1">{stage.age}</div>
                          <h3 className="text-base font-medium text-foreground mb-1">{stage.title}</h3>
                          <p className="text-xs text-muted-foreground line-clamp-2">{stage.description}</p>
                        </div>
                      </div>
                      {(stage as any).skills && (
                        <div className="flex flex-wrap gap-1 mb-2">
                          {(stage as any).skills.slice(0, 2).map((skill: string, i: number) => (
                            <span key={i} className="text-[10px] bg-white/60 dark:bg-primary/20 text-foreground px-2 py-0.5 rounded-full">
                              {skill}
                            </span>
                          ))}
                        </div>
                      )}
                      <button className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                        Подробнее
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </motion.div>

                  {/* Mobile Timeline Dot */}
                  <div className="absolute left-6 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-gradient-to-br from-primary to-accent rounded-full border-2 border-white shadow-lg z-10" />
                </div>

                {/* Desktop: zigzag layout */}
                <div className={`hidden md:flex items-center ${isLeft ? "justify-start" : "justify-end"}`}>
                  <motion.div
                    whileHover={{ scale: 1.05, y: -8 }}
                    onClick={() => onStageClick?.(stage.id)}
                    className={`w-[48%] cursor-pointer ${isLeft ? "mr-auto" : "ml-auto"}`}
                  >
                    <div className={`bg-gradient-to-br ${stage.color} dark:from-primary/20 dark:to-accent/20 backdrop-blur-sm border-2 border-white/50 dark:border-primary/30 rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all`}>
                      <div className="flex items-start gap-6 mb-5">
                        <motion.div
                          whileHover={{ rotate: [0, -10, 10, 0] }}
                          transition={{ duration: 0.5 }}
                          className="w-20 h-20 bg-white/80 dark:bg-card rounded-2xl flex items-center justify-center text-5xl flex-shrink-0 shadow-lg"
                        >
                          {stage.emoji}
                        </motion.div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-primary mb-2">{stage.age}</div>
                          <h3 className="text-2xl font-medium text-foreground mb-3">{stage.title}</h3>
                          <p className="text-muted-foreground mb-4 leading-relaxed">{stage.description}</p>
                        </div>
                      </div>
                      {(stage as any).skills && (
                        <div className="mb-4">
                          <div className="text-xs font-medium text-foreground/70 mb-2">Ключевые навыки:</div>
                          <div className="flex flex-wrap gap-2">
                            {(stage as any).skills.map((skill: string, i: number) => (
                              <span key={i} className="text-sm bg-white/70 dark:bg-primary/20 text-foreground px-3 py-1.5 rounded-full">
                                ✓ {skill}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      <button className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:gap-3 transition-all">
                        Подробнее
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>

                  {/* Desktop Timeline Dot */}
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: idx * 0.05 + 0.2 }}
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-gradient-to-br from-primary to-accent rounded-full border-4 border-white shadow-lg z-10"
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Bottom CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-12 md:mt-20 text-center"
      >
        <div className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-2xl md:rounded-3xl p-6 md:p-12 max-w-3xl mx-auto">
          <h3 className="text-lg md:text-2xl font-medium text-foreground mb-3 md:mb-4">
            Каждый ребенок уникален
          </h3>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            Это примерные этапы развития. Если у вас есть вопросы или переживания — обратитесь к педиатру. Вы справляетесь отлично! 💜
          </p>
        </div>
      </motion.div>
    </div>
  );
}

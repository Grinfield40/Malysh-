# Локальный сервер Малыш+

## Запуск на своем компьютере

```powershell
cd C:\Users\aleks\Documents\Codex\2026-05-12\new-chat\design-from-code
.\start-server.cmd
```

После запуска сайт будет доступен локально:

```text
http://localhost:8787
```

С другого устройства в той же Wi-Fi сети:

```text
http://IP_ВАШЕГО_КОМПЬЮТЕРА:8787
```

IP можно посмотреть в PowerShell:

```powershell
ipconfig
```

Нужен IPv4-адрес вашей активной сети.

## Что делает команда

- собирает сайт в `dist`;
- запускает один Node-сервер;
- сервер отдает и сайт, и API;
- SQLite-база хранится в `server/data/app.db`.

## Backup

```powershell
npm.cmd run backup
```

## Важно перед доступом из интернета

Для доступа извне понадобятся firewall/router-настройки или туннель/VPS. Перед этим стоит включить HTTPS, домен и более строгие настройки безопасности.

import { existsSync, statSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(join(__dirname, ".."));
const envPath = join(projectRoot, ".env");
const hasEnv = loadEnvFile(envPath);
const args = process.argv.slice(2);
const target = args.includes("--vps") ? "vps" : args.includes("--closed-beta") ? "closed-beta" : "local";
const problems = [];
const warnings = [];
const passed = [];

checkFile("package-lock.json");
checkFile("dist/index.html", "Сначала соберите сайт: npm.cmd run build");
checkFile("deploy/systemd/malysh.service.example");
checkFile("deploy/nginx/malysh.conf.example");
checkFile("deploy/cron/malysh-backup.cron.example");
checkFile("deploy/scripts/vps-first-install.sh.example");
checkFile("deploy/scripts/vps-update-release.sh.example");
checkFile("deploy/scripts/vps-direct-access.sh");
checkFile("BETA_PACKAGE.md");
checkFile("DIRECT_PUBLIC_ACCESS.md");
checkFile("KNOWN_STUBS.md");
checkFile("CLOSED_BETA.md", "После подготовки закрытой беты должен быть CLOSED_BETA.md");

if (!hasEnv) {
  warn(".env не найден. Для локального режима это допустимо, для VPS нужно создать .env из .env.production.example.");
} else {
  pass(".env найден");
}

const registrationMode = env("MALYSH_REGISTRATION_MODE", "open");
const inviteCode = env("MALYSH_BETA_INVITE_CODE", "");

if (target === "closed-beta" || target === "vps") {
  requireCheck(
    ["open", "closed", "disabled"].includes(registrationMode),
    "MALYSH_REGISTRATION_MODE должен быть open, closed или disabled."
  );
  requirePositiveEnvNumber("MALYSH_AUTH_RATE_LIMIT_WINDOW_MS", "900000");
  requirePositiveEnvNumber("MALYSH_AUTH_LOGIN_IP_LIMIT", "30");
  requirePositiveEnvNumber("MALYSH_AUTH_LOGIN_EMAIL_LIMIT", "12");
  requirePositiveEnvNumber("MALYSH_AUTH_REGISTER_IP_LIMIT", "10");
  requirePositiveEnvNumber("MALYSH_MAX_JSON_BODY_BYTES", "12582912");
  requirePositiveEnvNumber("MALYSH_MAX_STORAGE_KEYS", "80");
  requirePositiveEnvNumber("MALYSH_MAX_STORAGE_VALUE_BYTES", "8388608");
  requirePositiveEnvNumber("MALYSH_MAX_FRIDGE_CARDS", "24");
  requirePositiveEnvNumber("MALYSH_MAX_FRIDGE_IMAGES", "6");
  requirePositiveEnvNumber("MALYSH_MAX_FRIDGE_IMAGE_BYTES", "2500000");
  requirePositiveEnvNumber("MALYSH_MAX_FRIDGE_TOTAL_IMAGE_BYTES", "6000000");
  requirePositiveEnvNumber("MALYSH_MAX_CLOUD_FRIDGE_TOTAL_BYTES", "15000000");
  requirePositiveEnvNumber("MALYSH_FORUM_TITLE_MAX_LENGTH", "160");
  requirePositiveEnvNumber("MALYSH_FORUM_POST_MAX_LENGTH", "4000");
  requirePositiveEnvNumber("MALYSH_FORUM_COMMENT_MAX_LENGTH", "2000");
  requirePositiveEnvNumber("MALYSH_FORUM_REPORT_DETAILS_MAX_LENGTH", "1000");
}

if (target === "closed-beta") {
  requireCheck(
    registrationMode === "closed",
    "Для закрытой беты поставьте MALYSH_REGISTRATION_MODE=closed."
  );
  requireCheck(
    inviteCode.length >= 8 && inviteCode !== "change-this-invite-code",
    "Для закрытой беты нужен MALYSH_BETA_INVITE_CODE длиной хотя бы 8 символов."
  );
}

if (target === "vps") {
  const publicUrl = env("MALYSH_PUBLIC_URL", "");
  const allowedOrigins = env("MALYSH_ALLOWED_ORIGINS", "");
  const dbFile = env("MALYSH_DB_FILE", "");
  const mediaDir = env("MALYSH_MEDIA_DIR", "");
  const backupDir = env("MALYSH_BACKUP_DIR", "");

  requireCheck(env("NODE_ENV") === "production", "На VPS нужно NODE_ENV=production.");
  requireCheck(
    env("MALYSH_HOST") === "127.0.0.1" || env("MALYSH_HOST") === "localhost",
    "Node на VPS должен слушать localhost, а наружу должен смотреть nginx/Caddy."
  );
  requireCheck(/^https:\/\//.test(publicUrl), "MALYSH_PUBLIC_URL должен быть HTTPS-доменом.");
  requireCheck(!/example\.com/i.test(publicUrl), "Замените example.com на реальный домен.");
  requireCheck(allowedOrigins && !allowedOrigins.includes("*"), "MALYSH_ALLOWED_ORIGINS должен быть конкретным доменом без *.");
  requireCheck(allowedOrigins.includes(publicUrl), "MALYSH_ALLOWED_ORIGINS должен содержать MALYSH_PUBLIC_URL.");
  requireCheck(env("MALYSH_HEALTH_DETAILS") === "false", "На VPS поставьте MALYSH_HEALTH_DETAILS=false.");
  requireCheck(looksAbsolute(dbFile), "MALYSH_DB_FILE должен быть абсолютным путем, например /var/lib/malysh/app.db.");
  requireCheck(looksAbsolute(mediaDir), "MALYSH_MEDIA_DIR должен быть абсолютным путем, например /var/lib/malysh/media.");
  requireCheck(looksAbsolute(backupDir), "MALYSH_BACKUP_DIR должен быть абсолютным путем, например /var/backups/malysh.");
  requireCheck(!isRepoPath(dbFile), "Production-база не должна лежать внутри папки проекта.");
  requireCheck(!isRepoPath(mediaDir), "Production-фотографии не должны лежать внутри папки проекта.");
  requireCheck(!isRepoPath(backupDir), "Production-backup не должен лежать внутри папки проекта.");
  requireCheck(env("MALYSH_SERVE_WEB", "true") === "true", "Для первого VPS-запуска оставьте MALYSH_SERVE_WEB=true.");

  if (registrationMode === "closed") {
    requireCheck(
      inviteCode.length >= 8 && inviteCode !== "change-this-invite-code",
      "При MALYSH_REGISTRATION_MODE=closed нужен MALYSH_BETA_INVITE_CODE длиной хотя бы 8 символов."
    );
  } else if (registrationMode === "open") {
    warn("VPS будет в open beta: регистрация открыта всем, кто нашел сайт. Проверьте beta-предупреждение и rate limits.");
  } else if (registrationMode === "disabled") {
    warn("Регистрация на VPS выключена: смогут войти только уже созданные аккаунты.");
  }
}

printReport();

if (problems.length > 0) {
  process.exitCode = 1;
}

function env(key, fallback = "") {
  return String(process.env[key] ?? fallback).trim();
}

function checkFile(relativePath, message = "") {
  const filePath = join(projectRoot, relativePath);

  if (!existsSync(filePath)) {
    problems.push(`${relativePath} не найден. ${message}`.trim());
    return;
  }

  if (statSync(filePath).isFile()) {
    passed.push(`${relativePath} есть`);
  }
}

function requireCheck(condition, message) {
  if (condition) {
    passed.push(message.replace(/\.$/, ""));
    return;
  }

  problems.push(message);
}

function requirePositiveEnvNumber(key, fallback) {
  const value = Number(env(key, fallback));

  requireCheck(Number.isFinite(value) && value > 0, `${key} должен быть положительным числом.`);
}

function warn(message) {
  warnings.push(message);
}

function pass(message) {
  passed.push(message);
}

function looksAbsolute(value) {
  return Boolean(value) && (isAbsolute(value) || value.startsWith("/"));
}

function isRepoPath(value) {
  if (!value || value.startsWith("/")) return false;

  const resolved = resolve(projectRoot, value);
  return resolved === projectRoot || resolved.startsWith(`${projectRoot}\\`) || resolved.startsWith(`${projectRoot}/`);
}

function printReport() {
  console.log("");
  console.log(`Malysh+ preflight: ${target}`);
  console.log("");

  if (passed.length > 0) {
    console.log("OK:");
    passed.forEach((item) => console.log(`- ${item}`));
    console.log("");
  }

  if (warnings.length > 0) {
    console.log("Warnings:");
    warnings.forEach((item) => console.log(`- ${item}`));
    console.log("");
  }

  if (problems.length > 0) {
    console.log("Fix before beta:");
    problems.forEach((item) => console.log(`- ${item}`));
    console.log("");
    return;
  }

  console.log("Ready for the selected beta check.");
  console.log("");
}

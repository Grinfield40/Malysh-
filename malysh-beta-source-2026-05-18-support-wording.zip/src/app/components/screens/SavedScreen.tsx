import { Bookmark, MessageSquare, ShoppingBag, Clock } from "lucide-react";
import { useState } from "react";

const tabs = ["Статьи", "Обсуждения", "Списки"];

const savedArticles = [
  { id: 1, title: "Когда обращаться к врачу", category: "Здоровье", time: "5 мин", icon: "🩺" },
  { id: 2, title: "Первая аптечка для малыша", category: "Покупки", time: "3 мин", icon: "💊" },
  { id: 3, title: "Режим сна новорожденного", category: "Сон", time: "7 мин", icon: "🌙" },
];

const savedPosts = [
  { id: 1, title: "Малыш плохо спит ночью", comments: 12, category: "Сон" },
  { id: 2, title: "Когда вводить прикорм?", comments: 24, category: "Кормление" },
];

const savedLists = [
  { id: 1, title: "Аптечка", progress: 75, total: 8, completed: 6 },
  { id: 2, title: "Для сна", progress: 50, total: 4, completed: 2 },
];

export function SavedScreen() {
  const [activeTab, setActiveTab] = useState("Статьи");

  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-4 bg-gradient-to-b from-secondary/50 to-transparent sticky top-0 z-10 backdrop-blur-sm">
        <h1 className="text-2xl font-medium text-foreground mb-4">Сохраненное</h1>
        <div className="flex gap-2">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <div className="px-6 py-4">
        {activeTab === "Статьи" && (
          <div className="space-y-3">
            {savedArticles.map((article) => (
              <div
                key={article.id}
                className="rounded-xl bg-card border border-border p-4 flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                  {article.icon}
                </div>
                <div className="flex-1">
                  <div className="text-xs text-primary font-medium mb-1">{article.category}</div>
                  <h4 className="text-sm font-medium text-foreground mb-1">{article.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="w-3 h-3" />
                    <span>{article.time}</span>
                  </div>
                </div>
                <Bookmark className="w-5 h-5 text-primary fill-primary flex-shrink-0" />
              </div>
            ))}
          </div>
        )}

        {activeTab === "Обсуждения" && (
          <div className="space-y-3">
            {savedPosts.map((post) => (
              <div
                key={post.id}
                className="rounded-xl bg-card border border-border p-4"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="font-medium text-foreground flex-1">{post.title}</h4>
                  <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full whitespace-nowrap">
                    {post.category}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <MessageSquare className="w-4 h-4" />
                    <span>{post.comments}</span>
                  </div>
                  <Bookmark className="w-4 h-4 text-primary fill-primary ml-auto" />
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "Списки" && (
          <div className="space-y-3">
            {savedLists.map((list) => (
              <div
                key={list.id}
                className="rounded-xl bg-card border border-border p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
                      <ShoppingBag className="w-5 h-5 text-primary" />
                    </div>
                    <h4 className="font-medium text-foreground">{list.title}</h4>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {list.completed}/{list.total}
                  </span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full transition-all"
                    style={{ width: `${list.progress}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

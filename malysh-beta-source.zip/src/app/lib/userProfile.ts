import { useLocalStorageState } from "./useLocalStorageState";

export interface UserProfile {
  name: string;
  email: string;
  role: string;
}

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: "Родитель",
  email: "parent@example.com",
  role: "Родитель",
};

export function useUserProfile() {
  return useLocalStorageState<UserProfile>("mvp.user.profile", DEFAULT_USER_PROFILE);
}

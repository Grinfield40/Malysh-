import { ChevronLeft, Check, Plus } from "lucide-react";
import { useState } from "react";

interface ShoppingDetailScreenProps {
  onBack: () => void;
}

const items = [
  { id: "thermometer", name: "Градусник", essential: true, checked: true },
  { id: "drops", name: "Капли от коликов", essential: false, checked: false },
  { id: "cream", name: "Крем под подгузник", essential: true, checked: true },
  { id: "aspirator", name: "Аспиратор назальный", essential: true, checked: false },
  { id: "peroxide", name: "Перекись водорода", essential: true, checked: true },
  { id: "cotton", name: "Ватные диски и палочки", essential: true, checked: false },
  { id: "bandaid", name: "Пластыри детские", essential: false, checked: false },
  { id: "fennel", name: "Укропная вода", essential: false, checked: false },
];

export function ShoppingDetailScreen({ onBack }: ShoppingDetailScreenProps) {
  const [checklist, setChecklist] = useState(items);

  const toggleItem = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const essentialCount = checklist.filter(i => i.essential).length;
  const essentialChecked = checklist.filter(i => i.essential && i.checked).length;

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 border-b border-border bg-card">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={onBack} className="p-2 -ml-2">
            <ChevronLeft className="w-6 h-6 text-foreground" />
          </button>
          <h1 className="text-2xl font-medium text-foreground flex-1">Аптечка</h1>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Обязательных:</span>
          <span className="font-medium text-foreground">
            {essentialChecked} / {essentialCount}
          </span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 pb-24">
        <div className="space-y-2 mb-6">
          <h3 className="text-sm font-medium text-foreground mb-3">Обязательное</h3>
          {checklist
            .filter((item) => item.essential)
            .map((item) => (
              <button
                key={item.id}
                onClick={() => toggleItem(item.id)}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
              >
                <div
                  className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    item.checked
                      ? "bg-primary border-primary"
                      : "border-border bg-transparent"
                  }`}
                >
                  {item.checked && <Check className="w-4 h-4 text-white" />}
                </div>
                <span
                  className={`text-left flex-1 ${
                    item.checked ? "text-muted-foreground line-through" : "text-foreground"
                  }`}
                >
                  {item.name}
                </span>
              </button>
            ))}
        </div>

        <div className="space-y-2 mb-6">
          <h3 className="text-sm font-medium text-foreground mb-3">Дополнительное</h3>
          {checklist
            .filter((item) => !item.essential)
            .map((item) => (
              <button
                key={item.id}
                onClick={() => toggleItem(item.id)}
                className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
              >
                <div
                  className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                    item.checked
                      ? "bg-primary border-primary"
                      : "border-border bg-transparent"
                  }`}
                >
                  {item.checked && <Check className="w-4 h-4 text-white" />}
                </div>
                <span
                  className={`text-left flex-1 ${
                    item.checked ? "text-muted-foreground line-through" : "text-foreground"
                  }`}
                >
                  {item.name}
                </span>
              </button>
            ))}
        </div>

        <button className="w-full p-4 rounded-xl border-2 border-dashed border-border hover:border-primary/30 transition-all flex items-center justify-center gap-2 text-muted-foreground">
          <Plus className="w-5 h-5" />
          <span className="text-sm font-medium">Добавить свой пункт</span>
        </button>
      </div>
    </div>
  );
}

import { motion, AnimatePresence } from "motion/react";
import { X, DollarSign } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

interface AddShoppingItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (item: ShoppingItem) => void;
}

export interface ShoppingItem {
  name: string;
  price: string;
  priority: "high" | "medium" | "low";
  category: string;
}

const categories = [
  "Основные покупки",
  "Расходники",
  "Купание и уход",
  "Одежда",
  "Дом и организация",
  "Развлечения и комфорт",
  "Дополнительно",
];

const priorities = [
  { value: "high", label: "Высокий", color: "text-red-600 bg-red-100" },
  { value: "medium", label: "Средний", color: "text-yellow-600 bg-yellow-100" },
  { value: "low", label: "Низкий", color: "text-green-600 bg-green-100" },
];

export function AddShoppingItemModal({ isOpen, onClose, onAdd }: AddShoppingItemModalProps) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [priority, setPriority] = useState<"high" | "medium" | "low">("medium");
  const [category, setCategory] = useState(categories[0]);
  const trimmedName = name.trim();
  const validationMessage = !trimmedName
    ? "Введите название товара."
    : trimmedName.length < 2
    ? "Название слишком короткое."
    : "";
  const shouldShowValidation = Boolean(validationMessage && name);

  const handleSubmit = () => {
    if (validationMessage) return;

    onAdd({
      name: trimmedName,
      price: price || "—",
      priority,
      category,
    });

    onClose();
    resetForm();
  };

  const resetForm = () => {
    setName("");
    setPrice("");
    setPriority("medium");
    setCategory(categories[0]);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-4 md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-full md:max-w-xl md:max-h-[90vh] bg-background rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-border flex-shrink-0">
              <h2 className="text-2xl font-medium text-foreground">Добавить покупку</h2>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-secondary hover:bg-secondary/80 flex items-center justify-center transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Название товара</label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Например: Подгузники Pampers"
                  className="rounded-xl"
                  required
                />
              </div>

              {/* Price */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Цена (необязательно)
                </label>
                <div className="relative">
                  <Input
                    type="text"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="1 500 ₽"
                    className="rounded-xl pr-10"
                  />
                  <DollarSign className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">Категория</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full h-11 px-4 rounded-xl border-2 border-border bg-background focus:border-primary focus:outline-none"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              {/* Priority */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-3">Приоритет</label>
                <div className="grid grid-cols-3 gap-3">
                  {priorities.map((p) => (
                    <button
                      key={p.value}
                      onClick={() => setPriority(p.value as any)}
                      className={`py-3 px-4 rounded-xl border-2 transition-all ${
                        priority === p.value
                          ? `${p.color} border-current`
                          : "bg-secondary border-border hover:border-primary/30"
                      }`}
                    >
                      <div className="font-medium text-sm">{p.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Preview */}
              {name && (
                <div className="bg-secondary/30 rounded-2xl p-4 border-2 border-dashed border-border">
                  <div className="text-sm text-muted-foreground mb-3">Предварительный просмотр:</div>
                  <div className="bg-card border border-border rounded-xl p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 flex-1">
                        <div className="w-6 h-6 rounded-lg border-2 border-border" />
                        <div className="flex-1">
                          <div className="font-medium text-foreground">{name}</div>
                          <div className="text-sm text-muted-foreground">{price || "Цена не указана"}</div>
                        </div>
                      </div>
                      <div
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          priorities.find((p) => p.value === priority)?.color
                        }`}
                      >
                        {priorities.find((p) => p.value === priority)?.label}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex flex-col gap-3 border-t border-border p-6 md:flex-row">
              {shouldShowValidation ? (
                <div className="rounded-xl border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm text-destructive md:mr-auto">
                  {validationMessage}
                </div>
              ) : null}
              <Button variant="outline" onClick={onClose} className="flex-1 rounded-xl">
                Отмена
              </Button>
              <Button onClick={handleSubmit} disabled={Boolean(validationMessage)} className="flex-1 rounded-xl">
                Добавить в список
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

import { motion } from "motion/react";
import { Baby } from "lucide-react";

interface LogoProps {
  size?: number;
  animate?: boolean;
  className?: string;
}

export function Logo({ size = 40, animate = false, className = "" }: LogoProps) {
  const Component = animate ? motion.div : "div";
  const animationProps = animate ? {
    whileHover: { scale: 1.1, rotate: 5 },
  } : {};
  const iconSize = Math.max(18, Math.round(size * 0.46));
  const showMark = size >= 56;

  return (
    <Component
      role="img"
      aria-label="Малыш+ логотип"
      className={`relative inline-flex items-center justify-center rounded-[28%] border border-primary/20 bg-gradient-to-br from-white via-primary/10 to-accent/20 text-primary shadow-lg shadow-primary/10 ${className}`}
      style={{ width: size, height: size }}
      {...animationProps}
    >
      <Baby
        className="relative z-10 drop-shadow-sm"
        width={iconSize}
        height={iconSize}
        strokeWidth={2.2}
      />
      {showMark ? (
        <span className="absolute bottom-1.5 left-1/2 z-10 -translate-x-1/2 text-[10px] font-bold leading-none text-foreground">
          М+
        </span>
      ) : null}
    </Component>
  );
}

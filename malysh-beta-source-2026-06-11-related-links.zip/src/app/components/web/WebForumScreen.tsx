import { motion } from "motion/react";
import {
  ArrowLeft,
  Bookmark,
  Clock,
  Flag,
  MessageSquare,
  Plus,
  Search,
  Send,
  TrendingUp,
  Users,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { AddForumPostModal, ForumPost } from "./AddForumPostModal";
import { CareFlowStrip } from "./CareFlowStrip";
import {
  createForumComment,
  createForumPost,
  ForumPostDetail,
  ForumPostRecord,
  getForumPost,
  getForumPosts,
  getStoredSession,
  reportForumContent,
} from "../../lib/accountApi";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifyInfo, notifySuccess, notifyWarning } from "../../lib/notify";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import {
  SAVED_FORUM_POSTS_STORAGE_KEY,
  SavedForumPostItem,
  toggleSavedItem,
} from "../../lib/savedItems";

const tabs = [
  { id: "all", label: "Обсуждения" },
  { id: "popular", label: "Популярное" },
  { id: "new", label: "Новое" },
];

const categories = [
  { id: "", label: "Все" },
  { id: "sleep", label: "Сон" },
  { id: "feeding", label: "Кормление" },
  { id: "health", label: "Здоровье" },
  { id: "development", label: "Развитие" },
  { id: "shopping", label: "Покупки" },
  { id: "routine", label: "Режим" },
  { id: "other", label: "Общее" },
];

const reportReasons = [
  { id: "rude", label: "Грубость или давление" },
  { id: "medical", label: "Опасный совет" },
  { id: "private", label: "Личные данные" },
  { id: "spam", label: "Спам или реклама" },
  { id: "other", label: "Другое" },
];

const maxCommentLength = 2000;
const maxReportDetailsLength = 1000;

type ForumReportTarget = {
  type: "post" | "comment";
  id: string;
  title: string;
};

function formatRelativeTime(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) return "только что";

  const diffMs = Date.now() - date.getTime();
  const minutes = Math.max(0, Math.round(diffMs / 60000));

  if (minutes < 1) return "только что";
  if (minutes < 60) return `${minutes} мин назад`;

  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} ч назад`;

  const days = Math.round(hours / 24);
  if (days < 7) return `${days} дн назад`;

  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "long",
  }).format(date);
}

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function toSavedForumPost(post: ForumPostRecord): SavedForumPostItem {
  return {
    id: post.id,
    title: post.title,
    category: post.category,
    author: post.author,
    preview: post.preview,
    comments: post.comments,
    views: post.views,
    createdAt: post.createdAt,
    savedAt: new Date().toISOString(),
  };
}

interface WebForumScreenProps {
  onNavigate: (screen: string) => void;
}

export function WebForumScreen({ onNavigate }: WebForumScreenProps) {
  const [posts, setPosts] = useState<ForumPostRecord[]>([]);
  const [stats, setStats] = useState({ posts: 0, comments: 0, today: 0 });
  const [activeTab, setActiveTab] = useState("all");
  const [activeCategory, setActiveCategory] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<ForumPostDetail | null>(null);
  const [commentText, setCommentText] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [reportTarget, setReportTarget] = useState<ForumReportTarget | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isDetailLoading, setIsDetailLoading] = useState(false);
  const [isCommentSubmitting, setIsCommentSubmitting] = useState(false);
  const [isReportSubmitting, setIsReportSubmitting] = useState(false);
  const [savedForumPosts, setSavedForumPosts] = useLocalStorageState<SavedForumPostItem[]>(
    SAVED_FORUM_POSTS_STORAGE_KEY,
    []
  );
  const savedForumPostIds = useMemo(
    () => new Set(savedForumPosts.map((post) => post.id)),
    [savedForumPosts]
  );

  const loadPosts = useCallback(async () => {
    const session = getStoredSession();

    if (!session) return;

    setIsLoading(true);
    setError("");

    try {
      const response = await getForumPosts(session.token, {
        tab: activeTab,
        search: searchTerm,
        category: activeCategory,
      });

      setPosts(response.posts);
      setStats(response.stats);
    } catch (forumError) {
      setError(getErrorMessage(forumError, "Не удалось загрузить форум."));
    } finally {
      setIsLoading(false);
    }
  }, [activeCategory, activeTab, searchTerm]);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadPosts();
    }, 250);

    return () => window.clearTimeout(timer);
  }, [loadPosts]);

  const popularTags = useMemo(
    () =>
      Array.from(new Set(posts.flatMap((post) => post.tags)))
        .filter(Boolean)
        .slice(0, 10),
    [posts]
  );
  const hasForumFilters = Boolean(searchTerm.trim() || activeCategory || activeTab !== "all");
  const emptyForumTitle = hasForumFilters ? "Ничего не найдено" : "Пока нет обсуждений";
  const emptyForumDescription = hasForumFilters
    ? "Попробуйте изменить запрос, выбрать другую категорию или сбросить фильтры."
    : "Создайте первый пост: вопрос по сну, кормлению, покупкам или просто поделитесь опытом.";

  const resetForumFilters = () => {
    setSearchTerm("");
    setActiveCategory("");
    setActiveTab("all");
    trackEvent("forum_filters_reset", { screen: "forum" });
  };

  const toggleForumPostSave = (event: { stopPropagation: () => void }, post: ForumPostRecord) => {
    event.stopPropagation();
    const isSaved = savedForumPostIds.has(post.id);

    setSavedForumPosts((current) => toggleSavedItem(current, toSavedForumPost(post)));
    notifySuccess(isSaved ? "Обсуждение убрано из сохраненного" : "Обсуждение сохранено", {
      description: isSaved ? "Его можно сохранить снова из форума." : "Оно появится в разделе «Сохраненное».",
    });
  };

  const handleAddPost = async (post: ForumPost) => {
    const session = getStoredSession();

    if (!session) return;

    setError("");

    try {
      const response = await createForumPost(session.token, {
        title: post.title,
        content: post.content,
        category: post.category,
        tags: post.tags,
      });

      trackEvent("forum_post_created", {
        screen: "forum",
        meta: {
          category: post.category,
          tagsCount: post.tags.length,
        },
      });

      setSelectedPost({ post: response.post, comments: [] });
      notifySuccess("Пост опубликован", {
        description: "Он уже появился в форуме.",
      });
      await loadPosts();
    } catch (forumError) {
      setError(getErrorMessage(forumError, "Не удалось опубликовать пост."));
      notifyError(forumError, "Не удалось опубликовать пост.");
      throw forumError;
    }
  };

  const handleOpenPost = async (postId: string) => {
    const session = getStoredSession();

    if (!session) return;

    setIsDetailLoading(true);
    setError("");

    try {
      const detail = await getForumPost(session.token, postId);
      setSelectedPost(detail);
      trackEvent("forum_post_opened", {
        screen: "forum",
        meta: {
          category: detail.post.categoryId,
        },
      });
      await loadPosts();
    } catch (forumError) {
      setError(getErrorMessage(forumError, "Не удалось открыть обсуждение."));
      notifyError(forumError, "Не удалось открыть обсуждение.");
    } finally {
      setIsDetailLoading(false);
    }
  };

  const handleAddComment = async () => {
    const session = getStoredSession();
    const postId = selectedPost?.post.id;
    const content = commentText.trim();

    if (!session || !postId) return;

    if (!content) {
      notifyWarning("Напишите ответ перед отправкой");
      return;
    }

    if (content.length > maxCommentLength) {
      notifyWarning("Ответ слишком длинный.");
      return;
    }

    setIsCommentSubmitting(true);
    setError("");

    try {
      const response = await createForumComment(session.token, postId, content);

      setSelectedPost((current) =>
        current
          ? {
              post: response.post,
              comments: [...current.comments, response.comment],
            }
          : current
      );
      setCommentText("");
      trackEvent("forum_comment_created", {
        screen: "forum",
        meta: {
          category: selectedPost?.post.categoryId,
        },
      });
      notifySuccess("Ответ добавлен");
      await loadPosts();
    } catch (forumError) {
      setError(getErrorMessage(forumError, "Не удалось добавить ответ."));
      notifyError(forumError, "Не удалось добавить ответ.");
    } finally {
      setIsCommentSubmitting(false);
    }
  };

  const handleReportSubmit = async (reason: string, details: string) => {
    const session = getStoredSession();

    if (!session || !reportTarget) return;

    setIsReportSubmitting(true);
    setError("");
    setNotice("");

    try {
      const result = await reportForumContent(session.token, {
        targetType: reportTarget.type,
        targetId: reportTarget.id,
        reason,
        details,
      });

      setReportTarget(null);
      setNotice("");
      if (result.duplicate) {
        notifyInfo("Жалоба уже отправлена", {
          description: "Она ждет проверки в модерации.",
        });
      } else {
        notifySuccess("Жалоба отправлена", {
          description: "Администратор увидит ее в модерации.",
        });
      }
      trackEvent("forum_report_created", {
        screen: "forum",
        meta: {
          targetType: reportTarget.type,
          reason,
        },
      });
    } catch (forumError) {
      setError(getErrorMessage(forumError, "Не удалось отправить жалобу."));
      notifyError(forumError, "Не удалось отправить жалобу.");
      throw forumError;
    } finally {
      setIsReportSubmitting(false);
    }
  };

  const showDetail = Boolean(selectedPost);

  return (
    <div className="relative p-4 pb-24 md:p-8 md:pb-8 pt-20 md:pt-8 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between mb-6 md:mb-8"
      >
        <div className="max-w-3xl">
          <h1 className="text-3xl md:text-4xl font-medium text-foreground mb-2">Форум</h1>
          <p className="text-base md:text-lg text-muted-foreground">
            Общие обсуждения родителей: вопросы, опыт, ответы и спокойная поддержка.
          </p>
        </div>
        <Button
          onClick={() => {
            setIsModalOpen(true);
            trackEvent("forum_post_modal_opened", { screen: "forum" });
          }}
          className="hidden h-12 w-full justify-center rounded-xl px-6 shadow-sm sm:w-auto md:flex md:min-w-[180px]"
        >
          <Plus className="w-4 h-4" />
          Создать пост
        </Button>
      </motion.div>

      <CareFlowStrip active="forum" onNavigate={onNavigate} />

      {error ? (
        <div className="mb-5 rounded-xl border border-destructive/20 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      ) : null}

      {notice ? (
        <div className="mb-5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {notice}
        </div>
      ) : null}

      {showDetail && selectedPost ? (
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6">
          <section className="space-y-4">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedPost(null);
                setCommentText("");
              }}
              className="rounded-xl"
            >
              <ArrowLeft className="w-4 h-4" />
              К обсуждениям
            </Button>

            <article className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  {selectedPost.post.category}
                </span>
                <span className="text-xs text-muted-foreground">
                  {formatRelativeTime(selectedPost.post.createdAt)}
                </span>
                <button
                  type="button"
                  onClick={(event) => toggleForumPostSave(event, selectedPost.post)}
                  className={`ml-auto inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                    savedForumPostIds.has(selectedPost.post.id)
                      ? "border-primary/30 bg-primary/10 text-primary"
                      : "border-border bg-background text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Bookmark className={`h-3.5 w-3.5 ${savedForumPostIds.has(selectedPost.post.id) ? "fill-primary" : ""}`} />
                  {savedForumPostIds.has(selectedPost.post.id) ? "Сохранено" : "Сохранить"}
                </button>
              </div>
              <h2 className="text-2xl md:text-3xl font-medium text-foreground mb-4">
                {selectedPost.post.title}
              </h2>
              <div className="flex items-center gap-3 mb-5">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-sm font-medium text-foreground">
                  {selectedPost.post.avatar}
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">{selectedPost.post.author}</div>
                  <div className="text-xs text-muted-foreground">Автор обсуждения</div>
                </div>
              </div>
              <p className="whitespace-pre-wrap text-base leading-relaxed text-foreground">
                {selectedPost.post.content}
              </p>
              {selectedPost.post.tags.length > 0 ? (
                <div className="mt-5 flex flex-wrap gap-2">
                  {selectedPost.post.tags.map((tag) => (
                    <span key={tag} className="rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground">
                      #{tag}
                    </span>
                  ))}
                </div>
              ) : null}
              <div className="mt-5 flex justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() =>
                    setReportTarget({
                  type: "post",
                  id: selectedPost.post.id,
                  title: selectedPost.post.title,
                })
              }
                  className="h-9 rounded-xl border-border bg-background/60 text-xs text-muted-foreground hover:text-foreground"
                >
                  <Flag className="w-4 h-4" />
                  Сообщить
                </Button>
              </div>
            </article>

            <section className="bg-card border border-border rounded-xl p-4 md:p-6">
              <div className="flex items-center justify-between gap-3 mb-5">
                <h3 className="text-xl font-medium text-foreground">Ответы</h3>
                <span className="text-sm text-muted-foreground">{selectedPost.comments.length}</span>
              </div>

              <div className="space-y-3 mb-5">
                {selectedPost.comments.length === 0 ? (
                  <div className="rounded-xl bg-secondary/60 p-4 text-sm text-muted-foreground">
                    Ответов пока нет. Можно стать первым, кто поможет.
                  </div>
                ) : (
                  selectedPost.comments.map((comment) => (
                    <div key={comment.id} className="rounded-xl bg-secondary/60 p-4">
                      <div className="flex flex-col gap-3 mb-2 sm:flex-row sm:items-center sm:justify-between">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-background text-xs font-medium">
                            {comment.avatar}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-foreground">{comment.author}</div>
                            <div className="text-xs text-muted-foreground">
                              {formatRelativeTime(comment.createdAt)}
                            </div>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setReportTarget({
                              type: "comment",
                              id: comment.id,
                              title: `Ответ в теме: ${selectedPost.post.title}`,
                            })
                          }
                          className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
                        >
                          <Flag className="w-3.5 h-3.5" />
                          Жалоба
                        </button>
                      </div>
                      <p className="whitespace-pre-wrap text-sm leading-relaxed text-foreground">{comment.content}</p>
                    </div>
                  ))
                )}
              </div>

              <div className="space-y-3">
                <textarea
                  value={commentText}
                  onChange={(event) => setCommentText(event.target.value)}
                  maxLength={maxCommentLength}
                  placeholder="Напишите ответ..."
                  className="min-h-28 w-full resize-none rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
                />
                <div className="flex justify-stretch sm:justify-end">
                  <Button
                    onClick={handleAddComment}
                    disabled={!commentText.trim() || isCommentSubmitting}
                    className="w-full rounded-xl sm:w-auto"
                  >
                    <Send className="w-4 h-4" />
                    {isCommentSubmitting ? "Отправляем..." : "Ответить"}
                  </Button>
                </div>
              </div>
            </section>
          </section>

          <ForumSidebar
            stats={stats}
            popularTags={popularTags}
            isDetailLoading={isDetailLoading}
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_360px] gap-6">
          <section className="space-y-5">
            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  placeholder="Поиск по форуму..."
                  className="h-12 pl-12 rounded-xl bg-card border-border"
                />
              </div>

              <div className="flex gap-2 overflow-x-auto pb-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      trackEvent("forum_tab_changed", {
                        screen: "forum",
                        meta: { tab: tab.id },
                      });
                    }}
                    className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all border ${
                      activeTab === tab.id
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-card text-foreground border-border hover:border-primary/30"
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="flex gap-2 overflow-x-auto pb-1">
                {categories.map((category) => (
                  <button
                    key={category.id || "all"}
                    onClick={() => {
                      setActiveCategory(category.id);
                      trackEvent("forum_category_changed", {
                        screen: "forum",
                        meta: { category: category.id || "all" },
                      });
                    }}
                    className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all border ${
                      activeCategory === category.id
                        ? "bg-secondary text-foreground border-primary/40"
                        : "bg-card text-muted-foreground border-border hover:border-primary/30"
                    }`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
            </div>

            {isLoading ? (
              <div className="rounded-xl border border-border bg-card p-8 text-muted-foreground">
                Загружаем обсуждения...
              </div>
            ) : posts.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-primary/25 bg-card px-5 py-10 text-center shadow-sm">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <MessageSquare className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-medium text-foreground mb-2">{emptyForumTitle}</h3>
                <p className="mx-auto max-w-md text-sm text-muted-foreground mb-5">
                  {emptyForumDescription}
                </p>
                {!hasForumFilters ? (
                  <div className="mx-auto mb-5 flex max-w-md flex-wrap justify-center gap-2">
                    {["сон", "кормление", "покупки", "режим"].map((topic) => (
                      <button
                        key={topic}
                        type="button"
                        onClick={() => setSearchTerm(topic)}
                        className="rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:border-primary/30 hover:text-foreground"
                      >
                        #{topic}
                      </button>
                    ))}
                  </div>
                ) : null}
                <div className="flex flex-col justify-center gap-2 sm:flex-row">
                  {hasForumFilters && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={resetForumFilters}
                      className="w-full rounded-xl sm:w-auto"
                    >
                      Сбросить фильтры
                    </Button>
                  )}
                  <Button onClick={() => setIsModalOpen(true)} className="w-full rounded-xl sm:w-auto">
                    <Plus className="w-4 h-4" />
                    Создать пост
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {posts.map((post, index) => (
                  <motion.button
                    key={post.id}
                    type="button"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.03 }}
                    onClick={() => void handleOpenPost(post.id)}
                    className="w-full text-left bg-card border border-border rounded-xl p-3 shadow-sm transition-all hover:border-primary/30 hover:shadow-md md:p-4"
                  >
                    <div className="flex items-start gap-3 sm:gap-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-sm font-medium text-foreground sm:h-11 sm:w-11">
                        {post.avatar}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2 mb-2">
                          <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                            {post.category}
                          </span>
                          <span className="text-xs text-muted-foreground">{formatRelativeTime(post.createdAt)}</span>
                          <span
                            role="button"
                            tabIndex={0}
                            onClick={(event) => toggleForumPostSave(event, post)}
                            className={`ml-auto inline-flex h-8 w-8 items-center justify-center rounded-full border transition-colors ${
                              savedForumPostIds.has(post.id)
                                ? "border-primary/30 bg-primary/10 text-primary"
                                : "border-border bg-background text-muted-foreground hover:text-foreground"
                            }`}
                            aria-label={savedForumPostIds.has(post.id) ? "Убрать обсуждение из сохраненного" : "Сохранить обсуждение"}
                          >
                            <Bookmark className={`h-4 w-4 ${savedForumPostIds.has(post.id) ? "fill-primary" : ""}`} />
                          </span>
                        </div>
                        <h3 className="text-base font-medium leading-snug text-foreground mb-1 line-clamp-2 sm:text-lg">{post.title}</h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{post.preview}</p>
                        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                          <span className="rounded-full bg-secondary/70 px-2.5 py-1 font-medium text-foreground">{post.author}</span>
                          <span className="flex items-center gap-1 rounded-full bg-secondary/70 px-2.5 py-1">
                            <MessageSquare className="w-4 h-4" />
                            {post.comments} ответов
                          </span>
                          <span className="flex items-center gap-1 rounded-full bg-secondary/70 px-2.5 py-1">
                            <TrendingUp className="w-4 h-4" />
                            {post.views} просмотров
                          </span>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            )}
          </section>

          <ForumSidebar
            stats={stats}
            popularTags={popularTags}
            isDetailLoading={isDetailLoading}
          />
        </div>
      )}

      {!showDetail ? (
        <button
          type="button"
          onClick={() => {
            setIsModalOpen(true);
            trackEvent("forum_post_modal_opened", { screen: "forum", meta: { source: "mobile_floating" } });
          }}
          className="fixed bottom-24 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/25 md:hidden"
          aria-label="Создать пост"
        >
          <Plus className="h-6 w-6" />
        </button>
      ) : null}

      <AddForumPostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddPost}
      />
      <ForumReportDialog
        target={reportTarget}
        isSubmitting={isReportSubmitting}
        onClose={() => setReportTarget(null)}
        onSubmit={handleReportSubmit}
      />
    </div>
  );
}

function ForumSidebar({
  stats,
  popularTags,
  isDetailLoading,
}: {
  stats: { posts: number; comments: number; today: number };
  popularTags: string[];
  isDetailLoading: boolean;
}) {
  return (
    <aside className="space-y-5">
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-primary" />
          <h3 className="font-medium text-foreground">Активность</h3>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Metric label="Постов" value={stats.posts} />
          <Metric label="Ответов" value={stats.comments} />
          <Metric label="Сегодня" value={stats.today} />
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-primary" />
          <h3 className="font-medium text-foreground">Статус</h3>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">
          Посты и ответы видны участникам beta и помогают собрать живые вопросы родителей.
        </p>
        {isDetailLoading ? (
          <div className="mt-3 rounded-lg bg-secondary/60 px-3 py-2 text-xs text-muted-foreground">
            Открываем обсуждение...
          </div>
        ) : null}
      </div>

      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-medium text-foreground mb-4">Популярные теги</h3>
        {popularTags.length === 0 ? (
          <div className="text-sm text-muted-foreground">Теги появятся после первых постов.</div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {popularTags.map((tag) => (
              <span key={tag} className="rounded-full bg-secondary px-3 py-1 text-xs text-muted-foreground">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="bg-primary/10 border border-primary/20 rounded-xl p-5">
        <h3 className="font-medium text-foreground mb-3">Правила сообщества</h3>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>Будьте вежливы и не обесценивайте чужой опыт.</p>
          <p>Медицинские вопросы лучше обсуждать с врачом.</p>
          <p>Не публикуйте личные данные и контакты в открытых ответах.</p>
        </div>
      </div>
    </aside>
  );
}

function ForumReportDialog({
  target,
  isSubmitting,
  onClose,
  onSubmit,
}: {
  target: ForumReportTarget | null;
  isSubmitting: boolean;
  onClose: () => void;
  onSubmit: (reason: string, details: string) => Promise<void>;
}) {
  const [reason, setReason] = useState(reportReasons[0].id);
  const [details, setDetails] = useState("");

  useEffect(() => {
    if (!target) return;

    setReason(reportReasons[0].id);
    setDetails("");
  }, [target?.id]);

  if (!target) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4">
      <button
        type="button"
        aria-label="Закрыть жалобу"
        onClick={onClose}
        className="absolute inset-0 bg-black/45 backdrop-blur-sm"
      />
      <div className="relative w-full max-w-lg rounded-2xl border border-border bg-background p-5 shadow-2xl">
        <div className="mb-4">
          <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-destructive/10 px-3 py-1 text-xs font-medium text-destructive">
            <Flag className="h-4 w-4" />
            Жалоба на материал
          </div>
          <h3 className="text-xl font-medium text-foreground">{target.title}</h3>
          <p className="mt-2 text-sm text-muted-foreground">
            Жалобу увидит администратор. Материал не исчезнет автоматически, его проверит владелец проекта.
          </p>
        </div>

        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {reportReasons.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setReason(item.id)}
                className={`rounded-xl border px-3 py-2 text-left text-sm transition-colors ${
                  reason === item.id
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border bg-card text-muted-foreground hover:border-primary/30"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <textarea
            value={details}
            onChange={(event) => setDetails(event.target.value)}
            maxLength={maxReportDetailsLength}
            placeholder="Можно добавить короткое пояснение"
            className="min-h-24 w-full resize-none rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
          />
        </div>

        <div className="mt-5 flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
          <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting} className="rounded-xl">
            Отмена
          </Button>
          <Button
            type="button"
            onClick={() => void onSubmit(reason, details)}
            disabled={isSubmitting}
            className="rounded-xl"
          >
            <Flag className="w-4 h-4" />
            {isSubmitting ? "Отправляем..." : "Отправить жалобу"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg bg-secondary/60 px-3 py-3 text-center">
      <div className="text-lg font-medium text-foreground">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

import { motion } from "motion/react";
import { BookOpen, Search, Clock, Bookmark, TrendingUp, Star } from "lucide-react";
import { Input } from "../ui/input";
import { useMemo, useState } from "react";
import { getStoredSession, submitBetaFeedback } from "../../lib/accountApi";
import { notifyError, notifySuccess } from "../../lib/notify";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { ActionEmptyState } from "./ActionEmptyState";
import { ScreenHeader } from "./ScreenHeader";
import {
  SAVED_ARTICLES_STORAGE_KEY,
  SavedArticleItem,
  toggleSavedItem,
} from "../../lib/savedItems";

interface WebTipsScreenProps {
  onArticleClick?: () => void;
  onNavigate?: (screen: string) => void;
}

const categories = ["Все", "Здоровье", "Сон", "Кормление", "Развитие", "Покупки"];

const featuredArticle = {
  id: 1,
  title: "Можно ли целовать ребенка",
  category: "Здоровье",
  time: "4 мин",
  emoji: "💋",
  description: "Разбираемся в вопросе, который волнует многих родителей",
  rating: 4.9,
  reads: 1234,
};

const articles = [
  {
    id: 2,
    title: "Когда обращаться к врачу",
    category: "Здоровье",
    time: "5 мин",
    emoji: "🩺",
    description: "Важные симптомы, которые нельзя игнорировать",
    rating: 4.8,
    reads: 892,
  },
  {
    id: 3,
    title: "Как собрать аптечку",
    category: "Покупки",
    time: "3 мин",
    emoji: "💊",
    description: "Полный список необходимых медикаментов",
    rating: 4.7,
    reads: 654,
  },
  {
    id: 4,
    title: "Что нормально, а что нет",
    category: "Здоровье",
    time: "6 мин",
    emoji: "✅",
    description: "Развеиваем мифы о развитии младенцев",
    rating: 4.9,
    reads: 1567,
  },
  {
    id: 5,
    title: "Режим сна новорожденного",
    category: "Сон",
    time: "7 мин",
    emoji: "🌙",
    description: "Как наладить здоровый сон малыша",
    rating: 4.6,
    reads: 2341,
  },
  {
    id: 6,
    title: "Грудное вскармливание: первые дни",
    category: "Кормление",
    time: "8 мин",
    emoji: "🍼",
    description: "Советы и рекомендации для начинающих мам",
    rating: 4.8,
    reads: 1876,
  },
];

type ArticleItem = typeof featuredArticle;

function toSavedArticle(article: ArticleItem): SavedArticleItem {
  return {
    id: article.id,
    title: article.title,
    category: article.category,
    time: article.time,
    description: article.description,
    emoji: article.emoji,
    savedAt: new Date().toISOString(),
  };
}

export function WebTipsScreen({ onArticleClick, onNavigate }: WebTipsScreenProps) {
  const [activeCategory, setActiveCategory] = useState("Все");
  const [savedArticles, setSavedArticles] = useLocalStorageState<SavedArticleItem[]>(SAVED_ARTICLES_STORAGE_KEY, []);
  const [articleSearchQuery, setArticleSearchQuery] = useState(() => {
    try {
      return JSON.parse(window.localStorage.getItem("mvp.home.lastSearch") ?? "\"\"");
    } catch {
      return "";
    }
  });
  const [isNewsletterSending, setIsNewsletterSending] = useState(false);
  const [newsletterRequested, setNewsletterRequested] = useState(false);
  const savedArticleIds = useMemo(() => new Set(savedArticles.map((article) => article.id)), [savedArticles]);

  const normalizedArticleSearch = articleSearchQuery.trim().toLowerCase();
  const filteredArticles = articles.filter((article) => {
    const matchesCategory = activeCategory === "Все" || article.category === activeCategory;
    const haystack = `${article.title} ${article.category} ${article.description}`.toLowerCase();
    const matchesSearch = !normalizedArticleSearch || haystack.includes(normalizedArticleSearch);

    return matchesCategory && matchesSearch;
  });

  const toggleArticleSave = (event: { stopPropagation: () => void }, article: ArticleItem) => {
    event.stopPropagation();
    const isSaved = savedArticleIds.has(article.id);

    setSavedArticles((current) => toggleSavedItem(current, toSavedArticle(article)));
    notifySuccess(isSaved ? "Статья убрана из сохраненного" : "Статья сохранена", {
      description: isSaved ? "Ее можно добавить снова из раздела советов." : "Она появится в разделе «Сохраненное».",
    });
  };

  const requestNewsletter = async () => {
    const session = getStoredSession();

    if (!session) {
      notifyError(new Error("Войдите в аккаунт, чтобы отправить интерес к рассылке."));
      return;
    }

    setIsNewsletterSending(true);

    try {
      await submitBetaFeedback(session.token, {
        screen: "tips",
        topic: "idea",
        message: "Идея улучшения: хочу еженедельную рассылку с полезными советами.",
      });
      setNewsletterRequested(true);
      notifySuccess("Интерес к рассылке отмечен", {
        description: "Сообщение попадет в центр обращений администратора.",
      });
    } catch (error) {
      notifyError(error, "Не получилось отправить интерес к рассылке");
    } finally {
      setIsNewsletterSending(false);
    }
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      <ScreenHeader
        icon={<BookOpen className="h-6 w-6" />}
        title="Советы"
        description="Короткие материалы по уходу, развитию и спокойной подготовке."
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6 md:mb-8"
      >
        <div className="relative max-w-2xl">
          <Search className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 w-4 h-4 md:w-5 md:h-5 text-muted-foreground" />
          <Input
            value={articleSearchQuery}
            onChange={(event) => setArticleSearchQuery(event.target.value)}
            placeholder="Поиск статей..."
            className="h-12 md:h-14 pl-12 md:pl-14 rounded-2xl bg-card border-border text-sm md:text-base"
          />
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex gap-2 md:gap-3 mb-6 md:mb-8 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0"
      >
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCategory(cat)}
            className={`px-4 md:px-6 py-2 md:py-3 rounded-xl whitespace-nowrap text-xs md:text-sm font-medium transition-all border-2 ${
              activeCategory === cat
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-card text-foreground border-border hover:border-primary/30"
            }`}
          >
            {cat}
          </button>
        ))}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        <div className="lg:col-span-2 space-y-6 md:space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-xl font-medium text-foreground mb-4">Рекомендуем</h2>
            <motion.button
              type="button"
              onClick={onArticleClick}
              whileHover={{ y: -8 }}
              className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-3xl p-5 md:p-8 cursor-pointer group w-full text-left"
            >
              <div className="flex flex-col md:flex-row items-start gap-5 md:gap-6">
                <div className="w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-white flex items-center justify-center text-5xl flex-shrink-0 group-hover:scale-110 transition-transform">
                  {featuredArticle.emoji}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-full font-medium">
                      {featuredArticle.category}
                    </span>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-primary text-primary" />
                      <span className="text-sm font-medium text-foreground">{featuredArticle.rating}</span>
                    </div>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(event) => toggleArticleSave(event, featuredArticle)}
                      className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-medium transition-colors ${
                        savedArticleIds.has(featuredArticle.id)
                          ? "border-primary/30 bg-primary/10 text-primary"
                          : "border-border bg-card/70 text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <Bookmark className={`h-3.5 w-3.5 ${savedArticleIds.has(featuredArticle.id) ? "fill-primary" : ""}`} />
                      {savedArticleIds.has(featuredArticle.id) ? "Сохранено" : "Сохранить"}
                    </span>
                  </div>
                  <h3 className="text-xl md:text-2xl font-medium text-foreground mb-3 group-hover:text-primary transition-colors">
                    {featuredArticle.title}
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{featuredArticle.description}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{featuredArticle.time}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      <span>{featuredArticle.reads} прочитали</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.button>
          </motion.div>

          <div>
            <h2 className="text-xl font-medium text-foreground mb-4">Все статьи</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {filteredArticles.map((article, idx) => (
                <motion.button
                  key={article.id}
                  type="button"
                  onClick={onArticleClick}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + idx * 0.05 }}
                  whileHover={{ y: -8 }}
                  className="bg-card border border-border rounded-2xl p-6 cursor-pointer hover:border-primary/30 transition-all group w-full text-left"
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 rounded-xl bg-secondary flex items-center justify-center text-3xl flex-shrink-0 group-hover:scale-110 transition-transform">
                      {article.emoji}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full font-medium">
                          {article.category}
                        </span>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-primary text-primary" />
                          <span className="text-xs font-medium text-foreground">{article.rating}</span>
                        </div>
                        <span
                          role="button"
                          tabIndex={0}
                          onClick={(event) => toggleArticleSave(event, article)}
                          className={`ml-auto inline-flex h-8 w-8 items-center justify-center rounded-full border transition-colors ${
                            savedArticleIds.has(article.id)
                              ? "border-primary/30 bg-primary/10 text-primary"
                              : "border-border bg-background text-muted-foreground hover:text-foreground"
                          }`}
                          aria-label={savedArticleIds.has(article.id) ? "Убрать статью из сохраненного" : "Сохранить статью"}
                        >
                          <Bookmark className={`h-4 w-4 ${savedArticleIds.has(article.id) ? "fill-primary" : ""}`} />
                        </span>
                      </div>
                      <h3 className="font-medium text-foreground mb-2 group-hover:text-primary transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{article.description}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      <span>{article.time}</span>
                    </div>
                    <span>{article.reads} прочитали</span>
                  </div>
                </motion.button>
              ))}
            </div>
            {filteredArticles.length === 0 && (
              <ActionEmptyState
                compact
                icon={<Search className="h-6 w-6" />}
                title="Материал не нашелся"
                description="Попробуйте сбросить поиск или выбрать другую категорию."
                primaryAction={{
                  label: "Сбросить поиск",
                  onClick: () => {
                    setArticleSearchQuery("");
                    setActiveCategory("Все");
                  },
                }}
                className="border-border bg-secondary/30 shadow-none"
              />
            )}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Популярное</h3>
            </div>
            <div className="space-y-4">
              {articles.slice(0, 3).map((article, idx) => (
                <button key={article.id} type="button" onClick={onArticleClick} className="w-full text-left group">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl font-medium text-muted-foreground group-hover:text-primary transition-colors">
                      {idx + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors truncate">
                        {article.title}
                      </h4>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <span>{article.reads} прочитали</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Bookmark className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Сохраненное</h3>
            </div>
            <div className="space-y-2">
              <div className="text-3xl font-medium text-foreground">{savedArticles.length}</div>
              <p className="text-sm text-muted-foreground">статей в сохраненном</p>
              <button
                type="button"
                onClick={() => onNavigate?.("saved")}
                className="text-sm text-primary font-medium hover:underline"
              >
                Посмотреть все →
              </button>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="font-medium text-foreground mb-3">📧 Рассылка появится позже</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Можно отметить интерес, и администратор увидит, что такая функция нужна.
            </p>
            <button
              type="button"
              onClick={() => void requestNewsletter()}
              disabled={isNewsletterSending || newsletterRequested}
              className="w-full h-10 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-all text-sm font-medium disabled:cursor-not-allowed disabled:opacity-70"
            >
              {newsletterRequested ? "Интерес отмечен" : isNewsletterSending ? "Отправляем..." : "Хочу такую рассылку"}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

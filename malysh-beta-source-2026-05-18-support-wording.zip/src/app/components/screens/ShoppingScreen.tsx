import { ChevronLeft, Check } from "lucide-react";
import { useState } from "react";
import { Progress } from "../ui/progress";

interface ShoppingScreenProps {
  onBack: () => void;
  onCategoryClick?: () => void;
}

const categories = [
  {
    id: "sleep",
    name: "Для сна",
    items: [
      { id: "crib", name: "Детская кроватка", checked: true },
      { id: "mattress", name: "Матрас", checked: true },
      { id: "bedding", name: "Постельное белье", checked: false },
      { id: "monitor", name: "Радионяня", checked: false },
    ],
  },
  {
    id: "feeding",
    name: "Для кормления",
    items: [
      { id: "bottles", name: "Бутылочки", checked: true },
      { id: "sterilizer", name: "Стерилизатор", checked: false },
      { id: "pump", name: "Молокоотсос", checked: false },
      { id: "bibs", name: "Нагрудники", checked: true },
    ],
  },
  {
    id: "bathing",
    name: "Для купания",
    items: [
      { id: "bath", name: "Детская ванночка", checked: false },
      { id: "thermometer", name: "Термометр для воды", checked: false },
      { id: "towels", name: "Полотенца", checked: true },
      { id: "shampoo", name: "Детский шампунь", checked: true },
    ],
  },
  {
    id: "medical",
    name: "Аптечка",
    items: [
      { id: "thermometer-body", name: "Градусник", checked: true },
      { id: "drops", name: "Капли от коликов", checked: false },
      { id: "cream", name: "Крем под подгузник", checked: true },
      { id: "aspirator", name: "Аспиратор", checked: false },
    ],
  },
];

export function ShoppingScreen({ onBack, onCategoryClick }: ShoppingScreenProps) {
  const [items, setItems] = useState(categories);
  const [activeCategory, setActiveCategory] = useState("sleep");

  const totalItems = items.reduce((acc, cat) => acc + cat.items.length, 0);
  const checkedItems = items.reduce(
    (acc, cat) => acc + cat.items.filter((item) => item.checked).length,
    0
  );
  const progress = (checkedItems / totalItems) * 100;

  const toggleItem = (categoryId: string, itemId: string) => {
    setItems((prev) =>
      prev.map((cat) =>
        cat.id === categoryId
          ? {
              ...cat,
              items: cat.items.map((item) =>
                item.id === itemId ? { ...item, checked: !item.checked } : item
              ),
            }
          : cat
      )
    );
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-6 pb-4 border-b border-border bg-card">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={onBack} className="p-2 -ml-2">
            <ChevronLeft className="w-6 h-6 text-foreground" />
          </button>
          <h1 className="text-2xl font-medium text-foreground flex-1">Что купить</h1>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Прогресс</span>
            <span className="font-medium text-foreground">
              {checkedItems} из {totalItems}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>
      </div>

      <div className="flex gap-2 px-6 py-4 overflow-x-auto">
        {items.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setActiveCategory(cat.id);
              if (onCategoryClick) onCategoryClick();
            }}
            className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-all ${
              activeCategory === cat.id
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-secondary-foreground"
            }`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        {items
          .filter((cat) => cat.id === activeCategory)
          .map((category) => (
            <div key={category.id} className="space-y-3">
              {category.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => toggleItem(category.id, item.id)}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all"
                >
                  <div
                    className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                      item.checked
                        ? "bg-primary border-primary"
                        : "border-border bg-transparent"
                    }`}
                  >
                    {item.checked && <Check className="w-4 h-4 text-white" />}
                  </div>
                  <span
                    className={`text-left ${
                      item.checked ? "text-muted-foreground line-through" : "text-foreground"
                    }`}
                  >
                    {item.name}
                  </span>
                </button>
              ))}
            </div>
          ))}
      </div>
    </div>
  );
}

export const LEGAL_DOCUMENT_VERSION = "2026-05-21";

export const LEGAL_DOCUMENTS = {
  privacy: {
    screen: "privacy",
    path: "/privacy",
    title: "Политика обработки персональных данных",
    shortTitle: "Политика ПДн",
    version: LEGAL_DOCUMENT_VERSION,
  },
  personalDataConsent: {
    screen: "personal-consent",
    path: "/personal-data-consent",
    title: "Согласие на обработку персональных данных",
    shortTitle: "Согласие ПДн",
    version: LEGAL_DOCUMENT_VERSION,
  },
  childDataConsent: {
    screen: "child-consent",
    path: "/child-data-consent",
    title: "Согласие на обработку данных ребенка",
    shortTitle: "Согласие ребенка",
    version: LEGAL_DOCUMENT_VERSION,
  },
  betaTerms: {
    screen: "terms",
    path: "/terms",
    title: "Условия beta",
    shortTitle: "Условия beta",
    version: LEGAL_DOCUMENT_VERSION,
  },
  dataMap: {
    screen: "data-map",
    path: "/personal-data-map",
    title: "Карта персональных данных",
    shortTitle: "Карта данных",
    version: LEGAL_DOCUMENT_VERSION,
  },
} as const;

export type LegalDocumentKey = keyof typeof LEGAL_DOCUMENTS;

export const REQUIRED_REGISTRATION_CONSENTS = [
  {
    key: "personalData",
    documentKey: "personalDataConsent",
    label: "Согласен на обработку персональных данных",
  },
  {
    key: "childRepresentative",
    documentKey: "childDataConsent",
    label: "Я являюсь родителем или законным представителем ребенка",
  },
  {
    key: "sensitiveDataWarning",
    documentKey: "privacy",
    label: "Понимаю, что нельзя вводить диагнозы, документы, адреса и платежные данные",
  },
] as const;

export type RegistrationConsentKey = (typeof REQUIRED_REGISTRATION_CONSENTS)[number]["key"];

export type RegistrationConsentsPayload = Record<
  RegistrationConsentKey,
  {
    accepted: boolean;
    documentKey: LegalDocumentKey;
    documentTitle: string;
    documentVersion: string;
  }
>;

export function buildRegistrationConsentsPayload(
  accepted: Record<RegistrationConsentKey, boolean>,
): RegistrationConsentsPayload {
  return REQUIRED_REGISTRATION_CONSENTS.reduce((result, consent) => {
    const document = LEGAL_DOCUMENTS[consent.documentKey];
    result[consent.key] = {
      accepted: Boolean(accepted[consent.key]),
      documentKey: consent.documentKey,
      documentTitle: document.title,
      documentVersion: document.version,
    };
    return result;
  }, {} as RegistrationConsentsPayload);
}

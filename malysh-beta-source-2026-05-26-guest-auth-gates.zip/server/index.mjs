import { createServer } from "node:http";
import { randomBytes, pbkdf2Sync, timingSafeEqual } from "node:crypto";
import { mkdir } from "node:fs/promises";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, extname, join, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
loadEnvFile(join(__dirname, "..", ".env"));

const PORT = Number(process.env.MALYSH_API_PORT || 8787);
const HOST = process.env.MALYSH_HOST || process.env.MALYSH_API_HOST || "127.0.0.1";
const DATA_DIR = process.env.MALYSH_DATA_DIR || join(__dirname, "data");
const DB_FILE = process.env.MALYSH_DB_FILE || join(DATA_DIR, "app.db");
const BACKUP_DIR = process.env.MALYSH_BACKUP_DIR || join(__dirname, "backups");
const LEGACY_JSON_FILE = process.env.MALYSH_DATA_FILE || join(DATA_DIR, "app-data.json");
const DIST_DIR = process.env.MALYSH_DIST_DIR || join(__dirname, "..", "dist");
const SERVE_WEB = process.env.MALYSH_SERVE_WEB !== "false";
const PUBLIC_URL = process.env.MALYSH_PUBLIC_URL || `http://${HOST === "0.0.0.0" ? "localhost" : HOST}:${PORT}`;
const ALLOWED_ORIGINS = (process.env.MALYSH_ALLOWED_ORIGINS || "*")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
const CORS_ORIGIN = ALLOWED_ORIGINS.includes("*") ? "*" : ALLOWED_ORIGINS[0] || PUBLIC_URL;
const EXPOSE_HEALTH_DETAILS = process.env.MALYSH_HEALTH_DETAILS === "true";
const REGISTRATION_MODES = new Set(["open", "closed", "disabled"]);
const RAW_REGISTRATION_MODE = String(process.env.MALYSH_REGISTRATION_MODE || "open").trim().toLowerCase();
const REGISTRATION_MODE = REGISTRATION_MODES.has(RAW_REGISTRATION_MODE) ? RAW_REGISTRATION_MODE : "open";
const BETA_INVITE_CODE = String(process.env.MALYSH_BETA_INVITE_CODE || "").trim();
const AUTH_RATE_LIMIT_WINDOW_MS = getPositiveNumberEnv("MALYSH_AUTH_RATE_LIMIT_WINDOW_MS", 15 * 60 * 1000);
const AUTH_LOGIN_IP_LIMIT = getPositiveNumberEnv("MALYSH_AUTH_LOGIN_IP_LIMIT", 30);
const AUTH_LOGIN_EMAIL_LIMIT = getPositiveNumberEnv("MALYSH_AUTH_LOGIN_EMAIL_LIMIT", 12);
const AUTH_REGISTER_IP_LIMIT = getPositiveNumberEnv("MALYSH_AUTH_REGISTER_IP_LIMIT", 10);
const MAX_JSON_BODY_BYTES = getPositiveNumberEnv("MALYSH_MAX_JSON_BODY_BYTES", 12 * 1024 * 1024);
const MAX_STORAGE_KEYS = getPositiveNumberEnv("MALYSH_MAX_STORAGE_KEYS", 80);
const MAX_STORAGE_KEY_LENGTH = 120;
const MAX_STORAGE_VALUE_BYTES = getPositiveNumberEnv("MALYSH_MAX_STORAGE_VALUE_BYTES", 8 * 1024 * 1024);
const MAX_FRIDGE_CARDS = getPositiveNumberEnv("MALYSH_MAX_FRIDGE_CARDS", 24);
const MAX_FRIDGE_IMAGES = getPositiveNumberEnv("MALYSH_MAX_FRIDGE_IMAGES", 6);
const MAX_FRIDGE_IMAGE_BYTES = getPositiveNumberEnv("MALYSH_MAX_FRIDGE_IMAGE_BYTES", 2_500_000);
const MAX_FRIDGE_TOTAL_IMAGE_BYTES = getPositiveNumberEnv("MALYSH_MAX_FRIDGE_TOTAL_IMAGE_BYTES", 6_000_000);
const FORUM_TITLE_MAX_LENGTH = getPositiveNumberEnv("MALYSH_FORUM_TITLE_MAX_LENGTH", 160);
const FORUM_POST_MAX_LENGTH = getPositiveNumberEnv("MALYSH_FORUM_POST_MAX_LENGTH", 4000);
const FORUM_COMMENT_MAX_LENGTH = getPositiveNumberEnv("MALYSH_FORUM_COMMENT_MAX_LENGTH", 2000);
const FORUM_REPORT_DETAILS_MAX_LENGTH = getPositiveNumberEnv("MALYSH_FORUM_REPORT_DETAILS_MAX_LENGTH", 1000);
const FORUM_TAG_MAX_LENGTH = 32;
const FORUM_TAG_MAX_COUNT = 8;
const ACCESS_LOGS = process.env.MALYSH_ACCESS_LOGS === "true";
const ERROR_STACKS = process.env.MALYSH_ERROR_STACKS === "true";
const SESSION_DAYS = 30;
const BETA_FEEDBACK_MAX_LENGTH = getPositiveNumberEnv("MALYSH_BETA_FEEDBACK_MAX_LENGTH", 1600);
const BETA_FEEDBACK_STATUSES = new Set(["new", "reviewed", "resolved"]);
const BETA_FEEDBACK_TOPICS = new Set(["feedback", "login", "data_loss", "bug", "idea", "other"]);
const DEFAULT_FEATURE_FLAGS = [
  { key: "shopping", label: "Покупки", description: "Список покупок и витрина раздела", enabled: true },
  { key: "recommendations", label: "Мамы одобряют", description: "Раздел рекомендаций и сохраненных идей", enabled: true },
  { key: "premium", label: "Платная подписка", description: "Подписка и платные CTA", enabled: true },
  { key: "forum", label: "Форум", description: "Форум родителей", enabled: true },
  { key: "betaBanner", label: "Бета-баннер", description: "Предупреждение о beta-версии", enabled: true },
];
const LEGAL_DOCUMENT_VERSION = "2026-05-21";
const LEGAL_DOCUMENTS = {
  privacy: {
    screen: "privacy",
    path: "/privacy",
    title: "Политика обработки персональных данных",
    shortTitle: "Политика ПДн",
    version: LEGAL_DOCUMENT_VERSION,
  },
  personalDataConsent: {
    screen: "personal-consent",
    path: "/personal-data-consent",
    title: "Согласие на обработку персональных данных",
    shortTitle: "Согласие ПДн",
    version: LEGAL_DOCUMENT_VERSION,
  },
  childDataConsent: {
    screen: "child-consent",
    path: "/child-data-consent",
    title: "Согласие на обработку данных ребенка",
    shortTitle: "Согласие ребенка",
    version: LEGAL_DOCUMENT_VERSION,
  },
  betaTerms: {
    screen: "terms",
    path: "/terms",
    title: "Условия beta",
    shortTitle: "Условия beta",
    version: LEGAL_DOCUMENT_VERSION,
  },
  dataMap: {
    screen: "data-map",
    path: "/personal-data-map",
    title: "Карта персональных данных",
    shortTitle: "Карта данных",
    version: LEGAL_DOCUMENT_VERSION,
  },
};
const REQUIRED_REGISTRATION_CONSENTS = [
  { key: "personalData", documentKey: "personalDataConsent" },
  { key: "childRepresentative", documentKey: "childDataConsent" },
  { key: "sensitiveDataWarning", documentKey: "privacy" },
];
const SCHEMA_VERSION = "2026-05-21-legal-consents";
const rateLimitBuckets = new Map();
let lastRateLimitCleanupAt = 0;
const BODY_TOO_LARGE = Symbol("body-too-large");

await mkdir(DATA_DIR, { recursive: true });

const db = new DatabaseSync(DB_FILE);

db.exec(`
  PRAGMA foreign_keys = ON;
  PRAGMA journal_mode = WAL;

  CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    password_salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    blocked_at TEXT,
    created_at TEXT NOT NULL,
    last_login_at TEXT
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    last_seen_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS account_storage (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    key TEXT NOT NULL,
    value_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, key)
  );

  CREATE TABLE IF NOT EXISTS user_consents (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    consent_key TEXT NOT NULL,
    document_key TEXT NOT NULL,
    document_title TEXT NOT NULL,
    document_version TEXT NOT NULL,
    accepted_at TEXT NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    meta_json TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS user_consents_user_idx
    ON user_consents(user_id, accepted_at DESC);

  CREATE INDEX IF NOT EXISTS user_consents_email_idx
    ON user_consents(email, accepted_at DESC);

  CREATE TABLE IF NOT EXISTS baby_profiles (
    user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    birth_date TEXT,
    stage TEXT,
    height_cm TEXT,
    weight_kg TEXT,
    blood_type TEXT,
    emoji TEXT,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS parent_goals (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    goal_id TEXT NOT NULL,
    position INTEGER NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, goal_id)
  );

  CREATE TABLE IF NOT EXISTS diary_entries (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    entry_id TEXT NOT NULL,
    type TEXT,
    time TEXT,
    details TEXT,
    icon TEXT,
    category TEXT,
    date TEXT,
    source TEXT,
    routine_id TEXT,
    duration_minutes INTEGER,
    raw_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, entry_id)
  );

  CREATE INDEX IF NOT EXISTS diary_entries_user_date_idx
    ON diary_entries(user_id, date, time);

  CREATE TABLE IF NOT EXISTS routines (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    routine_id TEXT NOT NULL,
    time TEXT,
    activity TEXT,
    emoji TEXT,
    duration TEXT,
    color TEXT,
    raw_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, routine_id)
  );

  CREATE TABLE IF NOT EXISTS shopping_items (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_key TEXT NOT NULL,
    category_id TEXT,
    category_name TEXT,
    name TEXT,
    checked INTEGER NOT NULL DEFAULT 0,
    priority TEXT,
    price TEXT,
    raw_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, item_key)
  );

  CREATE TABLE IF NOT EXISTS fridge_items (
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL,
    title TEXT,
    image_src TEXT,
    raw_json TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (user_id, item_id)
  );

  CREATE TABLE IF NOT EXISTS forum_posts (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category_id TEXT NOT NULL,
    category_label TEXT NOT NULL,
    tags_json TEXT NOT NULL,
    views INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'published',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS forum_posts_created_idx
    ON forum_posts(created_at DESC);

  CREATE INDEX IF NOT EXISTS forum_posts_category_idx
    ON forum_posts(category_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS forum_comments (
    id TEXT PRIMARY KEY,
    post_id TEXT NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'published',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS forum_comments_post_idx
    ON forum_comments(post_id, created_at);

  CREATE TABLE IF NOT EXISTS forum_reports (
    id TEXT PRIMARY KEY,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    post_id TEXT REFERENCES forum_posts(id) ON DELETE CASCADE,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    reason TEXT NOT NULL,
    details TEXT,
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    resolved_by TEXT REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE INDEX IF NOT EXISTS forum_reports_status_idx
    ON forum_reports(status, created_at DESC);

  CREATE INDEX IF NOT EXISTS forum_reports_target_idx
    ON forum_reports(target_type, target_id);

  CREATE TABLE IF NOT EXISTS admin_audit (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    meta_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS admin_audit_created_idx
    ON admin_audit(created_at DESC);

  CREATE TABLE IF NOT EXISTS analytics_events (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
    session_id TEXT,
    event_name TEXT NOT NULL,
    screen TEXT,
    duration_ms INTEGER,
    meta_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS analytics_events_created_idx
    ON analytics_events(created_at DESC);

  CREATE INDEX IF NOT EXISTS analytics_events_user_idx
    ON analytics_events(user_id, created_at DESC);

  CREATE INDEX IF NOT EXISTS analytics_events_screen_idx
    ON analytics_events(screen, event_name);

  CREATE TABLE IF NOT EXISTS beta_invites (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    label TEXT,
    max_uses INTEGER,
    used_count INTEGER NOT NULL DEFAULT 0,
    created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL,
    last_used_at TEXT,
    disabled_at TEXT
  );

  CREATE INDEX IF NOT EXISTS beta_invites_status_idx
    ON beta_invites(disabled_at, created_at DESC);

  CREATE TABLE IF NOT EXISTS beta_invite_redemptions (
    invite_id TEXT NOT NULL REFERENCES beta_invites(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    used_at TEXT NOT NULL,
    PRIMARY KEY (invite_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS beta_feedback (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id) ON DELETE SET NULL,
    rating INTEGER,
    message TEXT NOT NULL,
    screen TEXT,
    topic TEXT NOT NULL DEFAULT 'feedback',
    status TEXT NOT NULL DEFAULT 'new',
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    resolved_by TEXT REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE INDEX IF NOT EXISTS beta_feedback_status_idx
    ON beta_feedback(status, created_at DESC);

  CREATE TABLE IF NOT EXISTS feature_flags (
    key TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    description TEXT,
    enabled INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT NOT NULL,
    updated_by TEXT REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE INDEX IF NOT EXISTS feature_flags_enabled_idx
    ON feature_flags(enabled, key);
`);

ensureTableColumn("beta_feedback", "topic", "TEXT NOT NULL DEFAULT 'feedback'");
db.exec("CREATE INDEX IF NOT EXISTS beta_feedback_topic_idx ON beta_feedback(topic, created_at DESC);");

db.prepare(`
  INSERT INTO schema_meta (key, value, updated_at)
  VALUES ('schema_version', ?, ?)
  ON CONFLICT(key) DO UPDATE SET
    value = excluded.value,
    updated_at = excluded.updated_at
`).run(SCHEMA_VERSION, nowIso());

seedFeatureFlags();
migrateLegacyJsonIfNeeded();

function sendJson(res, status, data, extraHeaders = {}) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": res.__corsOrigin || CORS_ORIGIN,
    "Vary": "Origin",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
    ...(res.__requestId ? { "X-Request-Id": res.__requestId } : {}),
    ...extraHeaders,
  });
  res.end(JSON.stringify(data));
}

function resolveCorsOrigin(origin) {
  if (!origin || ALLOWED_ORIGINS.includes("*")) return CORS_ORIGIN;
  if (ALLOWED_ORIGINS.includes(origin)) return origin;

  return CORS_ORIGIN;
}

function sendError(res, status, message, extraHeaders = {}) {
  sendJson(res, status, { error: message, requestId: res.__requestId }, extraHeaders);
}

function getPositiveNumberEnv(key, fallback) {
  const value = Number(process.env[key]);

  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function ensureTableColumn(tableName, columnName, definition) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  const hasColumn = columns.some((column) => column.name === columnName);

  if (!hasColumn) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition};`);
  }
}

function getClientIp(req) {
  const forwardedFor = String(req.headers["x-forwarded-for"] || "")
    .split(",")[0]
    .trim();
  const realIp = String(req.headers["x-real-ip"] || "").trim();
  const rawIp = forwardedFor || realIp || req.socket?.remoteAddress || "unknown";

  return rawIp.replace(/^::ffff:/, "").slice(0, 80);
}

function getClientUserAgent(req) {
  return String(req.headers["user-agent"] || "unknown").trim().slice(0, 500) || "unknown";
}

function validateRegistrationConsents(consents) {
  if (!consents || typeof consents !== "object" || Array.isArray(consents)) {
    return { ok: false, message: "Подтвердите согласия на обработку данных." };
  }

  const acceptedConsents = [];

  for (const required of REQUIRED_REGISTRATION_CONSENTS) {
    const item = consents[required.key];
    const document = LEGAL_DOCUMENTS[required.documentKey];
    const accepted = item && typeof item === "object" && item.accepted === true;
    const documentKey = String(item?.documentKey || "");
    const documentVersion = String(item?.documentVersion || item?.version || "");

    if (!accepted || documentKey !== required.documentKey || documentVersion !== document.version) {
      return { ok: false, message: "Подтвердите актуальные согласия и правила обработки данных." };
    }

    acceptedConsents.push({
      key: required.key,
      documentKey: required.documentKey,
      documentTitle: document.title,
      documentVersion: document.version,
      documentPath: document.path,
    });
  }

  return { ok: true, consents: acceptedConsents };
}

function getLegalConsentStatus(userId) {
  const rows = db.prepare(`
    SELECT consent_key, document_key, document_version, MAX(accepted_at) AS accepted_at
    FROM user_consents
    WHERE user_id = ?
    GROUP BY consent_key, document_key, document_version
  `).all(userId);
  const accepted = new Map(rows.map((row) => [`${row.consent_key}:${row.document_key}:${row.document_version}`, row]));
  const requiredConsents = REQUIRED_REGISTRATION_CONSENTS.map((required) => {
    const document = LEGAL_DOCUMENTS[required.documentKey];
    const key = `${required.key}:${required.documentKey}:${document.version}`;
    const acceptedRow = accepted.get(key);

    return {
      key: required.key,
      documentKey: required.documentKey,
      documentTitle: document.title,
      documentVersion: document.version,
      documentPath: document.path,
      acceptedAt: acceptedRow?.accepted_at || null,
      accepted: Boolean(acceptedRow),
    };
  });
  const missing = requiredConsents.filter((consent) => !consent.accepted);

  return {
    required: missing.length > 0,
    documentVersion: LEGAL_DOCUMENT_VERSION,
    missing: missing.map((consent) => consent.key),
    requiredConsents,
  };
}

function getLegalConsentAcceptedAt(status) {
  const acceptedAt = status.requiredConsents
    .map((consent) => consent.acceptedAt)
    .filter(Boolean)
    .sort();

  return acceptedAt.at(-1) || null;
}

function saveUserConsents({ userId, email, req, acceptedAt, consents, onlyKeys = null }) {
  const ip = getClientIp(req);
  const userAgent = getClientUserAgent(req);
  const insertConsent = db.prepare(`
    INSERT INTO user_consents (
      id, user_id, email, consent_key, document_key, document_title, document_version,
      accepted_at, ip_address, user_agent, meta_json
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  for (const consent of consents) {
    if (onlyKeys && !onlyKeys.has(consent.key)) continue;

    insertConsent.run(
      randomBytes(12).toString("hex"),
      userId,
      email,
      consent.key,
      consent.documentKey,
      consent.documentTitle,
      consent.documentVersion,
      acceptedAt,
      ip,
      userAgent,
      toJson({ documentPath: consent.documentPath, source: "registration" })
    );
  }
}

async function handleAccountConsentsAccept(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const consentValidation = validateRegistrationConsents(body.consents);

  if (!consentValidation.ok) {
    return sendError(res, 400, consentValidation.message);
  }

  const currentStatus = getLegalConsentStatus(auth.user.id);
  const missingKeys = new Set(currentStatus.missing);
  const acceptedAt = nowIso();

  transaction(() => {
    if (missingKeys.size > 0) {
      saveUserConsents({
        userId: auth.user.id,
        email: auth.user.email,
        req,
        acceptedAt,
        consents: consentValidation.consents,
        onlyKeys: missingKeys,
      });
    }
    addAudit(auth.user.id, "account.consents.accept", {
      version: LEGAL_DOCUMENT_VERSION,
      acceptedKeys: consentValidation.consents.map((consent) => consent.key),
      previousMissing: currentStatus.missing,
    });
  });

  return sendJson(res, 200, {
    ok: true,
    consentStatus: getLegalConsentStatus(auth.user.id),
  });
}

function cleanupExpiredRateLimits(now) {
  if (now - lastRateLimitCleanupAt < AUTH_RATE_LIMIT_WINDOW_MS) return;

  lastRateLimitCleanupAt = now;

  for (const [key, bucket] of rateLimitBuckets.entries()) {
    if (bucket.resetAt <= now) {
      rateLimitBuckets.delete(key);
    }
  }
}

function consumeRateLimit(res, key, limit, message) {
  if (!Number.isFinite(limit) || limit <= 0) return true;

  const now = Date.now();
  cleanupExpiredRateLimits(now);

  const current = rateLimitBuckets.get(key);
  const bucket = current && current.resetAt > now
    ? current
    : { count: 0, resetAt: now + AUTH_RATE_LIMIT_WINDOW_MS };

  if (bucket.count >= limit) {
    const retryAfterSeconds = Math.max(1, Math.ceil((bucket.resetAt - now) / 1000));

    sendError(res, 429, message, {
      "Retry-After": String(retryAfterSeconds),
      "X-RateLimit-Limit": String(limit),
      "X-RateLimit-Remaining": "0",
      "X-RateLimit-Reset": String(Math.ceil(bucket.resetAt / 1000)),
    });

    return false;
  }

  bucket.count += 1;
  rateLimitBuckets.set(key, bucket);

  return true;
}

function clearRateLimit(key) {
  rateLimitBuckets.delete(key);
}

function consumeAuthIpRateLimit(req, res, action, limit) {
  const clientIp = getClientIp(req);

  return consumeRateLimit(
    res,
    `auth:${action}:ip:${clientIp}`,
    limit,
    "Слишком много попыток. Подождите немного и попробуйте снова."
  );
}

function logAccess(req, res, startedAt, path) {
  if (!ACCESS_LOGS || !path.startsWith("/api/")) return;

  console.log(JSON.stringify({
    type: "access",
    requestId: res.__requestId,
    method: req.method,
    path,
    status: res.statusCode,
    durationMs: Date.now() - startedAt,
    ip: res.__clientIp,
  }));
}

function logServerError(req, res, error, path) {
  const errorInfo = {
    type: "error",
    requestId: res.__requestId,
    method: req.method,
    path,
    message: error instanceof Error ? error.message : String(error),
    ...(ERROR_STACKS && error instanceof Error ? { stack: error.stack } : {}),
  };

  console.error(JSON.stringify(errorInfo));
}

function getContentType(filePath) {
  const contentTypes = {
    ".html": "text/html; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".webp": "image/webp",
    ".woff": "font/woff",
    ".woff2": "font/woff2",
  };

  return contentTypes[extname(filePath).toLowerCase()] || "application/octet-stream";
}

function sendFile(res, filePath) {
  const body = readFileSync(filePath);
  const isAsset = filePath.includes(`${sep}assets${sep}`);

  res.writeHead(200, {
    "Content-Type": getContentType(filePath),
    "Cache-Control": isAsset ? "public, max-age=31536000, immutable" : "no-cache",
    ...(res.__requestId ? { "X-Request-Id": res.__requestId } : {}),
  });
  res.end(body);
}

function sendStaticAsset(res, pathname) {
  if (!SERVE_WEB) return sendError(res, 404, "Сайт не отдается этим сервером.");

  const distRoot = resolve(DIST_DIR);

  if (!existsSync(join(distRoot, "index.html"))) {
    return sendError(res, 404, "Сначала соберите сайт командой npm.cmd run build.");
  }

  let safePath;

  try {
    safePath = decodeURIComponent(pathname);
  } catch {
    return sendError(res, 400, "Некорректный путь.");
  }

  const relativePath = safePath === "/" ? "index.html" : safePath.replace(/^\/+/, "");
  const requestedPath = resolve(join(distRoot, relativePath));
  const isInsideDist = requestedPath === distRoot || requestedPath.startsWith(`${distRoot}${sep}`);

  if (!isInsideDist) return sendError(res, 403, "Недоступный путь.");

  if (existsSync(requestedPath)) {
    const info = statSync(requestedPath);

    if (info.isFile()) {
      return sendFile(res, requestedPath);
    }
  }

  return sendFile(res, join(distRoot, "index.html"));
}

async function readJsonBody(req) {
  const chunks = [];
  let totalBytes = 0;
  let tooLarge = false;

  for await (const chunk of req) {
    totalBytes += chunk.length;

    if (totalBytes > MAX_JSON_BODY_BYTES) {
      tooLarge = true;
      continue;
    }

    chunks.push(chunk);
  }

  if (tooLarge) return BODY_TOO_LARGE;

  const rawBody = Buffer.concat(chunks).toString("utf8");

  if (!rawBody) return {};

  try {
    return JSON.parse(rawBody);
  } catch {
    return null;
  }
}

function rejectBadJsonBody(res, body) {
  if (body === BODY_TOO_LARGE) {
    sendError(res, 413, "Запрос слишком большой. Уменьшите текст или размер изображений.");
    return true;
  }

  if (body === null) {
    sendError(res, 400, "Некорректный JSON.");
    return true;
  }

  return false;
}

function normalizeEmail(email) {
  return String(email || "").trim().toLowerCase();
}

function getEmailDomain(email) {
  const normalizedEmail = normalizeEmail(email);
  const domain = normalizedEmail.split("@")[1] || "";

  return domain.slice(0, 80);
}

function normalizeName(name, email) {
  const trimmedName = String(name || "").trim();

  if (trimmedName) return trimmedName;

  return normalizeEmail(email).split("@")[0] || "Родитель";
}

function nowIso() {
  return new Date().toISOString();
}

function createPasswordHash(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = pbkdf2Sync(String(password), salt, 120000, 32, "sha256").toString("hex");

  return { salt, hash };
}

function verifyPassword(password, salt, expectedHash) {
  const hash = pbkdf2Sync(String(password), salt, 120000, 32, "sha256");
  const expected = Buffer.from(expectedHash, "hex");

  return expected.length === hash.length && timingSafeEqual(hash, expected);
}

function parseJson(value, fallback = null) {
  try {
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function toJson(value) {
  return JSON.stringify(value ?? null);
}

function jsonSizeBytes(value) {
  return Buffer.byteLength(toJson(value), "utf8");
}

function getPlainText(value) {
  if (typeof value !== "string") return "";

  return value.replace(/\u0000/g, "").trim();
}

function isAllowedStorageKey(key) {
  if (typeof key !== "string") return false;
  if (key.length === 0 || key.length > MAX_STORAGE_KEY_LENGTH) return false;
  if (!key.startsWith("mvp.")) return false;
  if (key === "mvp.authenticated") return false;
  if (key.startsWith("mvp.server.")) return false;

  return true;
}

function validateStoragePayload(storage) {
  if (!storage || typeof storage !== "object" || Array.isArray(storage)) {
    return "Нужен объект storage.";
  }

  const entries = Object.entries(storage);

  if (entries.length > MAX_STORAGE_KEYS) {
    return `Слишком много ключей данных. Максимум: ${MAX_STORAGE_KEYS}.`;
  }

  for (const [key, value] of entries) {
    const error = validateStorageEntry(key, value);

    if (error) return error;
  }

  return "";
}

function validateStorageEntry(key, value) {
  if (!isAllowedStorageKey(key)) {
    return "Некорректный ключ данных.";
  }

  if (jsonSizeBytes(value) > MAX_STORAGE_VALUE_BYTES) {
    return "Слишком большой объем данных для одного раздела.";
  }

  if (key === "mvp.fridge.drawings") {
    return validateFridgeDrawings(value);
  }

  return "";
}

function validateFridgeDrawings(drawings) {
  if (!Array.isArray(drawings)) {
    return "Холодильник должен быть списком карточек.";
  }

  if (drawings.length > MAX_FRIDGE_CARDS) {
    return `Слишком много карточек в холодильнике. Максимум: ${MAX_FRIDGE_CARDS}.`;
  }

  let imageCount = 0;
  let totalImageBytes = 0;

  for (const drawing of drawings) {
    if (!drawing || typeof drawing !== "object" || Array.isArray(drawing)) {
      return "Некорректная карточка холодильника.";
    }

    if (typeof drawing.title === "string" && drawing.title.length > 120) {
      return "Название картинки в холодильнике слишком длинное.";
    }

    if (drawing.imageSrc == null || drawing.imageSrc === "") continue;

    if (typeof drawing.imageSrc !== "string") {
      return "Некорректное изображение в холодильнике.";
    }

    const imageBytes = estimateDataUrlImageBytes(drawing.imageSrc);

    if (!imageBytes) {
      return "Холодильник принимает только JPG, PNG или WEBP изображения.";
    }

    if (imageBytes > MAX_FRIDGE_IMAGE_BYTES) {
      return `Картинка слишком большая. Максимум: ${formatMegabytes(MAX_FRIDGE_IMAGE_BYTES)} МБ.`;
    }

    imageCount += 1;
    totalImageBytes += imageBytes;

    if (imageCount > MAX_FRIDGE_IMAGES) {
      return `Слишком много картинок в холодильнике. Максимум: ${MAX_FRIDGE_IMAGES}.`;
    }

    if (totalImageBytes > MAX_FRIDGE_TOTAL_IMAGE_BYTES) {
      return `Суммарный размер картинок в холодильнике слишком большой. Максимум: ${formatMegabytes(MAX_FRIDGE_TOTAL_IMAGE_BYTES)} МБ.`;
    }
  }

  return "";
}

function estimateDataUrlImageBytes(value) {
  const match = /^data:image\/(?:jpeg|jpg|png|webp);base64,([a-z0-9+/=\s]+)$/i.exec(value);

  if (!match) return 0;

  const base64 = match[1].replace(/\s/g, "");
  const padding = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;

  return Math.max(0, Math.floor((base64.length * 3) / 4) - padding);
}

function formatMegabytes(bytes) {
  return (bytes / 1024 / 1024).toFixed(1);
}

function normalizeInviteCode(value) {
  return String(value || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "-");
}

function createInviteCode() {
  return `BETA-${randomBytes(3).toString("hex").toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function isValidInviteCodeFormat(code) {
  return /^[A-Z0-9][A-Z0-9-]{5,63}$/.test(code);
}

function transaction(callback) {
  db.exec("BEGIN IMMEDIATE");

  try {
    const result = callback();
    db.exec("COMMIT");
    return result;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

function getUserCount() {
  return db.prepare("SELECT COUNT(*) AS count FROM users").get().count;
}

function getPublicUser(user) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role || "user",
    blockedAt: user.blocked_at,
    createdAt: user.created_at,
    lastLoginAt: user.last_login_at,
  };
}

function getBearerToken(req) {
  const header = req.headers.authorization || "";

  if (!header.startsWith("Bearer ")) return "";

  return header.slice("Bearer ".length).trim();
}

function cleanExpiredSessions() {
  db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(nowIso());
}

function createSession(userId) {
  const token = randomBytes(32).toString("hex");
  const createdAt = nowIso();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000).toISOString();

  db.prepare(`
    INSERT INTO sessions (token, user_id, created_at, last_seen_at, expires_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(token, userId, createdAt, createdAt, expiresAt);

  return token;
}

function getAuthedUser(req) {
  cleanExpiredSessions();

  const token = getBearerToken(req);

  if (!token) return null;

  const row = db.prepare(`
    SELECT
      sessions.token,
      sessions.created_at AS session_created_at,
      sessions.last_seen_at,
      sessions.expires_at,
      users.*
    FROM sessions
    JOIN users ON users.id = sessions.user_id
    WHERE sessions.token = ?
  `).get(token);

  if (!row || row.blocked_at) return null;

  db.prepare("UPDATE sessions SET last_seen_at = ? WHERE token = ?").run(nowIso(), token);

  return { token, user: row };
}

function addAudit(userId, action, meta = {}) {
  db.prepare(`
    INSERT INTO admin_audit (id, user_id, action, meta_json, created_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(randomBytes(8).toString("hex"), userId || null, action, toJson(meta), nowIso());
}

function getStorageForUser(userId) {
  const rows = db.prepare(`
    SELECT key, value_json
    FROM account_storage
    WHERE user_id = ?
    ORDER BY key
  `).all(userId);

  return Object.fromEntries(rows.map((row) => [row.key, parseJson(row.value_json)]));
}

function setStorageItem(userId, key, value) {
  db.prepare(`
    INSERT INTO account_storage (user_id, key, value_json, updated_at)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(user_id, key)
    DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at
  `).run(userId, key, toJson(value), nowIso());

  syncStructuredKey(userId, key, value);
}

function replaceStorage(userId, storage) {
  db.prepare("DELETE FROM account_storage WHERE user_id = ?").run(userId);
  clearStructuredData(userId);

  Object.entries(storage).forEach(([key, value]) => {
    setStorageItem(userId, key, value);
  });
}

function clearStructuredData(userId) {
  db.prepare("DELETE FROM baby_profiles WHERE user_id = ?").run(userId);
  db.prepare("DELETE FROM parent_goals WHERE user_id = ?").run(userId);
  db.prepare("DELETE FROM diary_entries WHERE user_id = ?").run(userId);
  db.prepare("DELETE FROM routines WHERE user_id = ?").run(userId);
  db.prepare("DELETE FROM shopping_items WHERE user_id = ?").run(userId);
  db.prepare("DELETE FROM fridge_items WHERE user_id = ?").run(userId);
}

function syncStructuredKey(userId, key, value) {
  if (key === "mvp.baby.profile") {
    syncBabyProfile(userId, value);
    return;
  }

  if (key === "mvp.parent.goals") {
    syncParentGoals(userId, value);
    return;
  }

  if (key === "mvp.tracker.entries") {
    syncDiaryEntries(userId, value);
    return;
  }

  if (key === "mvp.routines.items") {
    syncRoutines(userId, value);
    return;
  }

  if (key === "mvp.shopping.items") {
    syncShoppingItems(userId, value);
    return;
  }

  if (key === "mvp.fridge.drawings") {
    syncFridgeItems(userId, value);
  }
}

function getStorageAuditMeta(key, value) {
  const meta = { key };

  if (Array.isArray(value)) {
    meta.items = value.length;
  }

  if (key === "mvp.fridge.drawings" && Array.isArray(value)) {
    meta.images = value.filter(
      (item) => item && typeof item === "object" && typeof item.imageSrc === "string" && item.imageSrc.trim()
    ).length;
  }

  return meta;
}

function getStorageReplaceAuditMeta(storage) {
  const keys = Object.keys(storage);
  const meta = {
    keys: keys.length,
    sections: keys.slice(0, 12),
  };

  if (Array.isArray(storage["mvp.fridge.drawings"])) {
    const fridgeMeta = getStorageAuditMeta("mvp.fridge.drawings", storage["mvp.fridge.drawings"]);
    meta.fridgeItems = fridgeMeta.items || 0;
    meta.fridgeImages = fridgeMeta.images || 0;
  }

  return meta;
}

function syncBabyProfile(userId, profile) {
  db.prepare("DELETE FROM baby_profiles WHERE user_id = ?").run(userId);

  if (!profile || typeof profile !== "object") return;

  db.prepare(`
    INSERT INTO baby_profiles (
      user_id, name, birth_date, stage, height_cm, weight_kg, blood_type, emoji, updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    userId,
    String(profile.name || "Малыш"),
    String(profile.birthDate || ""),
    String(profile.stage || ""),
    String(profile.heightCm || ""),
    String(profile.weightKg || ""),
    String(profile.bloodType || ""),
    String(profile.emoji || "👶"),
    nowIso()
  );
}

function syncParentGoals(userId, goals) {
  db.prepare("DELETE FROM parent_goals WHERE user_id = ?").run(userId);

  if (!Array.isArray(goals)) return;

  const insert = db.prepare(`
    INSERT INTO parent_goals (user_id, goal_id, position, updated_at)
    VALUES (?, ?, ?, ?)
  `);

  goals.forEach((goalId, index) => {
    insert.run(userId, String(goalId), index, nowIso());
  });
}

function syncDiaryEntries(userId, entries) {
  db.prepare("DELETE FROM diary_entries WHERE user_id = ?").run(userId);

  if (!Array.isArray(entries)) return;

  const insert = db.prepare(`
    INSERT INTO diary_entries (
      user_id, entry_id, type, time, details, icon, category, date, source,
      routine_id, duration_minutes, raw_json, updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  entries.forEach((entry, index) => {
    const entryId = String(entry?.id ?? `${entry?.date || "no-date"}-${entry?.time || "no-time"}-${index}`);

    insert.run(
      userId,
      entryId,
      String(entry?.type || ""),
      String(entry?.time || ""),
      String(entry?.details || ""),
      String(entry?.icon || ""),
      String(entry?.category || ""),
      String(entry?.date || ""),
      String(entry?.source || ""),
      entry?.routineId == null ? null : String(entry.routineId),
      Number.isFinite(Number(entry?.durationMinutes)) ? Number(entry.durationMinutes) : null,
      toJson(entry),
      nowIso()
    );
  });
}

function syncRoutines(userId, routines) {
  db.prepare("DELETE FROM routines WHERE user_id = ?").run(userId);

  if (!Array.isArray(routines)) return;

  const insert = db.prepare(`
    INSERT INTO routines (
      user_id, routine_id, time, activity, emoji, duration, color, raw_json, updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  routines.forEach((routine, index) => {
    insert.run(
      userId,
      String(routine?.id ?? `${routine?.time || "no-time"}-${index}`),
      String(routine?.time || ""),
      String(routine?.activity || ""),
      String(routine?.emoji || ""),
      String(routine?.duration || ""),
      String(routine?.color || ""),
      toJson(routine),
      nowIso()
    );
  });
}

function syncShoppingItems(userId, categories) {
  db.prepare("DELETE FROM shopping_items WHERE user_id = ?").run(userId);

  if (!Array.isArray(categories)) return;

  const insert = db.prepare(`
    INSERT INTO shopping_items (
      user_id, item_key, category_id, category_name, name, checked,
      priority, price, raw_json, updated_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  categories.forEach((category, categoryIndex) => {
    const items = Array.isArray(category?.items) ? category.items : [];

    items.forEach((item, itemIndex) => {
      const itemKey = String(item?.id ?? `${category?.id || categoryIndex}-${itemIndex}`);

      insert.run(
        userId,
        itemKey,
        String(category?.id || ""),
        String(category?.name || ""),
        String(item?.name || ""),
        item?.checked ? 1 : 0,
        String(item?.priority || ""),
        String(item?.price || ""),
        toJson({ categoryId: category?.id, categoryName: category?.name, item }),
        nowIso()
      );
    });
  });
}

function syncFridgeItems(userId, items) {
  db.prepare("DELETE FROM fridge_items WHERE user_id = ?").run(userId);

  if (!Array.isArray(items)) return;

  const insert = db.prepare(`
    INSERT INTO fridge_items (user_id, item_id, title, image_src, raw_json, updated_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  items
    .filter((item) => item?.imageSrc)
    .forEach((item, index) => {
      insert.run(
        userId,
        String(item?.id ?? index),
        String(item?.title || item?.name || ""),
        String(item?.imageSrc || ""),
        toJson(item),
        nowIso()
      );
    });
}

const forumCategoryLabels = {
  health: "Здоровье",
  feeding: "Кормление",
  sleep: "Сон",
  development: "Развитие",
  shopping: "Покупки",
  routine: "Режим",
  other: "Общее",
};

const forumReportReasonLabels = {
  spam: "Спам или реклама",
  rude: "Грубость или токсичность",
  medical: "Опасный медицинский совет",
  private: "Личные данные",
  other: "Другое",
};

function getInitials(name = "") {
  const initials = String(name)
    .trim()
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return initials || "Р";
}

function sanitizeForumTags(tags) {
  if (!Array.isArray(tags)) return [];

  return Array.from(
    new Set(
      tags
        .map((tag) => String(tag || "").trim())
        .filter(Boolean)
        .map((tag) => tag.slice(0, FORUM_TAG_MAX_LENGTH))
    )
  ).slice(0, FORUM_TAG_MAX_COUNT);
}

function mapForumPost(row) {
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    preview: row.content.length > 170 ? `${row.content.slice(0, 170)}...` : row.content,
    categoryId: row.category_id,
    category: row.category_label,
    tags: parseJson(row.tags_json, []),
    views: row.views,
    comments: row.comments_count ?? 0,
    reports: row.reports_count ?? 0,
    status: row.status,
    author: row.author_name || "Родитель",
    avatar: getInitials(row.author_name),
    authorId: row.user_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastActivityAt: row.last_activity_at || row.updated_at,
  };
}

function mapForumComment(row) {
  return {
    id: row.id,
    postId: row.post_id,
    content: row.content,
    status: row.status,
    reports: row.reports_count ?? 0,
    author: row.author_name || "Родитель",
    avatar: getInitials(row.author_name),
    authorId: row.user_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function getForumPostById(postId) {
  const row = db.prepare(`
    SELECT
      forum_posts.*,
      users.name AS author_name,
      COUNT(DISTINCT forum_comments.id) AS comments_count,
      COUNT(DISTINCT forum_reports.id) AS reports_count,
      MAX(COALESCE(forum_comments.created_at, forum_posts.updated_at)) AS last_activity_at
    FROM forum_posts
    LEFT JOIN users ON users.id = forum_posts.user_id
    LEFT JOIN forum_comments ON forum_comments.post_id = forum_posts.id
      AND forum_comments.status = 'published'
    LEFT JOIN forum_reports ON forum_reports.target_type = 'post'
      AND forum_reports.target_id = forum_posts.id
      AND forum_reports.status = 'open'
    WHERE forum_posts.id = ?
      AND forum_posts.status = 'published'
    GROUP BY forum_posts.id
  `).get(postId);

  return row ? mapForumPost(row) : null;
}

function getForumComments(postId) {
  return db.prepare(`
    SELECT forum_comments.*, users.name AS author_name
    FROM forum_comments
    LEFT JOIN users ON users.id = forum_comments.user_id
    WHERE forum_comments.post_id = ?
      AND forum_comments.status = 'published'
    ORDER BY forum_comments.created_at ASC
  `).all(postId).map(mapForumComment);
}

function handleForumPostsList(res, url) {
  const tab = url.searchParams.get("tab") || "all";
  const search = String(url.searchParams.get("search") || "").trim().toLowerCase();
  const category = String(url.searchParams.get("category") || "").trim();
  const params = [];
  const conditions = ["forum_posts.status = 'published'"];

  if (search) {
    conditions.push("(LOWER(forum_posts.title) LIKE ? OR LOWER(forum_posts.content) LIKE ?)");
    params.push(`%${search}%`, `%${search}%`);
  }

  if (category) {
    conditions.push("forum_posts.category_id = ?");
    params.push(category);
  }

  const orderBy =
    tab === "popular"
      ? "comments_count DESC, forum_posts.views DESC, forum_posts.created_at DESC"
      : "forum_posts.created_at DESC";
  const posts = db.prepare(`
    SELECT
      forum_posts.*,
      users.name AS author_name,
      COUNT(DISTINCT forum_comments.id) AS comments_count,
      COUNT(DISTINCT forum_reports.id) AS reports_count,
      MAX(COALESCE(forum_comments.created_at, forum_posts.updated_at)) AS last_activity_at
    FROM forum_posts
    LEFT JOIN users ON users.id = forum_posts.user_id
    LEFT JOIN forum_comments ON forum_comments.post_id = forum_posts.id
      AND forum_comments.status = 'published'
    LEFT JOIN forum_reports ON forum_reports.target_type = 'post'
      AND forum_reports.target_id = forum_posts.id
      AND forum_reports.status = 'open'
    WHERE ${conditions.join(" AND ")}
    GROUP BY forum_posts.id
    ORDER BY ${orderBy}
    LIMIT 100
  `).all(...params).map(mapForumPost);
  const stats = {
    posts: db.prepare("SELECT COUNT(*) AS count FROM forum_posts WHERE status = 'published'").get().count,
    comments: db.prepare("SELECT COUNT(*) AS count FROM forum_comments WHERE status = 'published'").get().count,
    today: db.prepare(`
      SELECT COUNT(*) AS count
      FROM forum_posts
      WHERE status = 'published'
        AND created_at >= ?
    `).get(new Date(new Date().setHours(0, 0, 0, 0)).toISOString()).count,
  };

  return sendJson(res, 200, { posts, stats });
}

async function handleForumPostCreate(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const title = getPlainText(body.title);
  const content = getPlainText(body.content);
  const categoryId = getPlainText(body.category || body.categoryId || "other").slice(0, 40);
  const categoryLabel = forumCategoryLabels[categoryId] || forumCategoryLabels.other;
  const tags = sanitizeForumTags(body.tags);

  if (title.length < 6) return sendError(res, 400, "Заголовок должен быть не короче 6 символов.");
  if (title.length > FORUM_TITLE_MAX_LENGTH) return sendError(res, 400, "Заголовок слишком длинный.");
  if (content.length < 20) return sendError(res, 400, "Опишите вопрос чуть подробнее.");
  if (content.length > FORUM_POST_MAX_LENGTH) return sendError(res, 400, "Текст поста слишком длинный.");

  const createdAt = nowIso();
  const id = randomBytes(12).toString("hex");

  transaction(() => {
    db.prepare(`
      INSERT INTO forum_posts (
        id, user_id, title, content, category_id, category_label,
        tags_json, views, status, created_at, updated_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 0, 'published', ?, ?)
    `).run(id, auth.user.id, title, content, categoryId, categoryLabel, toJson(tags), createdAt, createdAt);
    addAudit(auth.user.id, "forum.post.create", { postId: id, category: categoryId });
  });

  return sendJson(res, 201, { post: getForumPostById(id) });
}

function handleForumPostDetail(res, postId) {
  const post = getForumPostById(postId);

  if (!post) return sendError(res, 404, "Пост не найден.");

  db.prepare("UPDATE forum_posts SET views = views + 1 WHERE id = ?").run(postId);

  return sendJson(res, 200, {
    post: getForumPostById(postId),
    comments: getForumComments(postId),
  });
}

async function handleForumCommentCreate(req, res, auth, postId) {
  const post = getForumPostById(postId);

  if (!post) return sendError(res, 404, "Пост не найден.");

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const content = getPlainText(body.content);

  if (content.length < 2) return sendError(res, 400, "Комментарий слишком короткий.");
  if (content.length > FORUM_COMMENT_MAX_LENGTH) return sendError(res, 400, "Комментарий слишком длинный.");

  const id = randomBytes(12).toString("hex");
  const createdAt = nowIso();

  transaction(() => {
    db.prepare(`
      INSERT INTO forum_comments (
        id, post_id, user_id, content, status, created_at, updated_at
      )
      VALUES (?, ?, ?, ?, 'published', ?, ?)
    `).run(id, postId, auth.user.id, content, createdAt, createdAt);
    db.prepare("UPDATE forum_posts SET updated_at = ? WHERE id = ?").run(createdAt, postId);
    addAudit(auth.user.id, "forum.comment.create", { postId, commentId: id });
  });

  return sendJson(res, 201, {
    comment: mapForumComment(
      db.prepare(`
        SELECT forum_comments.*, users.name AS author_name
        FROM forum_comments
        LEFT JOIN users ON users.id = forum_comments.user_id
        WHERE forum_comments.id = ?
      `).get(id)
    ),
    post: getForumPostById(postId),
  });
}

async function handleForumReportCreate(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const targetType = getPlainText(body.targetType || body.target_type);
  const targetId = getPlainText(body.targetId || body.target_id);
  const reason = getPlainText(body.reason || "other");
  const details = getPlainText(body.details);

  if (!["post", "comment"].includes(targetType)) return sendError(res, 400, "Нужен тип жалобы.");
  if (!targetId) return sendError(res, 400, "Нужна цель жалобы.");
  if (!forumReportReasonLabels[reason]) return sendError(res, 400, "Неверная причина жалобы.");
  if (details.length > FORUM_REPORT_DETAILS_MAX_LENGTH) return sendError(res, 400, "Пояснение к жалобе слишком длинное.");

  const target =
    targetType === "post"
      ? db.prepare(`
          SELECT id, id AS post_id
          FROM forum_posts
          WHERE id = ?
            AND status = 'published'
        `).get(targetId)
      : db.prepare(`
          SELECT forum_comments.id, forum_comments.post_id
          FROM forum_comments
          JOIN forum_posts ON forum_posts.id = forum_comments.post_id
          WHERE forum_comments.id = ?
            AND forum_comments.status = 'published'
            AND forum_posts.status = 'published'
        `).get(targetId);

  if (!target) return sendError(res, 404, "Материал не найден.");

  const duplicate = db.prepare(`
    SELECT id
    FROM forum_reports
    WHERE target_type = ?
      AND target_id = ?
      AND user_id = ?
      AND status = 'open'
  `).get(targetType, targetId, auth.user.id);

  if (duplicate) {
    return sendJson(res, 200, { ok: true, reportId: duplicate.id, duplicate: true });
  }

  const id = randomBytes(12).toString("hex");
  const createdAt = nowIso();

  transaction(() => {
    db.prepare(`
      INSERT INTO forum_reports (
        id, target_type, target_id, post_id, user_id, reason, details,
        status, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)
    `).run(id, targetType, targetId, target.post_id, auth.user.id, reason, details, createdAt);
    addAudit(auth.user.id, "forum.report.create", { reportId: id, targetType, targetId, reason });
  });

  return sendJson(res, 201, { ok: true, reportId: id });
}

function mapAdminForumPost(row) {
  return {
    ...mapForumPost(row),
    reports: row.reports_count ?? 0,
  };
}

function mapAdminForumComment(row) {
  return {
    ...mapForumComment(row),
    postTitle: row.post_title || "Обсуждение",
    reports: row.reports_count ?? 0,
  };
}

function mapAdminForumReport(row) {
  const isPost = row.target_type === "post";

  return {
    id: row.id,
    targetType: row.target_type,
    targetId: row.target_id,
    postId: row.post_id,
    reason: row.reason,
    reasonLabel: forumReportReasonLabels[row.reason] || forumReportReasonLabels.other,
    details: row.details || "",
    status: row.status,
    createdAt: row.created_at,
    resolvedAt: row.resolved_at,
    reporterName: row.reporter_name,
    reporterEmail: row.reporter_email,
    resolverName: row.resolver_name,
    targetLabel: isPost
      ? row.target_post_title || row.post_title || "Пост форума"
      : `Ответ в теме: ${row.post_title || "обсуждение"}`,
    targetPreview: isPost ? row.target_post_content || "" : row.target_comment_content || "",
  };
}

function getAdminForumPosts(limit = 15) {
  return db.prepare(`
    SELECT
      forum_posts.*,
      users.name AS author_name,
      COUNT(DISTINCT CASE WHEN forum_comments.status = 'published' THEN forum_comments.id END) AS comments_count,
      COUNT(DISTINCT CASE WHEN forum_reports.status = 'open' THEN forum_reports.id END) AS reports_count,
      MAX(COALESCE(forum_comments.created_at, forum_posts.updated_at)) AS last_activity_at
    FROM forum_posts
    LEFT JOIN users ON users.id = forum_posts.user_id
    LEFT JOIN forum_comments ON forum_comments.post_id = forum_posts.id
    LEFT JOIN forum_reports ON forum_reports.target_type = 'post'
      AND forum_reports.target_id = forum_posts.id
    GROUP BY forum_posts.id
    ORDER BY reports_count DESC, forum_posts.updated_at DESC
    LIMIT ?
  `).all(limit).map(mapAdminForumPost);
}

function getAdminForumComments(limit = 15) {
  return db.prepare(`
    SELECT
      forum_comments.*,
      users.name AS author_name,
      forum_posts.title AS post_title,
      COUNT(DISTINCT CASE WHEN forum_reports.status = 'open' THEN forum_reports.id END) AS reports_count
    FROM forum_comments
    LEFT JOIN users ON users.id = forum_comments.user_id
    LEFT JOIN forum_posts ON forum_posts.id = forum_comments.post_id
    LEFT JOIN forum_reports ON forum_reports.target_type = 'comment'
      AND forum_reports.target_id = forum_comments.id
    GROUP BY forum_comments.id
    ORDER BY reports_count DESC, forum_comments.updated_at DESC
    LIMIT ?
  `).all(limit).map(mapAdminForumComment);
}

function getAdminForumReports(limit = 25) {
  return db.prepare(`
    SELECT
      forum_reports.*,
      reporter.name AS reporter_name,
      reporter.email AS reporter_email,
      resolver.name AS resolver_name,
      forum_posts.title AS post_title,
      target_posts.title AS target_post_title,
      target_posts.content AS target_post_content,
      target_comments.content AS target_comment_content
    FROM forum_reports
    LEFT JOIN users AS reporter ON reporter.id = forum_reports.user_id
    LEFT JOIN users AS resolver ON resolver.id = forum_reports.resolved_by
    LEFT JOIN forum_posts ON forum_posts.id = forum_reports.post_id
    LEFT JOIN forum_posts AS target_posts
      ON target_posts.id = forum_reports.target_id
      AND forum_reports.target_type = 'post'
    LEFT JOIN forum_comments AS target_comments
      ON target_comments.id = forum_reports.target_id
      AND forum_reports.target_type = 'comment'
    ORDER BY
      CASE WHEN forum_reports.status = 'open' THEN 0 ELSE 1 END,
      forum_reports.created_at DESC
    LIMIT ?
  `).all(limit).map(mapAdminForumReport);
}

function getForumModerationSummary() {
  const countPostStatus = db.prepare("SELECT COUNT(*) AS count FROM forum_posts WHERE status = ?");
  const countCommentStatus = db.prepare("SELECT COUNT(*) AS count FROM forum_comments WHERE status = ?");

  return {
    stats: {
      publishedPosts: countPostStatus.get("published").count,
      hiddenPosts: countPostStatus.get("hidden").count,
      deletedPosts: countPostStatus.get("deleted").count,
      publishedComments: countCommentStatus.get("published").count,
      hiddenComments: countCommentStatus.get("hidden").count,
      deletedComments: countCommentStatus.get("deleted").count,
      openReports: db.prepare("SELECT COUNT(*) AS count FROM forum_reports WHERE status = 'open'").get().count,
      totalReports: getCount("forum_reports"),
    },
    reports: getAdminForumReports(),
    posts: getAdminForumPosts(),
    comments: getAdminForumComments(),
  };
}

function resolveOpenForumReports(targetType, targetId, adminId) {
  db.prepare(`
    UPDATE forum_reports
    SET status = 'reviewed',
        resolved_at = ?,
        resolved_by = ?
    WHERE target_type = ?
      AND target_id = ?
      AND status = 'open'
  `).run(nowIso(), adminId, targetType, targetId);
}

async function handleAdminForumPostStatus(req, res, auth, postId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);
  if (rejectBadJsonBody(res, body)) return;

  const status = getPlainText(body.status);

  if (!["published", "hidden", "deleted"].includes(status)) return sendError(res, 400, "Неверный статус поста.");

  const existing = db.prepare("SELECT id FROM forum_posts WHERE id = ?").get(postId);
  if (!existing) return sendError(res, 404, "Пост не найден.");

  transaction(() => {
    db.prepare("UPDATE forum_posts SET status = ?, updated_at = ? WHERE id = ?").run(status, nowIso(), postId);
    if (status !== "published") resolveOpenForumReports("post", postId, auth.user.id);
    addAudit(auth.user.id, "admin.forum.post.moderate", { postId, status });
  });

  return sendJson(res, 200, { ok: true, forumModeration: getForumModerationSummary() });
}

async function handleAdminForumCommentStatus(req, res, auth, commentId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);
  if (rejectBadJsonBody(res, body)) return;

  const status = getPlainText(body.status);

  if (!["published", "hidden", "deleted"].includes(status)) return sendError(res, 400, "Неверный статус ответа.");

  const existing = db.prepare("SELECT id, post_id FROM forum_comments WHERE id = ?").get(commentId);
  if (!existing) return sendError(res, 404, "Ответ не найден.");

  transaction(() => {
    db.prepare("UPDATE forum_comments SET status = ?, updated_at = ? WHERE id = ?").run(status, nowIso(), commentId);
    db.prepare("UPDATE forum_posts SET updated_at = ? WHERE id = ?").run(nowIso(), existing.post_id);
    if (status !== "published") resolveOpenForumReports("comment", commentId, auth.user.id);
    addAudit(auth.user.id, "admin.forum.comment.moderate", { commentId, postId: existing.post_id, status });
  });

  return sendJson(res, 200, { ok: true, forumModeration: getForumModerationSummary() });
}

async function handleAdminForumReportStatus(req, res, auth, reportId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);
  if (rejectBadJsonBody(res, body)) return;

  const status = getPlainText(body.status);

  if (!["open", "reviewed", "dismissed"].includes(status)) return sendError(res, 400, "Неверный статус жалобы.");

  const existing = db.prepare("SELECT id FROM forum_reports WHERE id = ?").get(reportId);
  if (!existing) return sendError(res, 404, "Жалоба не найдена.");

  transaction(() => {
    db.prepare(`
      UPDATE forum_reports
      SET status = ?,
          resolved_at = CASE WHEN ? = 'open' THEN NULL ELSE ? END,
          resolved_by = CASE WHEN ? = 'open' THEN NULL ELSE ? END
      WHERE id = ?
    `).run(status, status, nowIso(), status, auth.user.id, reportId);
    addAudit(auth.user.id, "admin.forum.report.moderate", { reportId, status });
  });

  return sendJson(res, 200, { ok: true, forumModeration: getForumModerationSummary() });
}

async function handleAuthRegister(req, res) {
  if (!consumeAuthIpRateLimit(req, res, "register", AUTH_REGISTER_IP_LIMIT)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const email = normalizeEmail(body.email);
  const password = String(body.password || "");
  const name = normalizeName(getPlainText(body.name), email);

  if (!email.includes("@")) return sendError(res, 400, "Укажите корректный email.");
  if (email.length > 254) return sendError(res, 400, "Email слишком длинный.");
  if (name.length > 80) return sendError(res, 400, "Имя слишком длинное.");
  if (password.length < 6) return sendError(res, 400, "Пароль должен быть не короче 6 символов.");
  if (password.length > 128) return sendError(res, 400, "Пароль слишком длинный.");

  if (REGISTRATION_MODE === "disabled") {
    addAudit(null, "auth.register.failed", {
      reason: "registration_disabled",
      emailDomain: getEmailDomain(email),
    });
    return sendError(res, 403, "Регистрация сейчас закрыта. Войдите в существующий аккаунт.");
  }

  let inviteGrant = null;

  if (REGISTRATION_MODE === "closed") {
    inviteGrant = getInviteGrant(body.inviteCode);

    if (!BETA_INVITE_CODE && getActiveBetaInviteCount() === 0) {
      return sendError(res, 503, "Закрытая бета еще не настроена: на сервере нет инвайт-кода.");
    }

    if (!inviteGrant.ok) {
      addAudit(null, "auth.register.failed", {
        reason: "invalid_invite",
        emailDomain: getEmailDomain(email),
      });
      return sendError(res, 403, "Нужен действующий код доступа к закрытой бете.");
    }
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    addAudit(null, "auth.register.failed", {
      reason: "email_exists",
      emailDomain: getEmailDomain(email),
    });
    return sendError(res, 409, "Такой email уже зарегистрирован.");
  }

  const consentValidation = validateRegistrationConsents(body.consents);
  if (!consentValidation.ok) {
    addAudit(null, "auth.register.failed", {
      reason: "missing_consents",
      emailDomain: getEmailDomain(email),
    });
    return sendError(res, 400, consentValidation.message);
  }

  const { salt, hash } = createPasswordHash(password);
  const createdAt = nowIso();
  let user;

  try {
    user = transaction(() => {
    const nextUser = {
      id: randomBytes(12).toString("hex"),
      email,
      name,
      role: getUserCount() === 0 ? "admin" : "user",
      password_salt: salt,
      password_hash: hash,
      created_at: createdAt,
      last_login_at: createdAt,
    };

    db.prepare(`
      INSERT INTO users (
        id, email, name, role, password_salt, password_hash, created_at, last_login_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      nextUser.id,
      nextUser.email,
      nextUser.name,
      nextUser.role,
      nextUser.password_salt,
      nextUser.password_hash,
      nextUser.created_at,
      nextUser.last_login_at
    );
    applyInviteGrant(inviteGrant, nextUser.id);
    saveUserConsents({
      userId: nextUser.id,
      email: nextUser.email,
      req,
      acceptedAt: createdAt,
      consents: consentValidation.consents,
    });
    addAudit(nextUser.id, "auth.register", {
      role: nextUser.role,
      invite: inviteGrant?.type || "open",
      consents: consentValidation.consents.map((consent) => ({
        key: consent.key,
        documentKey: consent.documentKey,
        version: consent.documentVersion,
      })),
    });
    createSession(nextUser.id);

    return nextUser;
    });
  } catch (error) {
    if (error instanceof Error && error.message === "beta-invite-unavailable") {
      addAudit(null, "auth.register.failed", {
        reason: "invite_used",
        emailDomain: getEmailDomain(email),
      });
      return sendError(res, 403, "Этот beta-код уже использован.");
    }

    throw error;
  }
  const session = db.prepare(`
    SELECT token FROM sessions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1
  `).get(user.id);

  return sendJson(res, 201, {
    token: session.token,
    user: getPublicUser(user),
    storage: {},
    consentStatus: getLegalConsentStatus(user.id),
  });
}

async function handleAuthLogin(req, res) {
  if (!consumeAuthIpRateLimit(req, res, "login", AUTH_LOGIN_IP_LIMIT)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const email = normalizeEmail(body.email);
  const password = String(body.password || "");
  const emailRateLimitKey = `auth:login:email:${email || "empty"}`;

  if (email.length > 254 || password.length > 128) {
    return sendError(res, 401, "Email или пароль не подошли.");
  }

  if (
    !consumeRateLimit(
      res,
      emailRateLimitKey,
      AUTH_LOGIN_EMAIL_LIMIT,
      "Слишком много попыток входа для этого email. Подождите немного и попробуйте снова."
    )
  ) {
    return;
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || user.blocked_at || !verifyPassword(password, user.password_salt, user.password_hash)) {
    addAudit(null, "auth.login.failed", {
      reason: user?.blocked_at ? "blocked" : "invalid_credentials",
      emailDomain: getEmailDomain(email),
    });
    return sendError(res, 401, "Email или пароль не подошли.");
  }

  const token = transaction(() => {
    db.prepare("UPDATE users SET last_login_at = ? WHERE id = ?").run(nowIso(), user.id);
    addAudit(user.id, "auth.login");
    return createSession(user.id);
  });
  clearRateLimit(emailRateLimitKey);

  const freshUser = db.prepare("SELECT * FROM users WHERE id = ?").get(user.id);

  return sendJson(res, 200, {
    token,
    user: getPublicUser(freshUser),
    storage: getStorageForUser(user.id),
    consentStatus: getLegalConsentStatus(user.id),
  });
}

function handleAuthLogout(req, res) {
  const token = getBearerToken(req);

  db.prepare("DELETE FROM sessions WHERE token = ?").run(token);

  return sendJson(res, 200, { ok: true });
}

async function handleStoragePut(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const validationError = validateStoragePayload(body.storage);
  if (validationError) return sendError(res, 400, validationError);

  transaction(() => {
    replaceStorage(auth.user.id, body.storage);
    addAudit(auth.user.id, "storage.replace", getStorageReplaceAuditMeta(body.storage));
  });

  return sendJson(res, 200, { ok: true, storage: getStorageForUser(auth.user.id) });
}

async function handleStoragePatch(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;
  if (!body || typeof body.key !== "string") return sendError(res, 400, "Нужен ключ storage.");

  const validationError = validateStorageEntry(body.key, body.value);
  if (validationError) return sendError(res, 400, validationError);

  transaction(() => {
    setStorageItem(auth.user.id, body.key, body.value);
    addAudit(auth.user.id, "storage.patch", getStorageAuditMeta(body.key, body.value));
  });

  return sendJson(res, 200, { ok: true });
}

function assertAdmin(res, auth) {
  if (auth.user.role !== "admin") {
    sendError(res, 403, "Нужны права администратора.");
    return false;
  }

  return true;
}

function getAdminManagedUser(userId) {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
}

function isLastActiveAdmin(userId) {
  const user = getAdminManagedUser(userId);

  if (!user || user.role !== "admin" || user.blocked_at) return false;

  const activeAdmins = db.prepare(`
    SELECT COUNT(*) AS count
    FROM users
    WHERE role = 'admin' AND blocked_at IS NULL
  `).get().count;

  return activeAdmins <= 1;
}

function getActiveSessionCount(userId) {
  return db.prepare(`
    SELECT COUNT(*) AS count
    FROM sessions
    WHERE user_id = ?
      AND expires_at > ?
  `).get(userId, nowIso()).count;
}

function getCount(table) {
  return db.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count;
}

function formatBackupInfo(fileName) {
  const path = join(BACKUP_DIR, fileName);
  const info = statSync(path);

  return {
    fileName,
    path,
    sizeBytes: info.size,
    createdAt: info.birthtime.toISOString(),
    updatedAt: info.mtime.toISOString(),
  };
}

function getRecentBackups(limit = 5) {
  if (!existsSync(BACKUP_DIR)) return [];

  return readdirSync(BACKUP_DIR)
    .filter((fileName) => fileName.endsWith(".db"))
    .map(formatBackupInfo)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, limit);
}

function getDatabaseInfo() {
  const info = existsSync(DB_FILE) ? statSync(DB_FILE) : null;

  return {
    path: DB_FILE,
    sizeBytes: info?.size ?? 0,
    backupDir: BACKUP_DIR,
    backups: getRecentBackups(),
  };
}

function mapBetaInvite(row) {
  return {
    id: row.id,
    code: row.code,
    label: row.label || "",
    maxUses: row.max_uses ?? null,
    usedCount: row.used_count || 0,
    createdBy: row.created_by_name || row.created_by_email || "",
    createdByEmail: row.created_by_email || "",
    createdAt: row.created_at,
    lastUsedAt: row.last_used_at,
    disabledAt: row.disabled_at,
    active: !row.disabled_at && (row.max_uses == null || row.used_count < row.max_uses),
  };
}

function getBetaInvites(limit = 12) {
  return db.prepare(`
    SELECT
      beta_invites.*,
      users.name AS created_by_name,
      users.email AS created_by_email
    FROM beta_invites
    LEFT JOIN users ON users.id = beta_invites.created_by
    ORDER BY beta_invites.created_at DESC
    LIMIT ?
  `).all(limit).map(mapBetaInvite);
}

function getActiveBetaInviteCount() {
  return db.prepare(`
    SELECT COUNT(*) AS count
    FROM beta_invites
    WHERE disabled_at IS NULL
      AND (max_uses IS NULL OR used_count < max_uses)
  `).get().count;
}

function getInviteGrant(inviteCode) {
  const code = normalizeInviteCode(inviteCode);

  if (!code) {
    return { ok: false, status: 403, message: "Нужен код доступа к закрытой бете." };
  }

  if (BETA_INVITE_CODE && code === normalizeInviteCode(BETA_INVITE_CODE)) {
    return { ok: true, type: "env", code };
  }

  const invite = db.prepare(`
    SELECT *
    FROM beta_invites
    WHERE code = ?
  `).get(code);

  if (!invite || invite.disabled_at) {
    return { ok: false, status: 403, message: "Нужен действующий код доступа к закрытой бете." };
  }

  if (invite.max_uses != null && invite.used_count >= invite.max_uses) {
    return { ok: false, status: 403, message: "Этот beta-код уже использован." };
  }

  return { ok: true, type: "db", id: invite.id, code };
}

function applyInviteGrant(inviteGrant, userId) {
  if (!inviteGrant || inviteGrant.type !== "db") return;

  const usedAt = nowIso();
  const result = db.prepare(`
    UPDATE beta_invites
    SET used_count = used_count + 1,
        last_used_at = ?
    WHERE id = ?
      AND disabled_at IS NULL
      AND (max_uses IS NULL OR used_count < max_uses)
  `).run(usedAt, inviteGrant.id);

  if (result.changes !== 1) {
    throw new Error("beta-invite-unavailable");
  }

  db.prepare(`
    INSERT INTO beta_invite_redemptions (invite_id, user_id, used_at)
    VALUES (?, ?, ?)
  `).run(inviteGrant.id, userId, usedAt);
}

function getAdminConfigInfo() {
  const activeInviteCount = getActiveBetaInviteCount();

  return {
    publicUrl: PUBLIC_URL,
    allowedOrigins: ALLOWED_ORIGINS,
    registrationMode: REGISTRATION_MODE,
    registrationRequiresInvite: REGISTRATION_MODE === "closed",
    inviteConfigured: BETA_INVITE_CODE.length > 0 || activeInviteCount > 0,
    envInviteConfigured: BETA_INVITE_CODE.length > 0,
    activeInviteCount,
    inviteCodes: getBetaInvites(),
    serveWeb: SERVE_WEB,
    healthDetails: EXPOSE_HEALTH_DETAILS,
    accessLogs: ACCESS_LOGS,
    errorStacks: ERROR_STACKS,
    legalDocuments: LEGAL_DOCUMENTS,
    limits: {
      maxJsonBodyBytes: MAX_JSON_BODY_BYTES,
      maxStorageKeys: MAX_STORAGE_KEYS,
      maxStorageValueBytes: MAX_STORAGE_VALUE_BYTES,
      maxFridgeCards: MAX_FRIDGE_CARDS,
      maxFridgeImages: MAX_FRIDGE_IMAGES,
      maxFridgeImageBytes: MAX_FRIDGE_IMAGE_BYTES,
      maxFridgeTotalImageBytes: MAX_FRIDGE_TOTAL_IMAGE_BYTES,
      forumTitleMaxLength: FORUM_TITLE_MAX_LENGTH,
      forumPostMaxLength: FORUM_POST_MAX_LENGTH,
      forumCommentMaxLength: FORUM_COMMENT_MAX_LENGTH,
      forumReportDetailsMaxLength: FORUM_REPORT_DETAILS_MAX_LENGTH,
    },
  };
}

function getAdminUsers() {
  const activeNow = nowIso();

  return db.prepare(`
    SELECT
      users.*,
      baby_profiles.name AS baby_name,
      baby_profiles.birth_date,
      baby_profiles.stage,
      baby_profiles.height_cm,
      baby_profiles.weight_kg,
      baby_profiles.blood_type,
      baby_profiles.emoji,
      COUNT(DISTINCT account_storage.key) AS storage_keys,
      COUNT(DISTINCT diary_entries.entry_id) AS diary_entries,
      COUNT(DISTINCT routines.routine_id) AS routines,
      COUNT(DISTINCT fridge_items.item_id) AS fridge_items,
      COUNT(DISTINCT sessions.token) AS active_sessions,
      COUNT(DISTINCT shopping_items.item_key) AS shopping_items,
      COUNT(DISTINCT CASE WHEN shopping_items.checked = 1 THEN shopping_items.item_key END) AS shopping_checked,
      COUNT(DISTINCT forum_posts.id) AS forum_posts,
      COUNT(DISTINCT forum_comments.id) AS forum_comments
    FROM users
    LEFT JOIN baby_profiles ON baby_profiles.user_id = users.id
    LEFT JOIN account_storage ON account_storage.user_id = users.id
    LEFT JOIN diary_entries ON diary_entries.user_id = users.id
    LEFT JOIN routines ON routines.user_id = users.id
    LEFT JOIN fridge_items ON fridge_items.user_id = users.id
    LEFT JOIN sessions ON sessions.user_id = users.id AND sessions.expires_at > ?
    LEFT JOIN shopping_items ON shopping_items.user_id = users.id
    LEFT JOIN forum_posts ON forum_posts.user_id = users.id AND forum_posts.status = 'published'
    LEFT JOIN forum_comments ON forum_comments.user_id = users.id AND forum_comments.status = 'published'
    GROUP BY users.id
    ORDER BY users.created_at DESC
  `).all(activeNow).map((user) => {
    const goals = db.prepare(`
      SELECT goal_id
      FROM parent_goals
      WHERE user_id = ?
      ORDER BY position
    `).all(user.id).map((goal) => goal.goal_id);
    const consentStatus = getLegalConsentStatus(user.id);

    return {
      ...getPublicUser(user),
      activeSessions: user.active_sessions,
      storageKeys: user.storage_keys,
      diaryEntries: user.diary_entries,
      routines: user.routines,
      shoppingItems: user.shopping_items,
      shoppingChecked: user.shopping_checked,
      forumPosts: user.forum_posts,
      forumComments: user.forum_comments,
      fridgeItems: user.fridge_items,
      babyName: user.baby_name,
      goals,
      consentStatus,
      legalConsentAcceptedAt: getLegalConsentAcceptedAt(consentStatus),
      recentDiaryEntries: getUserRecentDiaryEntries(user.id),
      recentForumPosts: getUserRecentForumPosts(user.id),
      recentActivity: getUserRecentActivity(user.id),
      babyProfile: user.baby_name
        ? {
            name: user.baby_name,
            birthDate: user.birth_date,
            stage: user.stage,
            heightCm: user.height_cm,
            weightKg: user.weight_kg,
            bloodType: user.blood_type,
            emoji: user.emoji,
          }
        : null,
    };
  });
}

function getUserRecentDiaryEntries(userId, limit = 4) {
  return db.prepare(`
    SELECT
      diary_entries.entry_id,
      diary_entries.type,
      diary_entries.time,
      diary_entries.details,
      diary_entries.icon,
      diary_entries.category,
      diary_entries.date,
      diary_entries.updated_at,
      users.name AS user_name,
      users.email AS user_email,
      baby_profiles.name AS baby_name
    FROM diary_entries
    JOIN users ON users.id = diary_entries.user_id
    LEFT JOIN baby_profiles ON baby_profiles.user_id = users.id
    WHERE diary_entries.user_id = ?
    ORDER BY diary_entries.date DESC, diary_entries.time DESC, diary_entries.updated_at DESC
    LIMIT ?
  `).all(userId, limit).map((entry) => ({
    id: entry.entry_id,
    type: entry.type,
    time: entry.time,
    details: entry.details,
    icon: entry.icon,
    category: entry.category,
    date: entry.date,
    updatedAt: entry.updated_at,
    userId,
    userName: entry.user_name,
    userEmail: entry.user_email,
    babyName: entry.baby_name,
  }));
}

function getUserRecentForumPosts(userId, limit = 4) {
  return db.prepare(`
    SELECT
      forum_posts.*,
      users.name AS author_name,
      COUNT(DISTINCT CASE WHEN forum_comments.status = 'published' THEN forum_comments.id END) AS comments_count,
      COUNT(DISTINCT CASE WHEN forum_reports.status = 'open' THEN forum_reports.id END) AS reports_count,
      MAX(COALESCE(forum_comments.created_at, forum_posts.updated_at)) AS last_activity_at
    FROM forum_posts
    LEFT JOIN users ON users.id = forum_posts.user_id
    LEFT JOIN forum_comments ON forum_comments.post_id = forum_posts.id
    LEFT JOIN forum_reports ON forum_reports.target_type = 'post'
      AND forum_reports.target_id = forum_posts.id
    WHERE forum_posts.user_id = ?
    GROUP BY forum_posts.id
    ORDER BY forum_posts.updated_at DESC
    LIMIT ?
  `).all(userId, limit).map(mapForumPost);
}

const storageSectionLabels = {
  "mvp.user.profile": "профиль родителя",
  "mvp.baby.profile": "профиль ребенка",
  "mvp.baby.onboarding.completed": "онбординг",
  "mvp.parent.goals": "цели родителя",
  "mvp.tracker.entries": "дневник",
  "mvp.routines.items": "режим дня",
  "mvp.reminders.items": "напоминания",
  "mvp.reminders.checklist": "чек-лист напоминаний",
  "mvp.shopping.items": "покупки",
  "mvp.fridge.drawings": "холодильник",
  "mvp.recommendations.saved": "сохраненные рекомендации",
  "mvp.profile.notes": "заметки профиля",
};

function formatRuCount(value, one, few, many) {
  const number = Number(value || 0);
  const modulo10 = Math.abs(number) % 10;
  const modulo100 = Math.abs(number) % 100;
  const form = modulo10 === 1 && modulo100 !== 11 ? one : modulo10 >= 2 && modulo10 <= 4 && (modulo100 < 12 || modulo100 > 14) ? few : many;

  return `${number} ${form}`;
}

function getStorageSectionLabel(key) {
  if (typeof key !== "string" || !key) return "данные";
  if (key.startsWith("mvp.home.completed.")) return "маршрут дня";

  return storageSectionLabels[key] || key.replace(/^mvp\./, "");
}

function getActivityNumber(meta, key) {
  const value = Number(meta?.[key] || 0);

  return Number.isFinite(value) ? value : 0;
}

function getForumCategoryLabel(category) {
  if (!category || typeof category !== "string") return "";

  return forumCategoryLabels[category] || category;
}

function describeStorageSections(sections) {
  if (!Array.isArray(sections) || sections.length === 0) return "";

  const labels = sections.slice(0, 4).map(getStorageSectionLabel);
  const rest = sections.length - labels.length;

  return rest > 0 ? `${labels.join(", ")} и еще ${rest}` : labels.join(", ");
}

function describeFridgeActivity(meta) {
  const images = getActivityNumber(meta, "images") || getActivityNumber(meta, "fridgeImages");
  const items = getActivityNumber(meta, "items") || getActivityNumber(meta, "fridgeItems");

  if (images > 0 && items > 0) {
    return `${formatRuCount(images, "изображение", "изображения", "изображений")}, всего ${formatRuCount(items, "карточка", "карточки", "карточек")}.`;
  }

  if (items > 0) {
    return `Обновлено ${formatRuCount(items, "карточка", "карточки", "карточек")}.`;
  }

  return "Обновлены карточки холодильника.";
}

function mapAuditActivity(event) {
  const meta = parseJson(event.meta_json, {});
  const base = {
    id: `audit:${event.id}`,
    type: "audit",
    label: event.action,
    createdAt: event.created_at,
    meta,
  };

  if (event.action === "auth.register") {
    return {
      ...base,
      kind: "registration",
      title: "Регистрация",
      description: meta.invite && meta.invite !== "open" ? "Аккаунт создан по beta-коду." : "Аккаунт создан.",
    };
  }

  if (event.action === "auth.login") {
    return {
      ...base,
      kind: "login",
      title: "Вход в аккаунт",
      description: "Успешный вход в приложение.",
    };
  }

  if (event.action === "auth.register.failed") {
    return {
      ...base,
      kind: "error",
      title: "Ошибка регистрации",
      description: meta.reason ? `Причина: ${meta.reason}.` : "Регистрация не завершилась.",
    };
  }

  if (event.action === "auth.login.failed") {
    return {
      ...base,
      kind: "error",
      title: "Ошибка входа",
      description: meta.reason ? `Причина: ${meta.reason}.` : "Вход не завершился.",
    };
  }

  if (event.action === "storage.patch") {
    const key = typeof meta.key === "string" ? meta.key : "";

    if (key === "mvp.fridge.drawings") {
      return {
        ...base,
        kind: "fridge",
        title: getActivityNumber(meta, "images") > 0 ? "Загрузка в холодильник" : "Холодильник",
        description: describeFridgeActivity(meta),
      };
    }

    return {
      ...base,
      kind: "data",
      title: "Изменение данных",
      description: `Раздел: ${getStorageSectionLabel(key)}.`,
    };
  }

  if (event.action === "storage.replace") {
    const sections = describeStorageSections(meta.sections);

    return {
      ...base,
      kind: "data",
      title: "Синхронизация данных",
      description: sections
        ? `${formatRuCount(meta.keys, "раздел", "раздела", "разделов")}: ${sections}.`
        : `${formatRuCount(meta.keys, "раздел", "раздела", "разделов")} обновлено.`,
    };
  }

  if (event.action === "forum.post.create") {
    const category = getForumCategoryLabel(meta.category);

    return {
      ...base,
      kind: "forum",
      title: "Создание поста",
      description: category ? `Категория: ${category}.` : "Новая тема на форуме.",
    };
  }

  if (event.action === "forum.comment.create") {
    return {
      ...base,
      kind: "forum",
      title: "Ответ на форуме",
      description: "Пользователь оставил комментарий.",
    };
  }

  if (event.action === "forum.report.create") {
    return {
      ...base,
      kind: "forum",
      title: "Жалоба на форуме",
      description: meta.reason ? `Причина: ${meta.reason}.` : "Пользователь отправил жалобу.",
    };
  }

  if (event.action.startsWith("admin.")) {
    return {
      ...base,
      kind: "admin",
      title: "Действие администратора",
      description: event.action,
    };
  }

  return {
    ...base,
    kind: "activity",
    title: event.action,
    description: "",
  };
}

function mapAnalyticsActivity(event) {
  const meta = parseJson(event.meta_json, {});

  return {
    id: `analytics:${event.id}`,
    type: "analytics",
    kind: "screen",
    label: event.event_name,
    title: event.event_name === "screen_time" ? "Время в разделе" : "Открыл раздел",
    description: event.screen ? `Раздел: ${event.screen}.` : "",
    screen: event.screen,
    durationMs: event.duration_ms,
    createdAt: event.created_at,
    meta,
  };
}

function getUserRecentActivity(userId, limit = 14) {
  const sourceLimit = Math.max(limit * 2, 16);
  const auditEvents = db.prepare(`
    SELECT id, action, meta_json, created_at
    FROM admin_audit
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT ?
  `).all(userId, sourceLimit).map(mapAuditActivity);
  const analyticsEvents = db.prepare(`
    SELECT id, event_name, screen, duration_ms, meta_json, created_at
    FROM analytics_events
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT ?
  `).all(userId, sourceLimit).map(mapAnalyticsActivity);

  return [...auditEvents, ...analyticsEvents]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

function getRecentDiaryEntries(limit = 12) {
  return db.prepare(`
    SELECT
      diary_entries.entry_id,
      diary_entries.type,
      diary_entries.time,
      diary_entries.details,
      diary_entries.icon,
      diary_entries.category,
      diary_entries.date,
      diary_entries.updated_at,
      users.id AS user_id,
      users.name AS user_name,
      users.email AS user_email,
      baby_profiles.name AS baby_name
    FROM diary_entries
    JOIN users ON users.id = diary_entries.user_id
    LEFT JOIN baby_profiles ON baby_profiles.user_id = users.id
    ORDER BY diary_entries.date DESC, diary_entries.time DESC, diary_entries.updated_at DESC
    LIMIT ?
  `).all(limit).map((entry) => ({
    id: entry.entry_id,
    type: entry.type,
    time: entry.time,
    details: entry.details,
    icon: entry.icon,
    category: entry.category,
    date: entry.date,
    updatedAt: entry.updated_at,
    userId: entry.user_id,
    userName: entry.user_name,
    userEmail: entry.user_email,
    babyName: entry.baby_name,
  }));
}

function getAdminAudit(limit = 30) {
  return db.prepare(`
    SELECT
      admin_audit.id,
      admin_audit.user_id,
      admin_audit.action,
      admin_audit.meta_json,
      admin_audit.created_at,
      users.name AS user_name,
      users.email AS user_email
    FROM admin_audit
    LEFT JOIN users ON users.id = admin_audit.user_id
    ORDER BY admin_audit.created_at DESC
    LIMIT ?
  `).all(limit).map((event) => {
    const activity = mapAuditActivity(event);

    return {
      id: event.id,
      userId: event.user_id,
      userName: event.user_name,
      userEmail: event.user_email,
      action: event.action,
      kind: activity.kind,
      title: activity.title,
      description: activity.description,
      meta: activity.meta,
      createdAt: event.created_at,
    };
  });
}

function getAnalyticsSummary() {
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayIso = today.toISOString();
  const totalEvents = getCount("analytics_events");
  const eventsToday = db.prepare(`
    SELECT COUNT(*) AS count
    FROM analytics_events
    WHERE created_at >= ?
  `).get(todayIso).count;
  const activeUsers7d = db.prepare(`
    SELECT COUNT(DISTINCT user_id) AS count
    FROM analytics_events
    WHERE created_at >= ?
  `).get(since).count;
  const screenViews = db.prepare(`
    SELECT screen, COUNT(*) AS views
    FROM analytics_events
    WHERE event_name = 'screen_view'
      AND screen IS NOT NULL
      AND screen != ''
      AND created_at >= ?
    GROUP BY screen
  `).all(since);
  const screenTimes = db.prepare(`
    SELECT
      screen,
      COUNT(*) AS time_events,
      COALESCE(SUM(duration_ms), 0) AS total_duration_ms,
      COALESCE(AVG(duration_ms), 0) AS avg_duration_ms
    FROM analytics_events
    WHERE event_name = 'screen_time'
      AND screen IS NOT NULL
      AND screen != ''
      AND duration_ms IS NOT NULL
      AND created_at >= ?
    GROUP BY screen
  `).all(since);
  const screenMap = new Map();

  screenViews.forEach((row) => {
    screenMap.set(row.screen, {
      screen: row.screen,
      views: row.views,
      totalDurationMs: 0,
      avgDurationMs: 0,
    });
  });

  screenTimes.forEach((row) => {
    const current = screenMap.get(row.screen) || {
      screen: row.screen,
      views: 0,
      totalDurationMs: 0,
      avgDurationMs: 0,
    };

    current.totalDurationMs = row.total_duration_ms;
    current.avgDurationMs = Math.round(row.avg_duration_ms);
    screenMap.set(row.screen, current);
  });

  const topScreens = Array.from(screenMap.values())
    .sort((a, b) => b.views - a.views || b.totalDurationMs - a.totalDurationMs)
    .slice(0, 8);
  const topActions = db.prepare(`
    SELECT event_name, COUNT(*) AS count
    FROM analytics_events
    WHERE event_name NOT IN ('screen_view', 'screen_time')
      AND created_at >= ?
    GROUP BY event_name
    ORDER BY count DESC
    LIMIT 10
  `).all(since).map((row) => ({
    name: row.event_name,
    count: row.count,
  }));
  const recentEvents = db.prepare(`
    SELECT
      analytics_events.id,
      analytics_events.event_name,
      analytics_events.screen,
      analytics_events.duration_ms,
      analytics_events.meta_json,
      analytics_events.created_at,
      users.name AS user_name,
      users.email AS user_email
    FROM analytics_events
    LEFT JOIN users ON users.id = analytics_events.user_id
    ORDER BY analytics_events.created_at DESC
    LIMIT 20
  `).all().map((event) => ({
    id: event.id,
    name: event.event_name,
    screen: event.screen,
    durationMs: event.duration_ms,
    meta: parseJson(event.meta_json, {}),
    createdAt: event.created_at,
    userName: event.user_name,
    userEmail: event.user_email,
  }));

  return {
    totalEvents,
    eventsToday,
    activeUsers7d,
    topScreens,
    topActions,
    recentEvents,
  };
}

function startOfTodayIso() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date.toISOString();
}

function daysAgoIso(days) {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
}

function seedFeatureFlags() {
  const stamp = nowIso();
  const insert = db.prepare(`
    INSERT INTO feature_flags (key, label, description, enabled, updated_at, updated_by)
    VALUES (?, ?, ?, ?, ?, NULL)
    ON CONFLICT(key) DO UPDATE SET
      label = excluded.label,
      description = excluded.description
  `);

  transaction(() => {
    DEFAULT_FEATURE_FLAGS.forEach((flag) => {
      insert.run(flag.key, flag.label, flag.description, flag.enabled ? 1 : 0, stamp);
    });
  });
}

function mapFeatureFlag(row) {
  return {
    key: row.key,
    label: row.label,
    description: row.description || "",
    enabled: Boolean(row.enabled),
    updatedAt: row.updated_at,
    updatedBy: row.updated_by,
  };
}

function getFeatureFlags() {
  return db.prepare("SELECT * FROM feature_flags ORDER BY key").all().map(mapFeatureFlag);
}

function mapBetaFeedback(row) {
  return {
    id: row.id,
    userId: row.user_id,
    userName: row.user_name,
    userEmail: row.user_email,
    rating: row.rating ?? null,
    message: row.message,
    screen: row.screen,
    topic: row.topic || "feedback",
    status: row.status,
    createdAt: row.created_at,
    resolvedAt: row.resolved_at,
    resolverName: row.resolver_name,
  };
}

function inferBetaFeedbackTopic(message, screen) {
  const text = `${message || ""} ${screen || ""}`.toLowerCase();

  if (text.includes("вход") || text.includes("парол") || text.includes("login") || text.includes("квот") || text.includes("доступ")) {
    return "login";
  }

  if (text.includes("данн") || text.includes("сохрани") || text.includes("пропал") || text.includes("сброс")) {
    return "data_loss";
  }

  if (text.includes("баг") || text.includes("ошиб") || text.includes("не работает") || text.includes("не нажим")) {
    return "bug";
  }

  if (text.includes("иде") || text.includes("улучш") || text.includes("не хватает") || text.includes("добав")) {
    return "idea";
  }

  return screen === "support" ? "other" : "feedback";
}

function getBetaFeedbackSummary(limit = 100) {
  const rows = db.prepare(`
    SELECT
      beta_feedback.*,
      users.name AS user_name,
      users.email AS user_email,
      resolver.name AS resolver_name
    FROM beta_feedback
    LEFT JOIN users ON users.id = beta_feedback.user_id
    LEFT JOIN users AS resolver ON resolver.id = beta_feedback.resolved_by
    ORDER BY beta_feedback.created_at DESC
    LIMIT ?
  `).all(limit);
  const statsRows = db.prepare("SELECT status, COUNT(*) AS count FROM beta_feedback GROUP BY status").all();
  const stats = { total: getCount("beta_feedback"), new: 0, reviewed: 0, resolved: 0 };

  statsRows.forEach((row) => {
    if (Object.prototype.hasOwnProperty.call(stats, row.status)) {
      stats[row.status] = row.count;
    }
  });

  return { stats, items: rows.map(mapBetaFeedback) };
}

async function handleBetaFeedbackCreate(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const message = typeof body.message === "string" ? body.message.trim() : "";

  if (message.length < 4) {
    return sendError(res, 400, "Напишите пару слов, чтобы обращение было полезным.");
  }

  if (message.length > BETA_FEEDBACK_MAX_LENGTH) {
    return sendError(res, 400, `Сообщение должно быть короче ${BETA_FEEDBACK_MAX_LENGTH} символов.`);
  }

  const rawRating = Number(body.rating);
  const rating = Number.isFinite(rawRating) && rawRating >= 1 && rawRating <= 5 ? Math.round(rawRating) : null;
  const screen = typeof body.screen === "string" ? body.screen.trim().slice(0, 80) : null;
  const rawTopic = typeof body.topic === "string" ? body.topic.trim() : "";
  const topic = BETA_FEEDBACK_TOPICS.has(rawTopic) ? rawTopic : inferBetaFeedbackTopic(message, screen);
  const id = randomBytes(10).toString("hex");
  const stamp = nowIso();

  db.prepare(`
    INSERT INTO beta_feedback (id, user_id, rating, message, screen, topic, status, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 'new', ?)
  `).run(id, auth.user.id, rating, message, screen, topic, stamp);

  addAudit(auth.user.id, "beta.feedback.create", { rating, screen, topic });

  return sendJson(res, 201, { ok: true });
}

async function handleAdminFeedbackStatus(req, res, auth, feedbackId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const status = String(body.status || "").trim();

  if (!BETA_FEEDBACK_STATUSES.has(status)) {
    return sendError(res, 400, "Неизвестный статус обращения.");
  }

  const exists = db.prepare("SELECT id FROM beta_feedback WHERE id = ?").get(feedbackId);

  if (!exists) return sendError(res, 404, "Обращение не найдено.");

  db.prepare(`
    UPDATE beta_feedback
    SET status = ?, resolved_at = ?, resolved_by = ?
    WHERE id = ?
  `).run(status, status === "resolved" ? nowIso() : null, status === "resolved" ? auth.user.id : null, feedbackId);

  addAudit(auth.user.id, "admin.feedback.status", { feedbackId, status });

  return sendJson(res, 200, { ok: true, feedback: getBetaFeedbackSummary() });
}

async function handleAdminFeatureFlagUpdate(req, res, auth, key) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  if (typeof body.enabled !== "boolean") {
    return sendError(res, 400, "Нужно передать enabled: true/false.");
  }

  const current = db.prepare("SELECT key FROM feature_flags WHERE key = ?").get(key);

  if (!current) return sendError(res, 404, "Фича не найдена.");

  db.prepare(`
    UPDATE feature_flags
    SET enabled = ?, updated_at = ?, updated_by = ?
    WHERE key = ?
  `).run(body.enabled ? 1 : 0, nowIso(), auth.user.id, key);

  addAudit(auth.user.id, "admin.feature.toggle", { key, enabled: body.enabled });

  return sendJson(res, 200, { ok: true, featureFlags: getFeatureFlags() });
}

function collectTextSnippets(value, snippets = []) {
  if (snippets.length >= 5 || value === null || value === undefined) return snippets;

  if (typeof value === "string") {
    const text = value.trim();

    if (text && !text.startsWith("data:image")) {
      snippets.push(text.slice(0, 180));
    }

    return snippets;
  }

  if (Array.isArray(value)) {
    value.forEach((item) => collectTextSnippets(item, snippets));
    return snippets;
  }

  if (typeof value === "object") {
    Object.entries(value).forEach(([key, item]) => {
      if (/image|avatar|src|base64/i.test(key)) return;
      collectTextSnippets(item, snippets);
    });
  }

  return snippets;
}

function getAdminFridgeItems(limit = 12) {
  return db.prepare(`
    SELECT
      fridge_items.item_id AS id,
      fridge_items.user_id,
      fridge_items.title,
      fridge_items.image_src,
      fridge_items.updated_at,
      users.name AS user_name,
      users.email AS user_email,
      baby_profiles.name AS baby_name
    FROM fridge_items
    JOIN users ON users.id = fridge_items.user_id
    LEFT JOIN baby_profiles ON baby_profiles.user_id = fridge_items.user_id
    WHERE fridge_items.image_src IS NOT NULL
      AND fridge_items.image_src != ''
    ORDER BY fridge_items.updated_at DESC
    LIMIT ?
  `).all(limit).map((row) => ({
    id: row.id,
    userId: row.user_id,
    userName: row.user_name,
    userEmail: row.user_email,
    babyName: row.baby_name,
    title: row.title,
    imageSrc: row.image_src,
    updatedAt: row.updated_at,
  }));
}

function getRecentProfileNotes(limit = 12) {
  const rows = db.prepare(`
    SELECT
      account_storage.user_id,
      account_storage.key,
      account_storage.value_json,
      account_storage.updated_at,
      users.name AS user_name,
      users.email AS user_email,
      baby_profiles.name AS baby_name
    FROM account_storage
    JOIN users ON users.id = account_storage.user_id
    LEFT JOIN baby_profiles ON baby_profiles.user_id = account_storage.user_id
    WHERE lower(account_storage.key) LIKE '%note%'
       OR lower(account_storage.key) LIKE '%question%'
       OR lower(account_storage.key) LIKE '%doctor%'
       OR lower(account_storage.key) LIKE '%reminder%'
       OR lower(account_storage.key) LIKE '%saved%'
       OR lower(account_storage.key) LIKE '%urgent%'
    ORDER BY account_storage.updated_at DESC
    LIMIT ?
  `).all(limit * 2);

  return rows.map((row) => {
    const snippets = collectTextSnippets(parseJson(row.value_json, {}), [])
      .filter((text, index, list) => list.indexOf(text) === index)
      .slice(0, 5);

    return {
      userId: row.user_id,
      userName: row.user_name,
      userEmail: row.user_email,
      babyName: row.baby_name,
      key: row.key,
      snippets,
      updatedAt: row.updated_at,
    };
  }).filter((row) => row.snippets.length > 0).slice(0, limit);
}

function getContentModerationSummary() {
  return {
    forum: getForumModerationSummary(),
    fridgeItems: getAdminFridgeItems(),
    notes: getRecentProfileNotes(),
  };
}

function getUserActivityOverview(users) {
  const todayIso = startOfTodayIso();
  const loggedInToday = users.filter((user) => user.lastLoginAt && user.lastLoginAt >= todayIso).slice(0, 20);
  const registeredToday = users.filter((user) => user.createdAt && user.createdAt >= todayIso).slice(0, 20);
  const creatorsRows = db.prepare(`
    SELECT user_id, MAX(last_activity_at) AS last_activity_at, SUM(count) AS count
    FROM (
      SELECT user_id, MAX(updated_at) AS last_activity_at, COUNT(*) AS count FROM diary_entries WHERE updated_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(updated_at) AS last_activity_at, COUNT(*) AS count FROM routines WHERE updated_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(updated_at) AS last_activity_at, COUNT(*) AS count FROM shopping_items WHERE updated_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(updated_at) AS last_activity_at, COUNT(*) AS count FROM fridge_items WHERE updated_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(created_at) AS last_activity_at, COUNT(*) AS count FROM forum_posts WHERE created_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(created_at) AS last_activity_at, COUNT(*) AS count FROM forum_comments WHERE created_at >= ? GROUP BY user_id
      UNION ALL
      SELECT user_id, MAX(created_at) AS last_activity_at, COUNT(*) AS count FROM beta_feedback WHERE created_at >= ? GROUP BY user_id
    )
    GROUP BY user_id
    ORDER BY last_activity_at DESC
    LIMIT 20
  `).all(todayIso, todayIso, todayIso, todayIso, todayIso, todayIso, todayIso);
  const userMap = new Map(users.map((user) => [user.id, user]));
  const toActivityUser = (user, extra = {}) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    babyName: user.babyName,
    createdAt: user.createdAt,
    lastLoginAt: user.lastLoginAt,
    ...extra,
  });
  const creatorsToday = creatorsRows
    .map((row) => {
      const user = userMap.get(row.user_id);
      return user ? toActivityUser(user, { count: row.count, lastActivityAt: row.last_activity_at }) : null;
    })
    .filter(Boolean);
  const recentCutoff = daysAgoIso(14);
  const onboardingDropoffs = users
    .filter((user) =>
      user.role !== "admin" &&
      user.createdAt >= recentCutoff &&
      !user.babyName &&
      user.diaryEntries + user.routines + user.shoppingItems + user.fridgeItems + user.forumPosts + user.forumComments === 0
    )
    .slice(0, 20)
    .map((user) => toActivityUser(user, { reason: "Нет профиля ребенка и действий" }));

  return { loggedInToday, registeredToday, creatorsToday, onboardingDropoffs };
}

function getProductHealthSummary() {
  const since = daysAgoIso(7);
  const failedLogins7d = db.prepare(`
    SELECT COUNT(*) AS count FROM admin_audit
    WHERE action = 'auth.login.failed' AND created_at >= ?
  `).get(since).count;
  const failedRegistrations7d = db.prepare(`
    SELECT COUNT(*) AS count FROM admin_audit
    WHERE action = 'auth.register.failed' AND created_at >= ?
  `).get(since).count;
  const analyticsErrors7d = db.prepare(`
    SELECT COUNT(*) AS count FROM analytics_events
    WHERE created_at >= ?
      AND (event_name = 'app_error' OR event_name LIKE '%error%' OR event_name LIKE '%failed%' OR event_name LIKE '%reject%')
  `).get(since).count;
  const auditProblems = db.prepare(`
    SELECT
      admin_audit.id,
      'audit' AS source,
      admin_audit.action AS name,
      NULL AS screen,
      NULL AS duration_ms,
      admin_audit.meta_json,
      admin_audit.created_at,
      users.name AS user_name,
      users.email AS user_email
    FROM admin_audit
    LEFT JOIN users ON users.id = admin_audit.user_id
    WHERE admin_audit.created_at >= ?
      AND (admin_audit.action LIKE '%failed%' OR admin_audit.action LIKE '%error%' OR admin_audit.action LIKE '%reject%' OR admin_audit.action LIKE '%denied%' OR admin_audit.action LIKE '%rate%')
    ORDER BY admin_audit.created_at DESC
    LIMIT 50
  `).all(since);
  const analyticsProblems = db.prepare(`
    SELECT
      analytics_events.id,
      'analytics' AS source,
      analytics_events.event_name AS name,
      analytics_events.screen,
      analytics_events.duration_ms,
      analytics_events.meta_json,
      analytics_events.created_at,
      users.name AS user_name,
      users.email AS user_email
    FROM analytics_events
    LEFT JOIN users ON users.id = analytics_events.user_id
    WHERE analytics_events.created_at >= ?
      AND (analytics_events.event_name = 'app_error' OR analytics_events.event_name LIKE '%error%' OR analytics_events.event_name LIKE '%failed%' OR analytics_events.event_name LIKE '%reject%')
    ORDER BY analytics_events.created_at DESC
    LIMIT 50
  `).all(since);
  const recentProblems = [...auditProblems, ...analyticsProblems]
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, 50)
    .map((row) => {
      const meta = parseJson(row.meta_json, {});

      return {
        id: row.id,
        source: row.source,
        name: row.name,
        label: row.name,
        screen: row.screen,
        status: meta.status,
        meta,
        createdAt: row.created_at,
        userName: row.user_name,
        userEmail: row.user_email,
      };
    });
  const frequency = new Map();

  recentProblems.forEach((problem) => {
    frequency.set(problem.label, (frequency.get(problem.label) || 0) + 1);
  });

  return {
    stats: {
      failedLogins7d,
      failedRegistrations7d,
      analyticsErrors7d,
      problemEvents7d: recentProblems.length,
    },
    recentProblems,
    frequentFailures: Array.from(frequency.entries())
      .map(([label, count]) => ({ label, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 8),
  };
}

function getAdminConsentSummary(users) {
  const consentUsers = users.map((user) => {
    const consentStatus = user.consentStatus || getLegalConsentStatus(user.id);

    return {
      userId: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      createdAt: user.createdAt,
      lastLoginAt: user.lastLoginAt,
      blockedAt: user.blockedAt,
      acceptedAt: user.legalConsentAcceptedAt || getLegalConsentAcceptedAt(consentStatus),
      consentStatus,
    };
  });
  const missing = consentUsers.filter((user) => user.consentStatus.required).length;
  const recent = db.prepare(`
    SELECT
      user_consents.*,
      users.name AS user_name,
      users.email AS current_email
    FROM user_consents
    LEFT JOIN users ON users.id = user_consents.user_id
    ORDER BY user_consents.accepted_at DESC
    LIMIT 30
  `).all().map((consent) => ({
    id: consent.id,
    userId: consent.user_id,
    userName: consent.user_name,
    userEmail: consent.current_email || consent.email,
    consentKey: consent.consent_key,
    documentKey: consent.document_key,
    documentTitle: consent.document_title,
    documentVersion: consent.document_version,
    acceptedAt: consent.accepted_at,
    ipAddress: consent.ip_address,
    userAgent: consent.user_agent,
    meta: parseJson(consent.meta_json, {}),
  }));

  return {
    stats: {
      requiredVersion: LEGAL_DOCUMENT_VERSION,
      usersTotal: users.length,
      accepted: users.length - missing,
      missing,
      consentRecords: getCount("user_consents"),
    },
    users: consentUsers,
    recent,
  };
}

function handleAdminOverview(res, auth) {
  if (!assertAdmin(res, auth)) return;

  const users = getAdminUsers();
  const sessions = db.prepare("SELECT COUNT(*) AS count FROM sessions WHERE expires_at > ?").get(nowIso()).count;
  const database = getDatabaseInfo();
  const analytics = getAnalyticsSummary();
  const forumModeration = getForumModerationSummary();
  const contentModeration = getContentModerationSummary();
  const productHealth = getProductHealthSummary();
  const userActivity = getUserActivityOverview(users);
  const feedback = getBetaFeedbackSummary();
  const featureFlags = getFeatureFlags();
  const consents = getAdminConsentSummary(users);

  return sendJson(res, 200, {
    users,
    stats: {
      users: users.length,
      sessions,
      userConsents: getCount("user_consents"),
      consentMissing: consents.stats.missing,
      diaryEntries: getCount("diary_entries"),
      storageKeys: getCount("account_storage"),
      routines: getCount("routines"),
      shoppingItems: getCount("shopping_items"),
      fridgeItems: getCount("fridge_items"),
      forumPosts: getCount("forum_posts"),
      forumComments: getCount("forum_comments"),
      forumReports: getCount("forum_reports"),
      backups: database.backups.length,
      analyticsEvents: analytics.totalEvents,
      betaFeedback: feedback.stats.total,
    },
    database,
    config: getAdminConfigInfo(),
    analytics,
    forumModeration,
    contentModeration,
    productHealth,
    userActivity,
    feedback,
    consents,
    featureFlags,
    recentDiaryEntries: getRecentDiaryEntries(),
    audit: getAdminAudit(),
  });
}

function getRows(table, orderBy = "") {
  const orderClause = orderBy ? ` ORDER BY ${orderBy}` : "";

  return db.prepare(`SELECT * FROM ${table}${orderClause}`).all();
}

function getPersonalDataRegistrySummary() {
  return {
    documentVersion: LEGAL_DOCUMENT_VERSION,
    operatorDraft: "Владелец проекта Малыш+",
    storage: "Сервер проекта, база SQLite и резервные копии",
    access: ["Пользователь к своим данным", "Администратор проекта для поддержки, модерации и безопасности"],
    deletion: "Запрос на выгрузку, исправление или удаление данных отправляется через поддержку.",
    categories: [
      { name: "Аккаунт", data: ["email", "имя", "роль", "хеш пароля", "даты входа"] },
      { name: "Ребенок", data: ["имя или псевдоним", "дата рождения", "рост", "вес", "бытовые записи ухода"] },
      { name: "Контент", data: ["форум", "комментарии", "жалобы", "сохраненные материалы", "покупки"] },
      { name: "Поддержка", data: ["тема обращения", "текст", "страница", "статус обработки"] },
      { name: "Технические данные", data: ["IP", "user-agent", "аналитика разделов", "журналы ошибок"] },
      { name: "Согласия", data: ["версия документа", "дата", "email", "IP", "user-agent"] },
    ],
    purposes: [
      "создание аккаунта",
      "синхронизация между устройствами",
      "сохранение дневника ухода",
      "поддержка пользователей",
      "модерация форума",
      "безопасность и восстановление доступа",
      "улучшение beta-версии",
    ],
  };
}

function buildAdminExport() {
  return {
    exportedAt: nowIso(),
    service: "malysh-api",
    database: getDatabaseInfo(),
    config: getAdminConfigInfo(),
    personalDataRegistry: getPersonalDataRegistrySummary(),
    users: db.prepare(`
      SELECT id, email, name, role, blocked_at, created_at, last_login_at
      FROM users
      ORDER BY created_at DESC
    `).all().map((user) => getPublicUser(user)),
    accountStorage: db.prepare(`
      SELECT user_id, key, value_json, updated_at
      FROM account_storage
      ORDER BY user_id, key
    `).all().map((row) => ({
      userId: row.user_id,
      key: row.key,
      value: parseJson(row.value_json),
      updatedAt: row.updated_at,
    })),
    userConsents: getRows("user_consents", "accepted_at DESC").map((consent) => ({
      ...consent,
      meta: parseJson(consent.meta_json, {}),
    })),
    babyProfiles: getRows("baby_profiles", "updated_at DESC"),
    parentGoals: getRows("parent_goals", "user_id, position"),
    diaryEntries: getRows("diary_entries", "date DESC, time DESC").map((entry) => ({
      ...entry,
      raw: parseJson(entry.raw_json, {}),
    })),
    routines: getRows("routines", "user_id, time").map((routine) => ({
      ...routine,
      raw: parseJson(routine.raw_json, {}),
    })),
    shoppingItems: getRows("shopping_items", "user_id, category_id, name").map((item) => ({
      ...item,
      raw: parseJson(item.raw_json, {}),
    })),
    fridgeItems: getRows("fridge_items", "updated_at DESC").map((item) => ({
      ...item,
      raw: parseJson(item.raw_json, {}),
    })),
    forumPosts: getRows("forum_posts", "created_at DESC").map((post) => ({
      ...post,
      tags: parseJson(post.tags_json, []),
    })),
    forumComments: getRows("forum_comments", "created_at DESC"),
    forumReports: getRows("forum_reports", "created_at DESC"),
    betaInvites: getRows("beta_invites", "created_at DESC"),
    betaInviteRedemptions: getRows("beta_invite_redemptions", "used_at DESC"),
    betaFeedback: getRows("beta_feedback", "created_at DESC"),
    featureFlags: getRows("feature_flags", "key"),
    analytics: {
      summary: getAnalyticsSummary(),
      events: db.prepare(`
        SELECT id, user_id, session_id, event_name, screen, duration_ms, meta_json, created_at
        FROM analytics_events
        ORDER BY created_at DESC
        LIMIT 1000
      `).all().map((event) => ({
        id: event.id,
        userId: event.user_id,
        sessionId: event.session_id,
        name: event.event_name,
        screen: event.screen,
        durationMs: event.duration_ms,
        meta: parseJson(event.meta_json, {}),
        createdAt: event.created_at,
      })),
    },
    audit: getAdminAudit(200),
  };
}

function handleAdminExport(res, auth) {
  if (!assertAdmin(res, auth)) return;

  addAudit(auth.user.id, "admin.export");

  return sendJson(res, 200, buildAdminExport());
}

async function handleAdminBackup(res, auth) {
  if (!assertAdmin(res, auth)) return;

  await mkdir(BACKUP_DIR, { recursive: true });

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const fileName = `app-${stamp}-${randomBytes(3).toString("hex")}.db`;
  const target = join(BACKUP_DIR, fileName);

  db.prepare("VACUUM INTO ?").run(target);

  const backup = formatBackupInfo(fileName);

  addAudit(auth.user.id, "admin.backup", {
    fileName,
    sizeBytes: backup.sizeBytes,
  });

  return sendJson(res, 201, { ok: true, backup, backups: getRecentBackups() });
}

async function handleAdminUserStatus(req, res, auth, userId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const target = getAdminManagedUser(userId);

  if (!target) return sendError(res, 404, "Пользователь не найден.");
  if (target.id === auth.user.id) return sendError(res, 400, "Нельзя заблокировать свой аккаунт.");

  const blocked = body.blocked === true;

  if (blocked && isLastActiveAdmin(target.id)) {
    return sendError(res, 400, "Нельзя заблокировать последнего активного администратора.");
  }

  transaction(() => {
    db.prepare("UPDATE users SET blocked_at = ? WHERE id = ?").run(blocked ? nowIso() : null, target.id);

    if (blocked) {
      db.prepare("DELETE FROM sessions WHERE user_id = ?").run(target.id);
    }

    addAudit(auth.user.id, blocked ? "admin.user.block" : "admin.user.unblock", {
      targetUserId: target.id,
      targetEmail: target.email,
    });
  });

  return sendJson(res, 200, { ok: true, user: getPublicUser(getAdminManagedUser(target.id)) });
}

async function handleAdminUserSessionsReset(res, auth, userId) {
  if (!assertAdmin(res, auth)) return;

  const target = getAdminManagedUser(userId);

  if (!target) return sendError(res, 404, "Пользователь не найден.");
  if (target.id === auth.user.id) return sendError(res, 400, "Нельзя сбросить собственную текущую сессию отсюда.");

  const result = db.prepare("DELETE FROM sessions WHERE user_id = ?").run(target.id);

  addAudit(auth.user.id, "admin.user.sessions.reset", {
    targetUserId: target.id,
    targetEmail: target.email,
    sessions: result.changes,
  });

  return sendJson(res, 200, { ok: true, sessionsDeleted: result.changes });
}

async function handleAdminUserDelete(req, res, auth, userId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const target = getAdminManagedUser(userId);

  if (!target) return sendError(res, 404, "Пользователь не найден.");
  if (target.id === auth.user.id) return sendError(res, 400, "Нельзя удалить свой аккаунт.");
  if (target.role === "admin") return sendError(res, 400, "Удаление администраторов отключено. Сначала смените роль вручную в базе.");
  if (!target.blocked_at) {
    return sendError(res, 409, "Безопасный режим: сначала заблокируйте пользователя. Блокировка также сбросит активные сессии.");
  }

  const activeSessions = getActiveSessionCount(target.id);

  if (activeSessions > 0) {
    return sendError(res, 409, "Безопасный режим: перед удалением нужно сбросить активные сессии пользователя.");
  }

  const confirmEmail = normalizeEmail(body.confirmEmail);

  if (confirmEmail !== target.email) {
    return sendError(res, 400, "Для удаления нужно подтвердить email пользователя.");
  }

  transaction(() => {
    db.prepare("DELETE FROM sessions WHERE user_id = ?").run(target.id);
    db.prepare("DELETE FROM users WHERE id = ?").run(target.id);
    addAudit(auth.user.id, "admin.user.delete", {
      targetUserId: target.id,
      targetEmail: target.email,
      reason: "data_deletion_request",
      note: "Аккаунт и связанные личные данные удалены после блокировки и сброса сессий.",
    });
  });

  return sendJson(res, 200, { ok: true });
}

async function handleAdminInviteCreate(req, res, auth) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const label = getPlainText(body.label).slice(0, 80);
  const maxUsesRaw = Number(body.maxUses ?? 1);
  const maxUses = Number.isFinite(maxUsesRaw)
    ? Math.min(1000, Math.max(1, Math.round(maxUsesRaw)))
    : 1;
  let code = normalizeInviteCode(body.code);

  if (!code) {
    for (let attempt = 0; attempt < 5; attempt += 1) {
      code = createInviteCode();

      if (!db.prepare("SELECT id FROM beta_invites WHERE code = ?").get(code)) break;
    }
  }

  if (!isValidInviteCodeFormat(code)) {
    return sendError(res, 400, "Код должен быть от 6 до 64 символов: латиница, цифры и дефис.");
  }

  const id = randomBytes(12).toString("hex");
  const createdAt = nowIso();

  try {
    db.prepare(`
      INSERT INTO beta_invites (id, code, label, max_uses, created_by, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(id, code, label || null, maxUses, auth.user.id, createdAt);
  } catch (error) {
    if (error instanceof Error && /UNIQUE/i.test(error.message)) {
      return sendError(res, 409, "Такой beta-код уже есть.");
    }

    throw error;
  }

  addAudit(auth.user.id, "admin.invite.create", { inviteId: id, maxUses });

  return sendJson(res, 201, {
    ok: true,
    invite: getBetaInvites(20).find((invite) => invite.id === id),
    config: getAdminConfigInfo(),
  });
}

async function handleAdminInviteUpdate(req, res, auth, inviteId) {
  if (!assertAdmin(res, auth)) return;

  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const existing = db.prepare("SELECT id FROM beta_invites WHERE id = ?").get(inviteId);

  if (!existing) return sendError(res, 404, "Beta-инвайт не найден.");

  const active = body.active === true;

  db.prepare(`
    UPDATE beta_invites
    SET disabled_at = ?
    WHERE id = ?
  `).run(active ? null : nowIso(), inviteId);

  addAudit(auth.user.id, active ? "admin.invite.activate" : "admin.invite.disable", { inviteId });

  return sendJson(res, 200, {
    ok: true,
    invite: getBetaInvites(20).find((invite) => invite.id === inviteId),
    config: getAdminConfigInfo(),
  });
}

function normalizeAnalyticsEvent(rawEvent = {}) {
  const name = String(rawEvent.name || rawEvent.event || "").trim().slice(0, 80);

  if (!name) return null;

  const rawDuration = Number(rawEvent.durationMs ?? rawEvent.duration_ms);
  const createdAt = new Date(rawEvent.createdAt || rawEvent.created_at || "");

  return {
    id: randomBytes(12).toString("hex"),
    sessionId: String(rawEvent.sessionId || rawEvent.session_id || "").trim().slice(0, 80),
    name,
    screen: String(rawEvent.screen || "").trim().slice(0, 80),
    durationMs: Number.isFinite(rawDuration) && rawDuration >= 0 ? Math.round(rawDuration) : null,
    meta: rawEvent.meta && typeof rawEvent.meta === "object" && !Array.isArray(rawEvent.meta) ? rawEvent.meta : {},
    createdAt: Number.isNaN(createdAt.getTime()) ? nowIso() : createdAt.toISOString(),
  };
}

async function handleAnalyticsEvents(req, res, auth) {
  const body = await readJsonBody(req);

  if (rejectBadJsonBody(res, body)) return;

  const rawEvents = Array.isArray(body.events) ? body.events : [body.event || body];
  const events = rawEvents
    .slice(0, 50)
    .map(normalizeAnalyticsEvent)
    .filter(Boolean);

  if (events.length === 0) return sendError(res, 400, "Нет событий для записи.");

  const insert = db.prepare(`
    INSERT INTO analytics_events (
      id, user_id, session_id, event_name, screen, duration_ms, meta_json, created_at
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  transaction(() => {
    events.forEach((event) => {
      insert.run(
        event.id,
        auth.user.id,
        event.sessionId,
        event.name,
        event.screen,
        event.durationMs,
        toJson(event.meta),
        event.createdAt
      );
    });
  });

  return sendJson(res, 201, { ok: true, accepted: events.length });
}

function handleHealth(res) {
  const tableCounts = Object.fromEntries(
    ["users", "sessions", "user_consents", "baby_profiles", "diary_entries", "routines", "shopping_items", "fridge_items", "forum_posts", "forum_comments", "forum_reports", "beta_feedback", "feature_flags", "admin_audit", "analytics_events"].map((table) => [
      table,
      db.prepare(`SELECT COUNT(*) AS count FROM ${table}`).get().count,
    ])
  );

  return sendJson(res, 200, {
    ok: true,
    service: "malysh-api",
    publicUrl: PUBLIC_URL,
    registrationMode: REGISTRATION_MODE,
    schemaVersion: SCHEMA_VERSION,
    details: EXPOSE_HEALTH_DETAILS
      ? {
          database: DB_FILE,
          dataDir: DATA_DIR,
          backupDir: BACKUP_DIR,
          tables: tableCounts,
        }
      : undefined,
  });
}

function handlePublicConfig(res) {
  return sendJson(res, 200, {
    appName: "Малыш+",
    publicUrl: PUBLIC_URL,
    registrationMode: REGISTRATION_MODE,
    registrationRequiresInvite: REGISTRATION_MODE === "closed",
    featureFlags: getFeatureFlags(),
    legalDocuments: LEGAL_DOCUMENTS,
  });
}

async function handleRequest(req, res) {
  const startedAt = Date.now();
  const requestId = randomBytes(6).toString("hex");
  const requestPath = (() => {
    try {
      return new URL(req.url || "/", `http://${req.headers.host || "127.0.0.1"}`).pathname;
    } catch {
      return "/";
    }
  })();

  res.__requestId = requestId;
  res.__clientIp = getClientIp(req);
  res.on("finish", () => logAccess(req, res, startedAt, requestPath));
  res.__corsOrigin = resolveCorsOrigin(req.headers.origin);

  if (req.method === "OPTIONS") return sendJson(res, 204, {});

  const url = new URL(req.url || "/", `http://${req.headers.host || "127.0.0.1"}`);
  const path = url.pathname;

  try {
    if (req.method === "GET" && path === "/api/health") {
      return handleHealth(res);
    }

    if (req.method === "GET" && path === "/api/config") {
      return handlePublicConfig(res);
    }

    if (req.method === "POST" && path === "/api/auth/register") {
      return await handleAuthRegister(req, res);
    }

    if (req.method === "POST" && path === "/api/auth/login") {
      return await handleAuthLogin(req, res);
    }

    if (req.method === "POST" && path === "/api/auth/logout") {
      return handleAuthLogout(req, res);
    }

    if (!path.startsWith("/api/")) {
      return sendStaticAsset(res, path);
    }

    const auth = getAuthedUser(req);

    if (!auth) return sendError(res, 401, "Нужно войти в аккаунт.");

    const consentStatus = getLegalConsentStatus(auth.user.id);
    const consentOpenPath =
      path === "/api/auth/me" ||
      path === "/api/account/consents/accept" ||
      path === "/api/feedback" ||
      path === "/api/auth/logout";

    if (req.method === "GET" && path === "/api/auth/me") {
      return sendJson(res, 200, {
        user: getPublicUser(auth.user),
        storage: getStorageForUser(auth.user.id),
        consentStatus,
      });
    }

    if (req.method === "POST" && path === "/api/account/consents/accept") {
      return await handleAccountConsentsAccept(req, res, auth);
    }

    if (consentStatus.required && !consentOpenPath) {
      return sendJson(res, 451, {
        error: "Нужно подтвердить обновленные правила обработки данных.",
        consentStatus,
      });
    }

    if (req.method === "GET" && path === "/api/account/storage") {
      return sendJson(res, 200, { storage: getStorageForUser(auth.user.id) });
    }

    if (req.method === "GET" && path === "/api/forum/posts") {
      return handleForumPostsList(res, url);
    }

    if (req.method === "POST" && path === "/api/forum/reports") {
      return await handleForumReportCreate(req, res, auth);
    }

    if (req.method === "POST" && path === "/api/forum/posts") {
      return await handleForumPostCreate(req, res, auth);
    }

    if (path.startsWith("/api/forum/posts/")) {
      const forumPathParts = path.split("/").filter(Boolean);
      const postId = forumPathParts[3];
      const forumAction = forumPathParts[4];

      if (req.method === "GET" && postId && !forumAction) {
        return handleForumPostDetail(res, postId);
      }

      if (req.method === "POST" && postId && forumAction === "comments") {
        return await handleForumCommentCreate(req, res, auth, postId);
      }
    }

    if (req.method === "PUT" && path === "/api/account/storage") {
      return await handleStoragePut(req, res, auth);
    }

    if (req.method === "PATCH" && path === "/api/account/storage") {
      return await handleStoragePatch(req, res, auth);
    }

    if (req.method === "POST" && path === "/api/analytics/events") {
      return await handleAnalyticsEvents(req, res, auth);
    }

    if (req.method === "POST" && path === "/api/feedback") {
      return await handleBetaFeedbackCreate(req, res, auth);
    }

    if (req.method === "GET" && path === "/api/admin/overview") {
      return handleAdminOverview(res, auth);
    }

    if (req.method === "GET" && path === "/api/admin/export") {
      return handleAdminExport(res, auth);
    }

    if (req.method === "POST" && path === "/api/admin/backup") {
      return await handleAdminBackup(res, auth);
    }

    if (path.startsWith("/api/admin/users/")) {
      const adminUserPathParts = path.split("/").filter(Boolean);
      const userId = adminUserPathParts[3];
      const action = adminUserPathParts[4];
      const subAction = adminUserPathParts[5];

      if (req.method === "PATCH" && userId && action === "status") {
        return await handleAdminUserStatus(req, res, auth, userId);
      }

      if (req.method === "POST" && userId && action === "sessions" && subAction === "reset") {
        return await handleAdminUserSessionsReset(res, auth, userId);
      }

      if (req.method === "DELETE" && userId && !action) {
        return await handleAdminUserDelete(req, res, auth, userId);
      }
    }

    if (req.method === "POST" && path === "/api/admin/invites") {
      return await handleAdminInviteCreate(req, res, auth);
    }

    if (path.startsWith("/api/admin/invites/")) {
      const inviteId = path.split("/").filter(Boolean)[3];

      if (req.method === "PATCH" && inviteId) {
        return await handleAdminInviteUpdate(req, res, auth, inviteId);
      }
    }

    if (path.startsWith("/api/admin/feedback/")) {
      const feedbackPathParts = path.split("/").filter(Boolean);
      const feedbackId = feedbackPathParts[3];
      const action = feedbackPathParts[4];

      if (req.method === "PATCH" && feedbackId && action === "status") {
        return await handleAdminFeedbackStatus(req, res, auth, feedbackId);
      }
    }

    if (path.startsWith("/api/admin/feature-flags/")) {
      const key = decodeURIComponent(path.split("/").filter(Boolean)[3] || "");

      if (req.method === "PATCH" && key) {
        return await handleAdminFeatureFlagUpdate(req, res, auth, key);
      }
    }

    if (path.startsWith("/api/admin/forum/")) {
      const adminForumPathParts = path.split("/").filter(Boolean);
      const target = adminForumPathParts[3];
      const targetId = adminForumPathParts[4];

      if (req.method === "PATCH" && target === "posts" && targetId) {
        return await handleAdminForumPostStatus(req, res, auth, targetId);
      }

      if (req.method === "PATCH" && target === "comments" && targetId) {
        return await handleAdminForumCommentStatus(req, res, auth, targetId);
      }

      if (req.method === "PATCH" && target === "reports" && targetId) {
        return await handleAdminForumReportStatus(req, res, auth, targetId);
      }
    }

    return sendError(res, 404, "Маршрут не найден.");
  } catch (error) {
    logServerError(req, res, error, path);
    return sendError(res, 500, "Внутренняя ошибка сервера.");
  }
}

function migrateLegacyJsonIfNeeded() {
  const migrationFlag = db.prepare("SELECT value FROM schema_meta WHERE key = 'legacy_json_migrated'").get();
  const hasUsers = getUserCount() > 0;

  if (migrationFlag || hasUsers || !existsSync(LEGACY_JSON_FILE)) return;

  try {
    const legacy = JSON.parse(readFileSyncText(LEGACY_JSON_FILE));

    if (!Array.isArray(legacy.users) || legacy.users.length === 0) return;

    transaction(() => {
      legacy.users.forEach((user) => {
        db.prepare(`
          INSERT OR IGNORE INTO users (
            id, email, name, role, password_salt, password_hash, created_at, last_login_at
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          user.id,
          normalizeEmail(user.email),
          normalizeName(user.name, user.email),
          user.role || "user",
          user.passwordSalt || user.password_salt,
          user.passwordHash || user.password_hash,
          user.createdAt || user.created_at || nowIso(),
          user.lastLoginAt || user.last_login_at || null
        );
      });

      if (legacy.storage && typeof legacy.storage === "object") {
        Object.entries(legacy.storage).forEach(([userId, storage]) => {
          if (!storage || typeof storage !== "object") return;
          Object.entries(storage).forEach(([key, value]) => setStorageItem(userId, key, value));
        });
      }

      if (Array.isArray(legacy.sessions)) {
        legacy.sessions.forEach((session) => {
          db.prepare(`
            INSERT OR IGNORE INTO sessions (token, user_id, created_at, last_seen_at, expires_at)
            VALUES (?, ?, ?, ?, ?)
          `).run(
            session.token,
            session.userId || session.user_id,
            session.createdAt || session.created_at || nowIso(),
            session.lastSeenAt || session.last_seen_at || nowIso(),
            session.expiresAt || session.expires_at || nowIso()
          );
        });
      }

      if (Array.isArray(legacy.audit)) {
        legacy.audit.forEach((event) => {
          db.prepare(`
            INSERT OR IGNORE INTO admin_audit (id, user_id, action, meta_json, created_at)
            VALUES (?, ?, ?, ?, ?)
          `).run(
            event.id || randomBytes(8).toString("hex"),
            event.userId || event.user_id || null,
            event.action || "legacy.event",
            toJson(event.meta || {}),
            event.createdAt || event.created_at || nowIso()
          );
        });
      }

      db.prepare(`
        INSERT INTO schema_meta (key, value, updated_at)
        VALUES ('legacy_json_migrated', 'true', ?)
      `).run(nowIso());
    });
  } catch (error) {
    console.warn("Не удалось мигрировать старый JSON:", error.message);
  }
}

function readFileSyncText(path) {
  return readFileSync(path, "utf8");
}

createServer(handleRequest).listen(PORT, HOST, () => {
  const displayHost = HOST === "0.0.0.0" ? "localhost" : HOST;

  console.log(`Малыш+ server: http://${displayHost}:${PORT}`);
  console.log(`Public URL: ${PUBLIC_URL}`);
  console.log(`API: http://${displayHost}:${PORT}/api/health`);
  console.log(`SQLite база: ${DB_FILE}`);
  console.log(SERVE_WEB ? `Web dist: ${DIST_DIR}` : "Web serving disabled");
});

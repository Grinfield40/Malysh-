import { getStoredSession, sendAnalyticsEvents } from "./accountApi";
import type { AnalyticsEventPayload } from "./accountApi";
import { canUseOptionalAnalytics } from "./cookieConsent";

const ANALYTICS_SESSION_KEY = "mvp.analytics.session";
const FLUSH_DELAY_MS = 900;
const MIN_SCREEN_TIME_MS = 400;
const MAX_META_KEYS = 12;
const MAX_STRING_LENGTH = 120;

let pendingEvents: AnalyticsEventPayload[] = [];
let flushTimer: number | undefined;
let currentScreen: string | undefined;
let currentScreenStartedAt = 0;
let getCurrentScreenForErrors: (() => string | undefined) | undefined;
let globalErrorTrackingInstalled = false;

function createAnalyticsSessionId() {
  const cryptoId = window.crypto?.randomUUID?.();
  return cryptoId || `session-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function getAnalyticsSessionId() {
  try {
    const existing = window.localStorage.getItem(ANALYTICS_SESSION_KEY);

    if (existing) return existing;

    const nextId = createAnalyticsSessionId();
    window.localStorage.setItem(ANALYTICS_SESSION_KEY, nextId);

    return nextId;
  } catch {
    return createAnalyticsSessionId();
  }
}

function sanitizeMetaValue(value: unknown): unknown {
  if (value == null) return value;

  if (typeof value === "string") return value.slice(0, MAX_STRING_LENGTH);
  if (typeof value === "number") return Number.isFinite(value) ? value : undefined;
  if (typeof value === "boolean") return value;
  if (Array.isArray(value)) return value.slice(0, 8).map(sanitizeMetaValue);

  return undefined;
}

function sanitizeMeta(meta?: Record<string, unknown>) {
  if (!meta) return {};

  return Object.fromEntries(
    Object.entries(meta)
      .slice(0, MAX_META_KEYS)
      .map(([key, value]) => [key.slice(0, 48), sanitizeMetaValue(value)])
      .filter(([, value]) => value !== undefined)
  );
}

function getErrorMessage(error: unknown) {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return "Unknown error";
}

function queueFlush() {
  if (flushTimer) window.clearTimeout(flushTimer);

  flushTimer = window.setTimeout(() => {
    void flushAnalytics();
  }, FLUSH_DELAY_MS);
}

export function trackEvent(
  name: string,
  options: {
    screen?: string;
    durationMs?: number;
    meta?: Record<string, unknown>;
    immediate?: boolean;
  } = {}
) {
  const normalizedName = name.trim();

  if (!normalizedName || !canUseOptionalAnalytics()) return;

  pendingEvents.push({
    name: normalizedName.slice(0, 80),
    sessionId: getAnalyticsSessionId(),
    screen: options.screen || currentScreen,
    durationMs: options.durationMs == null ? undefined : Math.round(options.durationMs),
    meta: sanitizeMeta(options.meta),
    createdAt: new Date().toISOString(),
  });

  if (options.immediate) {
    void flushAnalytics();
    return;
  }

  queueFlush();
}

export function trackError(
  error: unknown,
  options: {
    screen?: string;
    source?: string;
    meta?: Record<string, unknown>;
    immediate?: boolean;
  } = {}
) {
  trackEvent("app_error", {
    screen: options.screen || currentScreen || getCurrentScreenForErrors?.(),
    meta: {
      source: options.source || "app",
      message: getErrorMessage(error),
      ...options.meta,
    },
    immediate: options.immediate ?? true,
  });
}

export function installAnalyticsErrorTracking(getScreen?: () => string | undefined) {
  getCurrentScreenForErrors = getScreen;

  if (globalErrorTrackingInstalled) return;

  globalErrorTrackingInstalled = true;

  window.addEventListener("error", (event) => {
    trackError(event.error || event.message, {
      screen: getCurrentScreenForErrors?.(),
      source: "window_error",
      meta: {
        file: event.filename,
        line: event.lineno,
      },
    });
  });

  window.addEventListener("unhandledrejection", (event) => {
    trackError(event.reason, {
      screen: getCurrentScreenForErrors?.(),
      source: "unhandled_rejection",
    });
  });
}

export function trackScreenView(screen: string) {
  flushCurrentScreenTime();

  currentScreen = screen;
  currentScreenStartedAt = performance.now();
  trackEvent("screen_view", { screen });
}

export function flushCurrentScreenTime() {
  if (!currentScreen || currentScreenStartedAt <= 0) return;

  const durationMs = performance.now() - currentScreenStartedAt;

  if (durationMs >= MIN_SCREEN_TIME_MS) {
    trackEvent("screen_time", {
      screen: currentScreen,
      durationMs,
    });
  }

  currentScreenStartedAt = performance.now();
}

export async function flushAnalytics() {
  const session = getStoredSession();

  if (!session || pendingEvents.length === 0) return;

  const events = pendingEvents.slice(0, 50);
  pendingEvents = pendingEvents.slice(events.length);

  if (flushTimer) {
    window.clearTimeout(flushTimer);
    flushTimer = undefined;
  }

  try {
    await sendAnalyticsEvents(session.token, events);
  } catch {
    pendingEvents = [...events, ...pendingEvents].slice(0, 120);
  }
}

export const SAVED_ARTICLES_STORAGE_KEY = "mvp.saved.articles";
export const SAVED_FORUM_POSTS_STORAGE_KEY = "mvp.saved.forumPosts";

export interface SavedArticleItem {
  id: number;
  title: string;
  category: string;
  time: string;
  description: string;
  emoji: string;
  savedAt: string;
}

export interface SavedForumPostItem {
  id: string;
  title: string;
  category: string;
  author: string;
  preview: string;
  comments: number;
  views: number;
  createdAt: string;
  savedAt: string;
}

export function toggleSavedItem<T extends { id: string | number }>(items: T[], item: T) {
  const exists = items.some((savedItem) => savedItem.id === item.id);

  if (exists) {
    return items.filter((savedItem) => savedItem.id !== item.id);
  }

  return [item, ...items];
}

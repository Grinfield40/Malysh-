import { motion } from "motion/react";
import { Home, ShoppingBag, BookOpen, User, Clock, Activity, Bell, Bookmark, Baby, Heart, Image, MessageCircle, ShieldCheck } from "lucide-react";
import { Logo } from "../Logo";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";

interface SidebarProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
}

const menuSections = [
  {
    title: "Основное",
    items: [
      { id: "home", icon: Home, label: "Главная" },
      { id: "growth-timeline", icon: Baby, label: "Развитие малыша" },
      { id: "recommendations", icon: Heart, label: "Мамы одобряют" },
    ],
  },
  {
    title: "Ежедневно",
    items: [
      { id: "fridge", icon: Image, label: "Холодильник" },
      { id: "routines", icon: Clock, label: "Режим дня" },
      { id: "tracker", icon: Activity, label: "Трекер" },
      { id: "reminders", icon: Bell, label: "Напоминания" },
    ],
  },
  {
    title: "Подготовка",
    items: [
      { id: "shopping", icon: ShoppingBag, label: "Покупки" },
    ],
  },
  {
    title: "Контент",
    items: [
      { id: "tips", icon: BookOpen, label: "Советы" },
      { id: "forum", icon: MessageCircle, label: "Форум" },
    ],
  },
  {
    title: "Прочее",
    items: [
      { id: "saved", icon: Bookmark, label: "Сохраненное" },
      { id: "profile", icon: User, label: "Профиль" },
      { id: "privacy", icon: ShieldCheck, label: "Приватность" },
    ],
  },
];

export function Sidebar({ activeScreen, onNavigate }: SidebarProps) {
  const { baby, age } = useBabyProfile();
  const [profile] = useUserProfile();
  const sections = profile.role === "Администратор"
    ? menuSections.map((section) =>
        section.title === "Прочее"
          ? {
              ...section,
              items: [
                { id: "admin", icon: ShieldCheck, label: "Админ-панель" },
                ...section.items,
              ],
            }
          : section
      )
    : menuSections;

  return (
    <motion.aside
      initial={{ x: -280 }}
      animate={{ x: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="hidden md:flex fixed left-0 top-0 bottom-0 w-[280px] bg-card/80 backdrop-blur-xl border-r border-border/50 flex-col z-40"
    >
      {/* Logo */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="h-20 flex items-center gap-3 px-6 border-b border-border/50"
      >
        <Logo size={44} animate />
        <span className="text-2xl font-medium text-foreground">Малыш+</span>
      </motion.div>

      {/* Baby Profile */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="p-5 border-b border-border/50"
      >
        <button
          type="button"
          onClick={() => onNavigate("profile")}
          className="w-full text-left bg-gradient-to-br from-primary/10 via-accent/5 to-primary/5 rounded-2xl p-4 border border-primary/10 hover:border-primary/30 transition-all"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl flex items-center justify-center text-2xl">
              {baby.emoji}
            </div>
            <div className="flex-1">
              <div className="text-sm font-semibold text-foreground">{baby.name}</div>
              <div className="text-xs text-muted-foreground">{age.label}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-center">
            <div className="bg-card/50 rounded-lg py-1.5 px-2">
              <div className="text-xs text-muted-foreground">Дней</div>
              <div className="text-sm font-semibold text-foreground">{Math.max(0, age.days)}</div>
            </div>
            <div className="bg-card/50 rounded-lg py-1.5 px-2">
              <div className="text-xs text-muted-foreground">Недель</div>
              <div className="text-sm font-semibold text-foreground">{age.weeks}</div>
            </div>
          </div>
        </button>
      </motion.div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-6">
        <div className="px-4 space-y-6">
          {sections.map((section, sectionIdx) => (
            <div key={section.title}>
              {/* Section Title */}
              <div className="px-3 mb-3">
                <h3 className="text-[11px] font-semibold text-muted-foreground/60 uppercase tracking-wider">
                  {section.title}
                </h3>
              </div>

              {/* Section Items */}
              <div className="space-y-1">
                {section.items.map((item, itemIdx) => {
                  const Icon = item.icon;
                  const isActive = activeScreen === item.id || (item.id === "growth-timeline" && activeScreen === "growth-stage");

                  return (
                    <motion.button
                      key={item.id}
                      onClick={() => onNavigate(item.id)}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + sectionIdx * 0.1 + itemIdx * 0.05 }}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                      className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all relative group ${
                        isActive
                          ? "bg-primary/10 text-primary"
                          : "text-foreground hover:bg-secondary/60"
                      }`}
                    >
                      {/* Active Indicator Line */}
                      {isActive && (
                        <motion.div
                          layoutId="activeIndicator"
                          className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-r-full"
                          transition={{ type: "spring", damping: 25, stiffness: 300 }}
                        />
                      )}

                      <Icon
                        className={`w-5 h-5 transition-all ${
                          isActive
                            ? "text-primary"
                            : "text-muted-foreground/70 group-hover:text-foreground group-hover:scale-105"
                        }`}
                        strokeWidth={isActive ? 2.5 : 2}
                      />
                      <span className={`text-sm transition-all ${
                        isActive
                          ? "font-semibold"
                          : "font-medium group-hover:text-foreground"
                      }`}>
                        {item.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </nav>

      {/* Premium CTA */}
      <div className="p-4 border-t border-border">
        <motion.button
          onClick={() => onNavigate("subscription")}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="w-full bg-gradient-to-r from-primary to-accent text-white rounded-2xl p-4 mb-4 hover:shadow-lg hover:shadow-primary/30 transition-all"
        >
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
              <span className="text-xl">👑</span>
            </div>
            <div className="text-left flex-1">
              <div className="text-sm font-semibold">Премиум</div>
              <div className="text-xs text-white/80">Получить 7 дней бесплатно</div>
            </div>
          </div>
        </motion.button>
        <div className="text-xs text-muted-foreground text-center">
          © 2026 Малыш+
        </div>
      </div>
    </motion.aside>
  );
}

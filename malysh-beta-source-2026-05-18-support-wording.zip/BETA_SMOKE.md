# Malysh+ beta smoke test

This check starts a temporary local API, creates a temporary SQLite database, creates an admin, tests the closed beta flow, creates a tester, writes diary/fridge storage, creates analytics and forum content, checks moderation/reporting, checks data guards, checks safe admin actions, creates a backup, and then deletes the temporary files.

It does not touch the normal `server/data/app.db`.

Run:

```powershell
npm.cmd run beta:smoke
```

It checks:

- `/api/health` is online and registration mode is `closed`;
- admin bootstrap account can log in;
- admin can create a one-use beta invite code;
- registration without invite code is rejected;
- registration with an admin-created invite code works;
- the same one-use invite code cannot be reused;
- the first tester is not accidentally made admin;
- account storage accepts valid MVP profile data;
- diary entries are synced into the SQLite structured tables;
- fridge uploads are synced and shown in admin data;
- product analytics accepts screen/action events and appears in admin overview;
- forum post, comment, and report creation work;
- oversized JSON, bad storage keys, long forum posts, and oversized fridge images are rejected;
- admin overview, user cards, action history, backup, and safe user deletion mode work.

Use it before showing the build to testers and before moving a new version to VPS.

For a full pre-beta gate, run:

```powershell
npm.cmd run beta:launch
```

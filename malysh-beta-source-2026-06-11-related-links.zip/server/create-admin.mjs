import { pbkdf2Sync, randomBytes } from "node:crypto";
import { mkdir } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
loadEnvFile(join(__dirname, "..", ".env"));

const args = process.argv.slice(2);
const positionalArgs = args.filter((arg) => !arg.startsWith("--"));
const resetPassword = args.includes("--reset-password") || process.env.MALYSH_ADMIN_RESET_PASSWORD === "true";
const dataDir = process.env.MALYSH_DATA_DIR || join(__dirname, "data");
const dbFile = process.env.MALYSH_DB_FILE || join(dataDir, "app.db");
const email = normalizeEmail(positionalArgs[0] || process.env.MALYSH_ADMIN_EMAIL);
const name = String(positionalArgs[1] || process.env.MALYSH_ADMIN_NAME || "Администратор").trim();
const password = String(positionalArgs[2] || process.env.MALYSH_ADMIN_PASSWORD || "");

try {
  if (!email.includes("@")) {
    throw new Error("Укажите email админа: npm.cmd run admin:create -- admin@example.com Алекс StrongPassword123");
  }

  if (password.length < 8) {
    throw new Error("Пароль админа должен быть не короче 8 символов.");
  }

  await mkdir(dataDir, { recursive: true });

  const db = new DatabaseSync(dbFile);
  db.exec(`
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      password_salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      auth_provider TEXT NOT NULL DEFAULT 'password',
      yandex_user_id TEXT,
      email_verified_at TEXT,
      blocked_at TEXT,
      created_at TEXT NOT NULL,
      last_login_at TEXT
    );

    CREATE TABLE IF NOT EXISTS admin_audit (
      id TEXT PRIMARY KEY,
      user_id TEXT,
      action TEXT NOT NULL,
      meta_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
  `);

  ensureTableColumn(db, "users", "auth_provider", "TEXT NOT NULL DEFAULT 'password'");
  ensureTableColumn(db, "users", "yandex_user_id", "TEXT");
  ensureTableColumn(db, "users", "email_verified_at", "TEXT");
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS users_yandex_user_id_unique ON users(yandex_user_id) WHERE yandex_user_id IS NOT NULL;");

  const existing = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  const createdAt = nowIso();

  if (existing) {
    if (resetPassword) {
      const { salt, hash } = createPasswordHash(password);

      db.prepare(`
        UPDATE users
        SET name = ?, role = 'admin', password_salt = ?, password_hash = ?, blocked_at = NULL
        WHERE id = ?
      `).run(name, salt, hash, existing.id);
    } else {
      db.prepare("UPDATE users SET name = ?, role = 'admin', blocked_at = NULL WHERE id = ?").run(name, existing.id);
    }

    addAudit(db, existing.id, "admin.bootstrap", { email, resetPassword });
    db.close();

    console.log(`Admin is ready: ${email}`);
    console.log(resetPassword ? "Password was reset." : "Password was not changed. Add --reset-password to update it.");
    process.exit(0);
  }

  const { salt, hash } = createPasswordHash(password);
  const userId = randomBytes(12).toString("hex");

  db.prepare(`
    INSERT INTO users (
      id, email, name, role, password_salt, password_hash, created_at, last_login_at
    )
    VALUES (?, ?, ?, 'admin', ?, ?, ?, ?)
  `).run(userId, email, name || "Администратор", salt, hash, createdAt, null);

  addAudit(db, userId, "admin.bootstrap", { email, created: true });
  db.close();

  console.log(`Admin created: ${email}`);
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
}

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function nowIso() {
  return new Date().toISOString();
}

function createPasswordHash(value) {
  const salt = randomBytes(16).toString("hex");
  const hash = pbkdf2Sync(String(value), salt, 120000, 32, "sha256").toString("hex");

  return { salt, hash };
}

function addAudit(db, userId, action, meta) {
  db.prepare(`
    INSERT INTO admin_audit (id, user_id, action, meta_json, created_at)
    VALUES (?, ?, ?, ?, ?)
  `).run(randomBytes(8).toString("hex"), userId, action, JSON.stringify(meta), nowIso());
}

function ensureTableColumn(db, tableName, columnName, definition) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  const hasColumn = columns.some((column) => column.name === columnName);

  if (!hasColumn) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition};`);
  }
}

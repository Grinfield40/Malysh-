import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { ChevronLeft, ShieldCheck } from "lucide-react";
import { useState } from "react";

interface RegistrationScreenProps {
  onComplete: () => void;
  onBack: () => void;
}

export function RegistrationScreen({ onComplete, onBack }: RegistrationScreenProps) {
  const [role, setRole] = useState<string>("");

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="p-4">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="flex-1 px-6 flex flex-col">
        <div className="mb-8">
          <h1 className="text-3xl font-medium text-foreground mb-2">Регистрация</h1>
          <p className="text-muted-foreground">Создайте аккаунт, чтобы продолжить</p>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <Label>Имя</Label>
            <Input
              placeholder="Ваше имя"
              className="h-12 rounded-xl bg-input-background border-0"
            />
          </div>

          <div className="space-y-2">
            <Label>Email</Label>
            <Input
              type="email"
              placeholder="name@yandex.ru"
              className="h-12 rounded-xl bg-input-background border-0"
            />
          </div>

          <div className="space-y-2">
            <Label>Пароль</Label>
            <Input
              type="password"
              placeholder="Минимум 8 символов"
              className="h-12 rounded-xl bg-input-background border-0"
            />
          </div>

          <div className="space-y-3">
            <Label>Я...</Label>
            <div className="flex gap-3">
              <button
                onClick={() => setRole("мама")}
                className={`flex-1 h-12 rounded-xl border-2 transition-all ${
                  role === "мама"
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-transparent text-muted-foreground"
                }`}
              >
                Мама
              </button>
              <button
                onClick={() => setRole("папа")}
                className={`flex-1 h-12 rounded-xl border-2 transition-all ${
                  role === "папа"
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-transparent text-muted-foreground"
                }`}
              >
                Папа
              </button>
              <button
                onClick={() => setRole("вместе")}
                className={`flex-1 h-12 rounded-xl border-2 transition-all ${
                  role === "вместе"
                    ? "border-primary bg-primary/5 text-foreground"
                    : "border-border bg-transparent text-muted-foreground"
                }`}
              >
                Вместе
              </button>
            </div>
          </div>

          <div className="pt-2">
            <p className="text-xs text-muted-foreground leading-relaxed">
              Нажимая «Создать аккаунт», вы соглашаетесь с условиями использования и политикой конфиденциальности
            </p>
          </div>
        </div>

        <div className="mt-auto pb-8 space-y-4">
          <Button
            onClick={onComplete}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Создать аккаунт
          </Button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-background px-4 text-muted-foreground">Регистрация по email</span>
            </div>
          </div>

          <div className="rounded-2xl border border-primary/15 bg-primary/5 px-4 py-3">
            <div className="mb-1 flex items-center gap-2 text-sm font-medium text-foreground">
              <ShieldCheck className="h-4 w-4 text-primary" />
              Вход через Google в России запрещен
            </div>
            <p className="text-xs leading-relaxed text-muted-foreground">
              Создайте аккаунт через Яндекс ID или российскую почту: Яндекс, Mail.ru, VK или Rambler.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

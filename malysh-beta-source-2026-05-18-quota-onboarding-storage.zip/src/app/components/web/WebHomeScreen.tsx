import { motion } from "motion/react";
import { Search, AlertCircle, ShoppingBag, BookOpen, Clock, Bookmark, TrendingUp, ShieldAlert, ClipboardList, ArrowRight, CheckCircle2, Circle, Camera, ListChecks } from "lucide-react";
import { useState } from "react";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { useBabyProfile } from "../../lib/babyProfile";
import { useUserProfile } from "../../lib/userProfile";
import { useParentGoals } from "../../lib/parentGoals";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { CareDiaryEntry, getCareDiarySummary, getTodayCareEntries } from "../../lib/careDiary";
import { CareFlowStrip } from "./CareFlowStrip";
import { BetaFeedbackCard } from "./BetaFeedbackCard";

interface WebHomeScreenProps {
  onNavigate: (screen: string) => void;
}

interface StoredShoppingCategory {
  items: Array<{ checked: boolean }>;
}

interface StoredFridgeDrawing {
  imageSrc?: string;
}

function getTodayKey() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function readLocalStorage<T>(key: string): T | null {
  try {
    const value = window.localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : null;
  } catch {
    return null;
  }
}

export function WebHomeScreen({ onNavigate }: WebHomeScreenProps) {
  const [homeSearchQuery, setHomeSearchQuery] = useState("");
  const [profile] = useUserProfile();
  const { baby, age } = useBabyProfile();
  const { selectedGoals } = useParentGoals();
  const storedShopping = readLocalStorage<StoredShoppingCategory[]>("mvp.shopping.items");
  const trackerEntries = readLocalStorage<CareDiaryEntry[]>("mvp.tracker.entries") ?? [];
  const todayTrackerEntries = getTodayCareEntries(trackerEntries);
  const trackerSummary = getCareDiarySummary(todayTrackerEntries);
  const fridgeDrawings = readLocalStorage<StoredFridgeDrawing[]>("mvp.fridge.drawings") ?? [];
  const todayKey = getTodayKey();
  const [completedFocusIds, setCompletedFocusIds] = useLocalStorageState<string[]>(
    `mvp.home.completed.${todayKey}`,
    []
  );
  const displayName = profile.name?.trim() || "Родитель";
  const primaryGoal = selectedGoals[0];
  const uploadedFridgeCount = fridgeDrawings.filter((drawing) => drawing.imageSrc).length;

  const totalShoppingItems = storedShopping?.reduce((sum, category) => sum + category.items.length, 0) ?? 0;
  const checkedShoppingItems =
    storedShopping?.reduce(
      (sum, category) => sum + category.items.filter((item) => item.checked).length,
      0
    ) ?? 0;
  const shoppingProgressLabel = totalShoppingItems > 0 ? `${checkedShoppingItems}/${totalShoppingItems}` : "список";

  const trackerStats = {
    feeding: trackerSummary.feeding,
    sleep: trackerSummary.sleep,
    diaper: trackerSummary.diaper,
    temperature: trackerSummary.temperature === "—" ? "—" : trackerSummary.temperature.replace("°C", "°"),
  };

  const quickActions = [
    { id: "urgent", label: "Срочный вопрос", icon: AlertCircle, color: "bg-destructive", count: null },
    { id: "shopping", label: "Что купить", icon: ShoppingBag, color: "bg-primary", count: shoppingProgressLabel },
    { id: "discharge-checklist", label: "На выписку", icon: ClipboardList, color: "bg-[#A4B5A8]", count: null },
    { id: "tips", label: "Советы", icon: BookOpen, color: "bg-accent", count: "5 новых" },
    { id: "routines", label: "Режим дня", icon: Clock, color: "bg-[#8B9DC3]", count: null },
    { id: "taboo", label: "Табу", icon: ShieldAlert, color: "bg-destructive", count: null },
  ];

  const recentArticles = [
    { title: "Когда обращаться к врачу", time: "5 мин", category: "Здоровье", icon: "🩺" },
    { title: "Первая аптечка для малыша", time: "3 мин", category: "Покупки", icon: "💊" },
    { title: `Режим для этапа ${age.stageLabel}`, time: "7 мин", category: "Сон", icon: "🌙" },
  ];

  const latestActivities = todayTrackerEntries.slice(0, 3).map((entry) => ({
    time: entry.time,
    action: entry.type,
    details: entry.details,
    icon: entry.icon,
  }));

  const focusTasks = [
    ...selectedGoals.map((goal) => ({
      id: `goal-${goal.id}`,
      title: goal.actionLabel,
      description: goal.homeHint,
      icon: goal.icon,
      screen: goal.targetScreen,
    })),
    {
      id: "tracker-check",
      title: todayTrackerEntries.length > 0 ? "Проверить ленту ухода" : "Добавить первую запись",
      description:
        todayTrackerEntries.length > 0
          ? `Сегодня уже есть ${todayTrackerEntries.length} записей по уходу.`
          : `Запишите сон, кормление или подгузник для ${baby.name}.`,
      icon: "📝",
      screen: "tracker",
    },
  ].slice(0, 5);
  const completedFocusCount = focusTasks.filter((task) => completedFocusIds.includes(task.id)).length;
  const focusProgress = focusTasks.length > 0 ? Math.round((completedFocusCount / focusTasks.length) * 100) : 0;
  const nextTask = focusTasks.find((task) => !completedFocusIds.includes(task.id)) ?? focusTasks[0];

  const toggleFocusTask = (taskId: string) => {
    setCompletedFocusIds((prev) =>
      prev.includes(taskId)
        ? prev.filter((id) => id !== taskId)
        : [...prev, taskId]
    );
  };

  const handleHomeSearch = () => {
    if (!homeSearchQuery.trim()) return;
    try {
      window.localStorage.setItem("mvp.home.lastSearch", JSON.stringify(homeSearchQuery.trim()));
    } catch {
      // Search should still navigate even if local persistence is unavailable.
    }
    onNavigate("tips");
  };

  const quickActionsSection = (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.12 }}
      className="mb-6 md:mb-8"
    >
      <h2 className="text-lg md:text-xl font-medium text-foreground mb-3 md:mb-4">Быстрые действия</h2>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 xl:grid-cols-6">
        {quickActions.map((action, idx) => {
          const Icon = action.icon;
          return (
            <motion.button
              key={action.id}
              onClick={() => onNavigate(action.id)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.16 + idx * 0.05 }}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              className="bg-card border border-border rounded-xl md:rounded-2xl p-4 hover:border-primary/30 transition-all group"
            >
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className={`w-11 h-11 rounded-xl ${action.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                {action.count && (
                  <span className="text-[11px] md:text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-full">
                    {action.count}
                  </span>
                )}
              </div>
              <h3 className="text-sm font-medium text-foreground text-left leading-snug">{action.label}</h3>
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );

  return (
    <div className="p-4 md:p-8 max-w-[1400px] mx-auto relative">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-2">Добрый день, {displayName}!</h1>
        <p className="text-base md:text-lg text-muted-foreground">Сегодня собираем день вокруг {baby.name}</p>
      </motion.div>

      {/* Baby Context */}
      <motion.button
        type="button"
        onClick={() => onNavigate("profile")}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="w-full mb-6 md:mb-8 bg-card border border-border rounded-2xl p-4 md:p-5 text-left hover:border-primary/30 transition-all"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-3xl">
              {baby.emoji}
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Профиль ребенка</div>
              <div className="text-xl md:text-2xl font-medium text-foreground">
                {baby.name}, {age.label}
              </div>
            </div>
          </div>
          <div className="md:max-w-xl">
            <div className="text-xs font-medium text-primary mb-1">{age.stageLabel}</div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Фокус сейчас: {age.focus}.
            </p>
          </div>
        </div>
      </motion.button>

      {quickActionsSection}

      <CareFlowStrip active="home" onNavigate={onNavigate} />

      {/* Search */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="mb-6 md:mb-8"
      >
        <form
          onSubmit={(event) => {
            event.preventDefault();
            handleHomeSearch();
          }}
          className="flex max-w-3xl flex-col gap-2 sm:flex-row"
        >
          <div className="relative flex-1">
            <Search className="absolute left-4 md:left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              value={homeSearchQuery}
              onChange={(event) => setHomeSearchQuery(event.target.value)}
              placeholder={`Что важно для ${baby.name} сегодня?`}
              className="h-12 md:h-14 pl-12 md:pl-14 rounded-2xl bg-card border-border text-sm md:text-base"
            />
          </div>
          <Button type="submit" className="h-12 rounded-2xl md:h-14 sm:min-w-[130px]">
            Найти
          </Button>
        </form>
      </motion.div>

      {/* Day Command Center */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="mb-6 md:mb-8"
      >
        <div className="bg-card border border-border rounded-2xl md:rounded-3xl p-4 md:p-6 shadow-lg shadow-primary/5">
          <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_0.8fr] gap-5 md:gap-6">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <ListChecks className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium text-primary">План на сегодня</span>
              </div>
              <h2 className="text-xl md:text-3xl font-medium text-foreground mb-3">
                {nextTask ? nextTask.title : `День ${baby.name} под контролем`}
              </h2>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
                {nextTask
                  ? nextTask.description
                  : "Все фокусы отмечены. Можно спокойно возвращаться к наблюдениям и режиму."}
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                {nextTask && (
                  <Button
                    onClick={() => onNavigate(nextTask.screen)}
                    className="h-11 rounded-xl bg-primary hover:bg-primary/90"
                  >
                    Открыть действие
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={() => onNavigate("fridge")}
                  className="h-11 rounded-xl"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Холодильник
                </Button>
              </div>
            </div>

            <div className="rounded-2xl bg-secondary/50 border border-border p-4 md:p-5">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <div className="text-sm text-muted-foreground">Прогресс дня</div>
                  <div className="text-2xl font-medium text-foreground">{focusProgress}%</div>
                </div>
                <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-3xl">
                  {baby.emoji}
                </div>
              </div>
              <div className="h-2 bg-background rounded-full overflow-hidden mb-4">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${focusProgress}%` }}
                  className="h-full bg-primary rounded-full"
                />
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-card px-2 py-3">
                  <div className="text-lg font-medium text-foreground">{completedFocusCount}/{focusTasks.length}</div>
                  <div className="text-[10px] md:text-xs text-muted-foreground">фокусов</div>
                </div>
                <div className="rounded-xl bg-card px-2 py-3">
                  <div className="text-lg font-medium text-foreground">{todayTrackerEntries.length}</div>
                  <div className="text-[10px] md:text-xs text-muted-foreground">записей</div>
                </div>
                <div className="rounded-xl bg-card px-2 py-3">
                  <div className="text-lg font-medium text-foreground">{uploadedFridgeCount}</div>
                  <div className="text-[10px] md:text-xs text-muted-foreground">фото</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-8">
        {/* Left Column - Quick Actions + Tip */}
        <div className="lg:col-span-2 flex flex-col gap-4 md:gap-6">
          {/* Parent Goals */}
          {selectedGoals.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.18 }}
              className="order-1"
            >
              <div className="flex items-center justify-between gap-3 mb-3 md:mb-4">
                <h2 className="text-lg md:text-xl font-medium text-foreground">Ваши фокусы</h2>
                <button
                  type="button"
                  onClick={() => onNavigate("profile")}
                  className="text-xs md:text-sm text-primary hover:underline"
                >
                  Изменить
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 md:gap-4">
                {selectedGoals.map((goal) => (
                  <motion.button
                    key={goal.id}
                    type="button"
                    onClick={() => onNavigate(goal.targetScreen)}
                    whileHover={{ y: -3 }}
                    whileTap={{ scale: 0.99 }}
                    className="bg-card border border-border rounded-xl md:rounded-2xl p-4 text-left hover:border-primary/30 transition-all"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center text-2xl">
                        {goal.icon}
                      </div>
                      <div>
                        <div className="text-sm font-medium text-foreground">{goal.shortLabel}</div>
                        <div className="text-xs text-primary">{goal.actionLabel}</div>
                      </div>
                    </div>
                    <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">
                      {goal.homeHint}
                    </p>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Focus Checklist */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="order-2 bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6"
          >
            <div className="flex items-center justify-between gap-3 mb-4">
              <div>
                <h2 className="text-lg md:text-xl font-medium text-foreground">Чек-лист дня</h2>
                <p className="text-xs md:text-sm text-muted-foreground">
                  Отмечайте то, что уже закрыто сегодня
                </p>
              </div>
              <div className="text-sm font-medium text-primary">
                {completedFocusCount}/{focusTasks.length}
              </div>
            </div>
            <div className="space-y-2">
              {focusTasks.map((task) => {
                const isCompleted = completedFocusIds.includes(task.id);

                return (
                  <div
                    key={task.id}
                    className={`flex items-start gap-3 rounded-xl border px-3 py-3 transition-colors ${
                      isCompleted
                        ? "border-primary/20 bg-primary/5"
                        : "border-border bg-background"
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => toggleFocusTask(task.id)}
                      className="mt-0.5 text-primary"
                      aria-label={isCompleted ? "Вернуть задачу" : "Отметить задачу"}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5" />
                      ) : (
                        <Circle className="w-5 h-5" />
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onNavigate(task.screen)}
                      className="min-w-0 flex-1 text-left"
                    >
                      <div className={`text-sm font-medium ${isCompleted ? "text-muted-foreground line-through" : "text-foreground"}`}>
                        {task.icon} {task.title}
                      </div>
                      <div className="text-xs text-muted-foreground leading-relaxed">
                        {task.description}
                      </div>
                    </button>
                  </div>
                );
              })}
            </div>
          </motion.div>

          {/* Tip of the Day */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="order-3 bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-xl md:rounded-2xl p-4 md:p-6"
          >
            <div className="flex items-start gap-3 md:gap-4">
              <div className="w-12 h-12 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-white flex items-center justify-center text-2xl md:text-3xl flex-shrink-0">
                💡
              </div>
              <div className="flex-1">
              <h3 className="text-base md:text-lg font-medium text-foreground mb-2">Совет дня</h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-3 md:mb-4">
                  {primaryGoal
                    ? `${primaryGoal.homeHint} Для этапа «${age.stageLabel}» сейчас особенно важны ${age.focus}.`
                    : `Для этапа «${age.stageLabel}» сейчас особенно важны ${age.focus}. Добавляйте наблюдения в трекер, чтобы увидеть свой ритм без догадок.`}
              </p>
                <button className="text-xs md:text-sm text-primary font-medium hover:underline">
                  Узнать больше →
                </button>
              </div>
            </div>
          </motion.div>

          {/* Recent Articles */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="order-4"
          >
            <div className="flex items-center justify-between mb-3 md:mb-4">
              <h2 className="text-lg md:text-xl font-medium text-foreground">Полезное на старте</h2>
              <button onClick={() => onNavigate("tips")} className="text-xs md:text-sm text-primary hover:underline">
                Открыть советы
              </button>
            </div>
            <div className="space-y-2 md:space-y-3">
              {recentArticles.map((article, idx) => (
                <motion.button
                  key={idx}
                  onClick={() => onNavigate("tips")}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + idx * 0.1 }}
                  whileHover={{ x: 4 }}
                  className="w-full bg-card border border-border rounded-xl p-3 md:p-4 flex items-center gap-3 md:gap-4 hover:border-primary/30 transition-all"
                >
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-lg md:rounded-xl bg-secondary flex items-center justify-center text-xl md:text-2xl flex-shrink-0">
                    {article.icon}
                  </div>
                  <div className="flex-1 text-left">
                    <div className="text-xs text-primary font-medium mb-1">{article.category}</div>
                    <h4 className="text-xs md:text-sm font-medium text-foreground mb-1">{article.title}</h4>
                    <div className="text-xs text-muted-foreground">{article.time} чтения</div>
                  </div>
                  <Bookmark className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground flex-shrink-0" />
                </motion.button>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right Column - Activity Feed */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-4 md:space-y-6"
        >
          {/* Today's Stats */}
          <div className="bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-4 md:mb-6">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="text-sm md:text-base font-medium text-foreground">Сегодня у {baby.name}</h3>
            </div>
            <div className="grid grid-cols-2 gap-3 md:gap-4">
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.feeding}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Кормлений</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.sleep}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Сна</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.diaper}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Подгузников</div>
              </div>
              <div className="space-y-1">
                <div className="text-xl md:text-2xl font-medium text-foreground">{trackerStats.temperature}</div>
                <div className="text-xs md:text-sm text-muted-foreground">Температура</div>
              </div>
            </div>
          </div>

          <BetaFeedbackCard screen="home" />

          {/* Recent Activity */}
          <div className="bg-card border border-border rounded-xl md:rounded-2xl p-4 md:p-6">
            <h3 className="text-sm md:text-base font-medium text-foreground mb-3 md:mb-4">Последняя активность</h3>
            <div className="space-y-3 md:space-y-4">
              {latestActivities.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-border bg-secondary/30 px-4 py-6 text-center">
                  <div className="mb-2 text-3xl">📝</div>
                  <div className="text-sm font-medium text-foreground">Записей пока нет</div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Добавьте кормление, сон или заметку, и здесь появится живая лента дня.
                  </p>
                </div>
              ) : (
                latestActivities.map((activity, idx) => (
                  <div key={idx} className="flex items-start gap-2 md:gap-3">
                    <div className="w-9 h-9 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-secondary flex items-center justify-center text-lg md:text-xl flex-shrink-0">
                      {activity.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs md:text-sm font-medium text-foreground">{activity.action}</span>
                        <span className="text-xs text-muted-foreground">{activity.time}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">{activity.details}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
            <button
              onClick={() => onNavigate("tracker")}
              className="w-full mt-3 md:mt-4 h-9 md:h-10 rounded-lg md:rounded-xl border-2 border-dashed border-border hover:border-primary/30 transition-all text-xs md:text-sm text-muted-foreground font-medium"
            >
              Добавить запись
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

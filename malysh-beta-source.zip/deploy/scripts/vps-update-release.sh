#!/usr/bin/env bash
set -euo pipefail

# Updates the beta VPS from a release zip while keeping production data safe.
#
# Default source is the GitHub zip used by the beta project.
# Override it when needed:
# RELEASE_URL="https://example.com/malysh-beta-source.zip" bash deploy/scripts/vps-update-release.sh

PROJECT_DIR="${PROJECT_DIR:-/opt/malysh}"
APP_USER="${APP_USER:-malysh}"
SERVICE_NAME="${SERVICE_NAME:-malysh}"
RELEASE_URL="${RELEASE_URL:-https://raw.githubusercontent.com/Grinfield40/Malysh-/main/malysh-beta-source.zip}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/malysh}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:8787/api/health}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
STAGING_DIR="/tmp/malysh-release-${STAMP}"
ZIP_FILE="${STAGING_DIR}/release.zip"
UNZIP_DIR="${STAGING_DIR}/unzip"
CODE_BACKUP="${BACKUP_ROOT}/releases/code-${STAMP}.tgz"
ENV_BACKUP="${BACKUP_ROOT}/releases/env-${STAMP}.env"
ROLLBACK_READY=0

log() {
  printf '\n==> %s\n' "$1"
}

fail() {
  printf '\nERROR: %s\n' "$1" >&2
  exit 1
}

rollback() {
  local exit_code=$?

  if [ "$ROLLBACK_READY" != "1" ]; then
    exit "$exit_code"
  fi

  printf '\nUpdate failed. Rolling back previous code...\n' >&2

  systemctl stop "$SERVICE_NAME" >/dev/null 2>&1 || true

  if [ -f "$CODE_BACKUP" ]; then
    tar -xzf "$CODE_BACKUP" -C "$PROJECT_DIR" || true
  fi

  if [ -f "$ENV_BACKUP" ]; then
    cp "$ENV_BACKUP" "$PROJECT_DIR/.env" || true
  fi

  mkdir -p "$PROJECT_DIR/server/data" "$PROJECT_DIR/server/backups" /var/lib/malysh /var/backups/malysh
  chown -R "$APP_USER:$APP_USER" "$PROJECT_DIR" /var/lib/malysh /var/backups/malysh || true

  (
    cd "$PROJECT_DIR"
    npm ci --no-audit --no-fund
  ) || true

  systemctl start "$SERVICE_NAME" >/dev/null 2>&1 || true
  curl -fsS "$HEALTH_URL" >/dev/null 2>&1 || true

  printf 'Rollback attempted. Check service status with: systemctl status %s --no-pager -l\n' "$SERVICE_NAME" >&2
  exit "$exit_code"
}

trap rollback ERR

[ "$(id -u)" = "0" ] || fail "Run as root in the VPS console."
[ -d "$PROJECT_DIR" ] || fail "Project directory not found: $PROJECT_DIR"
[ -f "$PROJECT_DIR/.env" ] || fail "Production .env not found: $PROJECT_DIR/.env"

command -v curl >/dev/null 2>&1 || fail "curl is required."
command -v unzip >/dev/null 2>&1 || fail "unzip is required."
command -v npm >/dev/null 2>&1 || fail "npm is required."
command -v systemctl >/dev/null 2>&1 || fail "systemctl is required."

log "Downloading release zip"
mkdir -p "$STAGING_DIR" "$UNZIP_DIR" "$BACKUP_ROOT/releases"
curl -fsSL "$RELEASE_URL" -o "$ZIP_FILE"
unzip -q "$ZIP_FILE" -d "$UNZIP_DIR"

RELEASE_ROOT="$(find "$UNZIP_DIR" -maxdepth 3 -name package.json -type f -printf '%h\n' | head -n 1)"
[ -n "$RELEASE_ROOT" ] || fail "package.json was not found inside the release zip."
[ -f "$RELEASE_ROOT/server/index.mjs" ] || fail "server/index.mjs was not found inside the release zip."
[ -f "$RELEASE_ROOT/src/main.tsx" ] || fail "src/main.tsx was not found inside the release zip."

cp "$PROJECT_DIR/.env" "$RELEASE_ROOT/.env"

log "Checking release in a temporary folder"
(
  cd "$RELEASE_ROOT"
  npm ci --no-audit --no-fund
  npm run build
  npm run vps:check
  npm run beta:smoke
)

log "Creating database backup"
(
  cd "$PROJECT_DIR"
  npm run backup
)

log "Saving rollback snapshot"
tar -czf "$CODE_BACKUP" \
  --exclude='./node_modules' \
  --exclude='./.npm-cache' \
  --exclude='./server/data' \
  --exclude='./server/backups' \
  -C "$PROJECT_DIR" .
cp "$PROJECT_DIR/.env" "$ENV_BACKUP"
ROLLBACK_READY=1

log "Installing release"
systemctl stop "$SERVICE_NAME"

tar \
  --exclude='./.env' \
  --exclude='./node_modules' \
  --exclude='./.npm-cache' \
  --exclude='./server/data' \
  --exclude='./server/backups' \
  -C "$RELEASE_ROOT" -cf - . | tar -C "$PROJECT_DIR" -xf -

cp "$ENV_BACKUP" "$PROJECT_DIR/.env"
mkdir -p "$PROJECT_DIR/server/data" "$PROJECT_DIR/server/backups" /var/lib/malysh /var/backups/malysh
chown -R "$APP_USER:$APP_USER" "$PROJECT_DIR" /var/lib/malysh /var/backups/malysh

(
  cd "$PROJECT_DIR"
  npm ci --no-audit --no-fund
)

log "Starting service"
systemctl start "$SERVICE_NAME"
sleep 2
curl -fsS "$HEALTH_URL"
systemctl status "$SERVICE_NAME" --no-pager -l

ROLLBACK_READY=0
rm -rf "$STAGING_DIR"

log "Release updated successfully"
printf 'Code backup: %s\n' "$CODE_BACKUP"
printf 'Env backup:  %s\n' "$ENV_BACKUP"

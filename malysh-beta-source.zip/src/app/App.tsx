import { Component, lazy, Suspense, useCallback, useEffect, useState, type ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertCircle, LogOut, RefreshCw } from "lucide-react";
import { Sidebar } from "./components/web/Sidebar";
import { TopBar } from "./components/web/TopBar";
import { SplashScreen } from "./components/web/SplashScreen";
import { MobileBottomNav } from "./components/web/MobileBottomNav";
import { AuthScreen } from "./components/web/AuthScreen";
import { BabyOnboardingScreen } from "./components/web/BabyOnboardingScreen";
import { BetaPrivacyBanner } from "./components/web/BetaPrivacyBanner";
import { Button } from "./components/ui/button";
import { Toaster } from "./components/ui/sonner";
import { useLocalStorageState } from "./lib/useLocalStorageState";
import {
  AuthSession,
  clearStoredSession,
  getCurrentAccount,
  getStoredSession,
  hydrateLocalAppStorage,
  logoutAccount,
  saveStoredSession,
  setAppStorageItem,
} from "./lib/accountApi";
import {
  BABY_ONBOARDING_STORAGE_KEY,
  BABY_PROFILE_STORAGE_KEY,
  type BabyProfile,
} from "./lib/babyProfile";
import { PARENT_GOALS_STORAGE_KEY, type ParentGoalId } from "./lib/parentGoals";
import {
  flushAnalytics,
  flushCurrentScreenTime,
  installAnalyticsErrorTracking,
  trackError,
  trackEvent,
  trackScreenView,
} from "./lib/analytics";
import { notifySuccess } from "./lib/notify";

const WebHomeScreen = lazy(() => import("./components/web/WebHomeScreen").then((module) => ({ default: module.WebHomeScreen })));
const WebForumScreen = lazy(() => import("./components/web/WebForumScreen").then((module) => ({ default: module.WebForumScreen })));
const WebShoppingScreen = lazy(() => import("./components/web/WebShoppingScreen").then((module) => ({ default: module.WebShoppingScreen })));
const WebTrackerScreen = lazy(() => import("./components/web/WebTrackerScreen").then((module) => ({ default: module.WebTrackerScreen })));
const WebTipsScreen = lazy(() => import("./components/web/WebTipsScreen").then((module) => ({ default: module.WebTipsScreen })));
const WebArticleScreen = lazy(() => import("./components/web/WebArticleScreen").then((module) => ({ default: module.WebArticleScreen })));
const WebProfileScreen = lazy(() => import("./components/web/WebProfileScreen").then((module) => ({ default: module.WebProfileScreen })));
const WebSavedScreen = lazy(() => import("./components/web/WebSavedScreen").then((module) => ({ default: module.WebSavedScreen })));
const WebRemindersScreen = lazy(() => import("./components/web/WebRemindersScreen").then((module) => ({ default: module.WebRemindersScreen })));
const WebRoutinesScreen = lazy(() => import("./components/web/WebRoutinesScreen").then((module) => ({ default: module.WebRoutinesScreen })));
const WebUrgentScreen = lazy(() => import("./components/web/WebUrgentScreen").then((module) => ({ default: module.WebUrgentScreen })));
const WebRecommendationsScreen = lazy(() => import("./components/web/WebRecommendationsScreen").then((module) => ({ default: module.WebRecommendationsScreen })));
const GrowthTimelineScreen = lazy(() => import("./components/web/GrowthTimelineScreen").then((module) => ({ default: module.GrowthTimelineScreen })));
const GrowthStageDetail = lazy(() => import("./components/web/GrowthStageDetail").then((module) => ({ default: module.GrowthStageDetail })));
const WebFridgeScreen = lazy(() => import("./components/web/WebFridgeScreen").then((module) => ({ default: module.WebFridgeScreen })));
const StrollerGuideScreen = lazy(() => import("./components/web/StrollerGuideScreen").then((module) => ({ default: module.StrollerGuideScreen })));
const SubscriptionScreen = lazy(() => import("./components/web/SubscriptionScreen").then((module) => ({ default: module.SubscriptionScreen })));
const TabooScreen = lazy(() => import("./components/web/TabooScreen").then((module) => ({ default: module.TabooScreen })));
const DischargeChecklistScreen = lazy(() => import("./components/web/DischargeChecklistScreen").then((module) => ({ default: module.DischargeChecklistScreen })));
const WebAdminScreen = lazy(() => import("./components/web/WebAdminScreen").then((module) => ({ default: module.WebAdminScreen })));
const WebLegalScreen = lazy(() => import("./components/web/WebLegalScreen").then((module) => ({ default: module.WebLegalScreen })));

type Screen = "home" | "urgent" | "shopping" | "tips" | "article" | "forum" | "routines" | "tracker" | "reminders" | "saved" | "profile" | "growth-timeline" | "growth-stage" | "recommendations" | "fridge" | "stroller-guide" | "subscription" | "taboo" | "discharge-checklist" | "admin" | "privacy" | "terms";

const screenToPath: Record<Screen, string> = {
  home: "/",
  urgent: "/urgent",
  shopping: "/shopping",
  tips: "/tips",
  article: "/tips/article",
  forum: "/forum",
  routines: "/routines",
  tracker: "/tracker",
  reminders: "/reminders",
  saved: "/saved",
  profile: "/profile",
  "growth-timeline": "/growth",
  "growth-stage": "/growth/stage",
  recommendations: "/recommendations",
  fridge: "/fridge",
  "stroller-guide": "/stroller-guide",
  subscription: "/subscription",
  taboo: "/taboo",
  "discharge-checklist": "/discharge-checklist",
  admin: "/admin",
  privacy: "/privacy",
  terms: "/terms",
};

const pathToScreen = Object.fromEntries(
  Object.entries(screenToPath).map(([screen, path]) => [path, screen])
) as Record<string, Screen>;

function getScreenFromPath(pathname: string): Screen {
  const normalizedPath = pathname.replace(/\/+$/, "") || "/";
  return pathToScreen[normalizedPath] ?? "home";
}

function LoadingPanel({ label = "Открываем раздел..." }: { label?: string }) {
  return (
    <div className="p-4 md:p-8">
      <div className="rounded-3xl border border-border bg-card p-6 text-muted-foreground">
        <div className="mb-4 h-3 w-32 rounded-full bg-secondary" />
        <div className="mb-3 h-8 max-w-md rounded-2xl bg-secondary" />
        <div className="grid gap-3 md:grid-cols-3">
          <div className="h-24 rounded-2xl bg-secondary/70" />
          <div className="h-24 rounded-2xl bg-secondary/70" />
          <div className="h-24 rounded-2xl bg-secondary/70" />
        </div>
        <div className="mt-4 text-sm">{label}</div>
      </div>
    </div>
  );
}

function ServerIssueScreen({
  message,
  onRetry,
  onLogout,
}: {
  message: string;
  onRetry: () => void;
  onLogout: () => void;
}) {
  return (
    <div className="min-h-screen p-4 flex items-center justify-center bg-background">
      <div className="w-full max-w-xl rounded-3xl border border-border bg-card p-6 md:p-8 shadow-xl">
        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
          <AlertCircle className="h-7 w-7" />
        </div>
        <h1 className="mb-3 text-2xl md:text-3xl font-medium text-foreground">Сервер не отвечает</h1>
        <p className="mb-5 text-sm md:text-base leading-relaxed text-muted-foreground">
          {message || "Не получилось проверить аккаунт. Данные не удалены, можно повторить подключение."}
        </p>
        <div className="rounded-2xl border border-border bg-secondary/50 p-4 text-sm text-muted-foreground">
          Запустите локальный сервер из папки проекта командой <span className="font-medium text-foreground">npm.cmd run server</span>, затем нажмите “Повторить”.
        </div>
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Button onClick={onRetry} className="h-12 rounded-2xl sm:flex-1">
            <RefreshCw className="mr-2 h-4 w-4" />
            Повторить
          </Button>
          <Button onClick={onLogout} variant="outline" className="h-12 rounded-2xl sm:flex-1">
            <LogOut className="mr-2 h-4 w-4" />
            Выйти
          </Button>
        </div>
      </div>
    </div>
  );
}

interface ScreenErrorBoundaryProps {
  children: ReactNode;
  screen: string;
  onRecover: () => void;
}

interface ScreenErrorBoundaryState {
  hasError: boolean;
}

class ScreenErrorBoundary extends Component<ScreenErrorBoundaryProps, ScreenErrorBoundaryState> {
  state: ScreenErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: Error) {
    trackError(error, {
      screen: this.props.screen,
      source: "screen_boundary",
    });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 md:p-8">
          <div className="rounded-3xl border border-border bg-card p-6 md:p-8">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
              <AlertCircle className="h-6 w-6" />
            </div>
            <h2 className="mb-2 text-2xl font-medium text-foreground">Раздел не открылся</h2>
            <p className="mb-5 text-sm text-muted-foreground">
              Приложение осталось на месте. Вернемся на главную, а проблемный экран можно проверить отдельно.
            </p>
            <Button
              onClick={() => {
                this.setState({ hasError: false });
                this.props.onRecover();
              }}
              className="h-11 rounded-2xl"
            >
              На главную
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>(() =>
    getScreenFromPath(window.location.pathname)
  );
  const [isLoading, setIsLoading] = useState(true);
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => getStoredSession());
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [authBootError, setAuthBootError] = useState("");
  const [authRetryKey, setAuthRetryKey] = useState(0);
  const [isBabyOnboarded, setIsBabyOnboarded] = useLocalStorageState(BABY_ONBOARDING_STORAGE_KEY, false);

  const navigateTo = useCallback((screen: string) => {
    const nextScreen = screen in screenToPath ? (screen as Screen) : "home";
    const nextPath = screenToPath[nextScreen];

    if (window.location.pathname !== nextPath) {
      window.history.pushState(null, "", nextPath);
    }

    setCurrentScreen(nextScreen);
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 900);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      document.documentElement.classList.add("dark");
    }
  }, []);

  useEffect(() => {
    installAnalyticsErrorTracking(() => currentScreen);
  }, [currentScreen]);

  useEffect(() => {
    const storedSession = getStoredSession();
    setAuthBootError("");

    if (!storedSession) {
      setIsAuthReady(true);
      return;
    }

    let isCancelled = false;

    getCurrentAccount(storedSession.token)
      .then((response) => {
        if (isCancelled) return;

        const nextSession = { token: storedSession.token, user: response.user };
        saveStoredSession(nextSession);
        hydrateLocalAppStorage(response.storage || {});
        setAuthSession(nextSession);
        setIsBabyOnboarded(JSON.parse(window.localStorage.getItem(BABY_ONBOARDING_STORAGE_KEY) || "false"));
      })
      .catch((error) => {
        if (isCancelled) return;

        const message =
          error instanceof Error
            ? error.message
            : "Не получилось проверить аккаунт. Проверьте локальный сервер.";

        if (message.includes("Нужно войти")) {
          clearStoredSession();
          setAuthSession(null);
        } else {
          setAuthSession(storedSession);
          setAuthBootError(message);
        }
      })
      .finally(() => {
        if (!isCancelled) {
          setIsAuthReady(true);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [authRetryKey, setIsBabyOnboarded]);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentScreen(getScreenFromPath(window.location.pathname));
    };

    window.addEventListener("popstate", handlePopState);
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  useEffect(() => {
    if (!authSession || !isBabyOnboarded || !isAuthReady || isLoading) return;

    trackScreenView(currentScreen);
  }, [authSession, currentScreen, isAuthReady, isBabyOnboarded, isLoading]);

  useEffect(() => {
    if (!authSession) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        flushCurrentScreenTime();
        void flushAnalytics();
      }
    };
    const handleBeforeUnload = () => {
      flushCurrentScreenTime();
      void flushAnalytics();
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      flushCurrentScreenTime();
      void flushAnalytics();
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [authSession]);

  const handleAuth = (session: AuthSession) => {
    setAuthSession(session);
    setIsBabyOnboarded(JSON.parse(window.localStorage.getItem(BABY_ONBOARDING_STORAGE_KEY) || "false"));
    navigateTo("home");
  };

  const handleBabyOnboardingComplete = (profile: BabyProfile, goals: ParentGoalId[]) => {
    try {
      setAppStorageItem(BABY_PROFILE_STORAGE_KEY, profile);
      setAppStorageItem(PARENT_GOALS_STORAGE_KEY, goals);
      setAppStorageItem(BABY_ONBOARDING_STORAGE_KEY, true);
    } catch {
      // Local persistence should never block entry into the MVP.
    }

    setIsBabyOnboarded(true);
    trackEvent("onboarding_completed", {
      meta: {
        stage: profile.stage,
        goalsCount: goals.length,
      },
      immediate: true,
    });
    navigateTo("home");
  };

  const handleLogout = () => {
    const token = authSession?.token;

    trackEvent("auth_logout", {
      screen: currentScreen,
      immediate: true,
    });

    if (token) {
      void logoutAccount(token).catch(() => undefined);
    }

    clearStoredSession();
    setAuthSession(null);
    setAuthBootError("");
    navigateTo("home");
    notifySuccess("Вы вышли из аккаунта");
  };

  const handleRetryAuthCheck = () => {
    setIsAuthReady(false);
    setAuthRetryKey((value) => value + 1);
  };
  const isLegalScreen = currentScreen === "privacy" || currentScreen === "terms";
  const legalScreenType = currentScreen === "terms" ? "terms" : "privacy";

  return (
    <div className="size-full bg-background">
      <Toaster position="top-center" richColors closeButton />
      {/* Splash Screen */}
      <AnimatePresence>
        {isLoading && <SplashScreen />}
      </AnimatePresence>

      {!isAuthReady ? (
        <div className="min-h-screen flex items-center justify-center text-muted-foreground">
          Проверяем аккаунт...
        </div>
      ) : authBootError && authSession ? (
        <ServerIssueScreen
          message={authBootError}
          onRetry={handleRetryAuthCheck}
          onLogout={handleLogout}
        />
      ) : !authSession && isLegalScreen ? (
        <Suspense fallback={<LoadingPanel label="Открываем правила beta..." />}>
          <WebLegalScreen type={legalScreenType} onNavigate={navigateTo} />
        </Suspense>
      ) : !authSession ? (
        <AuthScreen onAuth={handleAuth} onNavigate={navigateTo} />
      ) : !isBabyOnboarded ? (
        <BabyOnboardingScreen
          onComplete={handleBabyOnboardingComplete}
          onLogout={handleLogout}
        />
      ) : (
        <>
          <Sidebar activeScreen={currentScreen} onNavigate={navigateTo} />
          <TopBar onProfileClick={() => navigateTo("profile")} onNavigate={navigateTo} />
          <MobileBottomNav activeScreen={currentScreen} onNavigate={navigateTo} />

      <main className="md:ml-[280px] min-h-screen pt-16 md:pt-20 pb-20 md:pb-0">
        <BetaPrivacyBanner hidden={isLegalScreen} onNavigate={navigateTo} />
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15, ease: "easeInOut" }}
          >
            <ScreenErrorBoundary key={currentScreen} screen={currentScreen} onRecover={() => navigateTo("home")}>
              <Suspense fallback={<LoadingPanel />}>
                {currentScreen === "home" && <WebHomeScreen onNavigate={navigateTo} />}
                {currentScreen === "shopping" && <WebShoppingScreen />}
                {currentScreen === "tracker" && <WebTrackerScreen onNavigate={navigateTo} />}
                {currentScreen === "tips" && <WebTipsScreen onArticleClick={() => navigateTo("article")} />}
                {currentScreen === "article" && <WebArticleScreen onBack={() => navigateTo("tips")} />}
                {currentScreen === "forum" && <WebForumScreen onNavigate={navigateTo} />}
                {currentScreen === "growth-timeline" && (
                  <GrowthTimelineScreen onStageClick={() => navigateTo("growth-stage")} />
                )}
                {currentScreen === "growth-stage" && (
                  <GrowthStageDetail onBack={() => navigateTo("growth-timeline")} />
                )}
                {currentScreen === "recommendations" && <WebRecommendationsScreen onNavigate={navigateTo} />}
                {currentScreen === "fridge" && <WebFridgeScreen />}
                {currentScreen === "stroller-guide" && <StrollerGuideScreen />}
                {currentScreen === "urgent" && <WebUrgentScreen />}
                {currentScreen === "routines" && <WebRoutinesScreen onNavigate={navigateTo} />}
                {currentScreen === "reminders" && <WebRemindersScreen />}
                {currentScreen === "saved" && <WebSavedScreen />}
                {currentScreen === "profile" && <WebProfileScreen onLogout={handleLogout} onNavigate={navigateTo} />}
                {currentScreen === "admin" && <WebAdminScreen />}
                {currentScreen === "privacy" && <WebLegalScreen type="privacy" onNavigate={navigateTo} />}
                {currentScreen === "terms" && <WebLegalScreen type="terms" onNavigate={navigateTo} />}
                {currentScreen === "subscription" && <SubscriptionScreen onClose={() => navigateTo("home")} />}
                {currentScreen === "taboo" && <TabooScreen onClose={() => navigateTo("home")} />}
                {currentScreen === "discharge-checklist" && <DischargeChecklistScreen onClose={() => navigateTo("home")} />}
              </Suspense>
            </ScreenErrorBoundary>
          </motion.div>
        </AnimatePresence>
      </main>
        </>
      )}
    </div>
  );
}

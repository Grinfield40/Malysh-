import { copyFile, mkdir, readdir, stat, unlink } from "node:fs/promises";
import { existsSync } from "node:fs";
import { basename, dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { loadEnvFile } from "./env.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));
loadEnvFile(join(__dirname, "..", ".env"));

const dataDir = process.env.MALYSH_DATA_DIR || join(__dirname, "data");
const dbFile = process.env.MALYSH_DB_FILE || join(dataDir, "app.db");
const backupDir = process.env.MALYSH_BACKUP_DIR || join(__dirname, "backups");
const requestedBackup = process.argv[2] || "latest";

try {
  await mkdir(dataDir, { recursive: true });
  await mkdir(backupDir, { recursive: true });

  const backupFile = await resolveBackupFile(requestedBackup);

  assertDbFile(backupFile);
  await verifySqliteDatabase(backupFile);
  await createPreRestoreCopy();
  await copyFile(backupFile, dbFile);
  await removeWalFiles();

  console.log(`Database restored from: ${backupFile}`);
  console.log(`Active DB: ${dbFile}`);
  console.log("Start the local server again after restore.");
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exitCode = 1;
}

async function resolveBackupFile(value) {
  if (value !== "latest") {
    return resolve(process.cwd(), value);
  }

  const files = await readdir(backupDir);
  const candidates = await Promise.all(
    files
      .filter((fileName) => fileName.endsWith(".db"))
      .map(async (fileName) => {
        const filePath = join(backupDir, fileName);
        const info = await stat(filePath);

        return { filePath, mtime: info.mtime.getTime() };
      })
  );

  const latest = candidates.sort((a, b) => b.mtime - a.mtime)[0];

  if (!latest) {
    throw new Error(`No .db backups found in ${backupDir}. Run npm.cmd run backup first.`);
  }

  return latest.filePath;
}

function assertDbFile(filePath) {
  if (!existsSync(filePath)) {
    throw new Error(`Backup file not found: ${filePath}`);
  }

  if (extname(filePath).toLowerCase() !== ".db") {
    throw new Error("Restore source must be a .db file.");
  }
}

async function verifySqliteDatabase(filePath) {
  const db = new DatabaseSync(filePath, { readOnly: true });
  const result = db.prepare("PRAGMA integrity_check").get();

  db.close();

  if (result.integrity_check !== "ok") {
    throw new Error(`Backup failed integrity check: ${result.integrity_check}`);
  }
}

async function createPreRestoreCopy() {
  if (!existsSync(dbFile)) return;

  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const preRestoreFile = join(backupDir, `pre-restore-${stamp}-${basename(dbFile)}`);

  await copyFile(dbFile, preRestoreFile);
  console.log(`Current DB copied before restore: ${preRestoreFile}`);
}

async function removeWalFiles() {
  await Promise.all([
    unlink(`${dbFile}-wal`).catch(() => undefined),
    unlink(`${dbFile}-shm`).catch(() => undefined),
  ]);
}

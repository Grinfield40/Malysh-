import { motion } from "motion/react";
import { type AuthUser } from "../../lib/accountApi";
import {
  isNavigationItemActive,
  mobileAdminNavigationItem,
  mobilePrimaryNavigation,
} from "../../lib/navigation";

interface MobileBottomNavProps {
  activeScreen: string;
  onNavigate: (screen: string) => void;
  isAuthenticated?: boolean;
  currentUser?: AuthUser | null;
}

export function MobileBottomNav({ activeScreen, onNavigate, isAuthenticated = true, currentUser }: MobileBottomNavProps) {
  const isAdmin = isAuthenticated && currentUser?.role === "admin";
  const visibleItems = isAdmin
    ? [
        ...mobilePrimaryNavigation.slice(0, 4),
        mobileAdminNavigationItem,
        mobilePrimaryNavigation[4],
      ]
    : mobilePrimaryNavigation;

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t-2 border-primary/10 shadow-2xl"
    >
      <div className={`grid ${isAdmin ? "grid-cols-6 px-1" : "grid-cols-5 px-2"} py-3 safe-bottom`}>
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = isNavigationItemActive(activeScreen, item.id);

          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-center gap-1 px-1 py-2 rounded-2xl transition-all relative"
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <Icon
                className={`w-6 h-6 relative z-10 transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              />
              <span
                className={`${isAdmin ? "text-[9px]" : "text-[10px]"} font-medium relative z-10 transition-colors ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
              >
                {item.label}
              </span>
            </motion.button>
          );
        })}
      </div>
    </motion.nav>
  );
}

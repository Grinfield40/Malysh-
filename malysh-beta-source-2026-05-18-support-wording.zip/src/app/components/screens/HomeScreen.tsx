import { Search, AlertCircle, ShoppingBag, BookOpen, Clock, Bookmark } from "lucide-react";
import { Input } from "../ui/input";

interface HomeScreenProps {
  onNavigate: (screen: string) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const quickActions = [
    { id: "urgent", label: "Срочный вопрос", icon: AlertCircle, color: "bg-destructive" },
    { id: "shopping", label: "Что купить", icon: ShoppingBag, color: "bg-primary" },
    { id: "tips", label: "Советы на сегодня", icon: BookOpen, color: "bg-accent" },
    { id: "routine", label: "Режим дня", icon: Clock, color: "bg-[#A4B5A8]" },
  ];

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="px-6 pt-8 pb-6 bg-gradient-to-b from-secondary/50 to-transparent">
        <h2 className="text-2xl font-medium text-foreground mb-1">Добрый день!</h2>
        <p className="text-muted-foreground">Чем можем помочь сегодня?</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 pb-24">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Что вас беспокоит?"
              className="h-12 pl-12 rounded-2xl bg-card border-border"
            />
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <h3 className="text-base font-medium mb-4">Быстрые действия</h3>
            <div className="grid grid-cols-2 gap-3">
              {quickActions.map((action) => (
                <button
                  key={action.id}
                  onClick={() => {
                    if (action.id === "shopping") onNavigate("shopping");
                    else if (action.id === "tips") onNavigate("tips");
                    else if (action.id === "urgent") onNavigate("urgent");
                    else if (action.id === "routine") onNavigate("routines");
                  }}
                  className="h-28 rounded-2xl bg-card border border-border p-4 flex flex-col items-start justify-between hover:border-primary/30 transition-all"
                >
                  <div className={`w-10 h-10 rounded-xl ${action.color} flex items-center justify-center text-white`}>
                    <action.icon className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{action.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-base font-medium mb-4">Совет дня</h3>
            <div className="rounded-2xl bg-gradient-to-br from-primary/10 to-accent/10 p-5 border border-primary/20">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center">
                  <span className="text-xl">💡</span>
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-foreground mb-1">Контакт кожа к коже</h4>
                  <p className="text-sm text-muted-foreground">
                    В первые дни жизни это помогает малышу чувствовать себя в безопасности
                  </p>
                </div>
              </div>
              <button className="text-sm text-primary font-medium">Узнать больше →</button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-medium">Недавно просмотренное</h3>
              <button className="text-sm text-primary">Все</button>
            </div>
            <div className="space-y-3">
              {[
                { title: "Когда обращаться к врачу", time: "5 мин", category: "Здоровье" },
                { title: "Первая аптечка для малыша", time: "3 мин", category: "Покупки" },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => onNavigate("article")}
                  className="w-full rounded-xl bg-card border border-border p-4 flex items-center gap-4 hover:border-primary/30 transition-all"
                >
                  <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
                    <Bookmark className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 text-left">
                    <h4 className="text-sm font-medium text-foreground mb-1">{item.title}</h4>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{item.category}</span>
                      <span>•</span>
                      <span>{item.time}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

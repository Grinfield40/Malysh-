import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cookie, ShieldCheck } from "lucide-react";
import { Button } from "../ui/button";
import {
  COOKIE_CONSENT_EVENT,
  readCookieConsent,
  saveCookieConsent,
  type CookieConsentChoice,
  type CookieConsentRecord,
} from "../../lib/cookieConsent";

interface CookieConsentBannerProps {
  hidden?: boolean;
  onNavigate: (screen: string) => void;
}

export function CookieConsentBanner({ hidden = false, onNavigate }: CookieConsentBannerProps) {
  const [consent, setConsent] = useState<CookieConsentRecord | null>(() => readCookieConsent());

  useEffect(() => {
    const handleConsentChange = (event: Event) => {
      setConsent((event as CustomEvent<CookieConsentRecord>).detail || readCookieConsent());
    };

    window.addEventListener(COOKIE_CONSENT_EVENT, handleConsentChange);

    return () => window.removeEventListener(COOKIE_CONSENT_EVENT, handleConsentChange);
  }, []);

  const chooseConsent = (choice: CookieConsentChoice) => {
    setConsent(saveCookieConsent(choice));
  };

  return (
    <AnimatePresence>
      {!hidden && !consent ? (
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 18 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          className="fixed inset-x-3 bottom-20 z-[90] md:inset-x-6 md:bottom-6"
        >
          <div className="mx-auto max-w-5xl rounded-2xl border border-border bg-card/95 p-3 shadow-2xl backdrop-blur md:p-4">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div className="flex gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <Cookie className="h-5 w-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2 text-sm font-medium text-foreground md:text-base">
                    <ShieldCheck className="h-4 w-4 text-primary" />
                    Cookies и локальное хранение
                  </div>
                  <p className="mt-1 max-w-3xl text-xs leading-relaxed text-muted-foreground md:text-sm">
                    Мы используем необходимые данные для входа и сохранения настроек. Дополнительная аналитика помогает улучшать beta-версию.
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate("privacy")}
                    className="mt-1 text-xs font-medium text-primary hover:underline md:text-sm"
                  >
                    Подробнее о данных
                  </button>
                </div>
              </div>

              <div className="grid shrink-0 grid-cols-2 gap-2 md:flex md:items-center">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => chooseConsent("necessary")}
                  className="h-10 rounded-xl px-3 text-xs md:px-4 md:text-sm"
                >
                  Только необходимые
                </Button>
                <Button
                  type="button"
                  onClick={() => chooseConsent("all")}
                  className="h-10 rounded-xl px-3 text-xs md:px-4 md:text-sm"
                >
                  Согласиться
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

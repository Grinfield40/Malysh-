import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Database,
  FileText,
  ShieldCheck,
  UserCheck,
} from "lucide-react";
import { Button } from "../ui/button";

type LegalScreenType = "privacy" | "terms";

interface WebLegalScreenProps {
  type: LegalScreenType;
  onNavigate: (screen: string) => void;
}

const privacySections = [
  {
    icon: Database,
    title: "Что сохраняется",
    text:
      "Аккаунт, профиль ребенка, дневник, режим дня, напоминания, форум, сохраненные товары и продуктовая аналитика по разделам.",
  },
  {
    icon: ShieldCheck,
    title: "Где это хранится",
    text:
      "В beta-версии данные лежат в SQLite-базе на локальном сервере проекта или на будущей VPS. Резервные копии делает владелец проекта.",
  },
  {
    icon: AlertTriangle,
    title: "Что не вводить",
    text:
      "Диагнозы, результаты анализов, документы, адреса, телефоны третьих лиц, платежные данные и любую информацию, которую нельзя безопасно показывать администратору beta.",
  },
  {
    icon: UserCheck,
    title: "Удаление и выгрузка",
    text:
      "На первом beta-этапе выгрузка, backup и удаление данных выполняются через администратора. Отдельный пользовательский экран добавим позже.",
  },
];

const termsSections = [
  {
    icon: FileText,
    title: "Это ранняя beta",
    text:
      "Некоторые разделы еще работают как заготовки, а интерфейс и структура данных могут меняться до публичного запуска.",
  },
  {
    icon: AlertTriangle,
    title: "Не медицинская консультация",
    text:
      "Подсказки, форум и рекомендации помогают ориентироваться в бытовых сценариях, но не ставят диагнозы и не заменяют врача.",
  },
  {
    icon: ShieldCheck,
    title: "Доступ и модерация",
    text:
      "Форум модерируется администратором. Спам, личные контакты, агрессия и опасные советы могут быть скрыты или удалены.",
  },
  {
    icon: CheckCircle2,
    title: "Заглушки и ограничения",
    text:
      "Платежи, партнерские ссылки, часть рекомендаций и публичный личный кабинет пока не подключены. В приложении они помечены как beta или в разработке.",
  },
];

export function WebLegalScreen({ type, onNavigate }: WebLegalScreenProps) {
  const isPrivacy = type === "privacy";
  const sections = isPrivacy ? privacySections : termsSections;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fbf8ff] via-white to-[#f7f3ff] px-4 py-6 md:px-8 md:py-10">
      <div className="mx-auto max-w-6xl">
        <Button
          type="button"
          variant="ghost"
          className="mb-6 h-11 rounded-2xl px-4 text-[#7c6fb0] hover:bg-[#f1ecff]"
          onClick={() => onNavigate("home")}
        >
          <ArrowLeft size={18} />
          На главную
        </Button>

        <header className="rounded-[2rem] border border-[#ebe4f7] bg-white p-6 shadow-sm md:p-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div>
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-3xl bg-[#f1ecff] text-[#9b83db]">
                {isPrivacy ? <ShieldCheck size={28} /> : <FileText size={28} />}
              </div>
              <h1 className="text-4xl font-semibold leading-tight text-[#332c4f] md:text-5xl">
                {isPrivacy ? "Приватность beta" : "Условия beta"}
              </h1>
              <p className="mt-4 max-w-3xl text-lg leading-relaxed text-[#7c6fb0]">
                {isPrivacy
                  ? "Коротко и честно: какие данные нужны приложению, где они живут и чего пока лучше не вводить."
                  : "Правила раннего тестирования: что уже работает, где есть ограничения и как безопасно пользоваться продуктом."}
              </p>
            </div>

            <div className="rounded-[1.5rem] border border-amber-200 bg-amber-50 p-4 text-amber-900 md:max-w-sm">
              <div className="mb-2 flex items-center gap-2 font-semibold">
                <AlertTriangle size={18} />
                Важно
              </div>
              <p className="text-sm leading-relaxed">
                Не вводите чувствительные медицинские данные. При тревожных симптомах обращайтесь к врачу
                или в экстренные службы.
              </p>
            </div>
          </div>
        </header>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <article key={section.title} className="rounded-[1.5rem] border border-[#ebe4f7] bg-white p-5 shadow-sm">
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f6f1ff] text-[#9b83db]">
                  <Icon size={22} />
                </div>
                <h2 className="text-xl font-semibold text-[#332c4f]">{section.title}</h2>
                <p className="mt-2 text-base leading-relaxed text-[#7c6fb0]">{section.text}</p>
              </article>
            );
          })}
        </div>

        <div className="mt-6 flex flex-col gap-3 rounded-[1.5rem] border border-[#ebe4f7] bg-white p-5 shadow-sm md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="text-xl font-semibold text-[#332c4f]">
              {isPrivacy ? "Нужны условия beta?" : "Нужна политика приватности?"}
            </h2>
            <p className="mt-1 text-[#7c6fb0]">
              Оба документа доступны внутри приложения и будут обновляться перед закрытым тестом.
            </p>
          </div>
          <Button
            type="button"
            className="h-12 rounded-2xl bg-[#9b83db] px-5 text-white hover:bg-[#8c75cf]"
            onClick={() => onNavigate(isPrivacy ? "terms" : "privacy")}
          >
            {isPrivacy ? "Открыть условия" : "Открыть приватность"}
          </Button>
        </div>
      </div>
    </div>
  );
}

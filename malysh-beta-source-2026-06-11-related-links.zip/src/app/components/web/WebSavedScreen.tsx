import { motion } from "motion/react";
import { ArrowRight, BookOpen, Bookmark, Heart, MessageSquare, ShoppingBag } from "lucide-react";
import { useState } from "react";
import type { ReactNode } from "react";
import { Button } from "../ui/button";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { recommendationProducts } from "./WebRecommendationsScreen";
import {
  SAVED_ARTICLES_STORAGE_KEY,
  SAVED_FORUM_POSTS_STORAGE_KEY,
  SavedArticleItem,
  SavedForumPostItem,
} from "../../lib/savedItems";

const tabs = ["Статьи", "Обсуждения", "Товары"] as const;

type SavedTab = (typeof tabs)[number];

interface WebSavedScreenProps {
  onNavigate?: (screen: string) => void;
}

function SavedEmptyState({
  icon,
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: string;
  title: string;
  description: string;
  actionLabel: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-2xl border border-dashed border-primary/25 bg-card px-5 py-10 text-center shadow-sm md:py-14">
      <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-3xl md:h-16 md:w-16 md:text-4xl">
        {icon}
      </div>
      <h3 className="mb-2 text-lg font-medium text-foreground md:text-xl">{title}</h3>
      <p className="mx-auto mb-5 max-w-md text-sm leading-relaxed text-muted-foreground">{description}</p>
      <Button type="button" onClick={onAction} className="h-10 rounded-xl">
        {actionLabel}
        <ArrowRight className="h-4 w-4" />
      </Button>
    </div>
  );
}

function SavedTypeBadge({
  icon,
  label,
}: {
  icon: ReactNode;
  label: string;
}) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-2.5 py-1 text-[11px] font-medium text-primary">
      {icon}
      {label}
    </span>
  );
}

export function WebSavedScreen({ onNavigate }: WebSavedScreenProps) {
  const [activeTab, setActiveTab] = useState<SavedTab>("Статьи");
  const [savedArticles] = useLocalStorageState<SavedArticleItem[]>(SAVED_ARTICLES_STORAGE_KEY, []);
  const [savedForumPosts] = useLocalStorageState<SavedForumPostItem[]>(SAVED_FORUM_POSTS_STORAGE_KEY, []);
  const [savedProductIds] = useLocalStorageState<number[]>("mvp.recommendations.saved", []);
  const savedProducts = recommendationProducts.filter((product) => savedProductIds.includes(product.id));
  const counts: Record<SavedTab, number> = {
    Статьи: savedArticles.length,
    Обсуждения: savedForumPosts.length,
    Товары: savedProducts.length,
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <div className="mb-3 flex items-center gap-3">
          <Bookmark className="h-7 w-7 text-primary" />
          <h1 className="text-2xl font-medium text-foreground md:text-4xl">Сохраненное</h1>
        </div>
        <p className="text-sm text-muted-foreground md:text-lg">
          Материалы и товары, к которым хочется вернуться позже.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4 pb-2 md:mx-0 md:mb-8 md:px-0"
      >
        {tabs.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition-all md:rounded-2xl md:px-6 md:py-3 ${
              activeTab === tab
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:border-primary/30"
            }`}
          >
            {tab}
            {counts[tab] > 0 ? (
              <span className="ml-2 rounded-full bg-background/70 px-2 py-0.5 text-[11px] text-foreground">
                {counts[tab]}
              </span>
            ) : null}
          </button>
        ))}
      </motion.div>

      {activeTab === "Статьи" && (
        savedArticles.length === 0 ? (
          <SavedEmptyState
            icon="📚"
            title="Сохраненных статей пока нет"
            description="Откройте советы и сохраните материал, который хочется прочитать позже или показать близким."
            actionLabel="Открыть советы"
            onAction={() => onNavigate?.("tips")}
          />
        ) : (
          <div className="space-y-4">
            <div className="rounded-2xl border border-primary/15 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено статей: {savedArticles.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Материалы, к которым можно спокойно вернуться, когда будет время.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("tips")} className="rounded-xl">
                  Открыть советы
                </Button>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {savedArticles.map((article, index) => (
                <motion.button
                  key={article.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("tips")}
                  className="rounded-2xl border border-border bg-card p-4 text-left shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <SavedTypeBadge icon={<BookOpen className="h-3.5 w-3.5" />} label="Статья" />
                    <span className="text-xs text-muted-foreground">{article.time}</span>
                  </div>
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-secondary text-2xl">
                      {article.emoji}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-foreground">{article.title}</div>
                      <div className="text-xs text-muted-foreground">{article.category}</div>
                    </div>
                  </div>
                  <p className="line-clamp-2 text-sm text-muted-foreground">{article.description}</p>
                  <div className="mt-4 flex items-center justify-between border-t border-border pt-3 text-xs font-medium text-primary">
                    <span>Открыть источник</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}

      {activeTab === "Обсуждения" && (
        savedForumPosts.length === 0 ? (
          <SavedEmptyState
            icon="💬"
            title="Сохраненных обсуждений пока нет"
            description="Сохраните полезную тему на форуме, чтобы вернуться к ответам без повторного поиска."
            actionLabel="Открыть форум"
            onAction={() => onNavigate?.("forum")}
          />
        ) : (
          <div className="space-y-4">
            <div className="rounded-2xl border border-primary/15 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено обсуждений: {savedForumPosts.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Важные темы форума остаются под рукой и не теряются в ленте.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("forum")} className="rounded-xl">
                  Открыть форум
                </Button>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {savedForumPosts.map((post, index) => (
                <motion.button
                  key={post.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("forum")}
                  className="rounded-2xl border border-border bg-card p-4 text-left shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <SavedTypeBadge icon={<MessageSquare className="h-3.5 w-3.5" />} label="Обсуждение" />
                    <Bookmark className="h-5 w-5 flex-shrink-0 fill-primary text-primary" />
                  </div>
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-medium text-foreground">{post.title}</div>
                        <div className="text-xs text-muted-foreground">{post.category} · {post.author}</div>
                      </div>
                    </div>
                  </div>
                  <p className="line-clamp-2 text-sm text-muted-foreground">{post.preview}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs">
                    <span className="text-muted-foreground">{post.comments} ответов · {post.views} просмотров</span>
                    <span className="inline-flex items-center gap-1 font-medium text-primary">
                      Открыть источник
                      <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}

      {activeTab === "Товары" && (
        savedProducts.length === 0 ? (
          <SavedEmptyState
            icon="💜"
            title="Сохраненных товаров пока нет"
            description="Отмечайте сердечком товары из подборки, чтобы спокойно сравнить их перед покупкой."
            actionLabel="Открыть подборки"
            onAction={() => onNavigate?.("recommendations")}
          />
        ) : (
          <div className="space-y-4">
            <div className="rounded-2xl border border-primary/15 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено товаров: {savedProducts.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Это товары, отмеченные сердечком. Их удобно сравнить перед покупкой позже.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("recommendations")} className="rounded-xl">
                  Открыть подборки
                </Button>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {savedProducts.map((product, index) => (
                <motion.button
                  key={product.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("recommendations")}
                  className="rounded-2xl border border-border bg-card p-4 text-left shadow-sm transition-all hover:border-primary/30 hover:shadow-md"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <SavedTypeBadge icon={<ShoppingBag className="h-3.5 w-3.5" />} label="Товар" />
                    <Heart className="h-5 w-5 flex-shrink-0 fill-primary text-primary" />
                  </div>
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10">
                        <ShoppingBag className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-medium text-foreground">{product.name}</div>
                        <div className="text-xs text-muted-foreground">{product.category}</div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-3 border-t border-border pt-3">
                    <span className="text-sm font-medium text-foreground">{product.price}</span>
                    <span className="inline-flex items-center gap-1 text-xs font-medium text-primary">
                      Открыть источник
                      <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}
    </div>
  );
}

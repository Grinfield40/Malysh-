import { motion } from "motion/react";
import { ArrowLeft, AlertCircle, CheckCircle, Heart, Lightbulb } from "lucide-react";
import { Button } from "../ui/button";
import { getGrowthStageById } from "../../lib/growthStages";

interface GrowthStageDetailProps {
  stageId?: string;
  onBack: () => void;
}

export function GrowthStageDetail({ stageId, onBack }: GrowthStageDetailProps) {
  const stage = getGrowthStageById(stageId);
  const tips = [
    {
      icon: Heart,
      title: "Наблюдайте без гонки",
      text: `Этап «${stage.title}» — ориентир, а не экзамен. Смотрите на общее состояние, настроение и постепенное движение вперед.`,
    },
    {
      icon: Lightbulb,
      title: "Давайте короткие игры",
      text: "Лучше несколько спокойных подходов в течение дня, чем одна длинная и утомительная активность.",
    },
    {
      icon: CheckCircle,
      title: "Записывайте заметки",
      text: "Если навык появился, исчез или вызывает вопросы, добавьте заметку в дневник. Так легче обсудить развитие с врачом.",
    },
  ];
  const warnings = [
    "Резкая потеря уже освоенного навыка",
    "Малыш не реагирует на голос, прикосновения или привычные стимулы",
    "Есть судороги, выраженная вялость или необычное дыхание",
    "Вы чувствуете, что состояние ребенка заметно изменилось",
  ];

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-8 max-w-[1200px] mx-auto">
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBack}
        className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 md:mb-8 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span>К этапам развития</span>
      </motion.button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`bg-gradient-to-br ${stage.color} dark:from-primary/20 dark:to-accent/20 rounded-3xl p-5 md:p-12 mb-8 border-2 border-white/50 dark:border-primary/30`}
      >
        <div className="flex flex-col md:flex-row md:items-center gap-6 md:gap-12">
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="relative mx-auto md:mx-0"
          >
            <div className="w-32 h-32 md:w-48 md:h-48 bg-white/80 dark:bg-card rounded-full flex items-center justify-center text-6xl md:text-8xl shadow-2xl">
              {stage.emoji}
            </div>
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -top-3 -right-3 md:-top-4 md:-right-4 w-12 h-12 md:w-16 md:h-16 bg-accent/30 rounded-full backdrop-blur-sm flex items-center justify-center text-2xl md:text-3xl"
            >
              ✦
            </motion.div>
          </motion.div>

          <div className="flex-1 text-center md:text-left">
            <div className="inline-block px-4 py-2 bg-primary/20 text-primary rounded-full text-sm font-medium mb-4">
              {stage.age}
            </div>
            <h1 className="text-3xl md:text-5xl font-medium text-foreground mb-4">
              {stage.title}
            </h1>
            <p className="text-base md:text-xl text-muted-foreground leading-relaxed">
              {stage.description}
            </p>
          </div>
        </div>
      </motion.div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
          >
            <h2 className="text-2xl font-medium text-foreground mb-6">Что обычно появляется</h2>
            <div className="space-y-3">
              {stage.skills.map((skill, index) => (
                <motion.div
                  key={skill}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.35 + index * 0.08 }}
                  className="flex items-start gap-4 bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-all"
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-foreground flex-1">{skill}</span>
                </motion.div>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h2 className="text-2xl font-medium text-foreground mb-6">Советы</h2>
            <div className="space-y-4">
              {tips.map((tip, index) => {
                const Icon = tip.icon;

                return (
                  <motion.div
                    key={tip.title}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 + index * 0.08 }}
                    whileHover={{ y: -4 }}
                    className="bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/20 rounded-2xl p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-white/80 dark:bg-card rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-foreground mb-2">{tip.title}</h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">{tip.text}</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.section>
        </div>

        <motion.aside
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.45 }}
          className="space-y-6"
        >
          <div className="bg-gradient-to-br from-destructive/10 to-destructive/5 border-2 border-destructive/20 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-white/80 dark:bg-card rounded-xl flex items-center justify-center shadow-lg">
                <AlertCircle className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="font-medium text-foreground">Когда к врачу</h3>
            </div>
            <ul className="space-y-2">
              {warnings.map((warning) => (
                <li key={warning} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-destructive mt-1">•</span>
                  <span>{warning}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 pt-6 border-t border-destructive/20">
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Если что-то беспокоит, лучше обсудить это со специалистом. Этот раздел помогает ориентироваться, но не заменяет врача.
              </p>
              <Button className="w-full rounded-2xl bg-primary hover:bg-primary/90">
                Добавить вопрос в заметки
              </Button>
            </div>
          </div>

          <div className="bg-gradient-to-br from-accent/20 to-primary/20 border-2 border-accent/30 rounded-2xl p-6">
            <div className="text-center">
              <div className="text-4xl mb-4">💜</div>
              <h3 className="font-medium text-foreground mb-2">Вы справляетесь</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Развитие не идет по линейке. Важнее спокойное наблюдение, регулярные осмотры и бережный контакт.
              </p>
            </div>
          </div>
        </motion.aside>
      </div>
    </div>
  );
}

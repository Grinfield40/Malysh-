import { motion } from "motion/react";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Crown,
  Lock,
  NotebookText,
  Pencil,
  Plus,
  Trash2,
  TrendingUp,
} from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { useEffect, useState } from "react";
import { AddTrackerModal, TrackerEntry } from "./AddTrackerModal";
import { EditDiaryEntryModal } from "./EditDiaryEntryModal";
import { ConfirmActionDialog } from "./ConfirmActionDialog";
import { PremiumBadge } from "../PremiumBadge";
import { CareFlowStrip } from "./CareFlowStrip";
import { useBabyProfile } from "../../lib/babyProfile";
import {
  addDaysToDateKey,
  CareDiaryEntry,
  formatDateLabel,
  getCareDiarySummary,
  getCareEntriesForDate,
  getCategoryByFilter,
  getDiaryWeekDays,
  getTodayKey,
  TRACKER_QUICK_ENTRY_STORAGE_KEY,
  trackerFilterTypes,
  trackerToCareDiaryEntry,
  useCareDiary,
} from "../../lib/careDiary";
import { trackEvent } from "../../lib/analytics";
import { notifySuccess } from "../../lib/notify";

function getEntryAccent(entry: CareDiaryEntry) {
  const accents: Record<string, string> = {
    feeding: "bg-primary/10 text-primary border-primary/20",
    sleep: "bg-accent/10 text-accent-foreground border-accent/20",
    diaper: "bg-secondary text-foreground border-border",
    temperature: "bg-destructive/10 text-destructive border-destructive/20",
    note: "bg-muted text-foreground border-border",
  };

  return accents[entry.category] ?? "bg-secondary text-foreground border-border";
}

interface WebTrackerScreenProps {
  onNavigate: (screen: string) => void;
}

export function WebTrackerScreen({ onNavigate }: WebTrackerScreenProps) {
  const [entries, setEntries] = useCareDiary();
  const todayKey = getTodayKey();
  const [selectedDate, setSelectedDate] = useState(todayKey);
  const [activeType, setActiveType] = useState("Все");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [initialTrackerType, setInitialTrackerType] = useState<TrackerEntry["type"] | null>(null);
  const [editingEntry, setEditingEntry] = useState<CareDiaryEntry | null>(null);
  const [entryToDelete, setEntryToDelete] = useState<CareDiaryEntry | null>(null);
  const { baby, age } = useBabyProfile();

  const selectedEntries = getCareEntriesForDate(entries, selectedDate, todayKey);
  const summary = getCareDiarySummary(selectedEntries);
  const activeCategory = getCategoryByFilter(activeType);
  const filteredEntries =
    activeCategory === "all"
      ? selectedEntries
      : selectedEntries.filter((entry) => entry.category === activeCategory);
  const weekDays = getDiaryWeekDays(entries, selectedDate);
  const selectedDateLabel = formatDateLabel(selectedDate, todayKey);
  const selectedDateTitle = selectedDateLabel.toLowerCase();
  const routineLinkedCount = selectedEntries.filter((entry) => entry.source === "routine").length;
  const maxWeekEntries = Math.max(...weekDays.map((day) => day.summary.total), 1);
  const hasActiveFilter = activeCategory !== "all";
  const emptyTitle =
    selectedEntries.length === 0
      ? "В этот день записей нет"
      : `Нет записей: ${activeType.toLowerCase()}`;
  const emptyDescription =
    selectedEntries.length === 0
      ? `Добавьте сон, кормление, подгузник, температуру или заметку для ${baby.name}.`
      : "За выбранный день записи есть, но они скрыты текущим фильтром.";

  const handleAddEntry = (entry: TrackerEntry) => {
    const nextEntry = trackerToCareDiaryEntry(entry);

    setEntries((prev) => [nextEntry, ...prev]);
    trackEvent("tracker_entry_added", {
      screen: "tracker",
      meta: {
        category: nextEntry.category,
        source: nextEntry.source || "manual",
      },
    });
    notifySuccess("Запись добавлена", {
      description: "Дневник и сводка дня обновлены.",
    });
  };

  const handleSaveEntry = (entry: CareDiaryEntry) => {
    setEntries((prev) => prev.map((item) => (item.id === entry.id ? entry : item)));
    setSelectedDate(entry.date || selectedDate);
    setEditingEntry(null);
    trackEvent("tracker_entry_edited", {
      screen: "tracker",
      meta: {
        category: entry.category,
      },
    });
    notifySuccess("Изменения сохранены", {
      description: "Запись обновлена в ленте и сводке дня.",
    });
  };

  const handleDeleteEntry = (entryId: number) => {
    const deletedEntry = entries.find((entry) => entry.id === entryId);

    setEntries((prev) => prev.filter((entry) => entry.id !== entryId));
    setEntryToDelete(null);
    trackEvent("tracker_entry_deleted", {
      screen: "tracker",
      meta: {
        category: deletedEntry?.category,
      },
    });
    notifySuccess("Запись удалена");
  };

  const summaryCards = [
    { label: "Кормлений", value: summary.feeding, icon: "🍼" },
    { label: "Снов", value: summary.sleep, icon: "💤" },
    { label: "Сон всего", value: summary.totalSleepLabel, icon: "🌙" },
    { label: "Подгузников", value: summary.diaper, icon: "🧷" },
  ];
  const quickEntryTypes: Array<{ type: TrackerEntry["type"]; label: string; icon: string; hint: string }> = [
    { type: "feeding", label: "Кормление", icon: "🍼", hint: "грудь, бутылочка, прикорм" },
    { type: "sleep", label: "Сон", icon: "💤", hint: "длительность и качество" },
    { type: "diaper", label: "Подгузник", icon: "🧷", hint: "мокрый, грязный или оба" },
    { type: "temperature", label: "Температура", icon: "🌡️", hint: "значение в градусах" },
  ];

  const openAddEntry = (type: TrackerEntry["type"] | null = null) => {
    setInitialTrackerType(type);
    setIsModalOpen(true);
  };

  useEffect(() => {
    try {
      const storedType = window.localStorage.getItem(TRACKER_QUICK_ENTRY_STORAGE_KEY);
      const requestedType = storedType ? (JSON.parse(storedType) as TrackerEntry["type"]) : null;
      const quickTypes: TrackerEntry["type"][] = ["feeding", "sleep", "diaper", "temperature"];

      if (requestedType && quickTypes.includes(requestedType)) {
        window.localStorage.removeItem(TRACKER_QUICK_ENTRY_STORAGE_KEY);
        openAddEntry(requestedType);
      }
    } catch {
      try {
        window.localStorage.removeItem(TRACKER_QUICK_ENTRY_STORAGE_KEY);
      } catch {
        // Ignore storage cleanup errors.
      }
    }
  }, []);

  return (
    <div className="relative p-4 pb-24 md:p-8 md:pb-8 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4 md:mb-6"
      >
        <div>
          <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-1 md:mb-2">Дневник ухода</h1>
          <p className="text-base md:text-lg text-muted-foreground">
            История сна, кормления и наблюдений для {baby.name}: {age.label}
          </p>
        </div>
        <Button
          onClick={() => openAddEntry()}
          className="hidden h-12 w-full justify-center rounded-xl bg-primary px-6 text-primary-foreground hover:bg-primary/90 sm:w-auto md:flex md:min-w-[190px]"
        >
          <Plus className="w-5 h-5 mr-2" />
          Добавить запись
        </Button>
      </motion.div>

      <div className="hidden md:block">
        <CareFlowStrip active="tracker" onNavigate={onNavigate} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.04 }}
        className="mb-4 rounded-xl border border-border bg-card p-3 md:hidden"
      >
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h2 className="text-base font-medium text-foreground">Быстро записать</h2>
            <p className="text-xs text-muted-foreground">Одно касание, детали можно уточнить дальше</p>
          </div>
          <Button type="button" variant="outline" onClick={() => openAddEntry()} className="h-9 rounded-xl px-3 text-xs">
            Еще
          </Button>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {quickEntryTypes.map((item) => (
            <button
              key={item.type}
              type="button"
              onClick={() => openAddEntry(item.type)}
              className="flex min-h-[82px] items-center gap-3 rounded-xl border border-border bg-secondary/45 px-3 py-3 text-left transition-colors hover:border-primary/30 hover:bg-primary/5"
            >
              <div className="text-2xl leading-none">{item.icon}</div>
              <div>
                <div className="text-sm font-medium leading-tight text-foreground">{item.label}</div>
                <div className="mt-1 line-clamp-1 text-[11px] leading-tight text-muted-foreground">{item.hint}</div>
              </div>
            </button>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.05 }}
        className="mb-4 md:mb-6 bg-card border border-border rounded-xl p-4 md:p-5"
      >
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
          <div>
            <div className="text-sm text-muted-foreground mb-1">{age.stageLabel}</div>
            <p className="text-base md:text-lg text-foreground">
              {selectedDateLabel}: {summary.total} записей. Сейчас важно отслеживать {age.focus}.
            </p>
          </div>
          <div className="rounded-xl bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            {routineLinkedCount > 0 ? `${routineLinkedCount} из режима` : "Режим связан с дневником"}
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 md:gap-6">
        <div className="lg:col-span-2 space-y-4 md:space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.08 }}
            className="bg-card border border-border rounded-xl p-3 md:p-5"
          >
            <div className="flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <CalendarDays className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h2 className="font-medium text-foreground">История дней</h2>
                  <p className="hidden text-sm text-muted-foreground sm:block">Выберите дату и смотрите дневник как архив</p>
                </div>
              </div>

              <div className="grid grid-cols-[40px_minmax(0,1fr)_40px] gap-2 sm:flex sm:flex-wrap sm:items-center">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedDate((date) => addDaysToDateKey(date, -1));
                    trackEvent("tracker_date_changed", {
                      screen: "tracker",
                      meta: { direction: "previous" },
                    });
                  }}
                  aria-label="Предыдущий день"
                  className="w-10 h-10 rounded-xl border border-border bg-background hover:border-primary/30 flex items-center justify-center transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(event) => {
                    setSelectedDate(event.target.value || todayKey);
                    trackEvent("tracker_date_changed", {
                      screen: "tracker",
                      meta: { direction: "picker" },
                    });
                  }}
                  className="h-10 w-full rounded-xl sm:w-[155px]"
                />
                <button
                  type="button"
                  onClick={() => {
                    setSelectedDate((date) => addDaysToDateKey(date, 1));
                    trackEvent("tracker_date_changed", {
                      screen: "tracker",
                      meta: { direction: "next" },
                    });
                  }}
                  aria-label="Следующий день"
                  className="w-10 h-10 rounded-xl border border-border bg-background hover:border-primary/30 flex items-center justify-center transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedDate(todayKey);
                    trackEvent("tracker_date_changed", {
                      screen: "tracker",
                      meta: { direction: "today" },
                    });
                  }}
                  className="col-span-3 h-10 rounded-xl sm:col-auto"
                >
                  Сегодня
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-1 sm:gap-2">
              {weekDays.map((day) => {
                const isSelected = day.dateKey === selectedDate;
                const barHeight = Math.max(10, Math.round((day.summary.total / maxWeekEntries) * 100));

                return (
                  <button
                    key={day.dateKey}
                    type="button"
                    onClick={() => {
                      setSelectedDate(day.dateKey);
                      trackEvent("tracker_date_changed", {
                        screen: "tracker",
                        meta: { direction: "week_day" },
                      });
                    }}
                    className={`min-h-16 rounded-xl border p-1.5 text-center transition-all sm:min-h-24 sm:p-2 ${
                      isSelected
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background border-border hover:border-primary/30"
                    }`}
                  >
                    <div className={`text-[10px] uppercase ${isSelected ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                      {day.weekday}
                    </div>
                    <div className="text-base font-medium">{day.day}</div>
                    <div className="h-5 mt-1 flex items-end justify-center sm:h-8 sm:mt-2">
                      <div
                        className={`w-3 rounded-full ${isSelected ? "bg-white/80" : "bg-primary/30"}`}
                        style={{ height: `${barHeight}%` }}
                      />
                    </div>
                    <div className={`text-[10px] mt-1 ${isSelected ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                      {day.summary.total}
                    </div>
                  </button>
                );
              })}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="grid grid-cols-2 gap-2 md:gap-3 xl:grid-cols-4"
          >
            {summaryCards.map((card) => (
              <div key={card.label} className="bg-card border border-border rounded-xl p-3 md:p-4">
                <div className="flex items-center justify-between gap-2 mb-2 md:mb-3">
                  <span className="text-xs text-muted-foreground md:text-sm">{card.label}</span>
                  <span className="text-xl md:text-2xl">{card.icon}</span>
                </div>
                <div className="text-xl font-medium text-foreground md:text-2xl">{card.value}</div>
              </div>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:gap-3 sm:overflow-visible sm:px-0 sm:pb-0"
          >
            {trackerFilterTypes.map((type) => (
              <button
                key={type}
                onClick={() => {
                  setActiveType(type);
                  trackEvent("tracker_filter_changed", {
                    screen: "tracker",
                    meta: { filter: type },
                  });
                }}
                className={`px-4 py-2.5 rounded-xl whitespace-nowrap text-sm font-medium transition-all border sm:px-5 sm:py-3 ${
                  activeType === type
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card text-foreground border-border hover:border-primary/30"
                }`}
              >
                {type}
              </button>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex flex-col gap-2 mb-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-lg font-medium text-foreground md:text-xl">Лента за {selectedDateTitle}</h2>
                <p className="hidden text-sm text-muted-foreground sm:block">Факты из трекера и режима идут в одну историю дня</p>
              </div>
              <span className="text-sm text-muted-foreground">{filteredEntries.length} записей</span>
            </div>

            {filteredEntries.length === 0 ? (
              <div className="text-center py-10 md:py-14 bg-secondary/30 border-2 border-dashed border-border rounded-xl">
                <div className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-card border border-border flex items-center justify-center">
                  <NotebookText className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-lg font-medium text-foreground mb-2">{emptyTitle}</h3>
                <p className="mx-auto max-w-md text-sm text-muted-foreground mb-5">
                  {emptyDescription}
                </p>
                <div className="flex flex-col justify-center gap-2 sm:flex-row">
                  {hasActiveFilter && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveType("Все")}
                      className="w-full rounded-xl sm:w-auto"
                    >
                      Показать все записи
                    </Button>
                  )}
                  <Button onClick={() => openAddEntry()} className="w-full rounded-xl sm:w-auto">
                    Добавить запись
                  </Button>
                </div>
                {selectedEntries.length === 0 && (
                  <div className="mx-auto mt-5 grid max-w-xl grid-cols-2 gap-2 sm:grid-cols-4">
                    {quickEntryTypes.map((item) => (
                      <button
                        key={item.type}
                        type="button"
                        onClick={() => openAddEntry(item.type)}
                        className="rounded-xl border border-border bg-card px-3 py-3 text-center transition-colors hover:border-primary/30"
                      >
                        <div className="text-2xl">{item.icon}</div>
                        <div className="mt-1 text-xs font-medium text-foreground">{item.label}</div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="relative space-y-3 md:space-y-4">
                <div className="hidden sm:block absolute left-5 top-5 bottom-5 w-px bg-border" />
                {filteredEntries.map((entry, idx) => (
                  <motion.div
                    key={entry.id ?? `${entry.time}-${idx}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.25 + idx * 0.04 }}
                    className="relative flex gap-3 md:gap-4"
                  >
                    <div className={`hidden sm:flex w-10 h-10 rounded-full border items-center justify-center text-xl shrink-0 z-10 ${getEntryAccent(entry)}`}>
                      {entry.icon}
                    </div>
                    <div className="flex-1 bg-card border border-border rounded-xl p-3 md:p-5 hover:border-primary/30 transition-all">
                      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-2 md:mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`sm:hidden w-10 h-10 rounded-full border flex items-center justify-center text-xl ${getEntryAccent(entry)}`}>
                            {entry.icon}
                          </div>
                          <div>
                            <h4 className="font-medium text-foreground">{entry.type}</h4>
                            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                              <Clock3 className="w-3.5 h-3.5" />
                              {entry.time}
                            </div>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-2">
                          {entry.source === "routine" && (
                            <span className="w-fit rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                              из режима
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={() => setEditingEntry(entry)}
                            aria-label={`Редактировать запись ${entry.type}`}
                            className="w-8 h-8 rounded-lg border border-border bg-background/70 text-muted-foreground hover:text-primary hover:border-primary/30 transition-colors flex items-center justify-center"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setEntryToDelete(entry)}
                            aria-label={`Удалить запись ${entry.type}`}
                            className="w-8 h-8 rounded-lg border border-border bg-background/70 text-muted-foreground hover:text-destructive hover:border-destructive/30 transition-colors flex items-center justify-center"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{entry.details}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="hidden space-y-4 md:space-y-6 lg:block"
        >
          <div className="bg-card border border-border rounded-2xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-5">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Что было: {selectedDateTitle}</h3>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Последняя запись</span>
                <span className="text-sm font-medium text-foreground">{summary.lastEntry?.time ?? "—"}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Температура</span>
                <span className="text-sm font-medium text-foreground">{summary.temperature}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Заметок</span>
                <span className="text-sm font-medium text-foreground">{summary.notes}</span>
              </div>
              <div className="rounded-xl bg-secondary/60 p-4">
                <div className="text-xs font-medium text-primary mb-1">Сводка</div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {summary.total > 0
                    ? `${summary.feeding} кормлений, ${summary.sleep} сна, ${summary.diaper} смен подгузника.`
                    : `Пока нет фактов за этот день. Можно добавить запись задним числом.`}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-4 md:p-6">
            <div className="flex items-center gap-2 mb-5">
              <CalendarDays className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Мини-неделя</h3>
            </div>
            <div className="h-28 flex items-end gap-2">
              {weekDays.map((day) => {
                const height = Math.max(8, Math.round((day.summary.total / maxWeekEntries) * 100));
                const isSelected = day.dateKey === selectedDate;

                return (
                  <button
                    key={day.dateKey}
                    type="button"
                    onClick={() => {
                      setSelectedDate(day.dateKey);
                      trackEvent("tracker_date_changed", {
                        screen: "tracker",
                        meta: { direction: "mini_week" },
                      });
                    }}
                    className="flex-1 h-full flex flex-col items-center justify-end gap-2"
                    aria-label={`Открыть ${day.label}`}
                  >
                    <div
                      className={`w-full max-w-8 rounded-t-lg transition-all ${
                        isSelected ? "bg-primary" : "bg-primary/25 hover:bg-primary/40"
                      }`}
                      style={{ height: `${height}%` }}
                    />
                    <div className="text-[10px] text-muted-foreground">{day.day}</div>
                  </button>
                );
              })}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-secondary/60 p-3">
                <div className="text-lg font-medium text-foreground">
                  {weekDays.reduce((sum, day) => sum + day.summary.feeding, 0)}
                </div>
                <div className="text-xs text-muted-foreground">кормлений</div>
              </div>
              <div className="rounded-xl bg-secondary/60 p-3">
                <div className="text-lg font-medium text-foreground">
                  {weekDays.reduce((sum, day) => sum + day.summary.sleep, 0)}
                </div>
                <div className="text-xs text-muted-foreground">сна</div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-2xl p-4 md:p-6">
            <h3 className="font-medium text-foreground mb-4">Быстро добавить</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                ...quickEntryTypes,
                { icon: "📝", label: "Заметка", type: "note" as TrackerEntry["type"], hint: "важное наблюдение" },
              ].map((item) => (
                <button
                  key={item.label}
                  onClick={() => openAddEntry(item.type)}
                  className="bg-white rounded-xl p-3 hover:bg-card transition-all border border-border hover:border-primary/30 flex flex-col items-center gap-2"
                >
                  <span className="text-2xl">{item.icon}</span>
                  <span className="text-xs font-medium text-foreground">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5 border border-primary/20 rounded-2xl p-4 pt-12 md:p-6 relative overflow-hidden">
            <div className="absolute top-3 right-3">
              <PremiumBadge showText size="sm" />
            </div>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-5 h-5 text-primary" />
              <h3 className="font-medium text-foreground">Аналитика и графики</h3>
            </div>
            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
              Расширенная история, сравнение недель и поиск закономерностей для {baby.name}
            </p>
            <div className="bg-card/50 rounded-xl p-4 mb-4 backdrop-blur-sm border border-border/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground">Средняя продолжительность сна</span>
                <Lock className="w-4 h-4 text-muted-foreground/50" />
              </div>
              <div className="h-20 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg flex items-end justify-around p-2 gap-1">
                {[60, 75, 45, 80, 70, 85, 65].map((height, i) => (
                  <div key={i} className="flex-1 bg-primary/20 rounded-t" style={{ height: `${height}%` }} />
                ))}
              </div>
            </div>
            <Button
              type="button"
              onClick={() => onNavigate("subscription")}
              className="w-full rounded-xl bg-gradient-to-r from-primary to-accent text-white hover:opacity-90"
            >
              <Crown className="w-4 h-4 mr-2" />
              Посмотреть план Премиум
            </Button>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6">
            <h3 className="font-medium text-foreground mb-3">Совет</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Записи можно добавлять задним числом, редактировать и смотреть по дням. Так дневник становится историей, а не только списком за сегодня.
            </p>
          </div>
        </motion.div>
      </div>

      <button
        type="button"
        onClick={() => openAddEntry()}
        className="fixed bottom-24 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/25 md:hidden"
        aria-label="Добавить запись"
      >
        <Plus className="h-6 w-6" />
      </button>

      <AddTrackerModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddEntry}
        defaultDate={selectedDate}
        initialType={initialTrackerType}
      />
      <EditDiaryEntryModal
        isOpen={Boolean(editingEntry)}
        entry={editingEntry}
        onClose={() => setEditingEntry(null)}
        onSave={handleSaveEntry}
      />
      <ConfirmActionDialog
        open={Boolean(entryToDelete)}
        onOpenChange={(open) => {
          if (!open) setEntryToDelete(null);
        }}
        title="Удалить запись?"
        description="Эта запись исчезнет из дневника, истории дня и сводки. Действие нельзя отменить."
        confirmLabel="Удалить"
        destructive
        onConfirm={() => {
          if (entryToDelete) {
            handleDeleteEntry(entryToDelete.id);
          }
        }}
      />
    </div>
  );
}

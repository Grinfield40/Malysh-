import { Button } from "../ui/button";
import { ChevronLeft } from "lucide-react";
import { useState } from "react";

interface OnboardingInterestsScreenProps {
  onComplete: () => void;
  onBack: () => void;
}

const interests = [
  { id: "sleep", label: "Сон", icon: "🌙" },
  { id: "feeding", label: "Кормление", icon: "🍼" },
  { id: "health", label: "Здоровье", icon: "💊" },
  { id: "shopping", label: "Покупки", icon: "🛒" },
  { id: "development", label: "Развитие", icon: "🧸" },
  { id: "anxiety", label: "Тревожные вопросы", icon: "💭" },
  { id: "routine", label: "Режим дня", icon: "⏰" },
  { id: "recovery", label: "Восстановление мамы", icon: "💆‍♀️" },
];

export function OnboardingInterestsScreen({ onComplete, onBack }: OnboardingInterestsScreenProps) {
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const toggleInterest = (id: string) => {
    setSelectedInterests(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      <div className="p-4">
        <button onClick={onBack} className="p-2 -ml-2">
          <ChevronLeft className="w-6 h-6 text-foreground" />
        </button>
      </div>

      <div className="flex-1 px-6 flex flex-col overflow-y-auto">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-1 flex-1 bg-primary rounded-full"></div>
            <div className="h-1 flex-1 bg-primary rounded-full"></div>
          </div>
          <h1 className="text-3xl font-medium text-foreground mb-2">Что вас интересует?</h1>
          <p className="text-muted-foreground">Выберите несколько тем</p>
        </div>

        <div className="grid grid-cols-2 gap-3 pb-6">
          {interests.map((interest) => (
            <button
              key={interest.id}
              onClick={() => toggleInterest(interest.id)}
              className={`rounded-2xl border-2 transition-all p-4 flex flex-col items-center justify-center gap-3 h-28 ${
                selectedInterests.includes(interest.id)
                  ? "border-primary bg-primary/5"
                  : "border-border bg-card"
              }`}
            >
              <span className="text-3xl">{interest.icon}</span>
              <span className="text-sm font-medium text-foreground text-center leading-tight">
                {interest.label}
              </span>
            </button>
          ))}
        </div>

        <div className="mt-auto py-8 sticky bottom-0 bg-background">
          <Button
            onClick={onComplete}
            disabled={selectedInterests.length === 0}
            className="w-full h-14 rounded-2xl bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            Готово
          </Button>
        </div>
      </div>
    </div>
  );
}

import { Plus } from "lucide-react";
import { Button } from "../ui/button";
import { useState } from "react";

const trackerTypes = ["Кормление", "Сон", "Подгузники", "Температура"];

const recentEntries = [
  { id: 1, type: "Кормление", time: "14:30", details: "Левая грудь, 15 мин", icon: "🍼" },
  { id: 2, type: "Подгузники", time: "13:45", details: "Мокрый", icon: "🧷" },
  { id: 3, type: "Сон", time: "11:00 - 13:00", details: "2 часа", icon: "💤" },
  { id: 4, type: "Кормление", time: "10:30", details: "Правая грудь, 20 мин", icon: "🍼" },
  { id: 5, type: "Температура", time: "09:00", details: "36.6°C", icon: "🌡️" },
  { id: 6, type: "Сон", time: "07:30 - 09:00", details: "1.5 часа", icon: "💤" },
];

export function TrackerScreen() {
  const [activeType, setActiveType] = useState("Кормление");

  const filteredEntries = activeType === "Кормление"
    ? recentEntries
    : recentEntries.filter(e => e.type === activeType);

  return (
    <div className="h-screen bg-background flex flex-col overflow-y-auto pb-24">
      <div className="px-6 pt-8 pb-4 bg-gradient-to-b from-secondary/50 to-transparent sticky top-0 z-10 backdrop-blur-sm">
        <h1 className="text-2xl font-medium text-foreground mb-2">Трекер</h1>
        <p className="text-sm text-muted-foreground mb-4">Отслеживайте заботу о малыше</p>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {trackerTypes.map((type) => (
            <button
              key={type}
              onClick={() => setActiveType(type)}
              className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-all ${
                activeType === type
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground border border-border"
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      <div className="px-6 py-4">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-medium text-foreground">Сегодня</h3>
          <span className="text-sm text-muted-foreground">{filteredEntries.length} записей</span>
        </div>

        <div className="space-y-3">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              className="rounded-xl bg-card border border-border p-4 flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center text-2xl flex-shrink-0">
                {entry.icon}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium text-foreground">{entry.type}</h4>
                  <span className="text-xs text-muted-foreground">{entry.time}</span>
                </div>
                <p className="text-sm text-muted-foreground">{entry.details}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="fixed bottom-24 right-6">
        <Button
          size="lg"
          className="h-14 w-14 rounded-full bg-primary text-primary-foreground shadow-lg hover:bg-primary/90"
        >
          <Plus className="w-6 h-6" />
        </Button>
      </div>
    </div>
  );
}

import { motion } from "motion/react";
import { ArrowRight } from "lucide-react";
import { Logo } from "../Logo";
import { growthStages } from "../../lib/growthStages";

interface GrowthTimelineScreenProps {
  onStageClick?: (stageId: string) => void;
}

export function GrowthTimelineScreen({ onStageClick }: GrowthTimelineScreenProps) {
  return (
    <div className="p-4 md:p-8 pt-20 md:pt-8 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8 md:mb-16"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="inline-block mb-4 md:mb-6 bg-white/80 rounded-2xl md:rounded-3xl p-3 md:p-4 shadow-lg"
        >
          <Logo size={64} />
        </motion.div>
        <h1 className="text-2xl md:text-5xl font-medium text-foreground mb-3 md:mb-4 px-4">
          Развитие малыша
        </h1>
        <p className="text-sm md:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
          Следите за ростом и развитием ребенка от первых дней до четырех лет
        </p>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 inline-block bg-gradient-to-r from-primary/10 to-accent/10 border-2 border-primary/20 rounded-full px-6 py-2"
        >
          <span className="text-sm md:text-base font-medium text-foreground">
            {growthStages.length} этапов развития
          </span>
        </motion.div>
      </motion.div>

      <div className="relative">
        <div className="absolute left-6 md:left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary/20 via-accent/20 to-primary/20 md:-translate-x-1/2 rounded-full" />

        <div className="space-y-8 md:space-y-12">
          {growthStages.map((stage, index) => {
            const isLeft = index % 2 === 0;

            return (
              <motion.div
                key={stage.id}
                initial={{ opacity: 0, x: isLeft ? -50 : 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.04, duration: 0.45 }}
                className="relative"
              >
                <div className="md:hidden pl-14">
                  <motion.button
                    type="button"
                    whileTap={{ scale: 0.98 }}
                    onClick={() => onStageClick?.(stage.id)}
                    className="block w-full cursor-pointer text-left"
                  >
                    <StageCard stage={stage} compact />
                  </motion.button>
                  <div className="absolute left-6 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-gradient-to-br from-primary to-accent rounded-full border-2 border-white shadow-lg z-10" />
                </div>

                <div className={`hidden md:flex items-center ${isLeft ? "justify-start" : "justify-end"}`}>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.03, y: -6 }}
                    onClick={() => onStageClick?.(stage.id)}
                    className={`w-[48%] cursor-pointer text-left ${isLeft ? "mr-auto" : "ml-auto"}`}
                  >
                    <StageCard stage={stage} />
                  </motion.button>

                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: index * 0.04 + 0.2 }}
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 bg-gradient-to-br from-primary to-accent rounded-full border-4 border-white shadow-lg z-10"
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-12 md:mt-20 text-center"
      >
        <div className="bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-2xl md:rounded-3xl p-6 md:p-12 max-w-3xl mx-auto">
          <h3 className="text-lg md:text-2xl font-medium text-foreground mb-3 md:mb-4">
            Каждый ребенок развивается в своем темпе
          </h3>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            Это примерные ориентиры. Если что-то тревожит, лучше спокойно обсудить это с педиатром.
          </p>
        </div>
      </motion.div>
    </div>
  );
}

function StageCard({
  stage,
  compact = false,
}: {
  stage: (typeof growthStages)[number];
  compact?: boolean;
}) {
  return (
    <div className={`bg-gradient-to-br ${stage.color} dark:from-primary/20 dark:to-accent/20 backdrop-blur-sm border-2 border-white/50 dark:border-primary/30 rounded-2xl md:rounded-3xl ${compact ? "p-4" : "p-8"} shadow-lg md:shadow-xl transition-all hover:shadow-2xl`}>
      <div className={`flex items-start ${compact ? "gap-3 mb-3" : "gap-6 mb-5"}`}>
        <div className={`${compact ? "w-14 h-14 text-3xl rounded-xl" : "w-20 h-20 text-5xl rounded-2xl"} bg-white/80 dark:bg-card flex items-center justify-center flex-shrink-0 shadow-lg`}>
          {stage.emoji}
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs md:text-sm font-medium text-primary mb-1 md:mb-2">{stage.age}</div>
          <h3 className={`${compact ? "text-base" : "text-2xl"} font-medium text-foreground mb-1 md:mb-3`}>
            {stage.title}
          </h3>
          <p className={`${compact ? "text-xs line-clamp-2" : "text-base"} text-muted-foreground leading-relaxed`}>
            {stage.description}
          </p>
        </div>
      </div>

      <div className={`${compact ? "mb-2" : "mb-4"}`}>
        {!compact && (
          <div className="text-xs font-medium text-foreground/70 mb-2">Ключевые навыки:</div>
        )}
        <div className="flex flex-wrap gap-1.5 md:gap-2">
          {stage.skills.slice(0, compact ? 2 : stage.skills.length).map((skill) => (
            <span
              key={skill}
              className="text-[10px] md:text-sm bg-white/70 dark:bg-primary/20 text-foreground px-2 md:px-3 py-1 rounded-full"
            >
              {compact ? skill : `✓ ${skill}`}
            </span>
          ))}
        </div>
      </div>

      <span className="inline-flex items-center gap-1 md:gap-2 text-xs md:text-sm font-medium text-primary">
        Подробнее
        <ArrowRight className="w-3 h-3 md:w-4 md:h-4" />
      </span>
    </div>
  );
}

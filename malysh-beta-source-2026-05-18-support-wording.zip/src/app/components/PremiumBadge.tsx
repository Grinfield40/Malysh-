import { Crown } from "lucide-react";
import { motion } from "motion/react";

interface PremiumBadgeProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
}

export function PremiumBadge({ size = "md", showText = false }: PremiumBadgeProps) {
  const sizes = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  const textSizes = {
    sm: "text-[10px]",
    md: "text-xs",
    lg: "text-sm",
  };

  const paddingSizes = {
    sm: "px-2 py-0.5",
    md: "px-2.5 py-1",
    lg: "px-3 py-1.5",
  };

  if (showText) {
    return (
      <motion.div
        whileHover={{ scale: 1.05 }}
        className={`inline-flex items-center gap-1.5 bg-gradient-to-r from-primary/20 to-accent/20 border border-primary/30 rounded-full ${paddingSizes[size]}`}
      >
        <Crown className={`${sizes[size]} text-primary`} />
        <span className={`${textSizes[size]} font-semibold text-primary`}>Премиум</span>
      </motion.div>
    );
  }

  return (
    <motion.div
      whileHover={{ scale: 1.1, rotate: 5 }}
      className="inline-flex items-center justify-center w-6 h-6 bg-gradient-to-br from-primary to-accent rounded-lg shadow-lg shadow-primary/30"
    >
      <Crown className="w-3.5 h-3.5 text-white" />
    </motion.div>
  );
}

import { motion } from "motion/react";
import { X, Check, Baby, Snowflake, Sun, CloudRain } from "lucide-react";
import { useState } from "react";

interface DischargeChecklistScreenProps {
  onClose?: () => void;
}

type Season = "winter" | "spring-autumn" | "summer";

const checklistData = {
  winter: {
    title: "Зима",
    icon: Snowflake,
    color: "from-blue-500/20 to-cyan-500/20",
    categories: [
      {
        title: "Транспорт и безопасность",
        icon: "🚗",
        items: [
          "Автокресло группы 0+ (от 0 до 13 кг)",
          "Теплый конверт или комбинезон для автокресла",
          "Одеяло для дополнительного утепления",
        ],
      },
      {
        title: "Одежда для малыша",
        icon: "👶",
        items: [
          "Боди с длинным рукавом (2-3 шт)",
          "Слип или человечек из хлопка",
          "Теплый комбинезон или конверт",
          "Шапочка тонкая хлопковая",
          "Шапка теплая зимняя",
          "Царапки (2 пары)",
          "Теплые носочки (2 пары)",
          "Пинетки или теплые ботиночки",
        ],
      },
      {
        title: "Одежда для мамы",
        icon: "👗",
        items: [
          "Удобная свободная одежда (не та, в которой приезжали)",
          "Теплая верхняя одежда",
          "Удобная обувь",
          "Прокладки послеродовые",
        ],
      },
      {
        title: "Документы",
        icon: "📄",
        items: [
          "Паспорта родителей",
          "Свидетельство о браке (если есть)",
          "Обменная карта",
          "Полис ОМС",
          "Выписка из роддома",
          "Справка о рождении ребенка",
        ],
      },
      {
        title: "Необходимые принадлежности",
        icon: "🎒",
        items: [
          "Одноразовые подгузники (размер 1 или newborn, 2-5 шт)",
          "Влажные салфетки для новорожденных",
          "Пустышка (если планируете использовать)",
          "Сумка или пакет для вещей из роддома",
        ],
      },
      {
        title: "Праздничное оформление (опционально)",
        icon: "🎈",
        items: [
          "Воздушные шары",
          "Красивый конверт для фото",
          "Лента для украшения (голубая/розовая)",
          "Табличка с именем малыша",
        ],
      },
    ],
  },
  "spring-autumn": {
    title: "Весна/Осень",
    icon: CloudRain,
    color: "from-orange-500/20 to-yellow-500/20",
    categories: [
      {
        title: "Транспорт и безопасность",
        icon: "🚗",
        items: [
          "Автокресло группы 0+ (от 0 до 13 кг)",
          "Демисезонный конверт или комбинезон",
          "Легкое одеяло или плед",
        ],
      },
      {
        title: "Одежда для малыша",
        icon: "👶",
        items: [
          "Боди с длинным рукавом (2 шт)",
          "Слип или человечек из хлопка",
          "Демисезонный комбинезон или конверт",
          "Шапочка тонкая хлопковая",
          "Шапка демисезонная",
          "Царапки (2 пары)",
          "Носочки (2 пары)",
          "Пинетки",
        ],
      },
      {
        title: "Одежда для мамы",
        icon: "👗",
        items: [
          "Удобная свободная одежда",
          "Демисезонная куртка или пальто",
          "Удобная обувь",
          "Прокладки послеродовые",
        ],
      },
      {
        title: "Документы",
        icon: "📄",
        items: [
          "Паспорта родителей",
          "Свидетельство о браке (если есть)",
          "Обменная карта",
          "Полис ОМС",
          "Выписка из роддома",
          "Справка о рождении ребенка",
        ],
      },
      {
        title: "Необходимые принадлежности",
        icon: "🎒",
        items: [
          "Одноразовые подгузники (размер 1 или newborn, 2-5 шт)",
          "Влажные салфетки для новорожденных",
          "Пустышка (если планируете использовать)",
          "Сумка или пакет для вещей из роддома",
          "Зонт (на случай дождя)",
        ],
      },
      {
        title: "Праздничное оформление (опционально)",
        icon: "🎈",
        items: [
          "Воздушные шары",
          "Красивый конверт для фото",
          "Лента для украшения (голубая/розовая)",
          "Табличка с именем малыша",
          "Букет цветов для мамы",
        ],
      },
    ],
  },
  summer: {
    title: "Лето",
    icon: Sun,
    color: "from-yellow-500/20 to-orange-500/20",
    categories: [
      {
        title: "Транспорт и безопасность",
        icon: "🚗",
        items: [
          "Автокресло группы 0+ (от 0 до 13 кг)",
          "Легкий летний конверт или плед",
          "Солнцезащитный козырек на автокресло",
        ],
      },
      {
        title: "Одежда для малыша",
        icon: "👶",
        items: [
          "Боди с коротким рукавом (2 шт)",
          "Слип или человечек из тонкого хлопка",
          "Легкий летний комбинезон или конверт",
          "Тонкая шапочка или чепчик",
          "Панамка с полями",
          "Царапки (1-2 пары)",
          "Тонкие носочки (1-2 пары)",
        ],
      },
      {
        title: "Одежда для мамы",
        icon: "👗",
        items: [
          "Легкая удобная одежда",
          "Кардиган или легкая кофта (на случай прохлады)",
          "Удобная обувь",
          "Прокладки послеродовые",
          "Солнцезащитные очки",
        ],
      },
      {
        title: "Документы",
        icon: "📄",
        items: [
          "Паспорта родителей",
          "Свидетельство о браке (если есть)",
          "Обменная карта",
          "Полис ОМС",
          "Выписка из роддома",
          "Справка о рождении ребенка",
        ],
      },
      {
        title: "Необходимые принадлежности",
        icon: "🎒",
        items: [
          "Одноразовые подгузники (размер 1 или newborn, 2-5 шт)",
          "Влажные салфетки для новорожденных",
          "Пустышка (если планируете использовать)",
          "Сумка или пакет для вещей из роддома",
          "Бутылка с водой для мамы",
        ],
      },
      {
        title: "Праздничное оформление (опционально)",
        icon: "🎈",
        items: [
          "Воздушные шары",
          "Красивый конверт для фото",
          "Лента для украшения (голубая/розовая)",
          "Табличка с именем малыша",
          "Букет цветов для мамы",
        ],
      },
    ],
  },
};

export function DischargeChecklistScreen({ onClose }: DischargeChecklistScreenProps) {
  const [selectedSeason, setSelectedSeason] = useState<Season>("winter");
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  const currentData = checklistData[selectedSeason];
  const SeasonIcon = currentData.icon;

  const toggleItem = (categoryIndex: number, itemIndex: number) => {
    const itemKey = `${selectedSeason}-${categoryIndex}-${itemIndex}`;
    const newChecked = new Set(checkedItems);
    if (newChecked.has(itemKey)) {
      newChecked.delete(itemKey);
    } else {
      newChecked.add(itemKey);
    }
    setCheckedItems(newChecked);
  };

  const isItemChecked = (categoryIndex: number, itemIndex: number) => {
    return checkedItems.has(`${selectedSeason}-${categoryIndex}-${itemIndex}`);
  };

  const getTotalItems = () => {
    return currentData.categories.reduce((sum, cat) => sum + cat.items.length, 0);
  };

  const getCheckedCount = () => {
    let count = 0;
    currentData.categories.forEach((cat, catIdx) => {
      cat.items.forEach((_, itemIdx) => {
        if (isItemChecked(catIdx, itemIdx)) count++;
      });
    });
    return count;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-accent/5 p-4 md:p-8 pt-20 md:pt-28">
      <div className="max-w-5xl mx-auto">
        {/* Close Button */}
        {onClose && (
          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={onClose}
            className="fixed top-24 right-8 w-10 h-10 rounded-full bg-card border border-border hover:bg-secondary transition-all flex items-center justify-center z-50"
          >
            <X className="w-5 h-5" />
          </motion.button>
        )}

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 md:mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
            <Baby className="w-5 h-5 text-primary" />
            <span className="text-sm font-semibold text-primary">Подготовка к выписке</span>
          </div>
          <h1 className="text-3xl md:text-5xl font-medium text-foreground mb-4">
            Что взять на выписку из роддома
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Полный список необходимых вещей для комфортной и безопасной выписки
          </p>
        </motion.div>

        {/* Season Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-8 md:mb-12"
        >
          <div className="flex items-center justify-center gap-4 flex-wrap">
            {(Object.keys(checklistData) as Season[]).map((season) => {
              const data = checklistData[season];
              const Icon = data.icon;
              const isSelected = selectedSeason === season;
              return (
                <motion.button
                  key={season}
                  onClick={() => {
                    setSelectedSeason(season);
                    setCheckedItems(new Set());
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center gap-3 px-6 py-4 rounded-2xl border-2 transition-all ${
                    isSelected
                      ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/30"
                      : "bg-card text-foreground border-border hover:border-primary/30"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-semibold">{data.title}</span>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8 bg-card border border-border rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-medium text-muted-foreground">Прогресс подготовки</span>
            <span className="text-sm font-semibold text-primary">
              {getCheckedCount()} / {getTotalItems()}
            </span>
          </div>
          <div className="w-full h-3 bg-secondary rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(getCheckedCount() / getTotalItems()) * 100}%` }}
              transition={{ duration: 0.5 }}
              className="h-full bg-gradient-to-r from-primary to-accent"
            />
          </div>
        </motion.div>

        {/* Checklist Categories */}
        <div className="space-y-6 md:space-y-8">
          {currentData.categories.map((category, categoryIdx) => (
            <motion.div
              key={categoryIdx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + categoryIdx * 0.05 }}
              className="bg-card border border-border rounded-2xl md:rounded-3xl overflow-hidden hover:border-primary/30 transition-all"
            >
              {/* Category Header */}
              <div className={`bg-gradient-to-r ${currentData.color} border-b border-border p-4 md:p-6`}>
                <div className="flex items-center gap-3 md:gap-4">
                  <div className="w-12 h-12 md:w-14 md:h-14 bg-card rounded-xl md:rounded-2xl flex items-center justify-center text-2xl md:text-3xl shadow-lg">
                    {category.icon}
                  </div>
                  <h2 className="text-xl md:text-2xl font-semibold text-foreground">{category.title}</h2>
                </div>
              </div>

              {/* Category Items */}
              <div className="p-4 md:p-6">
                <ul className="space-y-3">
                  {category.items.map((item, itemIdx) => {
                    const isChecked = isItemChecked(categoryIdx, itemIdx);
                    return (
                      <motion.li
                        key={itemIdx}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 + categoryIdx * 0.05 + itemIdx * 0.02 }}
                        onClick={() => toggleItem(categoryIdx, itemIdx)}
                        className={`flex items-center gap-3 md:gap-4 p-3 rounded-xl cursor-pointer transition-all ${
                          isChecked
                            ? "bg-primary/10 hover:bg-primary/20"
                            : "hover:bg-secondary/50"
                        }`}
                      >
                        <div
                          className={`w-6 h-6 md:w-7 md:h-7 rounded-lg border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                            isChecked
                              ? "bg-primary border-primary"
                              : "border-border hover:border-primary/50"
                          }`}
                        >
                          {isChecked && <Check className="w-4 h-4 md:w-5 md:h-5 text-white" />}
                        </div>
                        <p
                          className={`text-sm md:text-base leading-relaxed flex-1 transition-all ${
                            isChecked
                              ? "text-muted-foreground line-through"
                              : "text-foreground"
                          }`}
                        >
                          {item}
                        </p>
                      </motion.li>
                    );
                  })}
                </ul>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom Tip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-8 md:mt-12 bg-gradient-to-br from-accent/10 to-accent-soft/10 border border-accent/20 rounded-2xl md:rounded-3xl p-6 md:p-8"
        >
          <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 flex items-center gap-2">
            💡 Совет
          </h3>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            Подготовьте все вещи заранее, за 2-3 недели до предполагаемой даты родов. Соберите две сумки:
            одну с вещами для выписки (её заберет папа в день выписки), вторую — с вещами для роддома.
            Проверьте все документы и сделайте их копии на всякий случай.
          </p>
        </motion.div>
      </div>
    </div>
  );
}

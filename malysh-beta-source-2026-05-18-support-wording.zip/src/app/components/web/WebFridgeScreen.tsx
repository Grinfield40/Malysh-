import { motion } from "motion/react";
import { ImagePlus, Trash2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { ChildDrawing } from "../ChildDrawing";
import { Button } from "../ui/button";
import { ConfirmActionDialog } from "./ConfirmActionDialog";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { trackEvent } from "../../lib/analytics";
import { notifyError, notifySuccess, notifyWarning } from "../../lib/notify";

interface DrawingItem {
  id: number;
  type: "sun" | "house" | "family" | "flower" | "cat" | "rainbow" | "upload";
  x: number;
  y: number;
  rotation: number;
  magnetColor: string;
  imageSrc?: string;
  title?: string;
  uploadedAt?: string;
}

const magnetColors = ["#FF69B4", "#FFD700", "#87CEEB", "#98D8C8", "#E8B4D9", "#9B87D4", "#FFB6C1"];

const initialDrawings: DrawingItem[] = [
  { id: 1, type: "upload", x: 150, y: 150, rotation: -2, magnetColor: "#FFD700" },
  { id: 2, type: "upload", x: 400, y: 150, rotation: 1, magnetColor: "#87CEEB" },
  { id: 3, type: "upload", x: 650, y: 150, rotation: -1, magnetColor: "#FF69B4" },
  { id: 4, type: "upload", x: 150, y: 450, rotation: 2, magnetColor: "#98D8C8" },
  { id: 5, type: "upload", x: 400, y: 450, rotation: -3, magnetColor: "#E8B4D9" },
  { id: 6, type: "upload", x: 650, y: 450, rotation: 1, magnetColor: "#9B87D4" },
];

const maxFileSize = 2.5 * 1024 * 1024;
const maxTotalImageSize = 6 * 1024 * 1024;
const maxUploadedImages = 6;
const allowedImageTypes = new Set(["image/jpeg", "image/png", "image/webp"]);

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Не удалось прочитать файл"));
    reader.readAsDataURL(file);
  });
}

function getNextPosition(index: number) {
  const columns = [150, 400, 650];
  const row = Math.floor(index / columns.length);

  return {
    x: columns[index % columns.length],
    y: 150 + row * 300,
  };
}

function estimateDataUrlBytes(value?: string) {
  const match = /^data:image\/(?:jpeg|jpg|png|webp);base64,([a-z0-9+/=\s]+)$/i.exec(value || "");

  if (!match) return 0;

  const base64 = match[1].replace(/\s/g, "");
  const padding = base64.endsWith("==") ? 2 : base64.endsWith("=") ? 1 : 0;

  return Math.max(0, Math.floor((base64.length * 3) / 4) - padding);
}

export function WebFridgeScreen() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [drawings, setDrawings] = useLocalStorageState<DrawingItem[]>("mvp.fridge.drawings", initialDrawings);
  const [targetUploadId, setTargetUploadId] = useState<number | null>(null);
  const [uploadError, setUploadError] = useState("");
  const [drawingToRemove, setDrawingToRemove] = useState<DrawingItem | null>(null);

  const uploadedCount = drawings.filter((drawing) => drawing.imageSrc).length;

  const openUpload = (drawingId: number | null = null) => {
    setTargetUploadId(drawingId);
    setUploadError("");

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
      fileInputRef.current.click();
    }
  };

  const handleUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const imageFiles = Array.from(files).filter((file) => allowedImageTypes.has(file.type));

    if (imageFiles.length === 0) {
      const message = "Выберите изображение в формате JPG, PNG или WEBP.";
      setUploadError(message);
      trackEvent("fridge_upload_rejected", {
        screen: "fridge",
        meta: {
          reason: "file_type",
          files: files.length,
        },
      });
      notifyWarning(message);
      return;
    }

    const targetDrawing = targetUploadId === null ? null : drawings.find((drawing) => drawing.id === targetUploadId);
    const availableSlots = targetUploadId === null
      ? maxUploadedImages - uploadedCount
      : targetDrawing?.imageSrc
        ? 1
        : maxUploadedImages - uploadedCount;

    if (imageFiles.length > availableSlots) {
      const message = `В холодильник можно добавить до ${maxUploadedImages} картинок.`;
      setUploadError(message);
      trackEvent("fridge_upload_rejected", {
        screen: "fridge",
        meta: {
          reason: "slot_limit",
          files: imageFiles.length,
        },
      });
      notifyWarning(message);
      return;
    }

    const oversizedFile = imageFiles.find((file) => file.size > maxFileSize);
    if (oversizedFile) {
      const message = "Файл слишком большой. Для beta-версии загружайте изображения до 2.5 МБ.";
      setUploadError(message);
      trackEvent("fridge_upload_rejected", {
        screen: "fridge",
        meta: {
          reason: "file_size",
          size: oversizedFile.size,
        },
      });
      notifyWarning(message);
      return;
    }

    const existingImageBytes = drawings.reduce((total, drawing) => total + estimateDataUrlBytes(drawing.imageSrc), 0);
    const replacedImageBytes = targetDrawing?.imageSrc ? estimateDataUrlBytes(targetDrawing.imageSrc) : 0;
    const incomingImageBytes = imageFiles.reduce((total, file) => total + file.size, 0);

    if (existingImageBytes - replacedImageBytes + incomingImageBytes > maxTotalImageSize) {
      const message = "Холодильник уже почти заполнен. Уберите старые картинки или загрузите файлы поменьше.";
      setUploadError(message);
      trackEvent("fridge_upload_rejected", {
        screen: "fridge",
        meta: {
          reason: "total_size",
          incomingImageBytes,
        },
      });
      notifyWarning(message);
      return;
    }

    try {
      const uploadedItems = await Promise.all(
        imageFiles.map(async (file, index) => ({
          imageSrc: await readFileAsDataUrl(file),
          title: (file.name.replace(/\.[^.]+$/, "") || "Рисунок").slice(0, 80),
          uploadedAt: new Date().toLocaleDateString("ru-RU", {
            day: "numeric",
            month: "long",
          }),
          index,
        }))
      );

      setDrawings((prev) => {
        if (targetUploadId !== null) {
          const [firstUpload] = uploadedItems;

          return prev.map((drawing) =>
            drawing.id === targetUploadId
              ? {
                  ...drawing,
                  ...firstUpload,
                }
              : drawing
          );
        }

        const nextBaseId = Date.now();
        const firstEmptyIndex = prev.length;
        const newDrawings = uploadedItems.map((item, index) => {
          const position = getNextPosition(firstEmptyIndex + index);

          return {
            id: nextBaseId + index,
            type: "upload" as const,
            x: position.x,
            y: position.y,
            rotation: Math.random() * 6 - 3,
            magnetColor: magnetColors[(firstEmptyIndex + index) % magnetColors.length],
            imageSrc: item.imageSrc,
            title: item.title,
            uploadedAt: item.uploadedAt,
          };
        });

        return [...prev, ...newDrawings];
      });
      setTargetUploadId(null);
      setUploadError("");
      trackEvent("fridge_image_uploaded", {
        screen: "fridge",
        meta: {
          files: imageFiles.length,
          mode: targetUploadId === null ? "add" : "replace",
          incomingImageBytes,
        },
      });
      notifySuccess(imageFiles.length > 1 ? "Фотографии добавлены" : "Фотография добавлена");
    } catch {
      const message = "Не удалось загрузить изображение. Попробуйте другой файл.";
      setUploadError(message);
      notifyError(new Error(message));
    }
  };

  const removeDrawingImage = (drawingId: number) => {
    setDrawings((prev) =>
      prev.map((drawing) =>
        drawing.id === drawingId
          ? {
              ...drawing,
              imageSrc: undefined,
              title: undefined,
              uploadedAt: undefined,
            }
          : drawing
      )
    );
    setDrawingToRemove(null);
    trackEvent("fridge_image_removed", {
      screen: "fridge",
      meta: {
        drawingId,
      },
    });
    notifySuccess("Фотография убрана");
  };

  return (
    <div className="relative min-h-screen pt-20 pb-20 overflow-y-auto bg-gradient-to-b from-[#E8E8E8] to-[#D0D0D0]">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        multiple={targetUploadId === null}
        onChange={(event) => handleUpload(event.target.files)}
        className="hidden"
      />

      {/* Fridge Container */}
      <div className="relative max-w-[900px] mx-auto px-4 md:px-0">
        {/* Fridge Body */}
        <div className="relative bg-gradient-to-br from-[#F5F5F5] to-[#E0E0E0] rounded-2xl md:rounded-3xl shadow-2xl border-2 md:border-4 border-[#C0C0C0] overflow-hidden">
          {/* Fridge Handle */}
          <div className="absolute top-1/2 right-2 md:right-4 -translate-y-1/2 w-4 md:w-6 h-20 md:h-32 bg-gradient-to-r from-[#C0C0C0] to-[#A0A0A0] rounded-full shadow-lg" />

          {/* Door Separator */}
          <div className="absolute inset-x-0 top-1/3 h-1 md:h-2 bg-gradient-to-b from-[#B0B0B0] to-transparent" />

          {/* Content Area */}
          <div className="relative min-h-[800px] md:min-h-[1400px] p-6 md:p-12">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-8 md:mb-12"
            >
              <h1 className="text-2xl md:text-4xl font-medium text-foreground">
                Холодильник
              </h1>
              <p className="mt-2 text-sm md:text-base text-muted-foreground">
                {uploadedCount > 0
                  ? `${uploadedCount} фото сохранено локально`
                  : "Загрузите первые рисунки, фото или милые моменты"}
              </p>
              {uploadError && (
                <div
                  aria-live="polite"
                  className="mt-4 inline-flex rounded-xl border border-destructive/20 bg-destructive/10 px-4 py-2 text-sm text-destructive"
                >
                  {uploadError}
                </div>
              )}
            </motion.div>

            {/* Drawings */}
            <div className="relative">
              {drawings.map((drawing, idx) => (
                <motion.div
                  key={drawing.id}
                  initial={{ scale: 0, rotate: drawing.rotation - 180 }}
                  animate={{ scale: 1, rotate: drawing.rotation }}
                  transition={{ delay: idx * 0.08, type: "spring", stiffness: 200 }}
                  whileHover={{ scale: 1.05, rotate: 0, zIndex: 100 }}
                  drag
                  dragMomentum={false}
                  className="absolute cursor-move"
                  style={{
                    left: drawing.x,
                    top: drawing.y,
                  }}
                >
                  {/* Magnet */}
                  <div
                    className="absolute -top-2 md:-top-3 left-1/2 -translate-x-1/2 w-6 h-6 md:w-8 md:h-8 rounded-full shadow-lg z-10"
                    style={{
                      background: `linear-gradient(135deg, ${drawing.magnetColor}, ${drawing.magnetColor}dd)`,
                      border: "2px solid rgba(255,255,255,0.5)",
                    }}
                  />

                  {drawing.imageSrc ? (
                    <div
                      className="relative w-[150px] md:w-[220px] bg-white rounded-lg p-2 md:p-3 shadow-xl"
                      style={{
                        boxShadow: "0 8px 16px rgba(0,0,0,0.15)",
                      }}
                    >
                      <img
                        src={drawing.imageSrc}
                        alt={drawing.title ?? "Фото на холодильнике"}
                        className="aspect-square w-full rounded-md object-cover bg-secondary"
                      />
                      <div className="mt-2 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="truncate text-xs md:text-sm font-medium text-foreground">
                            {drawing.title ?? "Фото"}
                          </div>
                          <div className="text-[10px] md:text-xs text-muted-foreground">
                            {drawing.uploadedAt}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={(event) => {
                            event.stopPropagation();
                            setDrawingToRemove(drawing);
                          }}
                          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                          aria-label="Убрать фото"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ) : drawing.type === "upload" ? (
                    <motion.button
                      type="button"
                      onClick={() => openUpload(drawing.id)}
                      whileHover={{ scale: 1.05 }}
                      className="w-[140px] h-[140px] md:w-[200px] md:h-[200px] bg-white rounded-lg border-3 md:border-4 border-dashed border-primary/30 flex flex-col items-center justify-center gap-2 md:gap-3 cursor-pointer hover:border-primary/60 transition-all shadow-xl"
                      style={{
                        boxShadow: "0 8px 16px rgba(0,0,0,0.15)",
                      }}
                    >
                      <Upload className="w-8 h-8 md:w-12 md:h-12 text-primary/60" />
                      <div className="text-center px-2 md:px-4">
                        <div className="text-xs md:text-sm font-medium text-foreground/80 mb-1">
                          Добавить фото
                        </div>
                        <div className="text-[10px] md:text-xs text-muted-foreground">
                          JPG, PNG или WEBP
                        </div>
                      </div>
                    </motion.button>
                  ) : (
                    <div
                      className="shadow-xl"
                      style={{
                        filter: "drop-shadow(0 10px 20px rgba(0,0,0,0.2))",
                      }}
                    >
                      <ChildDrawing type={drawing.type} width={140} height={140} className="md:w-[200px] md:h-[200px]" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Decorative Elements */}
          <div className="hidden md:block absolute top-8 left-8 w-16 h-4 bg-gradient-to-r from-[#A0A0A0] to-transparent rounded-full opacity-30" />
          <div className="hidden md:block absolute top-8 right-24 w-16 h-4 bg-gradient-to-l from-[#A0A0A0] to-transparent rounded-full opacity-30" />
        </div>

        {/* Add Button */}
        <motion.button
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => openUpload(null)}
          className="fixed bottom-24 md:bottom-32 right-4 md:right-12 w-14 h-14 md:w-16 md:h-16 bg-gradient-to-br from-primary to-accent rounded-full shadow-2xl flex items-center justify-center text-white hover:shadow-primary/50 transition-all z-50"
          aria-label="Загрузить фото"
        >
          <ImagePlus className="w-7 h-7 md:w-8 md:h-8" />
        </motion.button>

        {/* Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mt-6 md:mt-8 bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-2xl md:rounded-3xl p-4 md:p-6 text-center"
        >
          <div className="text-3xl md:text-4xl mb-2 md:mb-3">💜</div>
          <h3 className="text-base md:text-xl font-medium text-foreground mb-2">
            Сохраните творчество вашего малыша
          </h3>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
            Загружайте фото, рисунки и маленькие моменты. В MVP они сохраняются локально в этом браузере.
          </p>
          <Button
            type="button"
            onClick={() => openUpload(null)}
            className="rounded-xl bg-primary hover:bg-primary/90"
          >
            <ImagePlus className="w-4 h-4 mr-2" />
            Загрузить картинки
          </Button>
        </motion.div>
        <ConfirmActionDialog
          open={Boolean(drawingToRemove)}
          onOpenChange={(open) => {
            if (!open) setDrawingToRemove(null);
          }}
          title="Убрать фото?"
          description="Фото исчезнет с холодильника в этом браузере. Действие нельзя отменить."
          confirmLabel="Убрать"
          destructive
          onConfirm={() => {
            if (drawingToRemove) {
              removeDrawingImage(drawingToRemove.id);
            }
          }}
        />
      </div>
    </div>
  );
}

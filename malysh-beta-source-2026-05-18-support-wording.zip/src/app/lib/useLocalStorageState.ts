import { Dispatch, SetStateAction, useEffect, useRef, useState } from "react";
import { queueAccountStorageSync, setLocalStorageJsonItem } from "./accountApi";

const LOCAL_STORAGE_STATE_EVENT = "mvp:local-storage-state";

interface LocalStorageStateEventDetail<T> {
  key: string;
  sourceId: string;
  value: T;
}

export function useLocalStorageState<T>(
  key: string,
  initialValue: T
): readonly [T, Dispatch<SetStateAction<T>>] {
  const sourceId = useRef(Math.random().toString(36).slice(2));
  const isFirstWrite = useRef(true);
  const [state, setState] = useState<T>(() => {
    try {
      const storedValue = window.localStorage.getItem(key);
      return storedValue ? (JSON.parse(storedValue) as T) : initialValue;
    } catch {
      return initialValue;
    }
  });

  useEffect(() => {
    if (isFirstWrite.current) {
      isFirstWrite.current = false;
      return;
    }

    try {
      setLocalStorageJsonItem(key, state);
      window.dispatchEvent(
        new CustomEvent<LocalStorageStateEventDetail<T>>(LOCAL_STORAGE_STATE_EVENT, {
          detail: {
            key,
            sourceId: sourceId.current,
            value: state,
          },
        })
      );
      queueAccountStorageSync(key, state);
    } catch {
      // Local persistence should never break the core UI.
    }
  }, [key, state]);

  useEffect(() => {
    const handleLocalSync = (event: Event) => {
      const detail = (event as CustomEvent<LocalStorageStateEventDetail<T>>).detail;

      if (!detail || detail.key !== key || detail.sourceId === sourceId.current) return;

      setState(detail.value);
    };

    const handleBrowserStorageSync = (event: StorageEvent) => {
      if (event.key !== key) return;

      try {
        setState(event.newValue ? (JSON.parse(event.newValue) as T) : initialValue);
      } catch {
        setState(initialValue);
      }
    };

    window.addEventListener(LOCAL_STORAGE_STATE_EVENT, handleLocalSync);
    window.addEventListener("storage", handleBrowserStorageSync);

    return () => {
      window.removeEventListener(LOCAL_STORAGE_STATE_EVENT, handleLocalSync);
      window.removeEventListener("storage", handleBrowserStorageSync);
    };
  }, [initialValue, key]);

  return [state, setState] as const;
}

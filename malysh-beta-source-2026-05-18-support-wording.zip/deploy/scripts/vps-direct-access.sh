#!/usr/bin/env bash
set -euo pipefail

# Prepares the beta VPS for direct public access through nginx + HTTPS.
# It does not touch the production SQLite database.
#
# Default:
#   bash deploy/scripts/vps-direct-access.sh
#
# Optional:
#   DOMAIN=beta.malyshplus.ru CERTBOT_EMAIL=you@example.com bash deploy/scripts/vps-direct-access.sh

PROJECT_DIR="${PROJECT_DIR:-/opt/malysh}"
APP_USER="${APP_USER:-malysh}"
SERVICE_NAME="${SERVICE_NAME:-malysh}"
DOMAIN="${DOMAIN:-beta.malyshplus.ru}"
EXTRA_SERVER_NAMES="${EXTRA_SERVER_NAMES:-}"
PUBLIC_URL="${PUBLIC_URL:-https://${DOMAIN}}"
APP_PORT="${APP_PORT:-8787}"
HEALTH_URL="${HEALTH_URL:-http://127.0.0.1:${APP_PORT}/api/health}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/malysh}"
NGINX_SITE_NAME="${NGINX_SITE_NAME:-malysh}"
NGINX_SITE_AVAILABLE="/etc/nginx/sites-available/${NGINX_SITE_NAME}"
NGINX_SITE_ENABLED="/etc/nginx/sites-enabled/${NGINX_SITE_NAME}"
DISABLE_CLOUDFLARED="${DISABLE_CLOUDFLARED:-true}"
CERTBOT_EMAIL="${CERTBOT_EMAIL:-}"
CERTBOT_STAGING="${CERTBOT_STAGING:-false}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"

log() {
  printf '\n==> %s\n' "$1"
}

fail() {
  printf '\nERROR: %s\n' "$1" >&2
  exit 1
}

backup_file() {
  local file_path="$1"
  local backup_dir="$BACKUP_ROOT/direct-access"

  if [ ! -f "$file_path" ]; then
    return 0
  fi

  mkdir -p "$backup_dir"
  cp "$file_path" "$backup_dir/$(basename "$file_path").${STAMP}.bak"
}

set_env_value() {
  local key="$1"
  local value="$2"
  local env_file="$PROJECT_DIR/.env"

  if grep -q "^${key}=" "$env_file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$env_file"
  else
    printf '\n%s=%s\n' "$key" "$value" >> "$env_file"
  fi
}

wait_for_health() {
  local attempts="${1:-30}"
  local delay_seconds="${2:-2}"
  local attempt=1

  while [ "$attempt" -le "$attempts" ]; do
    if curl -fsS "$HEALTH_URL" >/dev/null; then
      return 0
    fi

    printf 'Health check is not ready yet (%s/%s). Waiting %ss...\n' "$attempt" "$attempts" "$delay_seconds" >&2
    sleep "$delay_seconds"
    attempt=$((attempt + 1))
  done

  return 1
}

ensure_package_tools() {
  local packages=()

  command -v curl >/dev/null 2>&1 || packages+=("curl")
  command -v nginx >/dev/null 2>&1 || packages+=("nginx")
  command -v certbot >/dev/null 2>&1 || packages+=("certbot" "python3-certbot-nginx")

  if [ "${#packages[@]}" -eq 0 ]; then
    return 0
  fi

  command -v apt-get >/dev/null 2>&1 || fail "apt-get is required to install: ${packages[*]}"

  log "Installing required packages: ${packages[*]}"
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y "${packages[@]}"
}

[ "$(id -u)" = "0" ] || fail "Run as root in the VPS console."
[ -d "$PROJECT_DIR" ] || fail "Project directory not found: $PROJECT_DIR"
[ -f "$PROJECT_DIR/.env" ] || fail "Production .env not found: $PROJECT_DIR/.env"
command -v systemctl >/dev/null 2>&1 || fail "systemctl is required."

SERVER_NAMES="$DOMAIN"
if [ -n "$EXTRA_SERVER_NAMES" ]; then
  SERVER_NAMES="$SERVER_NAMES $EXTRA_SERVER_NAMES"
fi

ensure_package_tools

log "Saving current configuration backups"
mkdir -p "$BACKUP_ROOT/direct-access"
backup_file "$PROJECT_DIR/.env"
backup_file "$NGINX_SITE_AVAILABLE"

log "Updating application environment"
set_env_value "NODE_ENV" "production"
set_env_value "MALYSH_HOST" "127.0.0.1"
set_env_value "MALYSH_API_PORT" "$APP_PORT"
set_env_value "MALYSH_PUBLIC_URL" "$PUBLIC_URL"
set_env_value "MALYSH_ALLOWED_ORIGINS" "$PUBLIC_URL"
set_env_value "MALYSH_SERVE_WEB" "true"
set_env_value "MALYSH_HEALTH_DETAILS" "false"

log "Writing nginx reverse proxy config"
cat > "$NGINX_SITE_AVAILABLE" <<EOF
server {
  listen 80;
  listen [::]:80;
  server_name ${SERVER_NAMES};

  client_max_body_size 25m;

  location / {
    proxy_pass http://127.0.0.1:${APP_PORT};
    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
  }
}
EOF

rm -f /etc/nginx/sites-enabled/default
ln -sf "$NGINX_SITE_AVAILABLE" "$NGINX_SITE_ENABLED"
nginx -t
systemctl enable --now nginx >/dev/null
systemctl reload nginx

if command -v ufw >/dev/null 2>&1 && ufw status | grep -qi "Status: active"; then
  log "Opening nginx ports in ufw"
  ufw allow "Nginx Full" >/dev/null || true
fi

if [ "$DISABLE_CLOUDFLARED" = "true" ]; then
  log "Disabling Cloudflare Tunnel service on this VPS"
  systemctl disable --now cloudflared >/dev/null 2>&1 || true
  pkill cloudflared >/dev/null 2>&1 || true
fi

log "Restarting app"
systemctl restart "$SERVICE_NAME"
wait_for_health 30 2 || fail "App health check failed: $HEALTH_URL"

log "Issuing HTTPS certificate"
CERTBOT_ARGS=(--nginx -d "$DOMAIN" --non-interactive --agree-tos --redirect)
if [ -n "$CERTBOT_EMAIL" ]; then
  CERTBOT_ARGS+=(--email "$CERTBOT_EMAIL")
else
  CERTBOT_ARGS+=(--register-unsafely-without-email)
fi
if [ "$CERTBOT_STAGING" = "true" ]; then
  CERTBOT_ARGS+=(--staging)
fi

if ! certbot "${CERTBOT_ARGS[@]}"; then
  cat >&2 <<EOF

Certbot could not issue HTTPS yet.
The app and nginx are still configured for HTTP.

Check these two things, then rerun this script:
1. DNS for ${DOMAIN} points directly to this VPS IP, or Cloudflare proxy is configured correctly.
2. Inbound TCP 80 and 443 are open in the VPS provider firewall.
EOF
  exit 1
fi

log "Final checks"
nginx -t
systemctl reload nginx
systemctl restart "$SERVICE_NAME"
wait_for_health 30 2 || fail "App health check failed after HTTPS setup: $HEALTH_URL"
systemctl status "$SERVICE_NAME" --no-pager -l

cat <<EOF

Direct public access is ready.

Open:
  ${PUBLIC_URL}

If it still opens only through VPN, check DNS/proxy status and the provider firewall for TCP 80/443.
Database and user accounts were not touched.
EOF

export type CookieConsentChoice = "all" | "necessary";

export interface CookieConsentRecord {
  choice: CookieConsentChoice;
  acceptedAt: string;
  version: "2026-06-11";
}

export const COOKIE_CONSENT_STORAGE_KEY = "mvp.cookie.consent.v1";
export const COOKIE_CONSENT_EVENT = "mvp:cookie-consent";

export function readCookieConsent(): CookieConsentRecord | null {
  try {
    const rawValue = window.localStorage.getItem(COOKIE_CONSENT_STORAGE_KEY);
    const parsed = rawValue ? (JSON.parse(rawValue) as Partial<CookieConsentRecord>) : null;

    if (!parsed || (parsed.choice !== "all" && parsed.choice !== "necessary")) {
      return null;
    }

    return {
      choice: parsed.choice,
      acceptedAt: typeof parsed.acceptedAt === "string" ? parsed.acceptedAt : new Date().toISOString(),
      version: "2026-06-11",
    };
  } catch {
    return null;
  }
}

export function saveCookieConsent(choice: CookieConsentChoice): CookieConsentRecord {
  const record: CookieConsentRecord = {
    choice,
    acceptedAt: new Date().toISOString(),
    version: "2026-06-11",
  };

  try {
    window.localStorage.setItem(COOKIE_CONSENT_STORAGE_KEY, JSON.stringify(record));
    window.dispatchEvent(new CustomEvent(COOKIE_CONSENT_EVENT, { detail: record }));
  } catch {
    // Consent UI should not block the app if local storage is unavailable.
  }

  return record;
}

export function canUseOptionalAnalytics() {
  return readCookieConsent()?.choice === "all";
}

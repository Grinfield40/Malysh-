import { motion } from "motion/react";
import { Bookmark, Heart, MessageSquare, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { useLocalStorageState } from "../../lib/useLocalStorageState";
import { recommendationProducts } from "./WebRecommendationsScreen";
import {
  SAVED_ARTICLES_STORAGE_KEY,
  SAVED_FORUM_POSTS_STORAGE_KEY,
  SavedArticleItem,
  SavedForumPostItem,
} from "../../lib/savedItems";

const tabs = ["Статьи", "Обсуждения", "Товары"] as const;

type SavedTab = (typeof tabs)[number];

interface WebSavedScreenProps {
  onNavigate?: (screen: string) => void;
}

function SavedEmptyState({
  icon,
  title,
  description,
  actionLabel,
  onAction,
}: {
  icon: string;
  title: string;
  description: string;
  actionLabel: string;
  onAction?: () => void;
}) {
  return (
    <div className="rounded-3xl border-2 border-dashed border-border bg-secondary/30 px-5 py-14 text-center md:py-20">
      <div className="mb-6 text-5xl md:text-6xl">{icon}</div>
      <h3 className="mb-3 text-xl font-medium text-foreground md:text-2xl">{title}</h3>
      <p className="mx-auto mb-6 max-w-md text-sm text-muted-foreground md:text-base">{description}</p>
      <Button type="button" onClick={onAction} className="rounded-xl">
        {actionLabel}
      </Button>
    </div>
  );
}

export function WebSavedScreen({ onNavigate }: WebSavedScreenProps) {
  const [activeTab, setActiveTab] = useState<SavedTab>("Статьи");
  const [savedArticles] = useLocalStorageState<SavedArticleItem[]>(SAVED_ARTICLES_STORAGE_KEY, []);
  const [savedForumPosts] = useLocalStorageState<SavedForumPostItem[]>(SAVED_FORUM_POSTS_STORAGE_KEY, []);
  const [savedProductIds] = useLocalStorageState<number[]>("mvp.recommendations.saved", []);
  const savedProducts = recommendationProducts.filter((product) => savedProductIds.includes(product.id));
  const counts: Record<SavedTab, number> = {
    Статьи: savedArticles.length,
    Обсуждения: savedForumPosts.length,
    Товары: savedProducts.length,
  };

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-6 md:mb-8"
      >
        <div className="mb-3 flex items-center gap-3">
          <Bookmark className="h-7 w-7 text-primary" />
          <h1 className="text-2xl font-medium text-foreground md:text-4xl">Сохраненное</h1>
        </div>
        <p className="text-sm text-muted-foreground md:text-lg">
          Материалы и товары, к которым хочется вернуться позже.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4 pb-2 md:mx-0 md:mb-8 md:px-0"
      >
        {tabs.map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`rounded-xl border px-4 py-2.5 text-sm font-medium transition-all md:rounded-2xl md:px-6 md:py-3 ${
              activeTab === tab
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:border-primary/30"
            }`}
          >
            {tab}
            {counts[tab] > 0 ? (
              <span className="ml-2 rounded-full bg-background/70 px-2 py-0.5 text-[11px] text-foreground">
                {counts[tab]}
              </span>
            ) : null}
          </button>
        ))}
      </motion.div>

      {activeTab === "Статьи" && (
        savedArticles.length === 0 ? (
          <SavedEmptyState
            icon="📚"
            title="Сохраненных статей пока нет"
            description="Откройте советы и возвращайтесь к полезным материалам через этот раздел."
            actionLabel="Открыть советы"
            onAction={() => onNavigate?.("tips")}
          />
        ) : (
          <div className="space-y-5">
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено статей: {savedArticles.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Быстрый список материалов, к которым можно вернуться из раздела советов.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("tips")} className="rounded-xl">
                  Открыть советы
                </Button>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {savedArticles.map((article, index) => (
                <motion.button
                  key={article.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("tips")}
                  className="rounded-2xl border border-border bg-card p-4 text-left transition-all hover:border-primary/30"
                >
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-secondary text-2xl">
                      {article.emoji}
                    </div>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium text-foreground">{article.title}</div>
                      <div className="text-xs text-muted-foreground">{article.category} · {article.time}</div>
                    </div>
                  </div>
                  <p className="line-clamp-2 text-sm text-muted-foreground">{article.description}</p>
                  <div className="mt-3 border-t border-border pt-3 text-xs text-primary">Открыть источник</div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}

      {activeTab === "Обсуждения" && (
        savedForumPosts.length === 0 ? (
          <SavedEmptyState
            icon="💬"
            title="Сохраненных обсуждений пока нет"
            description="Когда появится важная тема на форуме, ее можно будет быстро найти здесь."
            actionLabel="Открыть форум"
            onAction={() => onNavigate?.("forum")}
          />
        ) : (
          <div className="space-y-5">
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено обсуждений: {savedForumPosts.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Важные темы форума теперь не теряются между разделами.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("forum")} className="rounded-xl">
                  Открыть форум
                </Button>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {savedForumPosts.map((post, index) => (
                <motion.button
                  key={post.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("forum")}
                  className="rounded-2xl border border-border bg-card p-4 text-left transition-all hover:border-primary/30"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10">
                        <MessageSquare className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-medium text-foreground">{post.title}</div>
                        <div className="text-xs text-muted-foreground">{post.category} · {post.author}</div>
                      </div>
                    </div>
                    <Bookmark className="h-5 w-5 flex-shrink-0 fill-primary text-primary" />
                  </div>
                  <p className="line-clamp-2 text-sm text-muted-foreground">{post.preview}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs">
                    <span className="text-muted-foreground">{post.comments} ответов · {post.views} просмотров</span>
                    <span className="text-primary">Открыть</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}

      {activeTab === "Товары" && (
        savedProducts.length === 0 ? (
          <SavedEmptyState
            icon="💜"
            title="Сохраненных товаров пока нет"
            description="В разделе «Мамы одобряют» нажмите сердечко на товаре, чтобы он появился здесь."
            actionLabel="Открыть подборки"
            onAction={() => onNavigate?.("recommendations")}
          />
        ) : (
          <div className="space-y-5">
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-foreground">Сохранено товаров: {savedProducts.length}</div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Это товары, отмеченные сердечком в подборках.
                  </p>
                </div>
                <Button type="button" variant="outline" onClick={() => onNavigate?.("recommendations")} className="rounded-xl">
                  Открыть подборки
                </Button>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {savedProducts.map((product, index) => (
                <motion.button
                  key={product.id}
                  type="button"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.04 }}
                  onClick={() => onNavigate?.("recommendations")}
                  className="rounded-2xl border border-border bg-card p-4 text-left transition-all hover:border-primary/30"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div className="flex min-w-0 items-center gap-3">
                      <div className="flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-xl bg-primary/10">
                        <ShoppingBag className="h-5 w-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-medium text-foreground">{product.name}</div>
                        <div className="text-xs text-muted-foreground">{product.category}</div>
                      </div>
                    </div>
                    <Heart className="h-5 w-5 flex-shrink-0 fill-primary text-primary" />
                  </div>
                  <div className="flex items-center justify-between gap-3 border-t border-border pt-3">
                    <span className="text-sm font-medium text-foreground">{product.price}</span>
                    <span className="text-xs text-primary">Открыть</span>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        )
      )}
    </div>
  );
}

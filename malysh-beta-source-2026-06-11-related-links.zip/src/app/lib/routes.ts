import { getGrowthStageById } from "./growthStages";

export type Screen =
  | "home"
  | "urgent"
  | "shopping"
  | "tips"
  | "article"
  | "forum"
  | "routines"
  | "tracker"
  | "reminders"
  | "saved"
  | "profile"
  | "growth-timeline"
  | "growth-stage"
  | "recommendations"
  | "fridge"
  | "stroller-guide"
  | "subscription"
  | "taboo"
  | "discharge-checklist"
  | "admin"
  | "privacy"
  | "personal-consent"
  | "child-consent"
  | "data-map"
  | "terms"
  | "not-found";

export const screenToPath: Record<Screen, string> = {
  home: "/",
  urgent: "/urgent",
  shopping: "/shopping",
  tips: "/tips",
  article: "/tips/article",
  forum: "/forum",
  routines: "/routines",
  tracker: "/tracker",
  reminders: "/reminders",
  saved: "/saved",
  profile: "/profile",
  "growth-timeline": "/growth",
  "growth-stage": "/growth/stage",
  recommendations: "/recommendations",
  fridge: "/fridge",
  "stroller-guide": "/stroller-guide",
  subscription: "/subscription",
  taboo: "/taboo",
  "discharge-checklist": "/discharge-checklist",
  admin: "/admin",
  privacy: "/privacy",
  "personal-consent": "/personal-data-consent",
  "child-consent": "/child-data-consent",
  "data-map": "/personal-data-map",
  terms: "/terms",
  "not-found": "/404",
};

export const legalScreenTypeByScreen = {
  privacy: "privacy",
  "personal-consent": "personal-consent",
  "child-consent": "child-consent",
  "data-map": "data-map",
  terms: "terms",
} as const;

const pathToScreen = Object.fromEntries(
  Object.entries(screenToPath).map(([screen, path]) => [path, screen])
) as Record<string, Screen>;

export const guestProtectedScreens = new Set<Screen>([
  "tracker",
  "routines",
  "reminders",
  "shopping",
  "fridge",
  "forum",
  "saved",
  "profile",
  "admin",
  "subscription",
  "discharge-checklist",
]);

const authPromptDescriptions: Partial<Record<Screen, string>> = {
  tracker: "Войдите или создайте аккаунт, чтобы сохранять сон, кормления, подгузники и температуру.",
  routines: "Режим дня хранится в аккаунте, чтобы не теряться между телефоном и компьютером.",
  reminders: "Напоминания привязываются к аккаунту и доступны после входа.",
  shopping: "Списки покупок сохраняются в аккаунте. Войдите или создайте аккаунт, чтобы продолжить.",
  fridge: "Фото и заметки холодильника доступны после входа, чтобы данные не потерялись.",
  forum: "Форум доступен после входа: так проще модерировать ответы и жалобы.",
  saved: "Сохраненные материалы привязываются к аккаунту.",
  profile: "Профиль ребенка и цели можно заполнить после входа.",
  admin: "Админ-панель доступна только после входа администратора.",
  subscription: "Подписка привязывается к аккаунту. Сначала войдите или создайте аккаунт.",
  "discharge-checklist": "Чек-лист сохраняется в аккаунте, чтобы вы могли вернуться к нему позже.",
};

export function getAuthPromptDescription(screen: Screen) {
  return authPromptDescriptions[screen] || "Войдите или создайте аккаунт, чтобы сохранить действия и продолжить.";
}

function normalizePath(pathname: string) {
  return pathname.replace(/\/+$/, "") || "/";
}

export function getScreenFromPath(pathname: string): Screen {
  const normalizedPath = normalizePath(pathname);
  if (normalizedPath.startsWith("/growth/stage/")) {
    return "growth-stage";
  }

  return pathToScreen[normalizedPath] ?? "not-found";
}

export function getGrowthStageIdFromPath(pathname: string) {
  const normalizedPath = normalizePath(pathname);
  if (!normalizedPath.startsWith("/growth/stage/")) {
    return getGrowthStageById("1month").id;
  }

  const stageId = decodeURIComponent(normalizedPath.replace("/growth/stage/", ""));
  return getGrowthStageById(stageId).id;
}

import { motion } from "motion/react";

interface ChildDrawingProps {
  type: "sun" | "house" | "family" | "flower" | "cat" | "rainbow";
  width?: number;
  height?: number;
}

export function ChildDrawing({ type, width = 200, height = 200 }: ChildDrawingProps) {
  const drawings = {
    sun: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        {/* Paper background */}
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Sun circle */}
        <circle cx="100" cy="80" r="35" fill="#FFD700" stroke="#FF8C00" strokeWidth="3" />
        {/* Sun rays */}
        <line x1="100" y1="30" x2="100" y2="10" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="135" y1="45" x2="150" y2="30" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="150" y1="80" x2="170" y2="80" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="135" y1="115" x2="150" y2="130" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="65" y1="45" x2="50" y2="30" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="50" y1="80" x2="30" y2="80" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        <line x1="65" y1="115" x2="50" y2="130" stroke="#FF8C00" strokeWidth="4" strokeLinecap="round" />
        {/* Ground */}
        <path d="M0 150 Q50 140, 100 150 T200 150 L200 200 L0 200 Z" fill="#90EE90" />
        {/* Flowers */}
        <circle cx="40" cy="155" r="6" fill="#FF69B4" />
        <circle cx="160" cy="160" r="5" fill="#FF1493" />
        <circle cx="120" cy="153" r="4" fill="#FFB6C1" />
      </svg>
    ),
    house: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Sky */}
        <rect width="200" height="100" fill="#87CEEB" />
        {/* Ground */}
        <rect y="100" width="200" height="100" fill="#90EE90" />
        {/* House body */}
        <rect x="60" y="90" width="80" height="70" fill="#D2691E" stroke="#8B4513" strokeWidth="3" />
        {/* Roof */}
        <path d="M50 90 L100 50 L150 90 Z" fill="#DC143C" stroke="#8B0000" strokeWidth="3" />
        {/* Door */}
        <rect x="85" y="120" width="30" height="40" fill="#8B4513" stroke="#654321" strokeWidth="2" rx="2" />
        {/* Windows */}
        <rect x="70" y="100" width="20" height="20" fill="#87CEEB" stroke="#4682B4" strokeWidth="2" />
        <rect x="110" y="100" width="20" height="20" fill="#87CEEB" stroke="#4682B4" strokeWidth="2" />
        {/* Window crosses */}
        <line x1="80" y1="100" x2="80" y2="120" stroke="#4682B4" strokeWidth="2" />
        <line x1="70" y1="110" x2="90" y2="110" stroke="#4682B4" strokeWidth="2" />
        <line x1="120" y1="100" x2="120" y2="120" stroke="#4682B4" strokeWidth="2" />
        <line x1="110" y1="110" x2="130" y2="110" stroke="#4682B4" strokeWidth="2" />
        {/* Sun */}
        <circle cx="170" cy="30" r="15" fill="#FFD700" />
        {/* Chimney */}
        <rect x="120" y="60" width="15" height="30" fill="#8B4513" stroke="#654321" strokeWidth="2" />
      </svg>
    ),
    family: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Sky background */}
        <rect width="200" height="130" fill="#E0F6FF" />
        {/* Ground */}
        <rect y="130" width="200" height="70" fill="#C8E6C9" />
        {/* Papa */}
        <circle cx="60" cy="70" r="20" fill="#FFE0BD" stroke="#000" strokeWidth="2" />
        <rect x="45" y="90" width="30" height="50" fill="#4169E1" stroke="#000" strokeWidth="2" rx="5" />
        <line x1="45" y1="100" x2="30" y2="120" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        <line x1="75" y1="100" x2="90" y2="120" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        {/* Papa eyes and smile */}
        <circle cx="55" cy="68" r="2" fill="#000" />
        <circle cx="65" cy="68" r="2" fill="#000" />
        <path d="M52 75 Q60 80 68 75" stroke="#000" strokeWidth="2" fill="none" strokeLinecap="round" />

        {/* Mama */}
        <circle cx="100" cy="75" r="18" fill="#FFE0BD" stroke="#000" strokeWidth="2" />
        <rect x="87" y="93" width="26" height="47" fill="#FF69B4" stroke="#000" strokeWidth="2" rx="5" />
        <line x1="87" y1="103" x2="72" y2="123" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        <line x1="113" y1="103" x2="128" y2="123" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        {/* Mama hair */}
        <path d="M82 67 Q100 55 118 67" stroke="#8B4513" strokeWidth="3" fill="none" />
        {/* Mama eyes and smile */}
        <circle cx="95" cy="73" r="2" fill="#000" />
        <circle cx="105" cy="73" r="2" fill="#000" />
        <path d="M92 80 Q100 85 108 80" stroke="#000" strokeWidth="2" fill="none" strokeLinecap="round" />

        {/* Baby */}
        <circle cx="140" cy="90" r="15" fill="#FFE0BD" stroke="#000" strokeWidth="2" />
        <rect x="128" y="105" width="24" height="35" fill="#98D8C8" stroke="#000" strokeWidth="2" rx="5" />
        <line x1="128" y1="115" x2="115" y2="130" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        <line x1="152" y1="115" x2="165" y2="130" stroke="#000" strokeWidth="3" strokeLinecap="round" />
        {/* Baby eyes and smile */}
        <circle cx="136" cy="88" r="2" fill="#000" />
        <circle cx="144" cy="88" r="2" fill="#000" />
        <path d="M134 94 Q140 97 146 94" stroke="#000" strokeWidth="2" fill="none" strokeLinecap="round" />

        {/* Hearts */}
        <path d="M50 30 L55 40 L50 50 L45 40 Z" fill="#FF69B4" />
        <path d="M150 40 L155 50 L150 60 L145 50 Z" fill="#FF1493" />
      </svg>
    ),
    flower: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Sky */}
        <rect width="200" height="140" fill="#B0E0E6" />
        {/* Ground */}
        <rect y="140" width="200" height="60" fill="#8FBC8F" />
        {/* Stem */}
        <rect x="95" y="100" width="10" height="60" fill="#228B22" />
        {/* Leaves */}
        <ellipse cx="85" cy="120" rx="15" ry="8" fill="#32CD32" transform="rotate(-30 85 120)" />
        <ellipse cx="115" cy="130" rx="15" ry="8" fill="#32CD32" transform="rotate(30 115 130)" />
        {/* Flower center */}
        <circle cx="100" cy="80" r="20" fill="#FFD700" stroke="#FFA500" strokeWidth="2" />
        {/* Petals */}
        <circle cx="100" cy="50" r="12" fill="#FF69B4" />
        <circle cx="130" cy="65" r="12" fill="#FF1493" />
        <circle cx="130" cy="95" r="12" fill="#FF69B4" />
        <circle cx="100" cy="110" r="12" fill="#FFB6C1" />
        <circle cx="70" cy="95" r="12" fill="#FF69B4" />
        <circle cx="70" cy="65" r="12" fill="#FF1493" />
        {/* Dots in center */}
        <circle cx="95" cy="75" r="2" fill="#FFA500" />
        <circle cx="105" cy="75" r="2" fill="#FFA500" />
        <circle cx="100" cy="85" r="2" fill="#FFA500" />
        {/* Butterfly */}
        <ellipse cx="150" cy="50" rx="8" ry="12" fill="#FFD700" />
        <ellipse cx="165" cy="50" rx="8" ry="12" fill="#FFD700" />
        <line x1="157.5" y1="45" x2="157.5" y2="35" stroke="#000" strokeWidth="1" />
      </svg>
    ),
    cat: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Background */}
        <rect width="200" height="150" fill="#FFE4E1" />
        {/* Floor */}
        <rect y="150" width="200" height="50" fill="#D2B48C" />
        {/* Cat body */}
        <ellipse cx="100" cy="120" rx="40" ry="35" fill="#FF8C00" stroke="#D2691E" strokeWidth="3" />
        {/* Cat head */}
        <circle cx="100" cy="80" r="30" fill="#FF8C00" stroke="#D2691E" strokeWidth="3" />
        {/* Ears */}
        <path d="M75 65 L70 45 L85 60 Z" fill="#FF8C00" stroke="#D2691E" strokeWidth="2" />
        <path d="M125 65 L130 45 L115 60 Z" fill="#FF8C00" stroke="#D2691E" strokeWidth="2" />
        {/* Inner ears */}
        <path d="M77 60 L73 48 L83 58 Z" fill="#FFB6C1" />
        <path d="M123 60 L127 48 L117 58 Z" fill="#FFB6C1" />
        {/* Eyes */}
        <circle cx="90" cy="78" r="5" fill="#000" />
        <circle cx="110" cy="78" r="5" fill="#000" />
        <circle cx="92" cy="76" r="2" fill="#FFF" />
        <circle cx="112" cy="76" r="2" fill="#FFF" />
        {/* Nose */}
        <path d="M100 88 L95 93 L100 95 L105 93 Z" fill="#FFB6C1" />
        {/* Whiskers */}
        <line x1="70" y1="85" x2="50" y2="83" stroke="#000" strokeWidth="1.5" />
        <line x1="70" y1="90" x2="50" y2="92" stroke="#000" strokeWidth="1.5" />
        <line x1="130" y1="85" x2="150" y2="83" stroke="#000" strokeWidth="1.5" />
        <line x1="130" y1="90" x2="150" y2="92" stroke="#000" strokeWidth="1.5" />
        {/* Smile */}
        <path d="M95 93 Q100 98 105 93" stroke="#000" strokeWidth="2" fill="none" />
        {/* Tail */}
        <path d="M135 115 Q160 100 170 120" stroke="#D2691E" strokeWidth="6" fill="none" strokeLinecap="round" />
        <path d="M135 115 Q160 100 170 120" stroke="#FF8C00" strokeWidth="5" fill="none" strokeLinecap="round" />
        {/* Paws */}
        <ellipse cx="80" cy="155" rx="8" ry="5" fill="#FF8C00" />
        <ellipse cx="120" cy="155" rx="8" ry="5" fill="#FF8C00" />
      </svg>
    ),
    rainbow: (
      <svg width={width} height={height} viewBox="0 0 200 200" fill="none">
        <rect width="200" height="200" fill="#FFFEF0" rx="4" />
        {/* Sky */}
        <rect width="200" height="140" fill="#87CEEB" />
        {/* Ground */}
        <rect y="140" width="200" height="60" fill="#90EE90" />
        {/* Rainbow arcs */}
        <path d="M30 140 Q100 40 170 140" stroke="#FF0000" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M35 140 Q100 50 165 140" stroke="#FF7F00" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M40 140 Q100 60 160 140" stroke="#FFFF00" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M45 140 Q100 70 155 140" stroke="#00FF00" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M50 140 Q100 80 150 140" stroke="#0000FF" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M55 140 Q100 90 145 140" stroke="#4B0082" strokeWidth="8" fill="none" strokeLinecap="round" />
        <path d="M60 140 Q100 100 140 140" stroke="#9400D3" strokeWidth="8" fill="none" strokeLinecap="round" />
        {/* Clouds */}
        <circle cx="20" cy="130" r="12" fill="#FFF" />
        <circle cx="30" cy="125" r="15" fill="#FFF" />
        <circle cx="40" cy="130" r="12" fill="#FFF" />
        <circle cx="160" cy="130" r="12" fill="#FFF" />
        <circle cx="170" cy="125" r="15" fill="#FFF" />
        <circle cx="180" cy="130" r="12" fill="#FFF" />
        {/* Sun */}
        <circle cx="40" cy="40" r="18" fill="#FFD700" />
        <line x1="40" y1="15" x2="40" y2="10" stroke="#FFD700" strokeWidth="3" />
        <line x1="58" y1="22" x2="62" y2="18" stroke="#FFD700" strokeWidth="3" />
        <line x1="65" y1="40" x2="70" y2="40" stroke="#FFD700" strokeWidth="3" />
        <line x1="58" y1="58" x2="62" y2="62" stroke="#FFD700" strokeWidth="3" />
      </svg>
    ),
  };

  return drawings[type];
}

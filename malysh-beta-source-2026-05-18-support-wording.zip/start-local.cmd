@echo off
cd /d "%~dp0"
start "Malysh API" cmd /k "npm.cmd run server"
start "Malysh Web" cmd /k "npm.cmd run dev"
echo Local Malysh+ services are starting.
echo API: http://127.0.0.1:8787
echo Web: http://127.0.0.1:5173

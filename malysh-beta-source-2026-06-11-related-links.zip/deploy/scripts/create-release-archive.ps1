param(
  [string]$OutputPath
)

$ErrorActionPreference = "Stop"

$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Resolve-Path (Join-Path $ScriptPath "..\..")
$DefaultOutput = Join-Path (Split-Path -Parent $ProjectRoot) "malysh-beta-source.zip"

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $OutputPath = $DefaultOutput
}

$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$OutputDir = Split-Path -Parent $OutputPath
if ([string]::IsNullOrWhiteSpace($OutputDir)) {
  $OutputDir = Split-Path -Parent $ProjectRoot
}

$TempRoot = Join-Path $OutputDir (".malysh-release-" + [System.Guid]::NewGuid().ToString("N"))

$ExcludedDirs = @(
  ".git",
  ".npm-cache",
  "node_modules",
  "dist",
  "server\data",
  "server\backups"
)

$ExcludedFileNames = @(
  ".env"
)

$ExcludedExtensions = @(
  ".log"
)

function Test-IsExcludedPath {
  param([string]$RelativePath, [bool]$IsDirectory)

  $normalized = $RelativePath.Replace("/", "\").TrimStart("\")

  foreach ($dir in $ExcludedDirs) {
    if ($normalized -eq $dir -or $normalized.StartsWith("$dir\")) {
      return $true
    }
  }

  if ($normalized.StartsWith(".tmp-persistence-test-")) {
    return $true
  }

  if (-not $IsDirectory) {
    $fileName = Split-Path -Leaf $normalized
    $extension = [System.IO.Path]::GetExtension($normalized)

    if ($ExcludedFileNames -contains $fileName) {
      return $true
    }

    if ($ExcludedExtensions -contains $extension) {
      return $true
    }
  }

  return $false
}

if (Test-Path -LiteralPath $TempRoot) {
  Remove-Item -LiteralPath $TempRoot -Recurse -Force
}

New-Item -ItemType Directory -Path $TempRoot | Out-Null

try {
  Get-ChildItem -LiteralPath $ProjectRoot -Force -Recurse | ForEach-Object {
    $relativePath = $_.FullName.Substring($ProjectRoot.Path.Length).TrimStart("\")

    if ([string]::IsNullOrWhiteSpace($relativePath)) {
      return
    }

    if (Test-IsExcludedPath -RelativePath $relativePath -IsDirectory $_.PSIsContainer) {
      return
    }

    $targetPath = Join-Path $TempRoot $relativePath

    if ($_.PSIsContainer) {
      New-Item -ItemType Directory -Path $targetPath -Force | Out-Null
      return
    }

    $targetDir = Split-Path -Parent $targetPath
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $targetPath -Force
  }

  if (Test-Path -LiteralPath $OutputPath) {
    Remove-Item -LiteralPath $OutputPath -Force
  }

  if (-not [string]::IsNullOrWhiteSpace($OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
  }

  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem

  $zip = [System.IO.Compression.ZipFile]::Open($OutputPath, [System.IO.Compression.ZipArchiveMode]::Create)
  try {
    Get-ChildItem -LiteralPath $TempRoot -Force -File -Recurse | ForEach-Object {
      $entryName = $_.FullName.Substring($TempRoot.Length).TrimStart([char[]]@("\", "/")).Replace("\", "/")
      [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip,
        $_.FullName,
        $entryName,
        [System.IO.Compression.CompressionLevel]::Optimal
      ) | Out-Null
    }
  }
  finally {
    $zip.Dispose()
  }

  $archive = Get-Item -LiteralPath $OutputPath
  Write-Host "Release archive created:"
  Write-Host $archive.FullName
  Write-Host ("Size: {0:N2} MB" -f ($archive.Length / 1MB))
}
finally {
  if (Test-Path -LiteralPath $TempRoot) {
    Remove-Item -LiteralPath $TempRoot -Recurse -Force
  }
}

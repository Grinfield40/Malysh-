import { existsSync, readFileSync, statSync } from "node:fs";
import { extname, join, resolve, sep } from "node:path";

export function createHttpUtils({
  allowedOrigins,
  corsOrigin,
  accessLogs,
  errorStacks,
  serveWeb,
  distDir,
  maxJsonBodyBytes,
}) {
  const BODY_TOO_LARGE = Symbol("body-too-large");

  function sendJson(res, status, data, extraHeaders = {}) {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": res.__corsOrigin || corsOrigin,
      "Vary": "Origin",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
      "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
      ...(res.__requestId ? { "X-Request-Id": res.__requestId } : {}),
      ...extraHeaders,
    });
    res.end(JSON.stringify(data));
  }

  function resolveCorsOrigin(origin) {
    if (!origin || allowedOrigins.includes("*")) return corsOrigin;
    if (allowedOrigins.includes(origin)) return origin;

    return corsOrigin;
  }

  function sendError(res, status, message, extraHeaders = {}) {
    sendJson(res, status, { error: message, requestId: res.__requestId }, extraHeaders);
  }

  function sendRedirect(res, location) {
    res.writeHead(302, {
      Location: location,
      ...(res.__requestId ? { "X-Request-Id": res.__requestId } : {}),
    });
    res.end();
  }

  function getClientIp(req) {
    const forwardedFor = String(req.headers["x-forwarded-for"] || "")
      .split(",")[0]
      .trim();
    const realIp = String(req.headers["x-real-ip"] || "").trim();
    const rawIp = forwardedFor || realIp || req.socket?.remoteAddress || "unknown";

    return rawIp.replace(/^::ffff:/, "").slice(0, 80);
  }

  function getClientUserAgent(req) {
    return String(req.headers["user-agent"] || "unknown").trim().slice(0, 500) || "unknown";
  }

  function logAccess(req, res, startedAt, path) {
    if (!accessLogs || !path.startsWith("/api/")) return;

    console.log(JSON.stringify({
      type: "access",
      requestId: res.__requestId,
      method: req.method,
      path,
      status: res.statusCode,
      durationMs: Date.now() - startedAt,
      ip: res.__clientIp,
    }));
  }

  function logServerError(req, res, error, path) {
    const errorInfo = {
      type: "error",
      requestId: res.__requestId,
      method: req.method,
      path,
      message: error instanceof Error ? error.message : String(error),
      ...(errorStacks && error instanceof Error ? { stack: error.stack } : {}),
    };

    console.error(JSON.stringify(errorInfo));
  }

  function getContentType(filePath) {
    const contentTypes = {
      ".html": "text/html; charset=utf-8",
      ".js": "application/javascript; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".json": "application/json; charset=utf-8",
      ".png": "image/png",
      ".jpg": "image/jpeg",
      ".jpeg": "image/jpeg",
      ".svg": "image/svg+xml",
      ".ico": "image/x-icon",
      ".webp": "image/webp",
      ".woff": "font/woff",
      ".woff2": "font/woff2",
    };

    return contentTypes[extname(filePath).toLowerCase()] || "application/octet-stream";
  }

  function sendFile(res, filePath) {
    const body = readFileSync(filePath);
    const isAsset = filePath.includes(`${sep}assets${sep}`);

    res.writeHead(200, {
      "Content-Type": getContentType(filePath),
      "Cache-Control": isAsset ? "public, max-age=31536000, immutable" : "no-cache",
      ...(res.__requestId ? { "X-Request-Id": res.__requestId } : {}),
    });
    res.end(body);
  }

  function sendStaticAsset(res, pathname) {
    if (!serveWeb) return sendError(res, 404, "Сайт не отдается этим сервером.");

    const distRoot = resolve(distDir);

    if (!existsSync(join(distRoot, "index.html"))) {
      return sendError(res, 404, "Сначала соберите сайт командой npm.cmd run build.");
    }

    let safePath;

    try {
      safePath = decodeURIComponent(pathname);
    } catch {
      return sendError(res, 400, "Некорректный путь.");
    }

    const relativePath = safePath === "/" ? "index.html" : safePath.replace(/^\/+/, "");
    const requestedPath = resolve(join(distRoot, relativePath));
    const isInsideDist = requestedPath === distRoot || requestedPath.startsWith(`${distRoot}${sep}`);

    if (!isInsideDist) return sendError(res, 403, "Недоступный путь.");

    if (existsSync(requestedPath)) {
      const info = statSync(requestedPath);

      if (info.isFile()) {
        return sendFile(res, requestedPath);
      }
    }

    return sendFile(res, join(distRoot, "index.html"));
  }

  async function readJsonBody(req) {
    const chunks = [];
    let totalBytes = 0;
    let tooLarge = false;

    for await (const chunk of req) {
      totalBytes += chunk.length;

      if (totalBytes > maxJsonBodyBytes) {
        tooLarge = true;
        continue;
      }

      chunks.push(chunk);
    }

    if (tooLarge) return BODY_TOO_LARGE;

    const rawBody = Buffer.concat(chunks).toString("utf8");

    if (!rawBody) return {};

    try {
      return JSON.parse(rawBody);
    } catch {
      return null;
    }
  }

  function rejectBadJsonBody(res, body) {
    if (body === BODY_TOO_LARGE) {
      sendError(res, 413, "Запрос слишком большой. Уменьшите текст или размер изображений.");
      return true;
    }

    if (body === null) {
      sendError(res, 400, "Некорректный JSON.");
      return true;
    }

    return false;
  }

  return {
    sendJson,
    resolveCorsOrigin,
    sendError,
    sendRedirect,
    getClientIp,
    getClientUserAgent,
    logAccess,
    logServerError,
    sendStaticAsset,
    readJsonBody,
    rejectBadJsonBody,
  };
}

import { motion } from "motion/react";
import { Thermometer, Moon, Baby, Milk, AlertCircle, Info, Phone } from "lucide-react";
import { Button } from "../ui/button";
import { UrgentTopicModal } from "./UrgentTopicModal";
import { useState } from "react";

const urgentTopics = [
  {
    id: "temperature",
    icon: "🌡️",
    label: "Температура",
    description: "Что делать при повышенной температуре",
    color: "from-red-200/40 to-orange-200/40",
    link: "/temperature",
  },
  {
    id: "sleep",
    icon: "😴",
    label: "Проблемы со сном",
    description: "Малыш не спит или плачет",
    color: "from-purple-200/40 to-blue-200/40",
    link: "/sleep-issues",
  },
  {
    id: "crying",
    icon: "😢",
    label: "Непрерывный плач",
    description: "Как успокоить ребенка",
    color: "from-pink-200/40 to-purple-200/40",
    link: "/crying",
  },
  {
    id: "feeding",
    icon: "🍼",
    label: "Отказ от еды",
    description: "Ребенок не хочет есть",
    color: "from-blue-200/40 to-cyan-200/40",
    link: "/feeding-issues",
  },
  {
    id: "breathing",
    icon: "💨",
    label: "Дыхание",
    description: "Затрудненное дыхание",
    color: "from-cyan-200/40 to-green-200/40",
    link: "/breathing",
  },
  {
    id: "vomiting",
    icon: "🤢",
    label: "Рвота и срыгивания",
    description: "Когда это норма, а когда нет",
    color: "from-green-200/40 to-yellow-200/40",
    link: "/vomiting",
  },
];

const emergencyContacts = [
  { label: "Скорая помощь", number: "103", emoji: "🚑" },
  { label: "Неотложная помощь", number: "03", emoji: "🏥" },
  { label: "Ваш педиатр", number: "+7 (XXX) XXX-XX-XX", emoji: "👨‍⚕️" },
];

export function WebUrgentScreen() {
  const [selectedTopic, setSelectedTopic] = useState<typeof urgentTopics[0] | null>(null);

  return (
    <div className="p-4 md:p-8 pt-20 md:pt-28 max-w-[1400px] mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8 md:mb-12"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
          className="inline-block mb-4 md:mb-6"
        >
          <div className="w-20 h-20 md:w-24 md:h-24 bg-gradient-to-br from-destructive/20 to-orange-200/40 rounded-full flex items-center justify-center text-4xl md:text-5xl backdrop-blur-sm shadow-xl">
            🆘
          </div>
        </motion.div>
        <h1 className="text-2xl md:text-4xl font-medium text-foreground mb-3 md:mb-4">Срочные ответы</h1>
        <p className="text-sm md:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
          Быстрая помощь в тревожных ситуациях. Если требуется экстренная медицинская помощь — звоните 103
        </p>
      </motion.div>

      {/* Emergency Contacts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gradient-to-br from-destructive/10 to-destructive/5 border-2 border-destructive/30 rounded-2xl md:rounded-3xl p-4 md:p-8 mb-8 md:mb-12"
      >
        <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
          <Phone className="w-5 h-5 md:w-6 md:h-6 text-destructive" />
          <h2 className="text-base md:text-xl font-medium text-foreground">Экстренные контакты</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
          {emergencyContacts.map((contact, idx) => (
            <motion.button
              key={idx}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white/80 rounded-xl md:rounded-2xl p-4 md:p-6 text-left hover:bg-white transition-all shadow-lg"
            >
              <div className="text-3xl md:text-4xl mb-2 md:mb-3">{contact.emoji}</div>
              <div className="text-xs md:text-sm text-muted-foreground mb-1">{contact.label}</div>
              <div className="text-xl md:text-2xl font-medium text-foreground">{contact.number}</div>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Topics Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="text-lg md:text-2xl font-medium text-foreground mb-4 md:mb-6">Частые вопросы</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {urgentTopics.map((topic, idx) => (
            <motion.div
              key={topic.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + idx * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              onClick={() => setSelectedTopic(topic)}
              className={`bg-gradient-to-br ${topic.color} backdrop-blur-sm border-2 border-white/50 rounded-2xl md:rounded-3xl p-4 md:p-6 cursor-pointer hover:shadow-xl transition-all`}
            >
              <div className="w-14 h-14 md:w-16 md:h-16 bg-white/80 rounded-xl md:rounded-2xl flex items-center justify-center text-3xl md:text-4xl mb-3 md:mb-4 shadow-lg">
                {topic.icon}
              </div>
              <h3 className="text-base md:text-lg font-medium text-foreground mb-2">{topic.label}</h3>
              <p className="text-xs md:text-sm text-muted-foreground leading-relaxed">{topic.description}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Important Notice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="mt-8 md:mt-12 bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/20 rounded-2xl md:rounded-3xl p-4 md:p-8"
      >
        <div className="flex flex-col md:flex-row items-start gap-4 md:gap-6">
          <div className="w-14 h-14 md:w-16 md:h-16 bg-white/80 rounded-xl md:rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
            <Info className="w-7 h-7 md:w-8 md:h-8 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg md:text-xl font-medium text-foreground mb-3">Важно помнить</h3>
            <ul className="space-y-2 text-sm md:text-base text-muted-foreground leading-relaxed">
              <li className="flex gap-2">
                <span className="text-primary">•</span>
                <span>Доверяйте своей интуиции. Если вам кажется, что что-то не так — обратитесь к врачу</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary">•</span>
                <span>Эта информация не заменяет консультацию специалиста</span>
              </li>
              <li className="flex gap-2">
                <span className="text-primary">•</span>
                <span>При любых сомнениях лучше перестраховаться и позвонить врачу</span>
              </li>
            </ul>
            <Button className="mt-4 md:mt-6 rounded-xl md:rounded-2xl bg-primary hover:bg-primary/90 w-full md:w-auto">
              Связаться с педиатром
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Modal */}
      <UrgentTopicModal topic={selectedTopic} onClose={() => setSelectedTopic(null)} />
    </div>
  );
}

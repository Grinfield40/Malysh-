import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Database,
  FileText,
  ShieldCheck,
  UserCheck,
  type LucideIcon,
} from "lucide-react";
import { LEGAL_DOCUMENTS, type LegalDocumentKey } from "../../lib/legal";
import { Button } from "../ui/button";
import { BetaFeedbackCard } from "./BetaFeedbackCard";

export type LegalScreenType = "privacy" | "personal-consent" | "child-consent" | "data-map" | "terms";

interface WebLegalScreenProps {
  type: LegalScreenType;
  onNavigate: (screen: string) => void;
}

interface LegalSection {
  icon: LucideIcon;
  title: string;
  text: string;
}

interface LegalContent {
  documentKey: LegalDocumentKey;
  icon: LucideIcon;
  lead: string;
  notice: string;
  sections: LegalSection[];
  feedbackScreen?: string;
}

const legalContent: Record<LegalScreenType, LegalContent> = {
  privacy: {
    documentKey: "privacy",
    icon: ShieldCheck,
    lead:
      "Коротко и честно: какие данные нужны приложению, где они хранятся, кому доступны и как попросить удалить информацию.",
    notice:
      "Не вводите диагнозы, результаты анализов, документы, адреса, платежные данные и другую чувствительную информацию.",
    feedbackScreen: "privacy",
    sections: [
      {
        icon: Database,
        title: "Что собираем",
        text:
          "Email, имя родителя, профиль ребенка, бытовые записи ухода, покупки, сохраненные материалы, форум, обращения в поддержку и технические события безопасности.",
      },
      {
        icon: ShieldCheck,
        title: "Зачем это нужно",
        text:
          "Чтобы вход работал на телефоне и ПК, данные не терялись, администратор мог помочь с доступом, а beta-версия оставалась безопасной.",
      },
      {
        icon: UserCheck,
        title: "Кто видит",
        text:
          "Пользователь видит свои данные. Администратор проекта может видеть данные, обращения и технические события для поддержки, модерации и восстановления доступа.",
      },
      {
        icon: CheckCircle2,
        title: "Удаление",
        text:
          "Пока отдельный экран удаления не готов, удаление и выгрузка выполняются через обращение администратору. Запрос можно отправить из раздела поддержки.",
      },
    ],
  },
  "personal-consent": {
    documentKey: "personalDataConsent",
    icon: UserCheck,
    lead:
      "Это согласие нужно, чтобы создать аккаунт, синхронизировать данные между устройствами и обрабатывать обращения пользователя.",
    notice:
      "Согласие фиксируется при регистрации: версия документа, дата, email, IP и user-agent сохраняются на сервере.",
    sections: [
      {
        icon: FileText,
        title: "На что дается согласие",
        text:
          "На обработку имени, email, пароля в защищенном виде, настроек аккаунта, обращений, записей приложения и технических данных входа.",
      },
      {
        icon: Database,
        title: "Как обрабатываем",
        text:
          "Данные записываются в базу проекта, используются для работы сервиса, поддержки, модерации, безопасности и резервного восстановления.",
      },
      {
        icon: ShieldCheck,
        title: "Срок действия",
        text:
          "Согласие действует до отзыва или удаления аккаунта. В beta-версии отзыв выполняется через обращение администратору.",
      },
      {
        icon: AlertTriangle,
        title: "Ограничение",
        text:
          "Малыш+ не просит вводить документы, адреса, платежные данные, диагнозы и результаты анализов.",
      },
    ],
  },
  "child-consent": {
    documentKey: "childDataConsent",
    icon: ShieldCheck,
    lead:
      "Это согласие подтверждает, что пользователь является родителем или законным представителем ребенка и может вести бытовые записи ухода.",
    notice:
      "Мы оставляем только бытовые данные ухода: имя или псевдоним, дата рождения, рост, вес, режим, дневник, заметки без диагнозов.",
    sections: [
      {
        icon: UserCheck,
        title: "Кто подтверждает",
        text:
          "Согласие дает родитель или законный представитель. Если пользователь не имеет такого права, аккаунт создавать нельзя.",
      },
      {
        icon: Database,
        title: "Какие данные ребенка",
        text:
          "Имя или домашний псевдоним, возраст, дата рождения, бытовой режим, кормление, сон, подгузники, температура и необязательные заметки ухода.",
      },
      {
        icon: AlertTriangle,
        title: "Что не вводить",
        text:
          "Не вводите диагнозы, анализы, выписки, номера документов, адреса, точные геоданные и сведения, которые должен хранить только врач.",
      },
      {
        icon: CheckCircle2,
        title: "Как удалить",
        text:
          "Профиль ребенка и связанные записи можно удалить через обращение администратору. Пользовательские инструменты удаления добавим позже.",
      },
    ],
  },
  "data-map": {
    documentKey: "dataMap",
    icon: Database,
    lead:
      "Рабочий список для учета персональных данных: что собираем, зачем, где хранится, кто имеет доступ и как удалить.",
    notice:
      "Это не заменяет консультацию юриста, но помогает аккуратно подготовить документы и уведомления для beta-запуска.",
    sections: [
      {
        icon: Database,
        title: "Категории данных",
        text:
          "Аккаунт, профиль ребенка, бытовые записи ухода, покупки, сохраненное, форум, обращения, аналитика использования, IP, user-agent и журналы безопасности.",
      },
      {
        icon: FileText,
        title: "Цели",
        text:
          "Создание аккаунта, синхронизация, сохранение прогресса, поддержка, модерация, безопасность, исправление ошибок и развитие продукта.",
      },
      {
        icon: ShieldCheck,
        title: "Хранение",
        text:
          "Данные хранятся на сервере проекта и в резервных копиях. Доступ к серверу и базе должен быть ограничен владельцем проекта.",
      },
      {
        icon: UserCheck,
        title: "Доступ и удаление",
        text:
          "Доступ есть у администратора проекта. Запрос на выгрузку, исправление или удаление данных отправляется через поддержку.",
      },
    ],
  },
  terms: {
    documentKey: "betaTerms",
    icon: FileText,
    lead:
      "Правила раннего тестирования: что уже работает, где есть ограничения и как безопасно пользоваться продуктом.",
    notice:
      "Малыш+ помогает вести день ребенка, но не является медицинской консультацией и не заменяет врача.",
    sections: [
      {
        icon: FileText,
        title: "Ранняя beta",
        text:
          "Интерфейс, тексты, структура данных и отдельные разделы могут меняться до публичного запуска.",
      },
      {
        icon: AlertTriangle,
        title: "Не медицинский сервис",
        text:
          "Подсказки, форум и рекомендации относятся к бытовому уходу. При тревожных симптомах нужно обращаться к врачу или в экстренные службы.",
      },
      {
        icon: ShieldCheck,
        title: "Модерация",
        text:
          "Администратор может скрывать спам, личные контакты, агрессию, опасные советы и сообщения с чувствительными данными.",
      },
      {
        icon: CheckCircle2,
        title: "Что появится позже",
        text:
          "Публичное удаление данных, расширенная выгрузка, платежи и партнерские рекомендации будут добавляться отдельно после beta-проверки.",
      },
    ],
  },
};

const relatedDocuments = [
  LEGAL_DOCUMENTS.privacy,
  LEGAL_DOCUMENTS.personalDataConsent,
  LEGAL_DOCUMENTS.childDataConsent,
  LEGAL_DOCUMENTS.betaTerms,
  LEGAL_DOCUMENTS.dataMap,
];

export function WebLegalScreen({ type, onNavigate }: WebLegalScreenProps) {
  const content = legalContent[type];
  const document = LEGAL_DOCUMENTS[content.documentKey];
  const HeaderIcon = content.icon;

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fbf8ff] via-white to-[#f7f3ff] px-4 py-6 md:px-8 md:py-10">
      <div className="mx-auto max-w-6xl">
        <Button
          type="button"
          variant="ghost"
          className="mb-6 h-11 rounded-2xl px-4 text-[#7c6fb0] hover:bg-[#f1ecff]"
          onClick={() => onNavigate("home")}
        >
          <ArrowLeft size={18} />
          На главную
        </Button>

        <header className="rounded-[2rem] border border-[#ebe4f7] bg-white p-6 shadow-sm md:p-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div>
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-3xl bg-[#f1ecff] text-[#9b83db]">
                <HeaderIcon size={28} />
              </div>
              <p className="mb-2 text-sm font-semibold uppercase tracking-[0.14em] text-[#9b83db]">
                Версия {document.version}
              </p>
              <h1 className="text-4xl font-semibold leading-tight text-[#332c4f] md:text-5xl">
                {document.title}
              </h1>
              <p className="mt-4 max-w-3xl text-lg leading-relaxed text-[#7c6fb0]">{content.lead}</p>
            </div>

            <div className="rounded-[1.5rem] border border-amber-200 bg-amber-50 p-4 text-amber-900 md:max-w-sm">
              <div className="mb-2 flex items-center gap-2 font-semibold">
                <AlertTriangle size={18} />
                Важно
              </div>
              <p className="text-sm leading-relaxed">{content.notice}</p>
            </div>
          </div>
        </header>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {content.sections.map((section) => {
            const Icon = section.icon;
            return (
              <article key={section.title} className="rounded-[1.5rem] border border-[#ebe4f7] bg-white p-5 shadow-sm">
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f6f1ff] text-[#9b83db]">
                  <Icon size={22} />
                </div>
                <h2 className="text-xl font-semibold text-[#332c4f]">{section.title}</h2>
                <p className="mt-2 text-base leading-relaxed text-[#7c6fb0]">{section.text}</p>
              </article>
            );
          })}
        </div>

        {content.feedbackScreen && (
          <div className="mt-6">
            <BetaFeedbackCard screen={content.feedbackScreen} />
          </div>
        )}

        <div className="mt-6 rounded-[1.5rem] border border-[#ebe4f7] bg-white p-5 shadow-sm">
          <h2 className="text-xl font-semibold text-[#332c4f]">Документы beta</h2>
          <p className="mt-1 text-[#7c6fb0]">
            Все документы доступны отдельно, чтобы пользователь видел, на что именно он соглашается.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            {relatedDocuments.map((item) => (
              <Button
                key={item.screen}
                type="button"
                variant={item.screen === type ? "default" : "outline"}
                className="rounded-2xl"
                onClick={() => onNavigate(item.screen)}
              >
                {item.shortTitle}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
